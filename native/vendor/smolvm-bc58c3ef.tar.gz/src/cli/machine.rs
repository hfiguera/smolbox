//! Machine management commands.
//!
//! All VM-related commands are under the `machine` subcommand:
//! - exec: Persistent execution (machine keeps running)
//! - create: Create named VM configuration
//! - start: Start a machine (named or default)
//! - stop: Stop a machine (named or default)
//! - delete: Delete a named VM configuration
//! - status: Show machine status
//! - ls: List all named VMs

use crate::cli::flush_output;
use crate::cli::format_bytes;
use crate::cli::parsers::{
    mounts_to_virtiofs_bindings, parse_cidr, parse_duration, parse_env_list, parse_image,
};
use crate::cli::vm_common::{self, DeleteVmOptions};
use clap::{builder::TypedValueParser, Args, Subcommand};
use sha2::{Digest, Sha256};
use smolvm::agent::{docker_config_mount, AgentClient, AgentManager, RunConfig, VmResources};
use smolvm::data::network::{PortMapping, PortMappingSpec, PortProtocol, MAX_PORT_MAPPINGS};
use smolvm::data::storage::HostMount;
use smolvm::network::{validate_requested_network_backend, NetworkBackend};
use smolvm::{DEFAULT_IDLE_CMD, DEFAULT_SHELL_CMD};
use std::io::Write;
use std::path::{Path, PathBuf};
use std::time::{Duration, SystemTime, UNIX_EPOCH};

/// How many orphaned ephemeral VMs `machine run` reaps per boot. Small so the
/// hot path never stalls on a large backlog; a heavier backlog drains over
/// successive runs (and other commands sweep without a cap).
const EPHEMERAL_RUN_SWEEP_CAP: usize = 8;

/// Resolve `--allow-cidr`, `--allow-host`, and `--outbound-localhost-only` into a CIDR list,
/// net flag, and the original hostname list (for DNS filtering).
///
/// Resolution failure for `--allow-host` is a hard error — a typo or DNS outage
/// should not silently weaken the security policy.
/// Returns true when `s` structurally looks like an OCI image reference
/// rather than an executable name or path.
///
/// Catches the common mistake of writing `smolvm machine run ubuntu:22.04 --
/// bash` instead of `smolvm machine run --image ubuntu:22.04 -- bash`.
/// Only unambiguous structural signals are checked:
///   - `image:tag` form — colons are not valid in executable names
///   - `registry/image` or `namespace/image` form (non-absolute slash path)
///
/// Bare names like `alpine` or `nginx` are intentionally not flagged here
/// because they are indistinguishable from valid bare commands.
fn is_likely_image_ref(s: &str) -> bool {
    if s.contains(':') {
        return true;
    }
    s.contains('/') && !s.starts_with('/') && !s.starts_with("./") && !s.starts_with("../")
}

/// `machine create`'s own long options that appear in a workload command, i.e.
/// after the `--` separator, where they are arguments for the guest process
/// rather than machine options.
///
/// Short flags are deliberately ignored: `-v`, `-e` and `-p` are far too common
/// in ordinary commands to name without drowning the real signal. The long
/// options come from clap itself, so a newly added flag is covered without
/// touching this list.
fn create_flags_in_workload(command: &[String]) -> Vec<String> {
    use clap::Args as _;
    let spec = CreateCmd::augment_args(clap::Command::new("create"));
    let longs: std::collections::HashSet<String> = spec
        .get_arguments()
        .filter_map(|arg| arg.get_long().map(|long| format!("--{long}")))
        .collect();
    let mut found: Vec<String> = Vec::new();
    for word in command {
        if longs.contains(word.as_str()) && !found.contains(word) {
            found.push(word.clone());
        }
    }
    found
}

/// The refusal for credentials on an ephemeral `.smolmachine` run. That run
/// goes through the packed launcher, which has no credential interceptor, so
/// it would boot with the variables unset and nothing substituted; a
/// persistent machine boots through the launcher that has one.
fn credentials_need_a_persistent_pack(source: &str) -> smolvm::Error {
    smolvm::Error::config(
        "--credential",
        format!(
            "credentials are not substituted for an ephemeral run of a .smolmachine \
             ('{source}'). Create a persistent machine instead:\n  \
             smolvm machine create --name <name> --credential ... --from|--image {source} \
             && smolvm machine start --name <name>"
        ),
    )
}

/// Fold `--credential` flags into the create parameters, after any Smolfile
/// `[[network.credentials]]` entries. A credential policy needs the network.
fn merge_cli_credentials(
    params: &mut vm_common::CreateVmParams,
    flags: &[String],
) -> smolvm::Result<()> {
    if flags.is_empty() {
        return Ok(());
    }
    let mut policy = params.credential_policy.take().unwrap_or_default();
    for spec in flags {
        policy.credentials.push(
            smolvm::credentials::parse_credential_flag(spec)
                .map_err(|e| smolvm::Error::config("--credential", e))?,
        );
    }
    params.net = true;
    params.credential_policy = Some(policy);
    Ok(())
}

fn resolve_egress_flags(
    mut allow_cidr: Vec<String>,
    allow_host: Vec<String>,
    allow_host_pattern: Vec<String>,
    outbound_localhost_only: bool,
    net: bool,
) -> smolvm::Result<(Vec<String>, bool, Option<Vec<String>>)> {
    // Resolve hostnames to CIDRs — fail hard on resolution errors
    for host in &allow_host {
        let cidrs = crate::cli::parsers::resolve_host_to_cidrs(host)
            .map_err(|e| smolvm::Error::config("--allow-host", e))?;
        tracing::info!(host, ?cidrs, "resolved hostname for egress policy");
        allow_cidr.extend(cidrs);
    }

    if outbound_localhost_only {
        allow_cidr.push("127.0.0.0/8".to_string());
        allow_cidr.push("::1/128".to_string());
    }
    let net = net || !allow_cidr.is_empty() || !allow_host_pattern.is_empty();

    // Bare stored names retain their legacy apex-and-subdomains meaning.
    let mut hosts = allow_host;
    for pattern in allow_host_pattern {
        hosts.push(
            smolvm_protocol::host_pattern::encode_strict(&pattern)
                .map_err(|e| smolvm::Error::config("--allow-host-pattern", e))?,
        );
    }
    let dns_filter_hosts = if hosts.is_empty() { None } else { Some(hosts) };

    Ok((allow_cidr, net, dns_filter_hosts))
}

/// Parse `--secret-env KEY=HOST_VAR` and `--secret-file KEY=PATH` flag values
/// into validated [`SecretRef`]s keyed by the guest-side env var name.
///
/// CLI-supplied refs are `TrustedLocal` (the host user invoked the command), so
/// both source kinds are allowed; `validate_ref` still enforces structure and
/// absolute `from_file` paths. A key that appears more than once — across or
/// within the two flags — is a hard error, since silently keeping the last
/// occurrence would mask a typo.
/// `--auto-ports` and `--auto-ports-exclude` laid over what a Smolfile asked
/// for: either flag turns auto ports on, and the exclusions add up.
fn merge_auto_ports_flags(
    base: Option<smolvm::data::network::AutoPorts>,
    flag: bool,
    exclude: &[u16],
) -> Option<smolvm::data::network::AutoPorts> {
    use smolvm::data::network::AutoPorts;
    if !flag && exclude.is_empty() {
        return base;
    }
    let flags = AutoPorts::excluding(exclude.iter().copied());
    Some(match base {
        Some(base) => base.merged(flags),
        None => flags,
    })
}

/// Parse `--expose-socket`/`--mount-socket` specs into published-socket configs.
///
/// - `--expose-socket GUEST_PATH[:HOST_PATH]`: expose a guest-listening socket to
///   the host. `HOST_PATH` optional (defaults to `<vm-dir>/<basename>`).
/// - `--mount-socket HOST_PATH:GUEST_PATH`: mount a host socket into the guest.
fn parse_published_sockets(
    expose: &[String],
    mount: &[String],
) -> smolvm::Result<Vec<smolvm::config::PublishedSocketConfig>> {
    use smolvm::config::{PublishedSocketConfig, SocketDirection};

    let mut out = Vec::new();
    for spec in expose {
        let (guest_path, host_path) = match spec.split_once(':') {
            Some((g, h)) => (g.to_string(), Some(h.to_string())),
            None => (spec.clone(), None),
        };
        if guest_path.is_empty() {
            return Err(smolvm::Error::config(
                "expose-socket",
                format!("empty guest path in '{spec}'"),
            ));
        }
        out.push(PublishedSocketConfig {
            direction: SocketDirection::Expose,
            guest_path,
            host_path: host_path.filter(|h| !h.is_empty()),
        });
    }
    for spec in mount {
        let (host_path, guest_path) = spec.split_once(':').ok_or_else(|| {
            smolvm::Error::config(
                "mount-socket",
                format!("expected HOST_PATH:GUEST_PATH, got '{spec}'"),
            )
        })?;
        if host_path.is_empty() || guest_path.is_empty() {
            return Err(smolvm::Error::config(
                "mount-socket",
                format!("both HOST_PATH and GUEST_PATH are required in '{spec}'"),
            ));
        }
        out.push(PublishedSocketConfig {
            direction: SocketDirection::Mount,
            guest_path: guest_path.to_string(),
            host_path: Some(host_path.to_string()),
        });
    }
    if out.len() > smolvm_protocol::ports::PUBLISH_SOCKET_MAX {
        return Err(smolvm::Error::config(
            "publish-socket",
            format!(
                "too many published sockets ({}); max is {}",
                out.len(),
                smolvm_protocol::ports::PUBLISH_SOCKET_MAX
            ),
        ));
    }
    // The guest env encoding uses ';' and '|' as separators; reject paths that
    // would corrupt it.
    for s in &out {
        if s.guest_path.contains(';') || s.guest_path.contains('|') {
            return Err(smolvm::Error::config(
                "publish-socket",
                format!(
                    "guest path '{}' contains an unsupported character (';' or '|')",
                    s.guest_path
                ),
            ));
        }
        // The guest resolves this path in its own namespace (and bind-mounts a
        // mounted socket there), so a relative path would silently land next to
        // whatever the resolving process happens to be rooted at.
        if !s.guest_path.starts_with('/') {
            return Err(smolvm::Error::config(
                "publish-socket",
                format!("guest path '{}' must be absolute", s.guest_path),
            ));
        }
    }
    // Two mount bridges at the same guest path silently shadow each other in
    // the guest, the later bind mount wins, leaving the first bridge's host
    // socket unreachable. Reject the config instead of paying out a dead
    // bridge. (Expose entries only *dial* their guest path, so duplicates
    // there are harmless.)
    let mut mounted_paths = std::collections::HashSet::new();
    for s in &out {
        if s.direction == smolvm::config::SocketDirection::Mount
            && !mounted_paths.insert(&s.guest_path)
        {
            return Err(smolvm::Error::config(
                "mount-socket",
                format!("guest path '{}' is mounted more than once", s.guest_path),
            ));
        }
    }
    Ok(out)
}

fn parse_cli_secret_refs(
    secret_env: &[String],
    secret_file: &[String],
    secret_keychain: &[String],
) -> smolvm::Result<std::collections::BTreeMap<String, smolvm::secrets::SecretRef>> {
    use smolvm::secrets::{
        env_ref, file_ref, keychain_ref, validate_ref, ResolutionScope, SecretRef,
    };
    use std::collections::BTreeMap;

    let mut out: BTreeMap<String, SecretRef> = BTreeMap::new();

    let mut add =
        |flag: &str, spec: &str, make: &dyn Fn(&str) -> SecretRef| -> smolvm::Result<()> {
            let (key, value) = spec.split_once('=').ok_or_else(|| {
                smolvm::Error::config(flag, format!("expected KEY=VALUE, got '{}'", spec))
            })?;
            if key.is_empty() {
                return Err(smolvm::Error::config(
                    flag,
                    format!("empty secret name in '{}'", spec),
                ));
            }
            let r = make(value);
            validate_ref(&r, ResolutionScope::TrustedLocal)
                .map_err(|e| smolvm::Error::config(flag, format!("secret '{}': {}", key, e)))?;
            if out.insert(key.to_string(), r).is_some() {
                return Err(smolvm::Error::config(
                    flag,
                    format!("secret '{}' specified more than once", key),
                ));
            }
            Ok(())
        };

    for spec in secret_env {
        add("--secret-env", spec, &|v| env_ref(v))?;
    }
    for spec in secret_file {
        add("--secret-file", spec, &|v| file_ref(v))?;
    }
    for spec in secret_keychain {
        add("--secret-keychain", spec, &|v| keychain_ref(v))?;
    }
    Ok(out)
}

/// Spawn a detached `smolvm _cleanup-ephemeral` helper process so the parent
/// CLI can exit immediately after flushing output.
///
/// Returns `true` if the helper was spawned successfully. The caller must then
/// call `std::process::exit(exit_code)` without doing any further cleanup.
///
/// Returns `false` if spawn fails (binary not found, exec error, etc.).
/// The caller falls back to synchronous cleanup in that case.
fn try_spawn_detached_cleanup(vm_name: &str, pid: i32, start_time: Option<u64>) -> bool {
    // Require a verified start time so the helper can use is_our_process_strict
    // before sending SIGKILL. Without it, fall back to synchronous cleanup.
    let start_time_val = match start_time {
        Some(t) => t,
        None => return false,
    };
    let exe = match std::env::current_exe() {
        Ok(p) => p,
        Err(_) => return false,
    };
    let mut cmd = std::process::Command::new(exe);
    cmd.arg("_cleanup-ephemeral")
        .arg(vm_name)
        .arg(pid.to_string())
        .arg(start_time_val.to_string())
        .stdin(std::process::Stdio::null())
        .stdout(std::process::Stdio::null())
        .stderr(std::process::Stdio::null());
    // New process group so the helper is immune to SIGHUP when the parent
    // terminal closes (pgid = child pid). POSIX-only; no Windows equivalent.
    #[cfg(unix)]
    {
        use std::os::unix::process::CommandExt;
        cmd.process_group(0);
    }
    let result = cmd.spawn();
    // Drop the Child handle without waiting — we exit immediately after this.
    // The OS will not create a zombie because the helper outlives us and its
    // real parent (launchd/init) reaps it when it exits.
    result.is_ok()
}

/// Manage machines
#[derive(Subcommand, Debug)]
pub enum MachineCmd {
    /// Run a container image in an ephemeral machine
    Run(RunCmd),

    /// Run a command in a machine (inside its image's container, if it has one)
    Exec(ExecCmd),

    /// Create a new named machine configuration
    Create(CreateCmd),

    /// Start a machine
    Start(StartCmd),

    /// Branch a running branchable machine into an independent child (CoW memory + disks)
    #[command(name = "branch", visible_alias = "fork")]
    Branch(ForkCmd),

    /// Save a running machine, including RAM, as a portable checkpoint
    Checkpoint(super::pack::CheckpointCmd),

    /// Prepare an incremental checkpoint for fast restores without starting a VM
    CheckpointWarm(super::pack::WarmCheckpointCmd),

    /// Remove unused objects from a checkpoint store
    CheckpointPrune(super::pack::PruneCheckpointStoreCmd),

    /// Show the history a checkpoint carries, or every checkpoint in a store
    CheckpointLog(super::pack::CheckpointLogCmd),

    /// Assign parameters and release one held branch-pool slot
    #[command(name = "branch-release", visible_alias = "fork-release")]
    BranchRelease(ForkReleaseCmd),

    /// Stop a running machine
    Stop(StopCmd),

    /// Save RAM and disk durably, then stop at the saved execution boundary
    Pause(PauseCmd),

    /// Resume saved execution in the same machine
    Resume(ResumeCmd),

    /// Delete a machine configuration
    #[command(visible_alias = "rm")]
    Delete(DeleteCmd),

    /// Show machine status
    Status(StatusCmd),

    /// Show a running machine's CPU and memory usage
    Stats(StatsCmd),

    /// Show the workload's output (stdout and stderr), even while stopped
    Logs(LogsCmd),

    /// Show egress denials — outbound connections the machine's egress policy refused
    EgressEvents(EgressEventsCmd),

    /// List all machines
    #[command(visible_alias = "list")]
    Ls(LsCmd),

    /// Grow a running machine's CPUs, RAM, or disks without rebooting
    Resize(ResizeCmd),

    /// Modify settings on a stopped machine (mounts, ports, resources, disks)
    Update(UpdateCmd),

    /// List cached images and storage usage
    Images(ImagesCmd),

    /// Remove unused images and layers to free disk space
    Prune(PruneCmd),

    /// Open an interactive shell in a running machine
    #[command(visible_alias = "sh")]
    Shell(ShellCmd),

    /// Copy files between host and machine
    Cp(CpCmd),

    /// Synchronize guest-local staged mounts back to their host directories
    Sync(SyncCmd),

    /// Mount or unmount host directories on a running machine, without a restart
    #[command(subcommand)]
    Mount(MountCmd),

    /// Monitor a machine with health checks and restart policy
    Monitor(MonitorCmd),

    /// Test network connectivity from inside the VM
    #[command(hide = true)]
    NetworkTest(NetworkTestCmd),

    /// Print the on-disk data directory path for a named machine.
    ///
    /// Useful for scripting and debugging — returns the path where the VM's
    /// storage disk, overlay disk, and agent socket live. The path is
    /// hash-derived, not name-derived.
    #[command(name = "data-dir")]
    DataDir(DataDirCmd),
}

impl MachineCmd {
    pub fn run(self) -> smolvm::Result<()> {
        // Reclaim orphaned ephemeral VMs before doing work. `machine run` uses a
        // BOUNDED sweep: a workflow that only ever calls `machine run` would
        // otherwise never reclaim a data dir left by a run whose detached cleanup
        // helper didn't finish (Ctrl-C / SIGKILL / host sleep mid-run). The cap
        // keeps the boot hot path from stalling on a large backlog — it drains
        // over successive runs. Other commands sweep everything.
        if matches!(self, MachineCmd::Run(_)) {
            super::vm_common::cleanup_orphaned_ephemeral_vms_bounded(EPHEMERAL_RUN_SWEEP_CAP);
        } else {
            super::vm_common::cleanup_orphaned_ephemeral_vms();
        }

        match self {
            MachineCmd::Run(cmd) => cmd.run(),
            MachineCmd::Exec(cmd) => cmd.run(),
            MachineCmd::Create(cmd) => cmd.run(),
            MachineCmd::Start(cmd) => cmd.run(),
            MachineCmd::Branch(cmd) => cmd.run(),
            MachineCmd::Checkpoint(cmd) => cmd.run(),
            MachineCmd::CheckpointPrune(cmd) => cmd.run(),
            MachineCmd::CheckpointLog(cmd) => cmd.run(),
            MachineCmd::CheckpointWarm(cmd) => cmd.run(),
            MachineCmd::BranchRelease(cmd) => cmd.run(),
            MachineCmd::Stop(cmd) => cmd.run(),
            MachineCmd::Pause(cmd) => cmd.run(),
            MachineCmd::Resume(cmd) => cmd.run(),
            MachineCmd::Delete(cmd) => cmd.run(),
            MachineCmd::Status(cmd) => cmd.run(),
            MachineCmd::Stats(cmd) => cmd.run(),
            MachineCmd::Logs(cmd) => cmd.run(),
            MachineCmd::EgressEvents(cmd) => cmd.run(),
            MachineCmd::Ls(cmd) => cmd.run(),
            MachineCmd::Mount(cmd) => cmd.run(),
            MachineCmd::Resize(cmd) => cmd.run(),
            MachineCmd::Update(cmd) => cmd.run(),
            MachineCmd::Images(cmd) => cmd.run(),
            MachineCmd::Prune(cmd) => cmd.run(),
            MachineCmd::Shell(cmd) => cmd.run(),
            MachineCmd::Cp(cmd) => cmd.run(),
            MachineCmd::Sync(cmd) => cmd.run(),
            MachineCmd::Monitor(cmd) => cmd.run(),
            MachineCmd::NetworkTest(cmd) => cmd.run(),
            MachineCmd::DataDir(cmd) => cmd.run(),
        }
    }
}

// ============================================================================
// Run Command (Ephemeral)
// ============================================================================

/// Run a container image in an ephemeral machine.
///
/// By default, runs in ephemeral mode (machine cleaned up after exit).
/// Use -d/--detach to keep the machine running for later interaction.
///
/// Examples:
///   smolvm machine run --image alpine -- echo "hello"
///   smolvm machine run -it -I alpine
///   smolvm machine run -d --net -I ubuntu
///   smolvm machine run --net -v ./src:/app --image node -- npm start
#[derive(Args, Debug)]
pub struct RunCmd {
    /// Container image: a registry reference (alpine, ubuntu:22.04,
    /// ghcr.io/org/image), a `docker save` archive (./myapp.tar, or `-` to read
    /// one from stdin), or an unpacked rootfs directory (./rootfs/). A bare name
    /// is always a registry reference — pipe `docker save` to use a locally
    /// built image. Optional when a Smolfile provides the image, or for bare VM mode.
    #[arg(short = 'I', long, value_name = "IMAGE", value_parser = parse_image)]
    pub image: Option<String>,

    /// Raise the max accepted local image-archive size (e.g. 16GiB, 512M, or a
    /// raw byte count); default 8GiB. For legitimately large images — sets
    /// SMOLVM_MAX_IMAGE_BYTES for this run.
    #[arg(long = "max-image-size", value_name = "SIZE",
          value_parser = crate::cli::parsers::parse_size_bytes, help_heading = "Execution")]
    pub max_image_size: Option<u64>,

    /// Reuse an image digest resolved at most this many seconds ago when
    /// seeding, skipping the per-run registry check inside the window.
    /// Default: resolve and authorize at the registry on every run.
    #[arg(long, value_name = "SECONDS", help_heading = "Execution")]
    pub seed_digest_ttl: Option<u64>,

    /// Run a packed `.smolmachine` artifact ephemerally (the VM is discarded on
    /// exit) — the one-shot equivalent of `machine create --from … + start`.
    /// CPU/memory fall back to the artifact's baked manifest unless overridden.
    #[arg(
        long,
        value_name = "PATH",
        conflicts_with_all = ["image", "smolfile", "detach", "name", "gpu", "gpu_vram_mib", "oci_platform", "allow_cidr", "deny_cidr", "allow_udp", "allow_host", "allow_host_pattern", "outbound_localhost_only", "secret_env", "secret_file", "secret_keychain",
            // The one-shot pack runner has no way to apply these, so they are
            // refused by name rather than dropped; `machine create --from`
            // takes every one of them.
            "block_private", "allow_private", "allow_host_loopback", "nested_virt", "rosetta", "shm_size", "guest_subnet", "network_name", "disk_durability", "disk", "cache_disk", "docker_socket", "auto_ports", "auto_ports_exclude", "expose_socket", "mount_socket", "init"],
        help_heading = "Machine source"
    )]
    pub from: Option<PathBuf>,

    /// Name a persistent machine when used with --detach.
    /// Matches the --name flag on start/stop/exec/status/resize. In foreground
    /// mode (no -d), --name is ignored with a warning.
    #[arg(short = 'n', long, value_name = "NAME", help_heading = "Execution")]
    pub name: Option<String>,

    /// Command and arguments to run (default: image entrypoint or /bin/sh)
    #[arg(trailing_var_arg = true, value_name = "COMMAND")]
    pub command: Vec<String>,

    /// Start the command in the background and detach, leaving the VM
    /// running. Use `machine exec` to run further commands against the VM
    /// and `machine stop` to tear it down.
    #[arg(short = 'd', long, help_heading = "Execution")]
    pub detach: bool,

    /// Keep stdin open for interactive input
    #[arg(short = 'i', long, help_heading = "Execution")]
    pub interactive: bool,

    /// Allocate a pseudo-TTY (use with -i for interactive shells)
    #[arg(short = 't', long, help_heading = "Execution")]
    pub tty: bool,

    /// Kill command after duration (e.g., "30s", "5m", "1h")
    #[arg(long, value_parser = parse_duration, value_name = "DURATION", help_heading = "Execution")]
    pub timeout: Option<Duration>,

    /// Set working directory inside container
    #[arg(short = 'w', long, value_name = "DIR", help_heading = "Container")]
    pub workdir: Option<String>,

    /// Run as this user, like `docker run --user`: a name from the image or a
    /// numeric `uid[:gid]`. Overrides the image's USER.
    #[arg(short = 'u', long, value_name = "USER", help_heading = "Container")]
    pub user: Option<String>,

    /// Set environment variable (can be used multiple times)
    #[arg(
        short = 'e',
        long = "env",
        value_name = "KEY=VALUE",
        help_heading = "Container"
    )]
    pub env: Vec<String>,

    /// Target OCI platform for multi-arch images
    #[arg(
        long = "oci-platform",
        value_name = "OS/ARCH",
        help_heading = "Container"
    )]
    pub oci_platform: Option<String>,

    /// Mount host directory into container (can be used multiple times). Also
    /// accepts S3-compatible object storage, mounted inside the container:
    /// `s3://bucket/prefix:/data[:ro]` (credentials from --env
    /// AWS_ACCESS_KEY_ID/AWS_SECRET_ACCESS_KEY, optional AWS_ENDPOINT_URL
    /// for R2/MinIO; anonymous without them; needs --net; `:ro` is its only
    /// mode). Nothing is required of the image: the agent performs the mount
    /// itself. `:staged` runs from a guest-local copy, seeded at first boot,
    /// for metadata-heavy workloads; `machine sync` and graceful stop mirror it
    /// back onto the host source, deleting host files the copy lacks.
    /// A container path alone (`-v /var/lib/docker`) is a directory on the
    /// machine's own disk instead of its overlay root, which nested container
    /// runtimes need; it persists across stop and start.
    #[arg(
        short = 'v',
        long = "volume",
        value_name = "HOST|REMOTE:CONTAINER[:ro|rw|staged]",
        help_heading = "Container"
    )]
    pub volume: Vec<String>,

    /// Allow trusted read-only host `/etc` and `/var/log` mounts below `/host`.
    /// This exposes sensitive host data to the guest and must not be used for
    /// untrusted workloads.
    #[arg(long, help_heading = "Container")]
    pub allow_system_mounts: bool,

    /// Expose port from container to host (single port or one-to-one range, repeatable; append /udp for UDP)
    #[arg(short = 'p', long = "port", value_parser = PortMappingSpec::parse, value_name = "PORT[-END]|HOST[-END]:GUEST[-END][/udp]", help_heading = "Network")]
    pub port: Vec<PortMappingSpec>,

    /// Enable outbound network access
    #[arg(long, help_heading = "Network")]
    pub net: bool,

    /// Select the networking backend.
    #[arg(long = "net-backend", value_enum, help_heading = "Network")]
    pub net_backend: Option<NetworkBackend>,

    /// Custom DNS resolver for the guest (implies --net). Defaults to the host's
    /// own resolver, so this is only needed when that is not the one to use.
    #[arg(long, value_name = "IP", help_heading = "Network")]
    pub dns: Option<std::net::Ipv4Addr>,

    /// Resolver option for the guest resolv.conf (repeatable, in order), e.g.
    /// `--dns-option timeout:1 --dns-option use-vc`. Written as one `options`
    /// line by every guest writer of resolv.conf (see `resolv.conf(5)`).
    /// glibc honors every accepted option; musl (Alpine) honors only
    /// `ndots`, `timeout` and `attempts` and ignores the rest.
    #[arg(long = "dns-option", value_name = "OPTION", value_parser = parse_dns_option, help_heading = "Network")]
    pub dns_option: Vec<String>,

    /// Size of the workload's /dev/shm: bytes with a k/m/g suffix (`512m`,
    /// `2g`) or a share of guest RAM (`25%`). Defaults to half the RAM.
    #[arg(long = "shm-size", value_name = "SIZE", value_parser = parse_shm_size)]
    pub shm_size: Option<String>,

    /// IPv4 subnet for the guest link, e.g. 10.200.0.0/30 (implies --net,
    /// virtio-net). The gateway and resolver take the first address, the guest
    /// the second. Use it when the guest runs Tailscale or another VPN that
    /// claims the default 100.96.0.0/30.
    #[arg(long, value_name = "CIDR", value_parser = parse_guest_subnet, help_heading = "Network")]
    pub guest_subnet: Option<String>,

    /// Join a named inter-VM network (implies --net, virtio-net only): members
    /// can reach each other by IP (100.96.N.2, leased at start; names do not
    /// resolve)
    #[arg(long = "network", value_name = "NAME", help_heading = "Network")]
    pub network_name: Option<String>,

    /// Allow egress to specific CIDR range (can be used multiple times, implies --net)
    #[arg(long = "allow-cidr", value_parser = parse_cidr, value_name = "CIDR", help_heading = "Network")]
    pub allow_cidr: Vec<String>,

    /// Deny egress to a CIDR range, checked before anything is allowed (can be used multiple times, implies --net)
    #[arg(long = "deny-cidr", value_parser = parse_cidr, value_name = "CIDR", help_heading = "Network")]
    pub deny_cidr: Vec<String>,

    #[arg(long = "allow-udp", value_parser = smolvm::smolfile::parse_allow_udp, value_name = "CIDR[:PORT[-END]]", help_heading = "Network", help = "Allow UDP to a CIDR, optionally on one port or a range, also under an egress interceptor; checked after every deny, DNS keeps its own path (can be used multiple times, implies --net)")]
    pub allow_udp: Vec<smolvm_protocol::EgressRule>,

    /// Allow egress to specific hostname, resolved at VM start (can be used multiple times, implies --net)
    #[arg(long = "allow-host", value_name = "HOSTNAME", help_heading = "Network")]
    pub allow_host: Vec<String>,

    /// Opt-in egress pattern: exact hostname or `*.domain` subdomains only.
    #[arg(
        long = "allow-host-pattern",
        value_name = "PATTERN",
        help_heading = "Network"
    )]
    pub allow_host_pattern: Vec<String>,

    /// Pass this host's proxy into the workload: HTTPS_PROXY/HTTP_PROXY/
    /// ALL_PROXY/NO_PROXY from the environment, or on macOS the system proxy.
    /// A proxy on the host's loopback is rewritten to an address the guest can
    /// reach. Also used for the image pull. Implies --net.
    #[arg(long, help_heading = "Network")]
    pub use_host_proxy: bool,

    /// Trust the certificates this host trusts for image pulls and the workload — e.g. a
    /// corporate TLS-inspection root on the host. Mounts them read-only at
    /// /etc/smolvm-host-trust/ca-bundle.pem and points SSL_CERT_FILE,
    /// NODE_EXTRA_CA_CERTS, REQUESTS_CA_BUNDLE and similar at it.
    /// SMOLVM_HOST_CA_BUNDLE selects another bundle. Not with --credential.
    #[arg(long, help_heading = "Network")]
    pub trust_host_certs: bool,

    /// Bind a credential the workload may use without ever seeing it:
    /// NAME=ENV_VAR@HOST[,HOST...][:body][:set-header=HEADER]. The guest gets a placeholder in ENV_VAR;
    /// the host substitutes the real value (from a `--secret-env`/`--secret-file`
    /// ref of the same name, else the host variable ENV_VAR) only on HTTPS
    /// requests to the listed hosts. Add :body for OAuth form-body tokens or
    /// :set-header=HEADER to set a request header to the complete secret value.
    /// Can be used multiple times; implies --net.
    #[arg(
        long = "credential",
        value_name = "NAME=ENV_VAR@HOST[,HOST...][:body][:set-header=HEADER]",
        help_heading = "Network"
    )]
    pub credential: Vec<String>,

    /// Restrict outbound to localhost only (implies --net)
    #[arg(long, help_heading = "Network")]
    pub outbound_localhost_only: bool,

    /// Block private, internal and link-local destinations (the LAN, cloud
    /// metadata, CGNAT, the host's loopback) while the public internet stays
    /// open. Implies --net.
    #[arg(long, help_heading = "Network")]
    pub block_private: bool,

    /// Re-open one private range under --block-private, such as an internal
    /// registry (implies --block-private). Can be used multiple times.
    #[arg(long = "allow-private", value_name = "CIDR", value_parser = parse_cidr, help_heading = "Network")]
    pub allow_private: Vec<String>,

    /// Let the guest reach services on the HOST's own loopback (127.0.0.1 / ::1);
    /// off by default so a sandbox can't reach host debuggers, Docker, or local
    /// databases. Cloud-metadata stays blocked. Implies --net.
    #[arg(long = "allow-host-loopback", help_heading = "Network")]
    pub allow_host_loopback: bool,

    /// Enable GPU acceleration (Vulkan via virtio-gpu)
    #[arg(long, help_heading = "Resources")]
    pub gpu: bool,

    /// Expose the host's virtualization extensions so the guest can run KVM --
    /// i.e. run smolvm, QEMU or Docker Desktop's hypervisor inside the machine.
    /// Off by default: nesting turns work the guest would do natively into
    /// vmexits, so a nested guest runs far slower.
    /// Needs nested KVM on a Linux host (kvm_intel/kvm_amd nested=1) or an
    /// M3 or newer Mac on macOS 15+.
    #[arg(long = "nested", help_heading = "Resources")]
    pub nested_virt: bool,

    /// GPU shared-memory region size in MiB. Ignored without --gpu.
    /// Default 4096 (4 GiB). Must be > 0.
    #[arg(
        long = "gpu-vram",
        value_name = "MiB",
        help_heading = "Resources",
        value_parser = crate::cli::parsers::parse_gpu_vram_mib,
    )]
    pub gpu_vram_mib: Option<u32>,

    /// Enable Rosetta 2 for x86_64 binary translation on Apple Silicon
    #[arg(long, help_heading = "Resources")]
    pub rosetta: bool,

    /// Maximum vCPUs the machine may use [default: 4]. Idle vCPUs cost nothing;
    /// this caps what the workload can consume, it does not reserve it.
    #[arg(long, value_name = "N", help_heading = "Resources")]
    pub cpus: Option<u8>,

    /// Maximum memory in MiB the machine may use [default: half the host's
    /// RAM, at most 8192]. Memory is elastic: the host commits only what the
    /// guest touches, up to this cap.
    #[arg(long, value_name = "MiB", help_heading = "Resources")]
    pub mem: Option<u32>,

    /// Writable data disk size in GiB (default 20). Bounds how much a workload
    /// can write: a disk-heavy or untrusted command fills this disk (ENOSPC),
    /// never the host. This is the flag to lower when sandboxing untrusted code.
    #[arg(long, value_name = "GiB", help_heading = "Resources")]
    pub storage: Option<u64>,

    /// Container rootfs overlay (copy-on-write upper layer) size in GiB. NOT the
    /// writable-data cap — use --storage to bound how much a workload can write.
    /// Rarely needs setting.
    #[arg(long, value_name = "GiB", help_heading = "Resources")]
    pub overlay: Option<u64>,

    /// Host block I/O engine. Async uses restricted io_uring for raw disks on Linux.
    #[arg(long = "block-io", value_enum, help_heading = "Resources")]
    pub block_io: Option<smolvm::data::resources::BlockIoEngine>,

    /// When guest disk writes must reach the host's disk. `full` (default):
    /// a guest fsync waits for the host disk. `deferred`: guest writes reach
    /// it on the host's schedule, much faster for fsync-heavy work such as
    /// database commits, but a host crash can lose recent writes.
    #[arg(long = "disk-durability", value_enum, help_heading = "Resources")]
    pub disk_durability: Option<smolvm::data::resources::DiskDurability>,

    /// Attach a host disk image or block device (repeatable), appearing in the
    /// guest as /dev/vdc, /dev/vdd, ... in the order given. Append `:ro` for
    /// read-only. The disk is handed over raw — smolvm never formats or mounts
    /// it — so a machine can put, say, a database's WAL on a different device
    /// from its data.
    #[arg(long = "disk", value_name = "PATH[:ro]", help_heading = "Resources")]
    pub disk: Vec<String>,

    /// Mount a shared cache disk at a guest path: `BASE:/guest/path`. BASE is
    /// a disk image (raw or qcow2) that stays read-only and can back many
    /// machines at once; this machine reads it and writes only to its own
    /// fast local layer, which every branch of it copies. The guest mounts its
    /// ext4 filesystem, making one if BASE is blank.
    #[arg(
        long = "cache-disk",
        value_name = "BASE:/PATH",
        help_heading = "Resources"
    )]
    pub cache_disk: Option<String>,

    /// Load VM configuration from a Smolfile (TOML)
    #[arg(
        long = "smolfile",
        visible_short_alias = 's',
        value_name = "PATH",
        help_heading = "Resources"
    )]
    pub smolfile: Option<PathBuf>,

    /// Forward host SSH agent into the VM (enables git/ssh without exposing keys)
    #[arg(long, help_heading = "Security")]
    pub ssh_agent: bool,

    /// Remote guest CUDA Driver-API calls to the host NVIDIA GPU over vsock
    #[arg(long, help_heading = "Hardware")]
    pub cuda: bool,

    /// Ask compatible CUDA frameworks to graph safe compiled regions.
    /// Implies --cuda; arbitrary eager CUDA calls are not captured.
    #[arg(long, help_heading = "Hardware")]
    pub auto_graph: bool,

    /// Expose the guest's Docker daemon socket to the host as a Unix socket
    /// (DOCKER_HOST=unix://…). Requires dockerd running in the VM.
    #[arg(long, help_heading = "Network")]
    pub docker_socket: bool,

    /// Publish every TCP port a process in the machine listens on at the same
    /// port on host loopback while it listens (dev servers, `docker run -p`).
    /// A host port already in use is skipped; ports below 1024 are not
    /// published automatically.
    #[arg(long, help_heading = "Network")]
    pub auto_ports: bool,

    /// Never publish this guest port automatically (repeatable). Implies
    /// --auto-ports.
    #[arg(
        long = "auto-ports-exclude",
        value_name = "PORT",
        help_heading = "Network"
    )]
    pub auto_ports_exclude: Vec<u16>,

    /// Expose a Unix socket the guest listens on to the host (repeatable). The
    /// host reaches it at the given host path, or `<basename>` in
    /// `smolvm machine data-dir` by default. Format: GUEST_PATH[:HOST_PATH].
    #[arg(
        long = "expose-socket",
        value_name = "GUEST_PATH[:HOST_PATH]",
        help_heading = "Network"
    )]
    pub expose_socket: Vec<String>,

    /// Mount a host Unix socket into the guest (repeatable), so a guest process
    /// reaches the host service at GUEST_PATH. Format: HOST_PATH:GUEST_PATH.
    #[arg(
        long = "mount-socket",
        value_name = "HOST_PATH:GUEST_PATH",
        help_heading = "Network"
    )]
    pub mount_socket: Vec<String>,

    /// Mount ~/.docker/ into the VM. Registry credentials from `docker login`
    /// (credential helpers included) are resolved on the host for every pull,
    /// so this is only needed for other contents of the directory.
    #[arg(long, help_heading = "Registry")]
    pub docker_config: bool,

    /// Inject a secret from a host env var (GUEST_VAR=HOST_VAR), resolved at
    /// launch. The value is never persisted to the machine record or a pack.
    #[arg(
        long = "secret-env",
        value_name = "GUEST_VAR=HOST_VAR",
        help_heading = "Security"
    )]
    pub secret_env: Vec<String>,

    /// Inject a secret from a host file (GUEST_VAR=/abs/path), resolved at
    /// launch. The value is never persisted to the machine record or a pack.
    #[arg(
        long = "secret-file",
        value_name = "GUEST_VAR=PATH",
        help_heading = "Security"
    )]
    pub secret_file: Vec<String>,

    /// Inject a secret from the host keychain (GUEST_VAR=SERVICE or
    /// GUEST_VAR=SERVICE/ACCOUNT): a macOS Keychain generic password, or a
    /// Linux Secret Service item, read at launch and never persisted.
    #[arg(
        long = "secret-keychain",
        value_name = "GUEST_VAR=SERVICE[/ACCOUNT]",
        help_heading = "Security"
    )]
    pub secret_keychain: Vec<String>,

    /// Run command before the workload (can be used multiple times); the same
    /// as `init` in a Smolfile, which the CLI form extends when both are given.
    /// Init provisions the machine, so it runs as root regardless of `--user`
    /// or the image's USER.
    #[arg(long = "init", value_name = "COMMAND")]
    pub init: Vec<String>,

    /// Skip the init-layer cache: re-run `init` on every ephemeral run instead of
    /// baking `image + init` once into a cached, reusable artifact. Use this when
    /// `init` depends on live volume contents (and so cannot be safely cached).
    #[arg(long, help_heading = "Resources")]
    pub no_init_cache: bool,

    /// Rebuild the cached init layer even if a matching one already exists.
    #[arg(long, help_heading = "Resources")]
    pub rebuild_init_cache: bool,

    /// Cache the pulled OCI image on the host so repeat ephemeral runs of the same
    /// `--image` skip the registry pull. The image is baked once into a reusable
    /// `.smolmachine` (keyed by image + env) and every later run rehydrates from it
    /// instead of re-pulling inside the guest. The VM stays throwaway; only the
    /// image is cached. Registry images only.
    #[arg(long, help_heading = "Resources")]
    pub oci_cache: bool,

    /// Run the workload as an unprivileged container: restricted capabilities,
    /// read-only cgroup, and no extra tmpfs. By default the workload is "VM-grade"
    /// (the microVM is the isolation boundary, so it gets full privileges and any
    /// image — incl. systemd — boots). Use this for defense-in-depth with untrusted
    /// code. `init` always runs VM-grade (it needs privileges for apt/mounts).
    #[arg(long, help_heading = "Security")]
    pub unprivileged: bool,

    #[command(flatten, next_help_heading = "Network")]
    pub proxy_opts: crate::cli::proxy_opts::ProxyOpts,
}

/// Cache directory for baked init layers: a sibling of the per-VM cache
/// (`<cache>/smolvm/init-layers`), derived from the same canonical root as
/// [`smolvm::agent::vm_cache_root`] so it shares the install's cache location.
fn init_layer_cache_dir() -> PathBuf {
    smolvm::agent::vm_cache_root()
        .parent()
        .map(|smolvm_root| smolvm_root.join("init-layers"))
        .unwrap_or_else(|| std::path::PathBuf::from("/tmp/smolvm-init-layers"))
}

/// Max real bytes the init-layer cache may occupy before eviction; override via
/// `SMOLVM_INIT_CACHE_MAX_BYTES`. Default 10 GiB (~tens of layers).
fn init_cache_max_bytes() -> u64 {
    const DEFAULT: u64 = 10 * 1024 * 1024 * 1024;
    std::env::var("SMOLVM_INIT_CACHE_MAX_BYTES")
        .ok()
        .and_then(|s| s.trim().parse::<u64>().ok())
        .filter(|&n| n > 0)
        .unwrap_or(DEFAULT)
}

/// Bump a cache entry's modification time to now so the LRU prune treats it as
/// recently used. Best-effort and cross-platform (`File::set_modified`); a
/// failure just leaves the old mtime, which at worst evicts a hot entry sooner.
fn touch_cache_entry(path: &Path) {
    if let Ok(f) = std::fs::OpenOptions::new().write(true).open(path) {
        let _ = f.set_modified(std::time::SystemTime::now());
    }
}

/// Evict least-recently-modified cached layers until the cache is at or below
/// `max_bytes`, never evicting `keep` (the layer just published). Best-effort:
/// per-entry errors are skipped. The `.smolmachine` sidecars are zstd-compressed
/// (dense) files, so apparent length is an accurate size.
fn prune_init_cache(dir: &Path, max_bytes: u64, keep: &Path) {
    let mut layers: Vec<(PathBuf, std::time::SystemTime, u64)> = Vec::new();
    let Ok(rd) = std::fs::read_dir(dir) else {
        return;
    };
    for entry in rd.flatten() {
        let path = entry.path();
        if path.extension().and_then(|x| x.to_str()) != Some("smolmachine") {
            continue;
        }
        let Ok(meta) = entry.metadata() else {
            continue;
        };
        let mtime = meta.modified().unwrap_or(std::time::SystemTime::UNIX_EPOCH);
        layers.push((path, mtime, meta.len()));
    }
    let total: u64 = layers.iter().map(|(_, _, s)| *s).sum();
    if total <= max_bytes {
        return;
    }
    layers.sort_by_key(|(_, mtime, _)| *mtime); // oldest first
    let mut over = total - max_bytes;
    for (path, _, size) in layers {
        if over == 0 {
            break;
        }
        if path == keep {
            continue;
        }
        if std::fs::remove_file(&path).is_ok() {
            over = over.saturating_sub(size);
        }
    }
}

/// Best-effort sweep of leftover `init-bake-*` temp machines from crashed bakes.
/// Age is taken from the DB record's `created_at` (always present — unlike the data
/// dir, which a create-then-crash leaves absent) and gated on a generous threshold
/// so an in-flight concurrent bake — which finishes in seconds — is never touched.
/// Override the threshold (seconds) with `SMOLVM_INIT_BAKE_GC_SECS`.
fn gc_stale_bake_machines(exe: &Path) {
    let stale_after = std::env::var("SMOLVM_INIT_BAKE_GC_SECS")
        .ok()
        .and_then(|s| s.trim().parse::<u64>().ok())
        .unwrap_or(30 * 60);
    let Ok(cfg) = smolvm::config::SmolvmConfig::load() else {
        return;
    };
    let now = smolvm::util::current_timestamp();
    let stale: Vec<String> = cfg
        .list_vms()
        .filter(|(name, _)| name.starts_with("init-bake-"))
        .filter(|(_, record)| now.saturating_sub(record.created_at) >= stale_after)
        .map(|(name, _)| name.clone())
        .collect();
    for name in stale {
        let _ = run_smolvm(exe, &["machine", "delete", "--name", &name, "-f"]);
    }
}

/// Content key for an init layer: a hash of the image + init commands + env, so the
/// cache rebuilds exactly when those inputs change.
///
/// When `digest` is supplied (the `--oci-cache` path resolves it at the auth
/// gate) it is mixed in, so the key pins the image's CONTENT rather than its
/// reference string. Without it, `alpine:latest` would hash the same forever and
/// a cached entry would keep serving the image as it was on the first run — the
/// tag moving upstream (including for a security fix) would never be picked up.
///
/// PROTOTYPE LIMITATION: if `init` runs a script that lives on a mounted volume
/// (e.g. `bash /project/init.sh`), the script's CONTENTS are not part of the key —
/// inline the init steps into the Smolfile, or pass `--no-init-cache`.
fn init_layer_key(
    image: Option<&str>,
    init: &[String],
    env: &[String],
    digest: Option<&str>,
) -> String {
    let mut h = Sha256::new();
    h.update(image.unwrap_or("").as_bytes());
    h.update([0u8]);
    if let Some(d) = digest {
        h.update(d.as_bytes());
    }
    h.update([0u8]);
    for c in init {
        h.update(c.as_bytes());
        h.update([0u8]);
    }
    h.update([0u8]);
    for e in env {
        h.update(e.as_bytes());
        h.update([0u8]);
    }
    hex::encode(h.finalize())[..16].to_string()
}

/// Whether a `--image` value is an init-cache-bakeable source. Only registry
/// refs are: the bake snapshots via `pack create --from-vm`, which sources base
/// layers by pulling the image's registry manifest. A local archive or rootfs
/// dir has no registry manifest (it is flattened on boot), so it takes the
/// direct, uncached init path instead of a broken bake (#459).
fn image_bakeable(image: Option<&str>) -> bool {
    matches!(
        image.map(smolvm::data::image_source::classify),
        Some(smolvm::data::image_source::ImageSource::Registry(_))
    )
}

/// Build the bake's `machine start` argv, forwarding the run's `--proxy` /
/// `--no-proxy` so the one-time init pull reaches the registry through the same
/// proxy the outer run uses. Without this, a Smolfile with `init` steps pulls
/// direct in the bake and times out on a proxy-only network.
fn bake_start_args<'a>(
    tmp: &'a str,
    proxy: Option<&'a str>,
    no_proxy: Option<&'a str>,
) -> Vec<&'a str> {
    // Provision the temp machine (pull image + run init) but never launch its
    // workload. The bake only needs the image layers and init's effects on
    // disk for the snapshot; running a workload is pointless and, worse, would
    // require a runnable command inside the image. The placeholder `/bin/true`
    // it was created with does not exist in minimal images (scratch, distroless,
    // `hello-world`), so launching it failed the whole bake. Skipping the
    // launch makes the cache work for any image (#1334).
    let mut start = vec!["machine", "start", "--name", tmp, "--no-workload"];
    if let Some(p) = proxy {
        start.push("--proxy");
        start.push(p);
    }
    if let Some(n) = no_proxy {
        start.push("--no-proxy");
        start.push(n);
    }
    start
}

/// Bake `image + init` into a cached `.smolmachine` (or reuse an existing one) and
/// return its path. Runs the well-tested `machine create/start/stop` + `pack create
/// --from-vm` flow as subprocesses of this same binary: create a temp machine from
/// the Smolfile with the workload replaced by a `/bin/true` no-op so only `init`
/// runs, snapshot it, and delete the temp machine. The real workload command is
/// supplied at run time against the resulting artifact.
fn ensure_init_layer(
    params: &vm_common::CreateVmParams,
    smolfile: Option<&Path>,
    cli_init: &[String],
    rebuild: bool,
    digest: Option<&str>,
    proxy: Option<&str>,
    no_proxy: Option<&str>,
) -> smolvm::Result<PathBuf> {
    // The bake here only ever receives a registry image: `ensure_init_layer` is
    // gated on `image_bakeable()` (local archives/dirs take the direct path),
    // because the `pack create --from-vm` snapshot below cannot source a local
    // image's layers (they're flattened, with no registry manifest to pull).
    let key = init_layer_key(params.image.as_deref(), &params.init, &params.env, digest);
    let dir = init_layer_cache_dir();
    std::fs::create_dir_all(&dir)
        .map_err(|e| smolvm::Error::config("init-layer cache", e.to_string()))?;
    let cached = dir.join(format!("{key}.smolmachine"));
    if cached.exists() && !rebuild {
        if params.init.is_empty() {
            println!("Using cached image {key} (host cache hit; no pull)");
        } else {
            println!("Using cached init layer {key}");
        }
        // Mark the entry recently used (bump mtime) so the LRU sweep keeps hot
        // images and evicts cold ones — without this a frequently-run cached image
        // could be evicted just for having an old bake time. Then bound the cache
        // on the hit path too, not only after a bake. Both best-effort.
        touch_cache_entry(&cached);
        prune_init_cache(&dir, init_cache_max_bytes(), &cached);
        return Ok(cached);
    }

    if params.init.is_empty() {
        println!("Caching image {key} (one-time; reused on later runs)");
    } else {
        println!(
            "Baking init layer (one-time; reused on later runs) [{key}, {} init step(s)]",
            params.init.len()
        );
    }
    let started = std::time::Instant::now();

    let exe = std::env::current_exe()
        .map_err(|e| smolvm::Error::config("init-layer cache", e.to_string()))?;
    // Reap any temp machines orphaned by previously crashed bakes (age-gated so it
    // never touches a concurrent in-flight bake).
    gc_stale_bake_machines(&exe);
    let pid = std::process::id();
    let tmp = format!("init-bake-{key}-{pid}");

    // Bake into a per-process staging dir, then atomically rename the sidecar into
    // its final cache path. This makes an interrupted bake leave nothing usable (no
    // truncated `.smolmachine` a later run would treat as valid), and makes two
    // concurrent bakes of the same key safe — each stages independently and the last
    // rename wins. The staging dir also absorbs `pack`'s stub binary, discarded when
    // the dir is removed (the cache only needs the sidecar).
    let staging = dir.join(format!(".staging-{key}-{pid}"));
    let _ = std::fs::remove_dir_all(&staging);
    std::fs::create_dir_all(&staging)
        .map_err(|e| smolvm::Error::config("init-layer cache", e.to_string()))?;
    let staged_out = staging.join("layer").to_string_lossy().to_string();
    let staged_sidecar = staging.join("layer.smolmachine");

    // Clear any temp machine left by a prior failed bake (best-effort; the common
    // case is "doesn't exist", whose error is captured and discarded by run_smolvm).
    let _ = run_smolvm(&exe, &["machine", "delete", "--name", &tmp, "-f"]);

    let bake = (|| -> smolvm::Result<()> {
        // Create from the Smolfile (init + volumes) but replace the workload with
        // `/bin/true` so `start` runs init only. Forward the RESOLVED image and env
        // (CLI overrides included) so the baked rootfs matches the cache key, which
        // is derived from those same resolved params.
        let mut create: Vec<String> = ["machine", "create", "--name", &tmp]
            .iter()
            .map(|s| s.to_string())
            .collect();
        if let Some(sf) = smolfile {
            create.push("--smolfile".into());
            create.push(sf.to_string_lossy().to_string());
        }
        if let Some(image) = &params.image {
            create.push("--image".into());
            create.push(image.clone());
        }
        for e in &params.env {
            create.push("-e".into());
            create.push(e.clone());
        }
        // `--smolfile` already supplies the Smolfile's init and `create` appends
        // `--init` to it, so forward only the run's own steps: together they are
        // the resolved init the cache key is derived from, each step once.
        for step in cli_init {
            create.push("--init".into());
            create.push(step.clone());
        }
        // Init runs in the resolved workdir as the resolved user; without these
        // a step like `echo x > $WORKDIR/f` has no directory to write into.
        if let Some(workdir) = &params.workdir {
            create.push("--workdir".into());
            create.push(workdir.clone());
        }
        if let Some(user) = &params.user {
            create.push("--user".into());
            create.push(user.clone());
        }
        if params.allow_system_mounts {
            create.push("--allow-system-mounts".into());
        }
        // Forward the run's network config so the bake's one-time in-guest pull can
        // reach the registry. The cached artifact carries the layers, so later runs
        // from it need no network to source the image.
        if params.net {
            create.push("--net".into());
        }
        if let Some(dns) = params.dns {
            create.push("--dns".into());
            create.push(dns.to_string());
        }
        for option in &params.dns_options {
            create.push("--dns-option".into());
            create.push(option.clone());
        }
        if let Some(subnet) = &params.guest_subnet {
            create.push("--guest-subnet".into());
            create.push(subnet.clone());
        }
        for c in params.allowed_cidrs.iter().flatten() {
            create.push("--allow-cidr".into());
            create.push(c.clone());
        }
        for h in params.dns_filter_hosts.iter().flatten() {
            if h.starts_with('=') || h.starts_with("*.") {
                create.push("--allow-host-pattern".into());
                create.push(h.strip_prefix('=').unwrap_or(h).to_string());
            } else {
                create.push("--allow-host".into());
                create.push(h.clone());
            }
        }
        create.push("--".into());
        create.push("/bin/true".into());
        let create: Vec<&str> = create.iter().map(String::as_str).collect();

        println!("  · pulling image and running init...");
        run_smolvm(&exe, &create)?;
        // The image pull happens at `start`; forward the run's proxy so the
        // bake reaches the registry through a corporate/loopback proxy too —
        // otherwise a Smolfile with `init` steps pulls direct and times out
        // even when the outer run was given --proxy.
        let start = bake_start_args(&tmp, proxy, no_proxy);
        run_smolvm(&exe, &start)?;
        run_smolvm(&exe, &["machine", "stop", "--name", &tmp])?;
        println!("  · snapshotting...");
        run_smolvm(
            &exe,
            // `--include-workspace`: init may well have written into the workdir,
            // which is the storage disk rather than the rootfs the snapshot
            // captures; without it every cached run would start without those
            // files and nothing would say why.
            &[
                "pack",
                "create",
                "--from-vm",
                &tmp,
                "--include-workspace",
                "-o",
                &staged_out,
            ],
        )?;
        if !staged_sidecar.exists() {
            return Err(smolvm::Error::config(
                "init-layer cache",
                format!("bake did not produce {}", staged_sidecar.display()),
            ));
        }
        Ok(())
    })();
    let _ = run_smolvm(&exe, &["machine", "delete", "--name", &tmp, "-f"]);

    // Publish atomically only on success; always clear staging (drops the stub + any
    // partial output) so a failed bake leaves the existing cache untouched.
    let publish = bake.and_then(|_| {
        std::fs::rename(&staged_sidecar, &cached).map_err(|e| {
            smolvm::Error::config("init-layer cache", format!("publish cached layer: {e}"))
        })
    });
    let _ = std::fs::remove_dir_all(&staging);
    publish?;

    // Bound the cache: evict oldest layers if we're over the cap (keeping the one
    // just baked). Best-effort — failure to prune never fails the run.
    prune_init_cache(&dir, init_cache_max_bytes(), &cached);

    println!("  ✓ baked in {}s", started.elapsed().as_secs());
    Ok(cached)
}

/// Run this same smolvm binary as a subprocess for one bake step. Output is
/// CAPTURED (not inherited) so the bake's internal create/pull/pack chatter — and
/// the harmless "vm not found" from the best-effort pre-clean — never reach the
/// user's terminal; on failure the captured stdout and stderr tails are surfaced
/// in the error.
fn run_smolvm(exe: &Path, args: &[&str]) -> smolvm::Result<()> {
    let out = std::process::Command::new(exe)
        .args(args)
        .output()
        .map_err(|e| smolvm::Error::config("init-layer bake", e.to_string()))?;
    if !out.status.success() {
        // An image's init step runs under a tty, so what it printed is on stdout,
        // ahead of the error on stderr: keep the last 12 lines of each.
        let tail = |bytes: &[u8]| {
            let text = String::from_utf8_lossy(bytes);
            let lines: Vec<&str> = text.lines().filter(|l| !l.trim().is_empty()).collect();
            lines[lines.len().saturating_sub(12)..].join("\n")
        };
        let tail = [tail(&out.stdout), tail(&out.stderr)]
            .into_iter()
            .filter(|t| !t.is_empty())
            .collect::<Vec<_>>()
            .join("\n");
        return Err(smolvm::Error::config(
            "init-layer bake",
            format!(
                "`smolvm {}` failed ({}):\n{tail}",
                args.join(" "),
                out.status
            ),
        ));
    }
    Ok(())
}

/// When an agent request fails because the VM process is gone, replace the
/// bare transport error ("connection closed") with how the process ended.
fn explain_vm_death(manager: &smolvm::agent::AgentManager, error: smolvm::Error) -> smolvm::Error {
    match manager.death_reason() {
        Some(reason) => smolvm::Error::agent(
            "run command",
            format!("the machine's VM process died while the command ran: {reason}"),
        ),
        None => error,
    }
}

impl RunCmd {
    pub fn run(mut self) -> smolvm::Result<()> {
        use smolvm::Error;

        let host = crate::cli::host_network::HostNetwork::resolve(
            self.use_host_proxy,
            self.trust_host_certs,
            !self.credential.is_empty(),
        )?;
        self.env = host
            .env
            .into_iter()
            .chain(std::mem::take(&mut self.env))
            .collect();
        self.volume.extend(host.volumes);
        if self.proxy_opts.proxy.is_none() {
            self.proxy_opts.proxy = host.pull_proxy;
        }
        self.net |= self.use_host_proxy;

        // --max-image-size raises the archive cap for this invocation by setting
        // the env var the resolver reads (image_source::max_archive_bytes).
        if let Some(bytes) = self.max_image_size {
            std::env::set_var("SMOLVM_MAX_IMAGE_BYTES", bytes.to_string());
        }

        // `--from`: run a packed .smolmachine artifact ephemerally, reusing the
        // proven pack-run path. Resource flags fall back to the artifact's baked
        // manifest values (matching `machine create --from`); the remaining run
        // flags pass through. Flags the sidecar runner can't honor are rejected
        // at parse time via `conflicts_with_all` on `from`.
        if let Some(from) = self.from {
            if !self.credential.is_empty() {
                return Err(credentials_need_a_persistent_pack(
                    &from.display().to_string(),
                ));
            }
            let port = PortMappingSpec::expand_all(&self.port)
                .map_err(|e| smolvm::Error::config("machine run ports", e))?;
            let mut env = self.env;
            if self.auto_graph {
                smolvm::util::enable_cuda_auto_graph_env_specs(&mut env);
            }
            return crate::cli::pack_run::PackRunCmd {
                sidecar: Some(from),
                local_bake: false,
                command: self.command,
                interactive: self.interactive,
                tty: self.tty,
                timeout: self.timeout,
                workdir: self.workdir,
                user: self.user,
                env,
                volume: self.volume,
                allow_system_mounts: self.allow_system_mounts,
                port: port.into_iter().map(PortMappingSpec::from).collect(),
                net: self.net,
                net_backend: self.net_backend,
                ssh_agent: self.ssh_agent,
                dns: self.dns,
                dns_option: self.dns_option.clone(),
                cpus: self.cpus,
                mem: self.mem,
                storage: self.storage,
                overlay: self.overlay,
                block_io: self.block_io,
                force_extract: false,
                info: false,
                debug: false,
                cuda: self.cuda,
                auto_graph: self.auto_graph,
                // `--from` rejects the egress flags at parse time
                // (`conflicts_with_all`), so there is no policy to carry.
                egress: None,
                // `--from` conflicts with `--secret-env`/`--secret-file` at parse
                // time, so there are never CLI secret refs to forward here.
                secret_refs: Default::default(),
            }
            .run();
        }

        let requested_name = self.name.clone();
        let vm_name = if self.detach {
            requested_name.unwrap_or_else(|| "default".to_string())
        } else {
            smolvm::util::generate_machine_name()
        };

        if self.name.is_some() && vm_name != "default" && self.detach {
            let config = smolvm::config::SmolvmConfig::load()?;
            if config.get_vm(&vm_name).is_some() {
                return Err(Error::config(
                    "machine run -d --name",
                    format!(
                        "a machine named '{}' already exists. Use 'machine start --name {}' to start it, or 'machine delete --name {} -f' to remove it.",
                        vm_name, vm_name, vm_name
                    ),
                ));
            }
        }

        // `--allow-host-loopback` relaxes only the host-loopback part of the egress
        // floor via libkrun's `SMOLVM_ALLOW_HOST_LOOPBACK` env (read once at launch),
        // rather than adding loopback to the allow-list — an allow-list would make
        // egress restrictive and force the guest onto virtio-net, where a guest's
        // 127.0.0.1 never reaches the host. Setting the env keeps the default TSI
        // datapath and leaves cloud-metadata blocked.
        if self.allow_host_loopback {
            std::env::set_var("SMOLVM_ALLOW_HOST_LOOPBACK", "1");
        }
        let (cli_allow_cidrs, net, cli_dns_filter_hosts) = resolve_egress_flags(
            self.allow_cidr,
            self.allow_host,
            self.allow_host_pattern,
            self.outbound_localhost_only,
            self.net || self.allow_host_loopback,
        )?;

        let mut params = crate::cli::smolfile::build_create_params(
            vm_name.clone(),
            self.image.clone(),
            None,
            self.command.clone(),
            self.cpus,
            self.mem,
            self.volume,
            self.port,
            net,
            self.net_backend,
            self.dns,
            self.network_name.clone(),
            self.init.clone(),
            self.env,
            self.workdir,
            self.user,
            self.smolfile.clone(),
            self.storage,
            self.overlay,
            self.block_io,
            cli_allow_cidrs,
            // Ephemeral runs are not addressable later, so they carry no labels;
            // `machine create` is the path an orchestrator labels.
            Default::default(),
        )?;
        params.apply_block_private(self.block_private, std::mem::take(&mut self.allow_private));
        // `--dns-option` is CLI-only (a Smolfile has no resolver options key).
        params.dns_options = self.dns_option.clone();
        params.shm_size = self.shm_size.clone();
        params.prepend_deny_cidrs(&self.deny_cidr);
        params.append_allow_udp(&self.allow_udp);
        // `build_create_params` fills resources from the Smolfile, so a CLI-only
        // flag has to be merged here or it never reaches the record.
        params.nested_virt = params.nested_virt || self.nested_virt;
        params.rosetta = params.rosetta || self.rosetta;
        params.oci_platform = self.oci_platform.clone();
        params.guest_subnet = self.guest_subnet.clone();
        if let Some(durability) = self.disk_durability {
            params.disk_durability = durability;
        }
        params.disks = parse_attached_disks(&self.disk)?;
        params.cache_disk = parse_cache_disk(self.cache_disk.as_deref())?;
        params.allow_system_mounts = self.allow_system_mounts;
        if self.auto_graph {
            smolvm::util::enable_cuda_auto_graph_env_specs(&mut params.env);
            params.cuda = true;
        }
        params.dns_filter_hosts = match (params.dns_filter_hosts.take(), cli_dns_filter_hosts) {
            (Some(mut from_smolfile), Some(mut from_cli)) => {
                from_smolfile.append(&mut from_cli);
                Some(from_smolfile)
            }
            (Some(from_smolfile), None) => Some(from_smolfile),
            (None, some) => some,
        };
        merge_cli_credentials(&mut params, &self.credential)?;
        // Ephemeral machines boot before their record exists: mint placeholders
        // now so the launch, the workload env and the record all agree.
        vm_common::prepare_params_credentials(&mut params)?;
        params.published_sockets =
            parse_published_sockets(&self.expose_socket, &self.mount_socket)?;
        params.auto_ports = merge_auto_ports_flags(
            params.auto_ports.take(),
            self.auto_ports,
            &self.auto_ports_exclude,
        );
        // CLI `--secret-env`/`--secret-file` refs merge over any Smolfile
        // `[secrets]` of the same name (CLI wins).
        for (key, r) in
            parse_cli_secret_refs(&self.secret_env, &self.secret_file, &self.secret_keychain)?
        {
            params.secret_refs.insert(key, r);
        }
        vm_common::warn_hosts_blocked_by_private_floor(
            params.block_private.as_deref(),
            &params.egress_rules,
            params.dns_filter_hosts.as_deref(),
            params.credential_policy.as_ref(),
        );
        // A detached run leaves a machine behind, recorded by the rules
        // `machine create` applies; refuse what they refuse before booting.
        if self.detach {
            vm_common::build_vm_record(&params)?;
        }

        // A registry --image can name a smolmachine PACK artifact (e.g.
        // registry.smolmachines.com/library/alpine), whose single "layer" is a
        // full .smolmachine sidecar — not an OCI filesystem layer. The in-guest
        // OCI puller would tar-unpack its multi-GiB storage.ext4 into the guest
        // disk, so probe the manifest on the host and reroute through the
        // proven pack-run path (same as `--from`); a failed probe falls back to
        // the normal in-guest pull.
        if let Some(img) = params.image.clone() {
            if let Some(sidecar) = smolvm::data::pack_ref::resolve_pack_ref_blocking(&img)? {
                if params
                    .credential_policy
                    .as_ref()
                    .is_some_and(|policy| !policy.is_empty())
                {
                    return Err(credentials_need_a_persistent_pack(&img));
                }
                if self.detach {
                    // pack-run is ephemeral-only; a persistent machine from a
                    // pack ref goes through create (which reroutes the same way).
                    return Err(Error::config(
                        "machine run",
                        format!(
                            "'{img}' is a smolmachine pack artifact and cannot run detached \
                             via --image. Create a persistent machine instead:\n  \
                             smolvm machine create --image {img} && smolvm machine start"
                        ),
                    ));
                }
                let command = if !self.command.is_empty() {
                    self.command.clone()
                } else {
                    let mut c = params.entrypoint.clone();
                    c.extend(params.cmd.clone());
                    c
                };
                return crate::cli::pack_run::PackRunCmd {
                    sidecar: Some(sidecar),
                    local_bake: false,
                    command,
                    interactive: self.interactive,
                    tty: self.tty,
                    timeout: self.timeout,
                    workdir: params.workdir.clone(),
                    user: params.user.clone(),
                    env: params.env.clone(),
                    volume: params.volume.clone(),
                    allow_system_mounts: params.allow_system_mounts,
                    port: params
                        .port
                        .iter()
                        .copied()
                        .map(PortMappingSpec::from)
                        .collect(),
                    net: params.net,
                    net_backend: params.network_backend,
                    ssh_agent: self.ssh_agent || params.ssh_agent,
                    dns: params.dns,
                    dns_option: params.dns_options.clone(),
                    cpus: Some(params.cpus),
                    mem: Some(params.mem),
                    storage: params.storage_gb,
                    overlay: params.overlay_gb,
                    block_io: Some(params.block_io),
                    force_extract: false,
                    info: false,
                    debug: false,
                    cuda: self.cuda || params.cuda,
                    auto_graph: self.auto_graph,
                    // A user-supplied artifact's manifest keeps deciding the
                    // network default (no override), but any allow-list / DNS
                    // filter from the flags or Smolfile must still be enforced.
                    egress: Some(crate::cli::pack_run::ResolvedEgressPolicy {
                        network_override: None,
                        allowed_cidrs: params.allowed_cidrs.clone(),
                        dns_filter_hosts: params.dns_filter_hosts.clone(),
                        block_private: params.block_private.clone(),
                        egress_rules: params.egress_rules.clone(),
                    }),
                    secret_refs: params.secret_refs.clone(),
                }
                .run();
            }
        }

        // Init-layer cache (prototype): for an ephemeral run of an IMAGE with `init`
        // commands, bake `image + init` once into a cached `.smolmachine` and run from
        // that artifact, so init's cost (e.g. `apt install`) is paid once and reused
        // on every later run instead of re-running on each ephemeral boot. Skipped for
        // detached/persistent runs (`-d`) and when `--no-init-cache` is set.
        //
        // Only REGISTRY images are baked. A local image (`--image -` / `--image
        // file.tar` / a rootfs dir) is flattened with no registry manifest, so the
        // bake's `pack create --from-vm` snapshot can't source its layers; and a
        // `--image -` archive can't be re-read by the bake's child subprocess
        // (null stdin) anyway. Local images take the direct path below, which
        // stages the archive once in this process and runs init inline (#459).
        // The cache normally applies to runs with `init` steps (bake `image + init`
        // once). `--oci-cache` extends it to a bare `--image` run with no init, so
        // the OCI image itself is cached on the host and repeat ephemeral runs skip
        // the pull — the same bake path, just with an empty init layer.
        // A cached bake runs through the packed launcher, which cannot
        // substitute credentials, so a credentialed run takes the direct path.
        if !self.no_init_cache
            && !self.detach
            && params
                .credential_policy
                .as_ref()
                .is_none_or(|policy| policy.is_empty())
            && image_bakeable(params.image.as_deref())
            && (!params.init.is_empty() || self.oci_cache)
        {
            // Auth gate: resolve + authorize the image on the HOST before baking
            // or serving a cached bake. A private image the caller cannot pull is
            // rejected here — the same registry-authorization gate the cloud path
            // uses, so caching never bypasses pull authorization. `FromConfig`
            // reads smolvm's registry config, then the host's Docker credentials
            // (so `docker login`ed private images resolve, credential helpers
            // included); anonymous is the fallback for public ones.
            //
            // The resolved digest also becomes part of the cache key, so the entry
            // tracks the image's CONTENT: when a mutable tag moves upstream the key
            // changes and the new content is baked, instead of serving the first
            // run's image forever.
            //
            // The same resolution also yields the image's own ENTRYPOINT/CMD.
            // The bake records `/bin/true` as the artifact's command (so `start`
            // runs init alone), which discards the image's default command; a run
            // that supplies none of its own would otherwise fall through to that
            // no-op and do nothing. We carry the image's command here so it runs,
            // exactly as the non-cached path does from image metadata (#1334).
            let mut resolved_digest = None;
            let mut image_entrypoint: Vec<String> = Vec::new();
            let mut image_cmd: Vec<String> = Vec::new();
            if self.oci_cache {
                if let Some(image) = params.image.as_deref() {
                    let auth = smolvm::registry::PullAuth::FromConfig;
                    let rt = tokio::runtime::Runtime::new()
                        .map_err(|e| Error::config("oci-cache", e.to_string()))?;
                    let cfg =
                        rt.block_on(smolvm::image_store::authorized_image_config(image, &auth))?;
                    resolved_digest = Some(cfg.digest);
                    image_entrypoint = cfg.entrypoint;
                    image_cmd = cfg.cmd;
                }
            }
            // Fail only when there is genuinely nothing to run: no CLI command,
            // no Smolfile entrypoint/cmd, no image default command, and no `-it`
            // to drop into a shell. When the image declares its own command, a
            // bare `--oci-cache --image X` runs it — matching `docker run` and
            // the non-cached path.
            if self.oci_cache
                && self.command.is_empty()
                && !self.interactive
                && self.smolfile.is_none()
                && params.entrypoint.is_empty()
                && params.cmd.is_empty()
                && image_entrypoint.is_empty()
                && image_cmd.is_empty()
            {
                return Err(Error::config(
                    "machine run",
                    "--oci-cache needs a command to run: the image declares no entrypoint or \
                     cmd, so pass one after `--`, use -it for a shell, or supply a Smolfile \
                     with an entrypoint/cmd"
                        .to_string(),
                ));
            }
            let cached = ensure_init_layer(
                &params,
                self.smolfile.as_deref(),
                &self.init,
                self.rebuild_init_cache,
                resolved_digest.as_deref(),
                self.proxy_opts.resolved_proxy()?.as_deref(),
                self.proxy_opts.no_proxy().as_deref(),
            )?;
            // Resolve the workload the same way the non-cached path does, since
            // the baked artifact's own command is a `/bin/true` no-op: CLI
            // trailing args > Smolfile entrypoint+cmd > image entrypoint+cmd >
            // default (a shell for foreground/interactive runs, idle for detach).
            let command = if !self.command.is_empty() {
                self.command.clone()
            } else if !params.entrypoint.is_empty() || !params.cmd.is_empty() {
                let mut c = params.entrypoint.clone();
                c.extend(params.cmd.clone());
                c
            } else if !image_entrypoint.is_empty() || !image_cmd.is_empty() {
                let mut c = image_entrypoint.clone();
                c.extend(image_cmd.clone());
                c
            } else if self.detach {
                DEFAULT_IDLE_CMD.iter().map(|s| s.to_string()).collect()
            } else {
                vec![DEFAULT_SHELL_CMD.to_string()]
            };
            return crate::cli::pack_run::PackRunCmd {
                sidecar: Some(cached),
                local_bake: true,
                command,
                interactive: self.interactive,
                tty: self.tty,
                timeout: self.timeout,
                workdir: params.workdir.clone(),
                user: params.user.clone(),
                env: params.env.clone(),
                volume: params.volume.clone(),
                allow_system_mounts: params.allow_system_mounts,
                port: params
                    .port
                    .iter()
                    .copied()
                    .map(PortMappingSpec::from)
                    .collect(),
                net: params.net,
                net_backend: params.network_backend,
                ssh_agent: self.ssh_agent || params.ssh_agent,
                dns: params.dns,
                dns_option: params.dns_options.clone(),
                cpus: Some(params.cpus),
                mem: Some(params.mem),
                storage: params.storage_gb,
                overlay: params.overlay_gb,
                block_io: Some(params.block_io),
                force_extract: false,
                info: false,
                debug: false,
                cuda: self.cuda || params.cuda,
                auto_graph: self.auto_graph,
                // The workload's network policy, resolved above from the flags
                // and Smolfile. The override is absolute: the baked artifact's
                // manifest records the BAKE VM's networking (enabled, for the
                // pull), so without it a cache hit would run the workload with
                // unrestricted egress no matter what the caller asked for.
                egress: Some(crate::cli::pack_run::ResolvedEgressPolicy {
                    network_override: Some(params.net),
                    allowed_cidrs: params.allowed_cidrs.clone(),
                    dns_filter_hosts: params.dns_filter_hosts.clone(),
                    block_private: params.block_private.clone(),
                    egress_rules: params.egress_rules.clone(),
                }),
                secret_refs: params.secret_refs.clone(),
            }
            .run();
        }

        // Remote volumes are mounted inside the guest by the agent, so peel them
        // off before the host-directory parse, which would reject an `s3://`
        // source as a missing directory.
        let (volume_specs, disk_volumes) =
            smolvm::data::storage::split_disk_volume_specs(&params.volume)?;
        let (host_volume_specs, remote_volumes) =
            smolvm::remote_volume::split_specs(&volume_specs)?;
        let mut mounts =
            HostMount::parse_with_system_mounts(&host_volume_specs, params.allow_system_mounts)?;
        smolvm::data::storage::ensure_disk_volumes_distinct(
            &disk_volumes,
            mounts
                .iter()
                .filter_map(|m| m.target.to_str())
                .chain(remote_volumes.iter().map(|v| v.target.as_str())),
        )?;
        if !remote_volumes.is_empty() && !params.net {
            return Err(Error::config(
                "machine run",
                "remote volumes need network access to reach the bucket: add --net",
            ));
        }
        let ports = params.port.clone();
        PortMapping::check_duplicates(&ports)
            .map_err(|e| smolvm::Error::config("validate ports", e))?;

        if self.docker_config {
            if let Some(docker_mount) = docker_config_mount() {
                mounts.push(docker_mount);
            } else {
                tracing::warn!("Docker config directory not found");
            }
        }

        // Require an explicit command, -it flag, or Smolfile entrypoint/cmd.
        // Without any of these, /bin/sh hangs waiting for input — confusing UX.
        if self.detach && (self.interactive || self.tty) {
            eprintln!("warning: -i/-t flags are ignored in detached mode (-d)");
        }

        let has_smolfile_command = !params.entrypoint.is_empty() || !params.cmd.is_empty();
        let (interactive, tty) = if !self.interactive
            && !self.tty
            && !self.detach
            && self.command.is_empty()
            && !has_smolfile_command
        {
            return Err(smolvm::Error::config(
                "machine run",
                "no command specified.\n\
                     Use: smolvm machine run -- <command>\n\
                     Or:  smolvm machine run -it",
            ));
        } else {
            (self.interactive, self.tty)
        };

        // `--image -` consumes stdin to read the archive; `-i`/`-t` also bind
        // stdin to the guest. They cannot both own stdin.
        if self.image.as_deref() == Some("-") && (interactive || tty) {
            return Err(smolvm::Error::config(
                "machine run",
                "`--image -` reads the image archive from stdin and cannot be \
                 combined with -i/-t, which also use stdin.\n\
                 Pipe the archive from a file instead: --image ./image.tar",
            ));
        }

        // Detect the common mistake of passing an image reference as a positional
        // argument instead of using --image.  clap's trailing_var_arg captures any
        // positional before "--" into `command`, so `smolvm machine run ubuntu:22.04
        // -- bash` silently puts "ubuntu:22.04" into command[0] and fails with a
        // confusing ENOENT after the VM boots.  Catching the unambiguous cases
        // (image:tag, registry/image) here avoids an unnecessary boot round-trip.
        {
            let resolved_image = self.image.as_deref().or(params.image.as_deref());
            if resolved_image.is_none()
                && !self.command.is_empty()
                && is_likely_image_ref(&self.command[0])
            {
                let cmd0 = &self.command[0];
                // Strip the "--" separator that trailing_var_arg includes
                // in the vec so the suggestion doesn't show a double "--".
                let rest: Vec<&str> = self.command[1..]
                    .iter()
                    .filter(|s| s.as_str() != "--")
                    .map(|s| s.as_str())
                    .collect();
                let suggestion = if rest.is_empty() {
                    format!("smolvm machine run --image {cmd0}")
                } else {
                    format!("smolvm machine run --image {cmd0} -- {}", rest.join(" "))
                };
                return Err(Error::config(
                    "machine run",
                    format!(
                        "'{cmd0}' looks like a container image reference, not a command.\n\
                         To run a container, use --image:\n  {suggestion}"
                    ),
                ));
            }
        }

        let resources = VmResources {
            cpus: params.cpus,
            memory_mib: params.mem,
            network: params.net,
            network_backend: params.network_backend,
            dns: params.dns,
            dns_options: params.dns_options.clone(),
            shm_size: params.shm_size.clone(),
            network_name: params.network_name.clone(),
            guest_subnet: params.guest_subnet.clone(),
            switch: None,
            // CLI --gpu wins; Smolfile gpu = true also enables it.
            gpu: self.gpu || params.gpu,
            nested_virt: self.nested_virt,
            gpu_vram_mib: self.gpu_vram_mib.or(params.gpu_vram_mib),
            cuda: self.cuda || params.cuda,
            rosetta: self.rosetta || params.rosetta,
            storage_gib: params.storage_gb,
            overlay_gib: params.overlay_gb,
            allowed_cidrs: params.allowed_cidrs.clone(),
            egress_rules: params.egress_rules.clone(),
            block_io: params.block_io,
            disk_durability: params.disk_durability,
            disks: params.disks.clone(),
            cache_disk: params.cache_disk.clone(),
            disk_volumes: disk_volumes.clone(),
            block_private: params.block_private.clone(),
        };
        validate_requested_network_backend(
            &resources,
            params.dns_filter_hosts.as_deref(),
            params.port.len(),
        )?;

        // Resolve the image source on the host before launch: registry refs
        // pass through to the guest pull; a local `docker save` archive or an
        // unpacked rootfs directory is staged/validated and mounted via
        // virtiofs (the `.smolmachine` packed-layers path), so no pull happens.
        let raw_image = self.image.clone().or(params.image.clone());
        let mut packed_layers_dir = None;
        let image = match raw_image.as_deref() {
            Some(img) => {
                use smolvm::data::image_source::{classify, resolve, ResolvedImage};
                match resolve(classify(img))? {
                    ResolvedImage::Registry(reference) => Some(reference),
                    ResolvedImage::Local {
                        reference,
                        packed_layers_dir: dir,
                    } => {
                        packed_layers_dir = Some(dir);
                        Some(reference)
                    }
                }
            }
            None => None,
        };
        // A fresh run starts on a shared seed of its image, so the guest finds
        // the image already in place, exactly as `machine start` does. A local
        // archive seeds under its resolved `local:<hash>` reference, which is
        // what the seed cache keys on. Best-effort: without a seed the guest
        // pulls or flattens as before.
        let seed_image = if packed_layers_dir.is_some() {
            image.clone()
        } else {
            params.image.clone()
        };
        // Nothing registers this run until its VM starts, so remove the data
        // directory the steps below create if the run returns before then.
        // Ephemeral runs only: their generated name is theirs alone, while a
        // detached run's name (`default` or `--name`) can be shared with a
        // concurrent run whose directory this must not remove.
        let mut unstarted_data_dir =
            (!self.detach).then(|| vm_common::UnstartedRunDataDir::new(&vm_name));
        // A seed holds the guest's own architecture; a run that pulls another
        // platform (Rosetta pulls linux/amd64) would only pull again over it.
        let seeds_platform = smolvm::image_seed::serves_platform(
            smolvm::vm::rosetta::image_platform(params.oci_platform.as_deref(), params.rosetta),
        );
        let seed_proxy = self.proxy_opts.resolved_proxy()?;
        let seed_no_proxy = self.proxy_opts.no_proxy();
        let interrupted = smolvm::image_seed::interruptible(|| {
            smolvm::image_seed::seed_ephemeral_run_with_trust(
                &vm_name,
                seed_image.as_deref().filter(|_| seeds_platform),
                params.storage_gb,
                self.seed_digest_ttl,
                seed_proxy.as_deref(),
                seed_no_proxy.as_deref(),
                self.trust_host_certs,
            )
        });
        if let Some(signal) = interrupted {
            // The seed build deleted its builder. Remove this run's data too.
            drop(unstarted_data_dir);
            smolvm::image_seed::exit_by_signal(signal);
        }

        let manager =
            AgentManager::for_vm_with_sizes(&vm_name, params.storage_gb, params.overlay_gb)
                .map_err(|e| Error::agent("create agent manager", e.to_string()))?;

        if self.detach {
            eprintln!("Starting persistent machine...");
        } else {
            eprintln!("Starting ephemeral machine ({})...", vm_name);
        }

        let ssh_agent_socket = if self.ssh_agent || params.ssh_agent {
            match std::env::var("SSH_AUTH_SOCK") {
                Ok(path) => Some(std::path::PathBuf::from(path)),
                Err(_) => {
                    return Err(Error::config(
                        "--ssh-agent",
                        "SSH_AUTH_SOCK is not set. Start an SSH agent with: eval $(ssh-agent) && ssh-add",
                    ));
                }
            }
        } else {
            None
        };

        let uses_packed_layers = packed_layers_dir.is_some();

        let mut features = smolvm::agent::LaunchFeatures {
            ssh_agent_socket,
            cuda: self.cuda || params.cuda,
            expose_docker: self.docker_socket || params.docker_socket,
            auto_ports: params.auto_ports.clone(),
            dns_filter_hosts: params.dns_filter_hosts.clone(),
            credentials: params.credential_policy.as_ref().and_then(|policy| {
                smolvm::credentials::CredentialLaunch::from_parts(
                    &vm_name,
                    policy,
                    &params.credential_placeholders,
                    &params.secret_refs,
                    None,
                )
            }),
            published_sockets: params.published_sockets.clone(),
            // A foreground ephemeral VM exists only to serve this command, so bind
            // its lifetime to this process. Without the watchdog the VM survives a
            // SIGKILL of the CLI — which is how orchestrators (and CI) enforce
            // timeouts — and then holds its full RAM until some later `machine run`
            // happens to sweep it (see the bounded reclaim in `MachineCmd::run`).
            // That sweep stays as the backstop for cases the watchdog can't cover,
            // such as a host that sleeps mid-run.
            //
            // `--detach` deliberately leaves the VM up for later `machine exec`, so
            // it must opt out: arming this there would kill the VM the moment the
            // launching CLI returned.
            watch_parent: Some(!self.detach),
            packed_layers_dir,
            extra_disks: std::env::var("SMOLVM_EXTRA_DISK")
                .ok()
                .into_iter()
                .flat_map(|spec| {
                    spec.split(',')
                        .filter(|s| !s.is_empty())
                        .map(|entry| {
                            let (path, ro) = match entry.strip_suffix(":ro") {
                                Some(p) => (p, true),
                                None => (entry, false),
                            };
                            (
                                std::path::PathBuf::from(path),
                                ro,
                                smolvm::data::disk::DiskFormat::Raw,
                            )
                        })
                        .collect::<Vec<_>>()
                })
                .collect(),
            ..Default::default()
        };

        // This launch pulls a registry image in-guest, subject to the egress
        // filter — fold its registry into the enforced policy so a hostname
        // scope doesn't block its own pull.
        features.allow_image_pull_egress(image.as_deref(), uses_packed_layers);

        let freshly_started = manager
            .ensure_running_with_full_config(mounts.clone(), ports, resources, features)
            .map_err(|e| Error::agent("start machine", e.to_string()))?;
        if let Some(guard) = unstarted_data_dir.as_mut() {
            guard.disarm();
        }

        // Tell the user how to reach the guest's Docker daemon from the host.
        // libkrun exposes the bridge as a Unix socket in the VM data dir; a
        // host docker client uses it via DOCKER_HOST. dockerd must be running
        // inside the VM (start it once the machine is up).
        if self.docker_socket || params.docker_socket {
            let sock = smolvm::agent::vm_data_dir(&vm_name).join("docker.sock");
            eprintln!(
                "Docker socket exposed — once dockerd is running in the VM, reach it with:\n  \
                 DOCKER_HOST=unix://{} docker ps",
                sock.display()
            );
        }

        if params.auto_ports.is_some() {
            eprintln!(
                "Auto ports on: a TCP port the machine listens on appears at 127.0.0.1:<same port>"
            );
        }

        // Register the ephemeral VM for tracking (machine list, orphan cleanup),
        // keyed by the VM's OWN name. The orphan sweep only has the DB record and
        // locates the disks via `vm_data_dir(record.name)`, so the record name
        // MUST be the VM name — a separate generated name would hash to a
        // different, nonexistent dir and the sweep would delete the record but
        // leak the real (multi-GB) data dir.
        //
        // Detached runs are tracked via persist_named_running instead — skip
        // ephemeral registration so the detach path does not leave an
        // unreachable orphan record after persist_named_running succeeds.
        if !self.detach {
            vm_common::register_ephemeral_vm(
                &vm_name,
                manager.child_pid(),
                params.cpus,
                params.mem,
                params.net,
                image.clone(),
                &mounts,
            );
        }

        let mut client = AgentClient::connect_with_retry(manager.vsock_socket())?;

        // Install SIGINT guard so Ctrl+C during pull kills the VM process
        // instead of orphaning it. The guard is disarmed before interactive
        // exec (which has its own SIGINT handling).
        let sigint_guard = manager.child_pid().map(smolvm::process::SigintGuard::new);

        // Resolve image: CLI > Smolfile > None (bare VM)
        // When Rosetta is enabled, default the image pull to linux/amd64 so there
        // is an x86_64 binary to translate; an explicit --oci-platform still wins.
        // Without this, a multi-arch image resolves to the guest-native arm64
        // variant and Rosetta has nothing to do.
        let effective_platform =
            smolvm::vm::rosetta::image_platform(params.oci_platform.as_deref(), params.rosetta);

        // A registry image is pulled. A local source's layers are already
        // mounted via virtiofs, but its image config (WORKDIR, Env, USER) is
        // only known once the guest materializes it; the agent's pull does that
        // for mounted layers without touching the network.
        let image_info = if let Some(ref img) = image {
            match crate::cli::pull_with_progress(
                &mut client,
                img,
                effective_platform,
                self.proxy_opts.resolved_proxy()?.as_deref(),
                self.proxy_opts.no_proxy().as_deref(),
            ) {
                Ok(info) => Some(info),
                Err(e) if !params.net && !uses_packed_layers => {
                    // Add a hint when pull fails and networking is disabled —
                    // this is the most common user error.
                    return Err(smolvm::Error::agent(
                        "pull image",
                        format!(
                            "{}\n\nHint: networking is disabled. Add --net to enable image pulls:\n  smolvm machine run --net --image {} ...",
                            e, img
                        ),
                    ));
                }
                Err(e) => return Err(e),
            }
        } else {
            None
        };

        // Resolve Smolfile [secrets] for this launch. Tuples are plaintext;
        // do not log them. Zeroizing buffers were scrubbed inside the helper.
        // These are merged into `env`/`init_env` below but never flow into
        // `params.env`, so the plaintext values never touch the persisted
        // VM record — only the refs are stored (via DefaultVmOverrides), and
        // they get re-resolved at each subsequent `machine start`.
        let resolved_secrets = vm_common::params_secret_env(&params)?;

        if freshly_started && !params.init.is_empty() {
            // Route through `run_init_commands` so init runs inside the
            // container when an image is set (so package managers like
            // pacman/apt/dnf resolve against the image's rootfs), and
            // in the bare agent otherwise. The persistent `start_*`
            // paths use the same helper — keep parity.
            //
            // Convert the parsed HostMount list into the record-shape
            // tuples the runner expects. This is a thin local conversion;
            // the runner does its own tag assignment internally so call
            // sites don't have to track which form the agent wants.
            let (record_mounts, _) = HostMount::split_storage_tuples(&mounts);
            let mut init_env = parse_env_list(&params.env);
            init_env.extend(resolved_secrets.iter().cloned());
            // Use the machine name as the overlay ID so any rootfs changes
            // init makes (e.g. `pacman -S git`) are visible to a
            // subsequent `machine exec`. The exec path resolves the
            // overlay from the machine name, falling back to "default",
            // so matching that name here is what makes init's effects
            // observable to the user.
            if let Err(e) = vm_common::run_init_commands(
                &mut client,
                &params.init,
                vm_common::InitRunContext {
                    image: image.as_deref(),
                    image_info: image_info.as_ref(),
                    env: &init_env,
                    workdir: params.workdir.as_deref(),
                    record_mounts: &record_mounts,
                    overlay_id: &vm_name,
                },
            ) {
                // Ephemeral VMs have no state to preserve — `kill()`
                // matches the success path's lifetime semantics
                // (manager.kill() at line ~563/655) and avoids the
                // graceful-shutdown latency `stop()` adds when no one
                // is going to use this VM again.
                vm_common::deregister_ephemeral_vm(&vm_name);
                manager.kill();
                return Err(e);
            }
        }

        // Resolve command: CLI trailing args > Smolfile entrypoint+cmd > image metadata > defaults
        let command = if !self.command.is_empty() {
            self.command.clone()
        } else if !params.entrypoint.is_empty() || !params.cmd.is_empty() {
            let mut cmd = params.entrypoint.clone();
            cmd.extend(params.cmd.clone());
            cmd
        } else if let Some(ref info) = image_info {
            let mut cmd = info.entrypoint.clone();
            cmd.extend(info.cmd.clone());
            if cmd.is_empty() {
                if self.detach {
                    DEFAULT_IDLE_CMD.iter().map(|s| s.to_string()).collect()
                } else {
                    vec![DEFAULT_SHELL_CMD.to_string()]
                }
            } else {
                cmd
            }
        } else if self.detach {
            DEFAULT_IDLE_CMD.iter().map(|s| s.to_string()).collect()
        } else {
            vec![DEFAULT_SHELL_CMD.to_string()]
        };

        let mut env = parse_env_list(&params.env);
        env.extend(resolved_secrets.iter().cloned());
        let mount_bindings = mounts_to_virtiofs_bindings(&mounts);

        // Two modes: with image or bare VM (no image)
        if let Some(ref img) = image {
            let defaults = vm_common::resolve_image_runtime_defaults(
                image_info.as_ref(),
                &env,
                params.workdir.as_deref(),
                params.user.as_deref(),
            );
            // Credentials and endpoint come from the workload's own env, the
            // same place every AWS SDK reads them, so a remote volume needs no
            // configuration beyond the `-v` spec and the usual variables.
            let s3_volumes = smolvm::remote_volume::to_s3_volumes(&remote_volumes, &defaults.env);
            if self.detach {
                // Start the main workload container first. If this fails, the
                // VM is stopped and no DB record is written — a retry won't
                // hit "machine already exists."
                {
                    let run_config = smolvm::agent::RunConfig::new(img.clone(), command.clone())
                        .with_env(defaults.env.clone())
                        .with_workdir(defaults.workdir.clone())
                        .with_user(defaults.user.clone())
                        .with_mounts(mount_bindings.clone())
                        .with_persistent_overlay(Some(vm_name.clone()))
                        .with_unprivileged(self.unprivileged)
                        .with_s3_volumes(s3_volumes.clone());
                    client
                        .run_container_detached(run_config)
                        .map_err(|e| explain_vm_death(&manager, e))?;
                }

                // Container started — persist the DB record. If this fails,
                // stop the VM to avoid an orphan that lifecycle commands can't find.
                {
                    use smolvm::config::SmolvmConfig;
                    use vm_common::DefaultVmOverrides;
                    let (mount_tuples, staged_mounts) = HostMount::split_storage_tuples(&mounts);
                    let port_tuples = params.port.clone();
                    let persist_result = SmolvmConfig::load().and_then(|mut config| {
                        vm_common::persist_named_running(
                            &mut config,
                            &vm_name,
                            manager.child_pid(),
                            Some({
                                let mut o = DefaultVmOverrides::from_create_params(
                                    &params,
                                    mount_tuples,
                                    staged_mounts,
                                    port_tuples,
                                )?;
                                // An image machine records what the image
                                // resolved to: its env (minus secret values, which
                                // stay as refs), workdir and user, the image itself
                                // and the workload command.
                                let r = &mut o.record;
                                r.env = defaults
                                    .env
                                    .iter()
                                    .filter(|(k, _)| !params.secret_refs.contains_key(k))
                                    .cloned()
                                    .collect();
                                r.workdir = defaults.workdir.clone();
                                r.user = defaults.user.clone();
                                r.image = Some(img.clone());
                                r.entrypoint = Vec::new();
                                r.cmd = command.clone();
                                r.ssh_agent |= self.ssh_agent;
                                r.cuda |= self.cuda;
                                r.docker_socket |= self.docker_socket;
                                if self.gpu {
                                    r.gpu = Some(true);
                                }
                                r.gpu_vram_mib = self.gpu_vram_mib.or(r.gpu_vram_mib);
                                o
                            }),
                        )
                    });
                    if let Err(e) = persist_result {
                        let _ = manager.stop();
                        return Err(Error::config(
                            "persist machine record",
                            format!("VM started but record could not be saved: {}. VM stopped to avoid orphan.", e),
                        ));
                    }
                }

                // Disarm SIGINT guard — detaching, VM stays running.
                drop(sigint_guard);

                if vm_name == "default" {
                    println!("Machine running in background");
                    println!("\nTo interact:");
                    println!("  smolvm machine exec -- <command>");
                    println!("\nTo stop:");
                    println!("  smolvm machine stop");
                } else {
                    println!("Machine '{}' running in background", vm_name);
                    println!("\nTo interact:");
                    println!("  smolvm machine exec --name {} -- <command>", vm_name);
                    println!("\nTo stop:");
                    println!("  smolvm machine stop --name {}", vm_name);
                }

                manager.detach();
                Ok(())
            } else {
                // Disarm SIGINT guard — exec phase has its own signal handling.
                if let Some(guard) = sigint_guard {
                    guard.disarm();
                }

                // Use the machine's persistent overlay so the foreground workload
                // sees init's filesystem changes (init ran with the same overlay id).
                // Without this the workload runs in a fresh overlay and init appears
                // to "do nothing" (e.g. `apt install`ed binaries are missing).
                let exit_code = if interactive || tty {
                    let config = RunConfig::new(img, command)
                        .with_env(defaults.env.clone())
                        .with_workdir(defaults.workdir.clone())
                        .with_user(defaults.user.clone())
                        .with_mounts(mount_bindings)
                        .with_timeout(self.timeout)
                        .with_tty(tty)
                        .with_persistent_overlay(Some(vm_name.clone()))
                        .with_unprivileged(self.unprivileged)
                        .with_s3_volumes(s3_volumes.clone());
                    client
                        .run_interactive(config)
                        .map_err(|e| explain_vm_death(&manager, e))?
                } else {
                    let config = RunConfig::new(img, command)
                        .with_env(defaults.env)
                        .with_workdir(defaults.workdir)
                        .with_user(defaults.user)
                        .with_mounts(mount_bindings)
                        .with_timeout(self.timeout)
                        .with_persistent_overlay(Some(vm_name.clone()))
                        .with_unprivileged(self.unprivileged)
                        .with_s3_volumes(s3_volumes.clone());
                    let (exit_code, stdout, stderr) = client
                        .run_non_interactive(config)
                        .map_err(|e| explain_vm_death(&manager, e))?;
                    if !stdout.is_empty() {
                        let _ = std::io::stdout().write_all(&stdout);
                    }
                    if !stderr.is_empty() {
                        let _ = std::io::stderr().write_all(&stderr);
                    }
                    flush_output();
                    exit_code
                };

                if mounts.iter().any(|mount| mount.staged) {
                    if let Err(error) = smolvm::staged_mount::sync_mounts(&mounts, &mut client) {
                        // Preserve the VM and its ephemeral DB record so the
                        // guest-local copy remains recoverable and sync can be
                        // retried by machine name.
                        manager.detach();
                        return Err(Error::agent(
                            "sync staged mounts",
                            format!(
                                "{error}; machine '{vm_name}' was left running so synchronization can be retried"
                            ),
                        ));
                    }
                }

                // Ephemeral run — tear down VM and its data directory.
                // Spawn a detached helper so the parent exits immediately after
                // flushing output. Falls back to synchronous cleanup if spawn fails.
                let (pid, start_time) = manager.pid_and_start_time().unwrap_or((0, None));
                if pid > 0 && try_spawn_detached_cleanup(&vm_name, pid, start_time) {
                    std::process::exit(exit_code);
                }
                // Fallback: synchronous cleanup (helper spawn failed).
                vm_common::deregister_ephemeral_vm(&vm_name);
                manager.kill();
                manager.cleanup_data_dir();
                std::process::exit(exit_code);
            }
        } else {
            // Bare VM mode (no image) — disarm SIGINT guard before exec.
            if let Some(guard) = sigint_guard {
                guard.disarm();
            }

            if self.detach {
                // Run entrypoint+cmd in background if present
                let is_idle = command.is_empty()
                    || command
                        == DEFAULT_IDLE_CMD
                            .iter()
                            .map(|s| s.to_string())
                            .collect::<Vec<_>>();
                if !is_idle {
                    let pid = client.vm_exec_background(command, env, params.workdir.clone())?;
                    tracing::info!(pid = pid, "background workload started");
                }

                // Persist the VM state so it survives stop/start.
                {
                    use smolvm::config::SmolvmConfig;
                    use vm_common::DefaultVmOverrides;
                    let (mount_tuples, staged_mounts) = HostMount::split_storage_tuples(&mounts);
                    let port_tuples = params.port.clone();
                    let mut config = SmolvmConfig::load()?;
                    vm_common::persist_named_running(
                        &mut config,
                        &vm_name,
                        manager.child_pid(),
                        Some({
                            let mut o = DefaultVmOverrides::from_create_params(
                                &params,
                                mount_tuples,
                                staged_mounts,
                                port_tuples,
                            )?;
                            // A one-shot run keeps no image on its record; the
                            // command line flags may enable features on top of
                            // what the Smolfile asked for.
                            let r = &mut o.record;
                            r.image = None;
                            r.ssh_agent |= self.ssh_agent;
                            r.cuda |= self.cuda;
                            r.docker_socket |= self.docker_socket;
                            if self.gpu {
                                r.gpu = Some(true);
                            }
                            r.gpu_vram_mib = self.gpu_vram_mib.or(r.gpu_vram_mib);
                            o
                        }),
                    )?;
                }

                if vm_name == "default" {
                    println!(
                        "Machine running (PID: {})",
                        manager.child_pid().unwrap_or(0)
                    );
                    println!("\nTo interact:");
                    println!("  smolvm machine exec -- <command>");
                    println!("\nTo stop:");
                    println!("  smolvm machine stop");
                } else {
                    println!(
                        "Machine '{}' running (PID: {})",
                        vm_name,
                        manager.child_pid().unwrap_or(0)
                    );
                    println!("\nTo interact:");
                    println!("  smolvm machine exec --name {} -- <command>", vm_name);
                    println!("\nTo stop:");
                    println!("  smolvm machine stop --name {}", vm_name);
                }

                manager.detach();
                Ok(())
            } else {
                let exit_code = if interactive || tty {
                    client.vm_exec_interactive(
                        command,
                        env,
                        params.workdir.clone(),
                        self.timeout,
                        tty,
                    )?
                } else {
                    // Capture for error context before command is moved into vm_exec.
                    let cmd0 = command.first().cloned().unwrap_or_default();
                    let (exit_code, stdout, stderr) = client
                        .vm_exec(command, env, params.workdir.clone(), self.timeout, None)
                        .map_err(|e| {
                            // In bare VM mode a spawn ENOENT often means the user
                            // forgot --image and passed the image name as a positional.
                            // Name the command that wasn't found so the hint is actionable.
                            let msg = e.to_string();
                            if image.is_none()
                                && (msg.contains("No such file or directory")
                                    || msg.contains("os error 2"))
                                && !cmd0.starts_with('/')
                                && !cmd0.starts_with('.')
                            {
                                Error::agent(
                                    "vm exec",
                                    format!(
                                        "{msg}\n\nNote: '{cmd0}' was not found in the VM. \
                                         If you meant to run a container image, use --image:\n  \
                                         smolvm machine run --image {cmd0} -- <command>"
                                    ),
                                )
                            } else {
                                e
                            }
                        })?;
                    if !stdout.is_empty() {
                        let _ = std::io::stdout().write_all(&stdout);
                    }
                    if !stderr.is_empty() {
                        let _ = std::io::stderr().write_all(&stderr);
                    }
                    flush_output();
                    exit_code
                };
                if mounts.iter().any(|mount| mount.staged) {
                    if let Err(error) = smolvm::staged_mount::sync_mounts(&mounts, &mut client) {
                        manager.detach();
                        return Err(Error::agent(
                            "sync staged mounts",
                            format!(
                                "{error}; machine '{vm_name}' was left running so synchronization can be retried"
                            ),
                        ));
                    }
                }
                // Ephemeral run — tear down VM and its data directory.
                // Spawn a detached helper so the parent exits immediately after
                // flushing output. Falls back to synchronous cleanup if spawn fails.
                let (pid, start_time) = manager.pid_and_start_time().unwrap_or((0, None));
                if pid > 0 && try_spawn_detached_cleanup(&vm_name, pid, start_time) {
                    std::process::exit(exit_code);
                }
                // Fallback: synchronous cleanup (helper spawn failed).
                vm_common::deregister_ephemeral_vm(&vm_name);
                manager.kill();
                manager.cleanup_data_dir();
                std::process::exit(exit_code);
            }
        }
    }
}

#[cfg(test)]
mod tests {
    /// Serialize tests whose asserts depend on SMOLVM_MACHINE_NAME, and shield
    /// them from an ambient value: clap reads real process env at parse time,
    /// so a value set by a concurrently running test (or exported in the
    /// developer's shell) flips any name-is-required assertion. Acquiring the
    /// guard also clears the variable, so each holder starts from unset.
    fn machine_name_env_lock() -> std::sync::MutexGuard<'static, ()> {
        static LOCK: std::sync::Mutex<()> = std::sync::Mutex::new(());
        let guard = LOCK.lock().unwrap_or_else(|e| e.into_inner());
        std::env::remove_var(smolvm::data::consts::ENV_SMOLVM_MACHINE_NAME);
        guard
    }

    /// One test covers every SMOLVM_MACHINE_NAME behavior, because it mutates
    /// process env: parallel test functions sharing the variable would race.
    #[test]
    fn machine_name_reads_the_environment_with_the_flag_winning() {
        let _env = machine_name_env_lock();
        use clap::Parser;
        #[derive(Parser)]
        struct Harness {
            #[command(subcommand)]
            cmd: super::MachineCmd,
        }
        let parse = |argv: &[&str]| Harness::try_parse_from(argv).map(|h| h.cmd);

        std::env::set_var("SMOLVM_MACHINE_NAME", "workspace-vm");

        // The environment fills --name on machine-selector commands.
        let Ok(super::MachineCmd::Status(status)) = parse(&["machine", "status"]) else {
            panic!("status must parse");
        };
        assert_eq!(status.name.as_deref(), Some("workspace-vm"));
        let Ok(super::MachineCmd::Delete(delete)) = parse(&["machine", "delete", "-f"]) else {
            panic!("delete must accept an env-supplied name");
        };
        assert_eq!(delete.name, "workspace-vm");

        // An explicit --name always wins.
        let Ok(super::MachineCmd::Status(status)) =
            parse(&["machine", "status", "--name", "other"])
        else {
            panic!("status must parse");
        };
        assert_eq!(status.name.as_deref(), Some("other"));

        // `machine run` deliberately ignores it: one ambient name across
        // every ephemeral run would collide on the second concurrent run.
        let Ok(super::MachineCmd::Run(run)) = parse(&["machine", "run", "--", "true"]) else {
            panic!("run must parse");
        };
        assert!(run.name.is_none());

        // `machine checkpoint --export-from` keeps working with the variable
        // set: its --name conflicts with --export-from, so the env must not
        // feed it. (Checkpoint's --name is excluded for exactly this reason.)
        let Ok(super::MachineCmd::Checkpoint(checkpoint)) = parse(&[
            "machine",
            "checkpoint",
            "--export-from",
            "/tmp/x",
            "--output",
            "/tmp/y.smolcheckpoint",
        ]) else {
            panic!("checkpoint --export-from must parse with the env var set");
        };
        assert!(checkpoint.name.is_none());

        std::env::remove_var("SMOLVM_MACHINE_NAME");

        // Without the variable, nothing changes: status falls back to its
        // default-name behavior and delete requires an explicit --name.
        let Ok(super::MachineCmd::Status(status)) = parse(&["machine", "status"]) else {
            panic!("status must parse");
        };
        assert!(status.name.is_none());
        assert!(parse(&["machine", "delete", "-f"]).is_err());
    }

    #[test]
    fn strict_host_flags_enable_network_without_static_cidrs() {
        let (cidrs, net, hosts) = super::resolve_egress_flags(
            vec![],
            vec![],
            vec!["api.example.com".into(), "*.example.com".into()],
            false,
            false,
        )
        .unwrap();
        assert!(cidrs.is_empty());
        assert!(net);
        assert_eq!(hosts.unwrap(), ["=api.example.com", "*.example.com"]);
    }

    #[test]
    fn bake_start_forwards_proxy_when_set() {
        // No proxy: plain start. The bake always provisions only (never launches
        // the workload), so `--no-workload` is present regardless of proxy.
        assert_eq!(
            super::bake_start_args("t", None, None),
            ["machine", "start", "--name", "t", "--no-workload"]
        );
        // Proxy only.
        assert_eq!(
            super::bake_start_args("t", Some("http://host.smolvm.internal:8118"), None),
            [
                "machine",
                "start",
                "--name",
                "t",
                "--no-workload",
                "--proxy",
                "http://host.smolvm.internal:8118"
            ]
        );
        // Proxy + no_proxy.
        assert_eq!(
            super::bake_start_args("t", Some("http://p:3128"), Some("localhost,.internal")),
            [
                "machine",
                "start",
                "--name",
                "t",
                "--no-workload",
                "--proxy",
                "http://p:3128",
                "--no-proxy",
                "localhost,.internal"
            ]
        );
    }

    #[test]
    fn bake_start_always_provisions_only() {
        // The bake must never launch the image's workload: it only needs the
        // pulled layers and init's effects for the snapshot, and minimal images
        // (scratch, distroless, hello-world) have no runnable no-op to launch.
        for args in [
            super::bake_start_args("t", None, None),
            super::bake_start_args("t", Some("http://p:3128"), None),
            super::bake_start_args("t", Some("http://p:3128"), Some("localhost")),
        ] {
            assert!(
                args.contains(&"--no-workload"),
                "bake start must be provision-only: {args:?}"
            );
        }
    }

    #[test]
    fn cp_mode_parses_common_octal_forms_and_rejects_garbage() {
        assert_eq!(super::parse_octal_mode("644").unwrap(), 0o644);
        assert_eq!(super::parse_octal_mode("0755").unwrap(), 0o755);
        assert_eq!(super::parse_octal_mode("0o600").unwrap(), 0o600);
        assert!(super::parse_octal_mode("8x").is_err());
        assert!(super::parse_octal_mode("77777").is_err());
    }

    use super::*;
    use clap::Parser;

    #[test]
    fn cli_credential_set_header_reaches_the_machine_record() {
        let mut params = crate::cli::smolfile::build_create_params(
            "credential-header".into(),
            None,
            None,
            vec![],
            None,
            None,
            vec![],
            vec![],
            false,
            None,
            None,
            None,
            vec![],
            vec![],
            None,
            None,
            None,
            None,
            None,
            None,
            Default::default(),
            Default::default(),
        )
        .unwrap();
        merge_cli_credentials(
            &mut params,
            &["github=GITHUB_AUTH@api.github.com:set-header=authorization".into()],
        )
        .unwrap();

        let record = vm_common::build_vm_record(&params).unwrap();
        let binding = &record.credential_policy.unwrap().credentials[0];
        assert_eq!(binding.set_header.as_deref(), Some("authorization"));
        assert_eq!(binding.environment_variable, "GITHUB_AUTH");
    }

    /// `machine monitor` flags override the machine's Smolfile `[health]`
    /// values, which override the defaults.
    #[test]
    fn monitor_health_flags_override_the_smolfile_values() {
        use clap::Parser;
        #[derive(Parser)]
        struct Harness {
            #[command(subcommand)]
            cmd: super::MachineCmd,
        }
        let monitor = |argv: &[&str]| match Harness::try_parse_from(argv).map(|h| h.cmd) {
            Ok(super::MachineCmd::Monitor(monitor)) => monitor,
            _ => panic!("monitor must parse"),
        };
        let secs = Duration::from_secs;

        let mut record =
            smolvm::config::VmRecord::new("web".into(), 1, 512, Vec::new(), Vec::new(), false);
        let defaults = monitor(&["machine", "monitor", "--name", "web"]);
        assert_eq!(defaults.health_settings(&record), (secs(5), 3, secs(5)));

        record.health_timeout_secs = Some(2);
        record.health_retries = Some(4);
        record.health_interval_secs = Some(10);
        assert_eq!(defaults.health_settings(&record), (secs(2), 4, secs(10)));

        let flags = monitor(&[
            "machine",
            "monitor",
            "--name",
            "web",
            "--health-timeout",
            "7",
            "--health-retries",
            "1",
            "--interval",
            "30",
        ]);
        assert_eq!(flags.health_settings(&record), (secs(7), 1, secs(30)));
    }

    #[test]
    fn cli_overlay_owner_uses_the_golden_for_fork_clones() {
        let ordinary =
            smolvm::config::VmRecord::new("ordinary".into(), 1, 512, Vec::new(), Vec::new(), false);
        assert_eq!(
            persistent_overlay_owner_for_record("ordinary", Some(&ordinary)),
            "ordinary"
        );

        let mut clone =
            smolvm::config::VmRecord::new("clone-a".into(), 1, 512, Vec::new(), Vec::new(), false);
        clone.golden = Some("golden-a".into());
        assert_eq!(
            persistent_overlay_owner_for_record("clone-a", Some(&clone)),
            "golden-a"
        );
    }

    /// `--oci-cache` resolves the image digest at the auth gate and mixes it into
    /// the key, so the cache tracks CONTENT. Without this a mutable tag like
    /// `alpine:latest` hashes identically forever and the first run's image keeps
    /// being served — upstream updates (security fixes included) never land.
    #[test]
    fn init_layer_key_pins_the_resolved_digest() {
        let init: Vec<String> = vec![];
        let env: Vec<String> = vec![];
        let untagged = init_layer_key(Some("alpine:latest"), &init, &env, None);
        let first = init_layer_key(Some("alpine:latest"), &init, &env, Some("sha256:aaa"));
        let moved = init_layer_key(Some("alpine:latest"), &init, &env, Some("sha256:bbb"));

        assert_ne!(
            first, moved,
            "the same tag at a NEW digest must be a new cache entry"
        );
        assert_eq!(
            first,
            init_layer_key(Some("alpine:latest"), &init, &env, Some("sha256:aaa")),
            "the same tag at the same digest still hits"
        );
        assert_ne!(
            untagged, first,
            "supplying a digest changes the key (no collision with the un-pinned path)"
        );
    }

    #[test]
    fn init_layer_key_is_stable_and_input_sensitive() {
        let init = vec!["apt-get install -y jq".to_string()];
        let env = vec!["FOO=bar".to_string()];
        let base = init_layer_key(Some("ubuntu:noble"), &init, &env, None);
        // Deterministic for identical inputs.
        assert_eq!(
            base,
            init_layer_key(Some("ubuntu:noble"), &init, &env, None)
        );
        assert_eq!(base.len(), 16);
        // Sensitive to each input: image, init, env.
        assert_ne!(
            base,
            init_layer_key(Some("ubuntu:jammy"), &init, &env, None)
        );
        assert_ne!(
            base,
            init_layer_key(Some("ubuntu:noble"), &["other".to_string()], &env, None)
        );
        assert_ne!(
            base,
            init_layer_key(Some("ubuntu:noble"), &init, &["FOO=baz".to_string()], None)
        );
        // Order of init steps matters (different layer).
        let init_rev = vec!["b".to_string(), "a".to_string()];
        let init_fwd = vec!["a".to_string(), "b".to_string()];
        assert_ne!(
            init_layer_key(Some("x"), &init_fwd, &[], None),
            init_layer_key(Some("x"), &init_rev, &[], None)
        );
    }

    #[test]
    fn parse_published_sockets_both_directions() {
        use smolvm::config::SocketDirection;
        let out = parse_published_sockets(
            &[
                "/var/run/app.sock".to_string(),
                "/run/svc.sock:/tmp/pinned.sock".to_string(),
            ],
            &["/run/host.sock:/run/guest.sock".to_string()],
        )
        .unwrap();
        assert_eq!(out.len(), 3);
        assert_eq!(out[0].direction, SocketDirection::Expose);
        assert_eq!(out[0].guest_path, "/var/run/app.sock");
        assert_eq!(out[0].host_path, None);
        assert_eq!(out[1].host_path.as_deref(), Some("/tmp/pinned.sock"));
        assert_eq!(out[2].direction, SocketDirection::Mount);
        assert_eq!(out[2].guest_path, "/run/guest.sock");
        assert_eq!(out[2].host_path.as_deref(), Some("/run/host.sock"));
    }

    #[test]
    fn parse_published_sockets_rejects_bad_specs() {
        assert!(parse_published_sockets(&[], &["/only-host".to_string()]).is_err());
        assert!(parse_published_sockets(&[":/tmp/h.sock".to_string()], &[]).is_err());
        assert!(parse_published_sockets(&["/run/a;b.sock".to_string()], &[]).is_err());
        // Relative guest paths resolve against whatever the guest process is
        // rooted at, so they can never name the socket the user meant.
        assert!(parse_published_sockets(&["app.sock".to_string()], &[]).is_err());
        assert!(parse_published_sockets(&[], &["/run/h.sock:app.sock".to_string()]).is_err());
        // Two mount bridges at one guest path shadow each other in the guest,
        // leaving the first host socket unreachable.
        assert!(parse_published_sockets(
            &[],
            &[
                "/run/h1.sock:/run/control/engine.sock".to_string(),
                "/run/h2.sock:/run/control/engine.sock".to_string(),
            ]
        )
        .is_err());
    }

    #[test]
    fn parse_cli_secret_refs_builds_env_and_file_refs() {
        let refs = parse_cli_secret_refs(
            &["GUEST_TOKEN=HOST_TOKEN".to_string()],
            &["GUEST_KEY=/abs/key".to_string()],
            &["GUEST_API=anthropic/me".to_string()],
        )
        .unwrap();
        assert_eq!(refs["GUEST_TOKEN"].from_env.as_deref(), Some("HOST_TOKEN"));
        assert_eq!(
            refs["GUEST_KEY"]
                .from_file
                .as_ref()
                .map(|p| p.to_string_lossy().into_owned()),
            Some("/abs/key".to_string())
        );
        assert_eq!(
            refs["GUEST_API"].from_keychain.as_deref(),
            Some("anthropic/me")
        );
    }

    #[test]
    fn parse_cli_secret_refs_rejects_bad_specs() {
        // Missing '='.
        assert!(parse_cli_secret_refs(&["NO_EQUALS".to_string()], &[], &[]).is_err());
        // Empty key.
        assert!(parse_cli_secret_refs(&["=HOST".to_string()], &[], &[]).is_err());
        // Relative from_file path (validate_ref under TrustedLocal).
        assert!(parse_cli_secret_refs(&[], &["K=relative/path".to_string()], &[]).is_err());
        // Duplicate key across the two flags.
        assert!(parse_cli_secret_refs(
            &["DUP=HOST".to_string()],
            &["DUP=/abs/path".to_string()],
            &[]
        )
        .is_err());
        // A keychain item needs a service, and an account when it has a '/'.
        for bad in ["K=", "K=/me", "K=svc/"] {
            assert!(
                parse_cli_secret_refs(&[], &[], &[bad.to_string()]).is_err(),
                "{bad}"
            );
        }
        assert!(
            parse_cli_secret_refs(&["DUP=HOST".to_string()], &[], &["DUP=svc".to_string()])
                .is_err()
        );
    }

    #[derive(Parser, Debug)]
    #[command(name = "machine")]
    struct TestMachineCli {
        #[command(subcommand)]
        command: MachineCmd,
    }

    /// `machine run --from` hands the pack to the one-shot pack runner, which
    /// cannot apply these; each is refused by name instead of dropped.
    #[test]
    fn run_from_a_pack_refuses_the_flags_it_cannot_apply() {
        for flags in [
            &["--block-private"][..],
            &["--allow-private", "10.0.0.0/8"],
            &["--allow-host-loopback"],
            &["--nested"],
            &["--rosetta"],
            &["--shm-size", "1g"],
            &["--guest-subnet", "10.200.0.0/30"],
            &["--network", "fabric"],
            &["--disk-durability", "deferred"],
            &["--disk", "/tmp/disk.img"],
            &["--cache-disk", "/tmp/base.img:/cache"],
            &["--docker-socket"],
            &["--expose-socket", "/run/app.sock"],
            &["--mount-socket", "/run/h.sock:/run/g.sock"],
            &["--init", "true"],
        ] {
            let mut argv = vec!["machine", "run", "--from", "x.smolmachine"];
            argv.extend_from_slice(flags);
            let error = TestMachineCli::try_parse_from(argv)
                .expect_err("refused")
                .to_string();
            assert!(error.contains(flags[0]), "{flags:?}: {error}");
        }
        assert!(TestMachineCli::try_parse_from([
            "machine",
            "run",
            "--from",
            "x.smolmachine",
            "--net"
        ])
        .is_ok());
    }

    #[test]
    fn create_takes_repeatable_dns_options_in_order_and_refuses_unknown_ones() {
        let cli = TestMachineCli::try_parse_from([
            "machine",
            "create",
            "--name",
            "dns-1",
            "--dns-option",
            "timeout:1",
            "--dns-option",
            "attempts:3",
            "--dns-option",
            "rotate",
            "--dns-option",
            "use-vc",
        ])
        .unwrap();
        let MachineCmd::Create(cmd) = cli.command else {
            panic!("expected machine create");
        };
        assert_eq!(
            cmd.dns_option,
            ["timeout:1", "attempts:3", "rotate", "use-vc"]
        );
        for bad in ["bogus", "timeout:0", "rotate:1", "options timeout:1"] {
            assert!(
                TestMachineCli::try_parse_from([
                    "machine",
                    "create",
                    "--name",
                    "dns-2",
                    "--dns-option",
                    bad
                ])
                .is_err(),
                "{bad:?} must be refused at the command line"
            );
        }
    }

    #[test]
    fn create_run_and_update_take_a_validated_shm_size() {
        for command in ["create", "update"] {
            let cli = TestMachineCli::try_parse_from([
                "machine",
                command,
                "--name",
                "shm-1",
                "--shm-size",
                "2G",
            ])
            .unwrap();
            let size = match cli.command {
                MachineCmd::Create(cmd) => cmd.shm_size,
                MachineCmd::Update(cmd) => {
                    assert!(!cmd.changes_only_egress() && !cmd.changes_only_ports());
                    cmd.shm_size
                }
                _ => panic!("expected machine {command}"),
            };
            assert_eq!(size.as_deref(), Some("2g"), "{command}");
            assert!(TestMachineCli::try_parse_from([
                "machine",
                command,
                "--name",
                "shm-2",
                "--shm-size",
                "1g,mode=777",
            ])
            .is_err());
        }
        let cli =
            TestMachineCli::try_parse_from(["machine", "run", "--shm-size", "25%", "--", "true"])
                .unwrap();
        let MachineCmd::Run(cmd) = cli.command else {
            panic!("expected machine run");
        };
        assert_eq!(cmd.shm_size.as_deref(), Some("25%"));
    }

    #[test]
    fn update_replaces_or_clears_dns_options() {
        let parse = |args: &[&str]| {
            TestMachineCli::try_parse_from(
                ["machine", "update", "--name", "dns-3"].iter().chain(args),
            )
        };
        let MachineCmd::Update(cmd) =
            parse(&["--dns-option", "timeout:1", "--dns-option", "use-vc"])
                .unwrap()
                .command
        else {
            panic!("expected machine update");
        };
        assert_eq!(cmd.dns_option, ["timeout:1", "use-vc"]);
        assert!(!cmd.changes_only_egress() && !cmd.changes_only_ports());
        let MachineCmd::Update(cmd) = parse(&["--clear-dns-options"]).unwrap().command else {
            panic!("expected machine update");
        };
        assert!(cmd.clear_dns_options && cmd.dns_option.is_empty());
        assert!(parse(&["--dns-option", "bogus"]).is_err());
        assert!(parse(&["--dns-option", "use-vc", "--clear-dns-options"]).is_err());
    }

    #[test]
    fn create_accepts_keep_identity() {
        let cli = TestMachineCli::try_parse_from([
            "machine",
            "create",
            "--name",
            "desk-2",
            "--from",
            "save.checkpoint",
            "--keep-identity",
        ])
        .unwrap();
        let MachineCmd::Create(cmd) = cli.command else {
            panic!("expected machine create");
        };
        assert!(cmd.keep_identity);
        let cli =
            TestMachineCli::try_parse_from(["machine", "create", "--name", "desk-3"]).unwrap();
        let MachineCmd::Create(cmd) = cli.command else {
            panic!("expected machine create");
        };
        assert!(!cmd.keep_identity);
    }

    #[test]
    fn restore_cache_flags_bound_create_and_checkpoint_warm() {
        let parse = |argv: &[&str]| TestMachineCli::try_parse_from(argv).map(|cli| cli.command);
        let Ok(MachineCmd::Create(create)) =
            parse(&["machine", "create", "--from", "save.checkpoint"])
        else {
            panic!("expected create");
        };
        assert_eq!(
            create.restore_cache.cache(),
            smolvm::portable_checkpoint::RestoreCache::default()
        );
        let Ok(MachineCmd::CheckpointWarm(warm)) = parse(&[
            "machine",
            "checkpoint-warm",
            "--from",
            "save.checkpoint",
            "--restore-cache-entries",
            "5",
            "--restore-cache-gib",
            "24",
        ]) else {
            panic!("expected checkpoint-warm");
        };
        let cache = warm.restore_cache.cache();
        assert_eq!(cache.entries, 5);
        assert_eq!(cache.max_bytes, 24 * 1024 * 1024 * 1024);
        assert!(parse(&[
            "machine",
            "create",
            "--from",
            "save.checkpoint",
            "--restore-cache-entries",
            "65",
        ])
        .is_err());
    }

    #[test]
    fn stats_takes_a_machine_name_and_json() {
        let Ok(MachineCmd::Stats(stats)) =
            TestMachineCli::try_parse_from(["machine", "stats", "--name", "web", "--json"])
                .map(|cli| cli.command)
        else {
            panic!("expected machine stats");
        };
        assert_eq!(stats.name.as_deref(), Some("web"));
        assert!(stats.json);
    }

    #[test]
    fn live_resize_accepts_absolute_resource_targets() {
        for (flag, value) in [
            ("--cpus", "4"),
            ("--mem", "4096"),
            ("--storage", "50"),
            ("--overlay", "20"),
        ] {
            let cli = TestMachineCli::try_parse_from([
                "machine", "resize", "--name", "worker", flag, value,
            ])
            .unwrap();
            let MachineCmd::Resize(cmd) = cli.command else {
                panic!("expected resize");
            };
            assert_eq!(cmd.name.as_deref(), Some("worker"));
            match flag {
                "--cpus" => assert_eq!(cmd.cpus, Some(4)),
                "--mem" => assert_eq!(cmd.mem, Some(4096)),
                "--storage" => assert_eq!(cmd.storage, Some(50)),
                _ => assert_eq!(cmd.overlay, Some(20)),
            }
        }
        assert!(TestMachineCli::try_parse_from([
            "machine",
            "resize",
            "--storage",
            "50",
            "--overlay",
            "20"
        ])
        .is_ok());
        assert!(TestMachineCli::try_parse_from(["machine", "resize"]).is_err());
        for (flag, value) in [
            ("--cpus", "0"),
            ("--cpus", "256"),
            ("--mem", "0"),
            ("--mem", "-1"),
        ] {
            assert!(TestMachineCli::try_parse_from(["machine", "resize", flag, value]).is_err());
        }
    }

    #[test]
    fn create_accepts_port_ranges() {
        let cli = TestMachineCli::parse_from([
            "machine",
            "create",
            "--name",
            "range-test",
            "--port",
            "5173-5175:6173-6175",
        ]);
        let MachineCmd::Create(cmd) = cli.command else {
            panic!("expected machine create command");
        };

        assert_eq!(
            PortMappingSpec::expand_all(&cmd.port).unwrap(),
            vec![
                PortMapping::new(5173, 6173),
                PortMapping::new(5174, 6174),
                PortMapping::new(5175, 6175),
            ]
        );
    }

    #[test]
    fn run_detach_accepts_name_flag() {
        let cli = TestMachineCli::parse_from([
            "machine", "run", "-d", "--name", "foo", "--image", "alpine",
        ]);

        let MachineCmd::Run(cmd) = cli.command else {
            panic!("expected machine run command");
        };
        assert_eq!(cmd.name, Some("foo".to_string()));
        assert!(cmd.detach);
    }

    #[test]
    fn start_cuda_pool_flags_parse_and_limit_requires_pool() {
        let cli = TestMachineCli::parse_from([
            "machine",
            "start",
            "--name",
            "golden",
            "--fork-pool-size",
            "4",
            "--cuda-vram-limit-mib",
            "10240",
        ]);
        let MachineCmd::Start(cmd) = cli.command else {
            panic!("expected machine start command");
        };
        assert_eq!(cmd.fork_pool_size.map(|v| v.get()), Some(4));
        assert_eq!(cmd.cuda_vram_limit_mib.map(|v| v.get()), Some(10240));

        assert!(TestMachineCli::try_parse_from([
            "machine",
            "start",
            "--name",
            "golden",
            "--cuda-vram-limit-mib",
            "10240",
        ])
        .is_err());
    }

    #[test]
    fn branch_accepts_single_batch_and_legacy_fork_forms() {
        let single =
            TestMachineCli::parse_from(["machine", "branch", "--from", "base", "--name", "worker"]);
        let MachineCmd::Branch(single) = single.command else {
            panic!("expected machine branch command");
        };
        assert_eq!(single.clone.as_deref(), Some("worker"));
        assert_eq!(single.count.get(), 1);
        assert!(!single.wait_ready);
        assert!(!single.freeze_source);

        let frozen = TestMachineCli::parse_from([
            "machine",
            "branch",
            "--from",
            "base",
            "--name",
            "worker",
            "--freeze-source",
        ]);
        let MachineCmd::Branch(frozen) = frozen.command else {
            panic!("expected machine branch command");
        };
        assert!(frozen.freeze_source);

        let batch = TestMachineCli::parse_from([
            "machine",
            "branch",
            "--from",
            "base",
            "--count",
            "8",
            "--name-prefix",
            "worker",
            "--parallel",
            "3",
            "--ready-timeout",
            "2m",
        ]);
        let MachineCmd::Branch(batch) = batch.command else {
            panic!("expected machine branch command");
        };
        assert_eq!(batch.count.get(), 8);
        assert_eq!(batch.name_prefix.as_deref(), Some("worker"));
        assert_eq!(batch.parallel.get(), 3);
        assert!(!batch.wait_ready);
        assert_eq!(batch.ready_timeout, Duration::from_secs(120));
        let plain = is_plain_branch(batch.count.get(), batch.name_prefix.is_some(), batch.hold);
        assert_eq!(
            forkpoint_timeout(plain, batch.wait_ready, batch.ready_timeout),
            Some(Duration::from_secs(120))
        );
        // --no-wait-ready is the batch's way out of the boundary wait, like the API's default
        let direct = TestMachineCli::parse_from([
            "machine",
            "branch",
            "--from",
            "base",
            "--count",
            "4",
            "--name-prefix",
            "w",
            "--no-wait-ready",
        ]);
        let MachineCmd::Branch(direct) = direct.command else {
            panic!("expected machine branch command");
        };
        assert!(direct.no_wait_ready && !direct.wait_ready && !direct.hold);
        assert!(
            TestMachineCli::try_parse_from([
                "machine",
                "branch",
                "--from",
                "base",
                "--count",
                "4",
                "--name-prefix",
                "w",
                "--no-wait-ready",
                "--hold",
            ])
            .is_err(),
            "--no-wait-ready and --hold contradict each other"
        );
        // A plain branch waits only when asked; every batch shape waits, so a
        // one-child batch is released at the boundary like any other.
        assert_eq!(
            forkpoint_timeout(true, false, Duration::from_secs(120)),
            None
        );
        assert_eq!(
            forkpoint_timeout(true, true, Duration::from_secs(120)),
            Some(Duration::from_secs(120))
        );
        assert_eq!(
            forkpoint_timeout(
                is_plain_branch(1, true, false),
                false,
                Duration::from_secs(120)
            ),
            Some(Duration::from_secs(120))
        );
        assert_eq!(
            forkpoint_timeout(
                is_plain_branch(1, false, true),
                false,
                Duration::from_secs(120)
            ),
            Some(Duration::from_secs(120))
        );

        let release = TestMachineCli::parse_from([
            "machine",
            "branch-release",
            "--name",
            "worker-0",
            "--env",
            "LR=3e-4",
        ]);
        let MachineCmd::BranchRelease(release) = release.command else {
            panic!("expected branch-release command");
        };
        assert_eq!(release.name, "worker-0");
        assert_eq!(release.env, vec!["LR=3e-4"]);

        let legacy = TestMachineCli::parse_from([
            "machine",
            "fork",
            "--golden",
            "base",
            "--name",
            "legacy-worker",
            "--forkable",
        ]);
        let MachineCmd::Branch(legacy) = legacy.command else {
            panic!("expected legacy fork alias to resolve to branch command");
        };
        assert_eq!(legacy.golden, "base");
        assert!(legacy.forkable);
    }

    #[test]
    fn only_a_named_single_child_skips_the_batch_path() {
        assert!(is_plain_branch(1, false, false));
        assert!(!is_plain_branch(1, true, false));
        assert!(!is_plain_branch(1, false, true));
        assert!(!is_plain_branch(2, true, false));
    }

    #[test]
    fn indexed_fork_env_renders_each_clone() {
        let specs = vec![
            "TRIAL={index}".to_string(),
            "OUTPUT=/runs/{name}".to_string(),
            "SMOLVM_FORK_INDEX=wrong".to_string(),
            "SMOLVM_FORK_BATCH_ID=wrong".to_string(),
            "SMOLVM_FORK_BATCH_SIZE=999".to_string(),
        ];
        assert_eq!(
            render_indexed_fork_env(
                &specs,
                3,
                "worker-3",
                true,
                Some(&ForkBatchIdentity {
                    id: "batch-1".to_string(),
                    size: 8,
                }),
            ),
            vec![
                ("TRIAL".to_string(), "3".to_string()),
                ("OUTPUT".to_string(), "/runs/worker-3".to_string()),
                ("SMOLVM_BRANCH_INDEX".to_string(), "3".to_string()),
                ("SMOLVM_BRANCH_NAME".to_string(), "worker-3".to_string()),
                ("SMOLVM_FORK_INDEX".to_string(), "3".to_string()),
                ("SMOLVM_FORK_NAME".to_string(), "worker-3".to_string()),
                ("SMOLVM_BRANCH_BATCH_ID".to_string(), "batch-1".to_string()),
                ("SMOLVM_BRANCH_BATCH_SIZE".to_string(), "8".to_string()),
                ("SMOLVM_FORK_BATCH_ID".to_string(), "batch-1".to_string()),
                ("SMOLVM_FORK_BATCH_SIZE".to_string(), "8".to_string()),
            ]
        );
        assert_eq!(
            render_indexed_fork_env(&specs, 3, "worker-3", true, None),
            vec![
                ("TRIAL".to_string(), "3".to_string()),
                ("OUTPUT".to_string(), "/runs/worker-3".to_string()),
                ("SMOLVM_BRANCH_INDEX".to_string(), "3".to_string()),
                ("SMOLVM_BRANCH_NAME".to_string(), "worker-3".to_string()),
                ("SMOLVM_FORK_INDEX".to_string(), "3".to_string()),
                ("SMOLVM_FORK_NAME".to_string(), "worker-3".to_string()),
            ]
        );
    }

    #[test]
    fn run_accepts_auto_graph_flag() {
        let cli = TestMachineCli::parse_from([
            "machine",
            "run",
            "--auto-graph",
            "--image",
            "alpine",
            "--",
            "true",
        ]);

        let MachineCmd::Run(cmd) = cli.command else {
            panic!("expected machine run command");
        };
        assert!(cmd.auto_graph);
        assert!(!cmd.cuda, "auto-graph implies CUDA during parameter merge");
    }

    #[test]
    fn create_accepts_stop_on_exit_flag() {
        let cli =
            TestMachineCli::parse_from(["machine", "create", "--name", "worker", "--stop-on-exit"]);
        let MachineCmd::Create(cmd) = cli.command else {
            panic!("expected machine create command");
        };
        assert!(cmd.stop_on_exit);
    }

    #[test]
    fn create_and_stop_accept_stop_settings_and_reject_bad_ones() {
        let cli = TestMachineCli::parse_from([
            "machine",
            "create",
            "--name",
            "worker",
            "--stop-signal",
            "SIGINT",
            "--stop-timeout",
            "45",
        ]);
        let MachineCmd::Create(cmd) = cli.command else {
            panic!("expected machine create command");
        };
        assert_eq!(cmd.stop_signal.as_deref(), Some("SIGINT"));
        assert_eq!(cmd.stop_timeout, Some(45));

        let cli = TestMachineCli::parse_from(["machine", "stop", "--name", "worker", "-t", "0"]);
        let MachineCmd::Stop(cmd) = cli.command else {
            panic!("expected machine stop command");
        };
        assert_eq!(cmd.timeout, Some(0));

        for bad in [
            vec![
                "machine",
                "create",
                "--name",
                "w",
                "--stop-signal",
                "SIGNOPE",
            ],
            vec!["machine", "create", "--name", "w", "--stop-timeout", "301"],
            vec!["machine", "stop", "--name", "w", "--timeout", "soon"],
        ] {
            assert!(TestMachineCli::try_parse_from(&bad).is_err(), "{bad:?}");
        }
    }

    #[test]
    fn logs_accepts_follow_and_tail() {
        let cli = TestMachineCli::parse_from([
            "machine", "logs", "--name", "worker", "-f", "--tail", "20",
        ]);
        let MachineCmd::Logs(cmd) = cli.command else {
            panic!("expected machine logs command");
        };
        assert!(cmd.follow);
        assert_eq!(cmd.tail, Some(20));
    }

    #[test]
    fn create_accepts_auto_graph_flag() {
        let cli =
            TestMachineCli::parse_from(["machine", "create", "--name", "golden", "--auto-graph"]);

        let MachineCmd::Create(cmd) = cli.command else {
            panic!("expected machine create command");
        };
        assert!(cmd.auto_graph);
    }

    /// `--disk` is repeatable and order-preserving: the guest sees them as
    /// /dev/vdc, /dev/vdd, ... in the order given, so order is meaningful.
    #[test]
    fn disk_flag_is_repeatable_and_keeps_order() {
        let cli = TestMachineCli::parse_from([
            "machine",
            "create",
            "--name",
            "db",
            "--disk",
            "/dev/nvme1n1",
            "--disk",
            "/srv/golden.img:ro",
        ]);
        let MachineCmd::Create(cmd) = cli.command else {
            panic!("expected machine create command");
        };
        assert_eq!(cmd.disk, vec!["/dev/nvme1n1", "/srv/golden.img:ro"]);

        let parsed = parse_attached_disks(&cmd.disk)
            .expect_err("validation runs at create, so absent paths are refused up front");
        assert!(format!("{parsed}").contains("/dev/nvme1n1"));
    }

    fn parse_update(extra: &[&'static str]) -> UpdateCmd {
        let argv = [&["machine", "update", "--name", "l"][..], extra].concat();
        let MachineCmd::Update(cmd) = TestMachineCli::parse_from(argv).command else {
            panic!("expected machine update command");
        };
        cmd
    }

    #[test]
    fn update_changes_labels_alone_in_any_state() {
        assert!(parse_update(&["--label", "kit=git"]).changes_only_labels());
        assert!(parse_update(&["--remove-label", "kit"]).changes_only_labels());
        assert!(!parse_update(&["--label", "kit=git", "--cpus", "2"]).changes_only_labels());
        // A running machine applies an allow-list or port change alone, so a
        // label beside one must not ride along unapplied.
        let mixed = parse_update(&["--label", "kit=git", "--allow-host", "pypi.org"]);
        assert!(!mixed.changes_only_labels() && !mixed.changes_only_egress());
        let mixed = parse_update(&["--label", "kit=git", "-p", "3000:3000"]);
        assert!(!mixed.changes_only_labels() && !mixed.changes_only_ports());
    }

    #[test]
    fn update_sets_and_removes_labels() {
        let apply = |extra: &[&'static str], labels: &mut _| {
            let cmd = parse_update(extra);
            let set = smolvm::util::parse_labels(&cmd.labels).unwrap();
            cmd.apply_labels(labels, &set)
        };
        let mut labels: std::collections::BTreeMap<String, String> =
            [("owner", "exo"), ("kit", "git"), ("old", "1")]
                .into_iter()
                .map(|(k, v)| (k.to_string(), v.to_string()))
                .collect();
        let changes = apply(
            &[
                "--label",
                "kit=git,node",
                "--label",
                "new=a=b",
                "--remove-label",
                "old",
                "--remove-label",
                "absent",
            ],
            &mut labels,
        );
        assert_eq!(
            labels.into_iter().collect::<Vec<_>>(),
            [("kit", "git,node"), ("new", "a=b"), ("owner", "exo")]
                .map(|(k, v)| (k.to_string(), v.to_string()))
        );
        assert_eq!(
            changes,
            [
                "  removed label: old",
                "  label: kit=git,node",
                "  label: new=a=b"
            ]
        );

        // A key removed and set in one update ends up set.
        let mut labels = std::collections::BTreeMap::new();
        apply(
            &["--remove-label", "kit", "--label", "kit=git"],
            &mut labels,
        );
        assert_eq!(labels.get("kit").map(String::as_str), Some("git"));
    }

    #[test]
    fn update_changes_ports_alone_on_a_running_machine() {
        use smolvm::config::VmRecord;

        let parse_update = |argv: &[&str]| {
            let cli = TestMachineCli::parse_from(argv);
            let MachineCmd::Update(cmd) = cli.command else {
                panic!("expected machine update command");
            };
            cmd
        };
        let base = ["machine", "update", "--name", "p"];
        let with = |extra: &[&'static str]| parse_update(&[&base[..], extra].concat());

        assert!(with(&["-p", "3000:3000"]).changes_only_ports());
        assert!(with(&["--remove-port", "3000:3000"]).changes_only_ports());
        assert!(!with(&["-p", "3000:3000", "--cpus", "2"]).changes_only_ports());
        assert!(!with(&["-p", "3000:3000", "--allow-host", "pypi.org"]).changes_only_ports());
        assert!(!with(&["-p", "3000:3000", "--allow-host", "pypi.org"]).changes_only_egress());

        let record = VmRecord::new("p".to_string(), 1, 512, vec![], vec![(3000, 3000)], true);
        let next = with(&["-p", "8080:80", "--remove-port", "3000:3000"])
            .next_ports(&record)
            .unwrap();
        assert_eq!(next, vec![PortMapping::new(8080, 80)]);
        assert!(with(&["-p", "3000:4000"]).next_ports(&record).is_err());
    }

    #[test]
    fn allow_udp_is_parsed_on_run_create_and_update() {
        use smolvm::config::VmRecord;
        let rule = smolvm::smolfile::parse_allow_udp("192.0.2.0/24:3478-3480").unwrap();

        let cli = TestMachineCli::parse_from([
            "machine",
            "run",
            "--allow-udp",
            "192.0.2.0/24:3478-3480",
            "--",
            "true",
        ]);
        let MachineCmd::Run(cmd) = cli.command else {
            panic!("expected machine run command");
        };
        assert_eq!(cmd.allow_udp, vec![rule.clone()]);

        let cli = TestMachineCli::parse_from([
            "machine",
            "create",
            "--name",
            "u",
            "--allow-udp",
            "192.0.2.0/24:3478-3480",
        ]);
        let MachineCmd::Create(cmd) = cli.command else {
            panic!("expected machine create command");
        };
        assert_eq!(cmd.allow_udp, vec![rule.clone()]);

        let rejected: [&[&str]; 4] = [
            &["machine", "run", "--allow-udp", "10.0.0.0/8:0"],
            &["machine", "create", "--allow-udp", "example.com:53"],
            &[
                "machine",
                "update",
                "--name",
                "u",
                "--allow-udp",
                "1.1.1.1:9-1",
            ],
            &[
                "machine",
                "update",
                "--name",
                "u",
                "--remove-allow-udp",
                "1.1.1.1:9-1",
            ],
        ];
        for argv in rejected {
            assert!(TestMachineCli::try_parse_from(argv).is_err(), "{argv:?}");
        }
        assert!(TestMachineCli::try_parse_from([
            "machine",
            "update",
            "--name",
            "u",
            "--allow-udp",
            "1.1.1.1:1-9",
        ])
        .is_ok());
        assert!(TestMachineCli::try_parse_from([
            "machine",
            "update",
            "--name",
            "u",
            "--no-net",
            "--allow-udp",
            "1.1.1.1",
        ])
        .is_err());

        let parse_update = |argv: &[&str]| {
            let cli = TestMachineCli::parse_from(argv);
            let MachineCmd::Update(cmd) = cli.command else {
                panic!("expected machine update command");
            };
            cmd
        };
        let record = VmRecord::new("u".to_string(), 1, 512, vec![], vec![], false);
        let cmd = parse_update(&[
            "machine",
            "update",
            "--name",
            "u",
            "--allow-udp",
            "192.0.2.0/24:3478-3480",
        ]);
        assert!(cmd.changes_only_egress());
        let next = cmd.next_egress(&record).unwrap().unwrap();
        assert_eq!(next.egress_rules, vec![rule.clone()]);
        assert!(next.network);

        let cmd = parse_update(&[
            "machine",
            "update",
            "--name",
            "u",
            "--remove-allow-udp",
            "192.0.2.0/24:3478-3480",
        ]);
        assert!(cmd.changes_only_egress());
        let removed = cmd.next_egress(&next).unwrap().unwrap();
        assert!(removed.egress_rules.is_empty());
    }

    #[test]
    fn update_outbound_localhost_only_adds_the_loopback_cidrs() {
        use smolvm::config::VmRecord;

        let parse_update = |argv: &[&str]| {
            let cli = TestMachineCli::parse_from(argv);
            let MachineCmd::Update(cmd) = cli.command else {
                panic!("expected machine update command");
            };
            cmd
        };

        // The flag is sugar for the same two entries create's flag adds, and
        // repeating it never duplicates them.
        let mut record = VmRecord::new("lo".to_string(), 1, 512, vec![], vec![], true);
        record.allowed_cidrs = Some(vec!["127.0.0.0/8".to_string()]);
        let cmd = parse_update(&[
            "machine",
            "update",
            "--name",
            "lo",
            "--outbound-localhost-only",
        ]);
        let next = cmd
            .next_egress(&record)
            .expect("applies")
            .expect("egress changed");
        assert_eq!(
            next.allowed_cidrs.as_deref(),
            Some(["127.0.0.0/8".to_string(), "::1/128".to_string()].as_slice())
        );

        // Entry-by-entry removal undoes it, like any other allowed CIDR.
        let cmd = parse_update(&[
            "machine",
            "update",
            "--name",
            "lo",
            "--net",
            "--remove-allow-cidr",
            "127.0.0.0/8",
            "--remove-allow-cidr",
            "::1/128",
        ]);
        let next = cmd
            .next_egress(&next)
            .expect("applies")
            .expect("egress changed");
        assert_eq!(
            next.allowed_cidrs.as_deref().unwrap_or_default(),
            &[] as &[String]
        );

        // --no-net still conflicts, exactly as it does for --allow-cidr.
        assert!(TestMachineCli::try_parse_from([
            "machine",
            "update",
            "--name",
            "lo",
            "--no-net",
            "--outbound-localhost-only",
        ])
        .is_err());
    }

    #[test]
    fn external_interceptor_requires_a_named_start() {
        // The named-start assertion below fails if SMOLVM_MACHINE_NAME fills
        // --name, whether set by the env test running in parallel or by the
        // developer's own shell.
        let _env = machine_name_env_lock();
        let cli = TestMachineCli::parse_from([
            "machine",
            "start",
            "--name",
            "worker",
            "--egress-interceptor",
            "[::1]:43123",
        ]);
        let MachineCmd::Start(cmd) = cli.command else {
            panic!("expected machine start command");
        };
        assert_eq!(cmd.egress_interceptor, Some("[::1]:43123".parse().unwrap()));
        assert!(TestMachineCli::try_parse_from([
            "machine",
            "start",
            "--egress-interceptor",
            "[::1]:43123",
        ])
        .is_err());

        let cli = TestMachineCli::parse_from([
            "machine",
            "monitor",
            "--name",
            "worker",
            "--egress-interceptor",
            "127.0.0.1:43123",
        ]);
        let MachineCmd::Monitor(cmd) = cli.command else {
            panic!("expected machine monitor command");
        };
        assert_eq!(
            cmd.egress_interceptor,
            Some("127.0.0.1:43123".parse().unwrap())
        );
    }

    #[test]
    fn block_io_defaults_to_unset_and_accepts_async() {
        let cli = TestMachineCli::parse_from(["machine", "create", "--name", "default"]);
        let MachineCmd::Create(cmd) = cli.command else {
            panic!("expected machine create command");
        };
        assert_eq!(cmd.block_io, None);

        let cli = TestMachineCli::parse_from([
            "machine",
            "create",
            "--name",
            "queued",
            "--block-io",
            "async",
        ]);
        let MachineCmd::Create(cmd) = cli.command else {
            panic!("expected machine create command");
        };
        assert_eq!(
            cmd.block_io,
            Some(smolvm::data::resources::BlockIoEngine::Async)
        );

        let cli = TestMachineCli::parse_from([
            "machine",
            "update",
            "--name",
            "queued",
            "--block-io",
            "sync",
        ]);
        let MachineCmd::Update(cmd) = cli.command else {
            panic!("expected machine update command");
        };
        assert_eq!(
            cmd.block_io,
            Some(smolvm::data::resources::BlockIoEngine::Sync)
        );
    }

    // Documents the clap parsing behaviour: positionals before "--" land in
    // `command`, not `image`.  is_likely_image_ref() catches the unambiguous
    // cases before a VM is booted.
    #[test]
    fn run_image_ref_as_positional_lands_in_command_vec() {
        let cli = TestMachineCli::parse_from(["machine", "run", "ubuntu:22.04", "--", "bash"]);
        let MachineCmd::Run(cmd) = cli.command else {
            panic!("expected machine run command");
        };
        assert_eq!(cmd.image, None);
        // With trailing_var_arg, clap includes the "--" separator in the vec.
        assert_eq!(cmd.command, ["ubuntu:22.04", "--", "bash"]);
        // is_likely_image_ref catches this before the VM starts
        assert!(is_likely_image_ref(&cmd.command[0]));
    }

    // Machine options after `--` are workload arguments; clap cannot reject
    // them, so they must at least be named.
    #[test]
    fn create_flags_after_separator_are_detected() {
        let cli = TestMachineCli::parse_from([
            "machine",
            "create",
            "--name",
            "x",
            "--",
            "/bin/sh",
            "-c",
            "sleep infinity",
            "--mem",
            "32768",
            "--storage",
            "120",
            "--net",
        ]);
        let MachineCmd::Create(cmd) = cli.command else {
            panic!("expected machine create command");
        };
        // They configured nothing: no cap was given, so the default applies later.
        assert_eq!(cmd.mem, None);
        assert_eq!(cmd.storage, None);
        assert!(!cmd.net);
        assert_eq!(
            create_flags_in_workload(&cmd.command),
            ["--mem", "--storage", "--net"]
        );
    }

    #[test]
    fn create_workload_own_options_are_not_reported() {
        // A workload's own long options are not machine options, and short
        // flags are never reported — `-v`, `-e` and `-p` are too common.
        let words: Vec<String> = ["myserver", "--listen", "0.0.0.0", "-v", "-e", "-p", "8080"]
            .iter()
            .map(|s| s.to_string())
            .collect();
        assert!(create_flags_in_workload(&words).is_empty());
    }

    #[test]
    fn create_accepts_trailing_workload_command() {
        let cli = TestMachineCli::parse_from([
            "machine", "create", "--name", "golden", "--image", "alpine", "--", "echo", "hi",
        ]);
        let MachineCmd::Create(cmd) = cli.command else {
            panic!("expected machine create command");
        };
        assert_eq!(cmd.name, Some("golden".to_string()));
        assert_eq!(cmd.image, Some("alpine".to_string()));
        // The trailing command is captured (clap may include the "--" separator).
        let words: Vec<&str> = cmd
            .command
            .iter()
            .map(String::as_str)
            .filter(|s| *s != "--")
            .collect();
        assert_eq!(words, ["echo", "hi"]);
    }

    #[test]
    fn create_without_command_leaves_command_empty() {
        // Regression: adding the trailing COMMAND arg must not break the common
        // no-command form `machine create --name <name> --net`.
        let cli = TestMachineCli::parse_from(["machine", "create", "--name", "golden", "--net"]);
        let MachineCmd::Create(cmd) = cli.command else {
            panic!("expected machine create command");
        };
        assert_eq!(cmd.name, Some("golden".to_string()));
        assert!(cmd.command.is_empty());
        assert!(cmd.net);
    }

    #[test]
    fn create_rejects_bare_positional_name() {
        // Machine names are flags everywhere (issue #370). A bare positional —
        // the old `machine create myvm` habit — must error, not be silently
        // captured as the workload command.
        assert!(TestMachineCli::try_parse_from(["machine", "create", "myvm"]).is_err());
    }

    #[test]
    fn is_likely_image_ref_classifies_correctly() {
        // Unambiguous image references
        assert!(is_likely_image_ref("ubuntu:22.04")); // image:tag
        assert!(is_likely_image_ref("ghcr.io/org/image")); // registry/path
        assert!(is_likely_image_ref("library/alpine")); // namespace/image

        // Bare names are not flagged — indistinguishable from commands at parse time
        assert!(!is_likely_image_ref("alpine"));
        assert!(!is_likely_image_ref("bash"));

        // Absolute and relative paths are always commands
        assert!(!is_likely_image_ref("/bin/sh"));
        assert!(!is_likely_image_ref("./script.sh"));
    }

    #[test]
    fn prune_evicts_oldest_and_a_touch_saves_a_hot_entry() {
        let dir = tempfile::tempdir().unwrap();
        let write = |name: &str, bytes: usize| {
            let p = dir.path().join(name);
            std::fs::write(&p, vec![0u8; bytes]).unwrap();
            p
        };
        // Three 4 KiB entries; cap at 6 KiB forces evicting down to one.
        let cold = write("cold.smolmachine", 4096);
        let mid = write("mid.smolmachine", 4096);
        let hot = write("hot.smolmachine", 4096);

        // Establish an age order: cold < mid < hot, then simulate a cache HIT on
        // `cold` by touching it so it becomes the most-recently-used.
        let base = std::time::SystemTime::now() - std::time::Duration::from_secs(300);
        for (p, age) in [(&cold, 300), (&mid, 200), (&hot, 100)] {
            std::fs::OpenOptions::new()
                .write(true)
                .open(p)
                .unwrap()
                .set_modified(base + std::time::Duration::from_secs(300 - age))
                .unwrap();
        }
        touch_cache_entry(&cold); // hit → now newest

        // Cap at 8 KiB keeps two of the three 4 KiB entries, evicting exactly one.
        prune_init_cache(dir.path(), 8192, &hot);

        // `hot` is kept (explicit keep), `cold` survives (just touched), and the
        // now-oldest `mid` is the one evicted.
        assert!(hot.exists(), "the just-baked entry is always kept");
        assert!(cold.exists(), "a touched (recently-used) entry survives");
        assert!(!mid.exists(), "the least-recently-used entry is evicted");
    }
}

// ============================================================================
// Exec Command (Persistent) - Direct VM Execution
// ============================================================================

/// Resolve the persistent container overlay visible to CLI operations.
///
/// A fork clone inherits the golden's overlay directory through its CoW storage
/// disk. Addressing a new directory under the clone's name would silently give
/// `machine exec` and `machine cp` a clean image instead of the forked rootfs.
fn persistent_overlay_owner_for_record(
    machine_name: &str,
    record: Option<&smolvm::config::VmRecord>,
) -> String {
    smolvm::workload::persistent_overlay_owner_with_lineage(
        machine_name,
        record.and_then(|record| record.golden.as_deref()),
        record.and_then(|record| record.fork_overlay_owner.as_deref()),
    )
}

/// Execute a command in a running machine.
///
/// On a machine created from an image the command runs inside that image's
/// container; on a bare machine it runs in the VM's Alpine rootfs.
///
/// Examples:
///   smolvm machine exec -- uname -a
///   smolvm machine exec --name myvm -- df -h
///   smolvm machine exec -it -- /bin/sh
#[derive(Args, Debug)]
pub struct ExecCmd {
    /// Command and arguments to execute
    #[arg(trailing_var_arg = true, required = true, value_name = "COMMAND")]
    pub command: Vec<String>,

    /// Target machine (default: "default")
    #[arg(long, value_name = "NAME", env = smolvm::data::consts::ENV_SMOLVM_MACHINE_NAME)]
    pub name: Option<String>,

    /// Set working directory in the VM
    #[arg(short = 'w', long, value_name = "DIR")]
    pub workdir: Option<String>,

    /// Run as this user (name or `uid[:gid]`). Defaults to the machine's
    /// configured user, then the image's USER.
    #[arg(short = 'u', long, value_name = "USER")]
    pub user: Option<String>,

    /// Set environment variable (can be used multiple times)
    #[arg(short = 'e', long = "env", value_name = "KEY=VALUE")]
    pub env: Vec<String>,

    /// Inject a secret from a host env var (GUEST_VAR=HOST_VAR) for this exec,
    /// resolved on the host. The value never persists to the record.
    #[arg(long = "secret-env", value_name = "GUEST_VAR=HOST_VAR")]
    pub secret_env: Vec<String>,

    /// Inject a secret from a host file (GUEST_VAR=/abs/path) for this exec,
    /// resolved on the host. The value never persists to the record.
    #[arg(long = "secret-file", value_name = "GUEST_VAR=PATH")]
    pub secret_file: Vec<String>,

    /// Inject a secret from the host keychain (GUEST_VAR=SERVICE or
    /// GUEST_VAR=SERVICE/ACCOUNT): a macOS Keychain generic password, or a
    /// Linux Secret Service item, read at launch and never persisted.
    #[arg(
        long = "secret-keychain",
        value_name = "GUEST_VAR=SERVICE[/ACCOUNT]",
        help_heading = "Security"
    )]
    pub secret_keychain: Vec<String>,

    /// Kill command after duration (e.g., "30s", "5m")
    #[arg(long, value_parser = parse_duration, value_name = "DURATION")]
    pub timeout: Option<Duration>,

    /// Keep stdin open for interactive input
    #[arg(short = 'i', long)]
    pub interactive: bool,

    /// Allocate a pseudo-TTY (use with -i for shells)
    #[arg(short = 't', long)]
    pub tty: bool,

    /// Stream output in real-time (prints as it arrives)
    #[arg(long)]
    pub stream: bool,

    /// Detach: spawn the command in the background and return its PID
    /// immediately. The process keeps running (it is not killed when this
    /// command returns), so it can host long-lived services — e.g. a server
    /// bound to a published port. Incompatible with -i/-t and --stream.
    #[arg(short = 'd', long, conflicts_with_all = ["interactive", "tty", "stream"])]
    pub detach: bool,
}

impl ExecCmd {
    pub fn run(self) -> smolvm::Result<()> {
        let (manager, mut client) = vm_common::ensure_running_and_connect(&self.name)?;

        // Detach immediately — exec never owns the VM lifecycle. Without this,
        // any early return (failed exec, timeout, client signal) triggers
        // AgentManager::Drop which calls stop() and kills the VM.
        manager.detach();

        let env = parse_env_list(&self.env);

        // Load machine record for workdir and image info
        let name = self.name.clone().unwrap_or_else(|| "default".to_string());
        // A database failure is not an instruction to execute in the bare VM.
        let record = smolvm::db::SmolvmDb::open()?.get_vm(&name)?;

        // Resolve workdir: CLI --workdir flag takes priority over Smolfile/machine config
        let workdir = self
            .workdir
            .clone()
            .or_else(|| record.as_ref().and_then(|r| r.workdir.clone()));
        // Same precedence for the user: an explicit flag, then whatever the
        // machine was created with (or resolved from the image at first start).
        let user = self
            .user
            .clone()
            .or_else(|| record.as_ref().and_then(|r| r.user.clone()));
        let record_image = record.as_ref().and_then(|r| r.image.clone());

        // Check if this machine has an image — if so, exec inside the image's
        // rootfs via client.run_interactive()/run_non_interactive() instead of bare vm_exec().
        let mount_bindings = record
            .as_ref()
            .map(|r| mounts_to_virtiofs_bindings(&r.host_mounts()))
            .unwrap_or_default();

        // Base env for the exec: the record's persisted `env` plus its
        // `secret_refs` resolved to plaintext on the host (RecordReplay scope).
        // CLI `--env` flags are layered on top via `merge_env_overrides`. The
        // resolved plaintext lives only in this local for the exec's duration —
        // it is never written back to the record or the DB.
        let mut record_env: Vec<(String, String)> = match record.as_ref() {
            Some(r) => vm_common::record_env_with_secrets(r)?,
            None => Vec::new(),
        };
        // Ad-hoc `--secret-env`/`--secret-file` refs for this exec only. The CLI
        // user is TrustedLocal; resolved plaintext lives only in this local and
        // is layered under any explicit `--env` overrides below.
        let exec_secret_refs =
            parse_cli_secret_refs(&self.secret_env, &self.secret_file, &self.secret_keychain)?;
        record_env.extend(smolvm::secrets::expose_into_env(
            smolvm::secrets::resolve_refs_to_env(
                &exec_secret_refs,
                smolvm::secrets::ResolutionScope::TrustedLocal,
            )?,
        ));

        if let Some(ref image) = record_image {
            let image_info = match client.query(image) {
                Ok(info) => info,
                Err(e) => {
                    tracing::debug!(
                        error = %e,
                        image = %image,
                        "failed to query local image metadata"
                    );
                    None
                }
            };
            let configured_env = vm_common::merge_env_overrides(&record_env, &env);
            let defaults = vm_common::resolve_image_runtime_defaults(
                image_info.as_ref(),
                &configured_env,
                workdir.as_deref(),
                user.as_deref(),
            );
            // Image-based machine: exec inside the image's rootfs via crun.
            // Fork clones address the golden's inherited overlay; ordinary
            // machines use their own name.
            let overlay_owner = persistent_overlay_owner_for_record(&name, record.as_ref());
            // An exec may be what establishes the workload container — the
            // machine's command exited, or the image's own default was
            // short-lived — and that container is where the mount lives. Carry
            // the machine's volumes so the bucket is in whichever container
            // serves this session, not only when a long-running workload
            // happened to survive.
            let exec_s3_volumes = record
                .as_ref()
                .map(|r| smolvm::remote_volume::to_s3_volumes(&r.remote_volumes, &r.env))
                .unwrap_or_default();
            if self.detach {
                let config = smolvm::agent::RunConfig::new(image, self.command.clone())
                    .with_env(defaults.env)
                    .with_workdir(defaults.workdir)
                    .with_user(defaults.user)
                    .with_mounts(mount_bindings)
                    .with_s3_volumes(exec_s3_volumes.clone())
                    .with_s3_volumes(exec_s3_volumes.clone())
                    .with_persistent_overlay(Some(overlay_owner));
                let pid = client.run_background(config)?;
                println!("{pid}");
                return Ok(());
            }
            if self.interactive || self.tty {
                let config = smolvm::agent::RunConfig::new(image, self.command.clone())
                    .with_env(defaults.env.clone())
                    .with_workdir(defaults.workdir.clone())
                    .with_user(defaults.user.clone())
                    .with_mounts(mount_bindings)
                    .with_timeout(self.timeout)
                    .with_tty(self.tty)
                    .with_s3_volumes(exec_s3_volumes.clone())
                    .with_persistent_overlay(Some(overlay_owner.clone()));
                let exit_code = client.run_interactive(config)?;
                std::process::exit(exit_code);
            }

            if self.stream {
                let config = smolvm::agent::RunConfig::new(image, self.command.clone())
                    .with_env(defaults.env.clone())
                    .with_workdir(defaults.workdir.clone())
                    .with_user(defaults.user.clone())
                    .with_mounts(mount_bindings)
                    .with_timeout(self.timeout)
                    .with_s3_volumes(exec_s3_volumes.clone())
                    .with_persistent_overlay(Some(overlay_owner.clone()));
                let mut printer = ExecEventPrinter::default();
                // Written straight to stdout, so there is nothing to bound.
                client.set_streaming_output_cap(None);
                client.run_streaming_with(config, |event| printer.handle(event))?;
                std::process::exit(printer.exit_code);
            }

            let config = smolvm::agent::RunConfig::new(image, self.command.clone())
                .with_env(defaults.env)
                .with_workdir(defaults.workdir)
                .with_user(defaults.user)
                .with_mounts(mount_bindings)
                .with_timeout(self.timeout)
                .with_s3_volumes(exec_s3_volumes.clone())
                .with_persistent_overlay(Some(overlay_owner));
            let (exit_code, stdout, stderr) = client.run_non_interactive(config)?;
            vm_common::print_output_and_exit(&manager, exit_code, &stdout, &stderr);
        } else {
            // Bare VM: exec directly in the VM rootfs. Its agent runs every
            // command as root and has no per-command user, so a requested user
            // cannot be honoured. An explicit `--user` is refused rather than
            // silently run as root (as the embedded runtime does); a user the
            // machine was created with is only warned about, so machines that
            // already rely on the old behaviour keep working.
            if let Some(user) = &self.user {
                return Err(smolvm::Error::config(
                    "exec --user",
                    format!(
                        "running a command as '{user}' needs an image machine; \
                         a bare VM runs every command as root"
                    ),
                ));
            }
            if let Some(user) = &user {
                eprintln!(
                    "warning: this machine was created with user '{user}', but a bare VM \
                     runs every command as root; the user is not applied"
                );
            }
            // Merge record env + resolved secrets with CLI env, same as image path.
            let env = vm_common::merge_env_overrides(&record_env, &env);
            if self.detach {
                // Spawn detached in the guest root netns — no setsid/killpg, so
                // a daemon (e.g. a server on a published port) survives. TSI sees
                // the listen() and opens the host-side forward.
                let pid = client.vm_exec_background(self.command.clone(), env, workdir.clone())?;
                println!("{pid}");
                return Ok(());
            }
            if self.interactive || self.tty {
                let exit_code = client.vm_exec_interactive(
                    self.command.clone(),
                    env.clone(),
                    workdir.clone(),
                    self.timeout,
                    self.tty,
                )?;
                std::process::exit(exit_code);
            }

            if self.stream {
                let mut printer = ExecEventPrinter::default();
                client.set_streaming_output_cap(None);
                client.vm_exec_streaming_with(
                    self.command.clone(),
                    env.clone(),
                    workdir.clone(),
                    self.timeout,
                    |event| printer.handle(event),
                )?;
                std::process::exit(printer.exit_code);
            }

            let (exit_code, stdout, stderr) = client.vm_exec(
                self.command.clone(),
                env,
                workdir.clone(),
                self.timeout,
                None,
            )?;
            vm_common::print_output_and_exit(&manager, exit_code, &stdout, &stderr);
        }
    }
}

#[derive(Default)]
struct ExecEventPrinter {
    exit_code: i32,
}

impl ExecEventPrinter {
    fn handle(&mut self, event: smolvm::agent::ExecEvent) {
        match event {
            smolvm::agent::ExecEvent::Stdout(data) => {
                let mut out = std::io::stdout();
                exit_on_broken_pipe(out.write_all(&data).and_then(|()| out.flush()));
            }
            smolvm::agent::ExecEvent::Stderr(data) => {
                let mut err = std::io::stderr();
                exit_on_broken_pipe(err.write_all(&data).and_then(|()| err.flush()));
            }
            smolvm::agent::ExecEvent::Exit(code) => {
                self.exit_code = code;
            }
            smolvm::agent::ExecEvent::Error(msg) => {
                eprintln!("error: {}", msg);
                self.exit_code = 1;
            }
        }
    }
}

/// Stop when the reader of our output has gone (`exec --stream -- yes | head`),
/// as a command killed by SIGPIPE would: exit 141. Closing the connection makes
/// the agent kill the command; without this the CLI would relay its output into
/// a closed pipe for as long as it runs.
fn exit_on_broken_pipe(result: std::io::Result<()>) {
    if let Err(e) = result {
        if e.kind() == std::io::ErrorKind::BrokenPipe {
            std::process::exit(141);
        }
    }
}

// ============================================================================
// Shell Command
// ============================================================================

/// Open an interactive shell in a machine.
///
/// Shortcut for `machine exec -it -- /bin/sh`. The machine must be running.
///
/// Examples:
///   smolvm machine shell
///   smolvm machine shell --name myvm
///   smolvm machine sh --name myvm
#[derive(Args, Debug)]
pub struct ShellCmd {
    /// Target machine (default: "default")
    #[arg(long, short = 'n', value_name = "NAME", env = smolvm::data::consts::ENV_SMOLVM_MACHINE_NAME)]
    pub name: Option<String>,
}

impl ShellCmd {
    pub fn run(self) -> smolvm::Result<()> {
        // Delegate to exec with -it -- /bin/sh
        ExecCmd {
            command: vec!["/bin/sh".to_string()],
            name: self.name,
            workdir: None,
            user: None,
            env: vec![],
            secret_env: vec![],
            secret_file: vec![],
            secret_keychain: vec![],
            timeout: None,
            interactive: true,
            tty: true,
            stream: false,
            detach: false,
        }
        .run()
    }
}

// ============================================================================
// Create Command
// ============================================================================

/// Create a named machine configuration.
///
/// Creates a persistent VM configuration that can be started later.
/// Use `smolvm machine start --name <name>` to start, then
/// `smolvm machine exec --name <name> -- <command>` to run commands inside.
///
/// Examples:
///   smolvm machine create --name myvm
///   smolvm machine create --name webserver --cpus 2 --mem 1024 -p 80:80
#[derive(Args, Debug)]
pub struct CreateCmd {
    /// Restore cache used when `--from` names a stored checkpoint.
    #[command(flatten)]
    pub restore_cache: super::pack::RestoreCacheArgs,

    /// With `--from` a checkpoint: keep the hostname and machine ID it was
    /// saved with instead of giving the new machine its own identity. For
    /// rewinding a machine to an earlier save point, which skips about a second
    /// of identity reset; do not run two machines from one checkpoint with it
    #[arg(long)]
    pub keep_identity: bool,

    /// Name for the machine (auto-generated if omitted)
    #[arg(short = 'n', long, value_name = "NAME", env = smolvm::data::consts::ENV_SMOLVM_MACHINE_NAME)]
    pub name: Option<String>,

    /// Attach metadata to the machine (repeatable), e.g.
    /// `--label owner=exo --label sandbox=agent-7`.
    ///
    /// smolvm never interprets these. They exist so a process managing many
    /// machines can identify its own later — which sandbox a machine serves, who
    /// created it, whether it may be reclaimed — instead of encoding that into
    /// the name. Read them back with `machine ls --json`.
    #[arg(long = "label", value_name = "KEY=VALUE")]
    pub labels: Vec<String>,

    /// Container image: a registry reference (alpine, python:3.12-alpine), a
    /// `docker save` archive (./myapp.tar, or `-` to read one from stdin), or an
    /// unpacked rootfs directory (./rootfs/). A bare name is always a registry
    /// reference — pipe `docker save` to use a locally built image.
    #[arg(short = 'I', long, value_name = "IMAGE", value_parser = parse_image)]
    pub image: Option<String>,

    /// Raise the max accepted local image-archive size (e.g. 16GiB, 512M, or a
    /// raw byte count); default 8GiB. For legitimately large images — sets
    /// SMOLVM_MAX_IMAGE_BYTES for this run.
    #[arg(long = "max-image-size", value_name = "SIZE",
          value_parser = crate::cli::parsers::parse_size_bytes)]
    pub max_image_size: Option<u64>,

    /// Maximum vCPUs the machine may use [default: 4, or the Smolfile/pack
    /// value]. Idle vCPUs cost nothing; this caps consumption, not a reservation.
    #[arg(long, value_name = "N")]
    pub cpus: Option<u8>,

    /// Maximum memory in MiB the machine may use [default: half the host's
    /// RAM, at most 8192, or the Smolfile/pack value]. Elastic: only touched
    /// memory is committed.
    #[arg(long, value_name = "MiB")]
    pub mem: Option<u32>,

    /// Storage disk size in GiB (for OCI layers and container data)
    #[arg(long, value_name = "GiB")]
    pub storage: Option<u64>,

    /// Overlay disk size in GiB (for persistent rootfs changes)
    #[arg(long, value_name = "GiB")]
    pub overlay: Option<u64>,

    /// Host block I/O engine. Async uses restricted io_uring for raw disks on Linux.
    #[arg(long = "block-io", value_enum)]
    pub block_io: Option<smolvm::data::resources::BlockIoEngine>,

    /// When guest disk writes must reach the host's disk. `full` (default):
    /// a guest fsync waits for the host disk. `deferred`: guest writes reach
    /// it on the host's schedule, much faster for fsync-heavy work such as
    /// database commits, but a host crash can lose recent writes.
    #[arg(long = "disk-durability", value_enum)]
    pub disk_durability: Option<smolvm::data::resources::DiskDurability>,

    /// Attach a host disk image or block device (repeatable), appearing in the
    /// guest as /dev/vdc, /dev/vdd, ... in the order given. Append `:ro` for
    /// read-only. The disk is handed over raw — smolvm never formats or mounts
    /// it — so a machine can put, say, a database's WAL on a different device
    /// from its data.
    #[arg(long = "disk", value_name = "PATH[:ro]")]
    pub disk: Vec<String>,

    /// Mount a shared cache disk at a guest path: `BASE:/guest/path`. BASE is
    /// a disk image (raw or qcow2) that stays read-only and can back many
    /// machines at once; this machine reads it and writes only to its own
    /// fast local layer, which every branch of it copies. The guest mounts its
    /// ext4 filesystem, making one if BASE is blank.
    #[arg(
        long = "cache-disk",
        value_name = "BASE:/PATH",
        help_heading = "Resources"
    )]
    pub cache_disk: Option<String>,

    /// Mount host directory (can be used multiple times). Also accepts
    /// S3-compatible object storage, mounted inside the guest on every start:
    /// `s3://bucket/prefix:/data[:ro]` (credentials from --env
    /// AWS_ACCESS_KEY_ID/AWS_SECRET_ACCESS_KEY, optional AWS_ENDPOINT_URL
    /// for R2/MinIO; anonymous without them; needs --net; `:ro` is its only
    /// mode). Nothing is required of the image: the agent performs the mount
    /// itself. `:staged` runs from a guest-local copy, seeded at first boot,
    /// for metadata-heavy workloads; `machine sync` and graceful stop mirror it
    /// back onto the host source, deleting host files the copy lacks.
    /// A container path alone (`-v /var/lib/docker`) is a directory on the
    /// machine's own disk instead of its overlay root, which nested container
    /// runtimes need; it persists across stop and start.
    #[arg(
        short = 'v',
        long = "volume",
        value_name = "HOST|REMOTE:GUEST[:ro|rw|staged]"
    )]
    pub volume: Vec<String>,

    /// Allow trusted read-only host `/etc` and `/var/log` mounts below `/host`.
    /// This exposes sensitive host data to the guest and must not be used for
    /// untrusted workloads.
    #[arg(long)]
    pub allow_system_mounts: bool,

    /// Expose port from VM to host (single port or one-to-one range, repeatable; append /udp for UDP)
    #[arg(short = 'p', long = "port", value_parser = PortMappingSpec::parse, value_name = "PORT[-END]|HOST[-END]:GUEST[-END][/udp]")]
    pub port: Vec<PortMappingSpec>,

    /// Enable outbound network access
    #[arg(long)]
    pub net: bool,

    /// Select the networking backend.
    #[arg(long = "net-backend", value_enum)]
    pub net_backend: Option<NetworkBackend>,

    /// Custom DNS resolver for the guest (implies --net). Defaults to the host's
    /// own resolver, so this is only needed when that is not the one to use.
    #[arg(long, value_name = "IP")]
    pub dns: Option<std::net::Ipv4Addr>,

    /// Resolver option for the guest resolv.conf (repeatable, in order), e.g.
    /// `--dns-option timeout:1 --dns-option use-vc`. Written as one `options`
    /// line by every guest writer of resolv.conf (see `resolv.conf(5)`).
    /// glibc honors every accepted option; musl (Alpine) honors only
    /// `ndots`, `timeout` and `attempts` and ignores the rest.
    #[arg(long = "dns-option", value_name = "OPTION", value_parser = parse_dns_option)]
    pub dns_option: Vec<String>,

    /// Size of the workload's /dev/shm: bytes with a k/m/g suffix (`512m`,
    /// `2g`) or a share of guest RAM (`25%`). Defaults to half the RAM.
    #[arg(long = "shm-size", value_name = "SIZE", value_parser = parse_shm_size)]
    pub shm_size: Option<String>,

    /// IPv4 subnet for the guest link, e.g. 10.200.0.0/30 (implies --net,
    /// virtio-net). The gateway and resolver take the first address, the guest
    /// the second. Use it when the guest runs Tailscale or another VPN that
    /// claims the default 100.96.0.0/30.
    #[arg(long, value_name = "CIDR", value_parser = parse_guest_subnet)]
    pub guest_subnet: Option<String>,

    /// Join a named inter-VM network (implies --net, virtio-net only): members
    /// can reach each other by IP (100.96.N.2, leased at start; names do not
    /// resolve)
    #[arg(long = "network", value_name = "NAME")]
    pub network_name: Option<String>,

    /// Allow egress to specific CIDR range (can be used multiple times, implies --net)
    #[arg(long = "allow-cidr", value_parser = parse_cidr, value_name = "CIDR")]
    pub allow_cidr: Vec<String>,

    /// Deny egress to a CIDR range, checked before anything is allowed (can be used multiple times, implies --net)
    #[arg(long = "deny-cidr", value_parser = parse_cidr, value_name = "CIDR")]
    pub deny_cidr: Vec<String>,

    #[arg(long = "allow-udp", value_parser = smolvm::smolfile::parse_allow_udp, value_name = "CIDR[:PORT[-END]]", help = "Allow UDP to a CIDR, optionally on one port or a range, also under an egress interceptor; checked after every deny, DNS keeps its own path (can be used multiple times, implies --net)")]
    pub allow_udp: Vec<smolvm_protocol::EgressRule>,

    /// Allow egress to specific hostname, resolved at VM start (can be used multiple times, implies --net)
    #[arg(long = "allow-host", value_name = "HOSTNAME")]
    pub allow_host: Vec<String>,

    /// Opt-in egress pattern: exact hostname or `*.domain` subdomains only.
    #[arg(long = "allow-host-pattern", value_name = "PATTERN")]
    pub allow_host_pattern: Vec<String>,

    /// Pass this host's proxy into the workload: HTTPS_PROXY/HTTP_PROXY/
    /// ALL_PROXY/NO_PROXY from the environment, or on macOS the system proxy.
    /// A proxy on the host's loopback is rewritten to an address the guest can
    /// reach. Also used for the image pull. Implies --net.
    #[arg(long, help_heading = "Network")]
    pub use_host_proxy: bool,

    /// Trust the certificates this host trusts for image pulls and the workload — e.g. a
    /// corporate TLS-inspection root on the host. Mounts them read-only at
    /// /etc/smolvm-host-trust/ca-bundle.pem and points SSL_CERT_FILE,
    /// NODE_EXTRA_CA_CERTS, REQUESTS_CA_BUNDLE and similar at it.
    /// SMOLVM_HOST_CA_BUNDLE selects another bundle. Not with --credential.
    #[arg(long, help_heading = "Network")]
    pub trust_host_certs: bool,

    /// Bind a credential the workload may use without ever seeing it:
    /// NAME=ENV_VAR@HOST[,HOST...][:body][:set-header=HEADER]. The guest gets a placeholder in ENV_VAR;
    /// the host substitutes the real value (from a `--secret-env`/`--secret-file`
    /// ref of the same name, else the host variable ENV_VAR) only on HTTPS
    /// requests to the listed hosts. Add :body for OAuth form-body tokens or
    /// :set-header=HEADER to set a request header to the complete secret value.
    /// Can be used multiple times; implies --net.
    #[arg(
        long = "credential",
        value_name = "NAME=ENV_VAR@HOST[,HOST...][:body][:set-header=HEADER]"
    )]
    pub credential: Vec<String>,

    /// Restrict outbound to localhost only (implies --net)
    #[arg(long)]
    pub outbound_localhost_only: bool,

    /// Block private, internal and link-local destinations (the LAN, cloud
    /// metadata, CGNAT, the host's loopback) while the public internet stays
    /// open. Implies --net.
    #[arg(long)]
    pub block_private: bool,

    /// Re-open one private range under --block-private, such as an internal
    /// registry (implies --block-private). Can be used multiple times.
    #[arg(long = "allow-private", value_name = "CIDR", value_parser = parse_cidr)]
    pub allow_private: Vec<String>,

    /// Enable GPU acceleration (Vulkan via virtio-gpu)
    #[arg(long)]
    pub gpu: bool,

    /// Expose the host's virtualization extensions so the guest can run KVM --
    /// i.e. run smolvm, QEMU or another hypervisor inside the machine. Off by
    /// default: nesting turns work the guest would do natively into vmexits.
    /// Needs nested KVM on a Linux host (kvm_intel/kvm_amd nested=1) or an
    /// M3 or newer Mac on macOS 15+.
    #[arg(long = "nested")]
    pub nested_virt: bool,

    /// GPU shared-memory region size in MiB. Ignored without --gpu.
    /// Default 4096 (4 GiB). Must be > 0.
    #[arg(
        long = "gpu-vram",
        value_name = "MiB",
        value_parser = crate::cli::parsers::parse_gpu_vram_mib,
    )]
    pub gpu_vram_mib: Option<u32>,

    /// Enable Rosetta 2 for x86_64 binary translation on Apple Silicon
    #[arg(long)]
    pub rosetta: bool,

    /// Image platform to pull for a multi-arch image, for example linux/amd64.
    /// Defaults to linux/amd64 with --rosetta, else the guest's architecture.
    #[arg(long = "oci-platform", value_name = "OS/ARCH")]
    pub oci_platform: Option<String>,

    /// Expose a Unix socket the guest listens on to the host (repeatable). The
    /// host reaches it at the given host path, or `<basename>` in
    /// `smolvm machine data-dir` by default. Format: GUEST_PATH[:HOST_PATH].
    #[arg(long = "expose-socket", value_name = "GUEST_PATH[:HOST_PATH]")]
    pub expose_socket: Vec<String>,

    /// Mount a host Unix socket into the guest (repeatable), so a guest process
    /// reaches the host service at GUEST_PATH. Format: HOST_PATH:GUEST_PATH.
    #[arg(long = "mount-socket", value_name = "HOST_PATH:GUEST_PATH")]
    pub mount_socket: Vec<String>,

    /// Run command once, on the machine's first start (can be used multiple times)
    #[arg(long = "init", value_name = "COMMAND")]
    pub init: Vec<String>,

    /// Set environment variable (can be used multiple times)
    #[arg(short = 'e', long = "env", value_name = "KEY=VALUE")]
    pub env: Vec<String>,

    /// Set working directory inside the machine
    #[arg(short = 'w', long = "workdir", value_name = "DIR")]
    pub workdir: Option<String>,

    /// Run the workload as this user, like `docker run --user`: a name from the
    /// image or a numeric `uid[:gid]`. Overrides the image's USER, so a workload
    /// can match the owner of a mounted host directory. `init` commands still
    /// run as root.
    #[arg(short = 'u', long = "user", value_name = "USER")]
    pub user: Option<String>,

    /// Forward host SSH agent into the VM (enables git/ssh without exposing keys)
    #[arg(long)]
    pub ssh_agent: bool,

    /// Stop the machine once its workload exits, whatever the exit status.
    /// The guest flushes storage as for `machine stop`, then powers off.
    #[arg(long)]
    pub stop_on_exit: bool,

    /// Signal sent to the workload when the machine stops, so it can save its
    /// state and exit (e.g. SIGINT, SIGRTMIN+3; default SIGTERM)
    #[arg(long, value_name = "SIGNAL", value_parser = parse_stop_signal_arg)]
    pub stop_signal: Option<String>,

    /// Seconds the workload gets to exit after its stop signal before it is
    /// killed (default 10, at most 300)
    #[arg(long, value_name = "SECONDS", value_parser = parse_stop_timeout_arg)]
    pub stop_timeout: Option<u64>,

    /// Remote guest CUDA Driver-API calls to the host NVIDIA GPU over vsock
    #[arg(long)]
    pub cuda: bool,

    /// Ask compatible CUDA frameworks to graph safe compiled regions.
    /// Implies --cuda; arbitrary eager CUDA calls are not captured.
    #[arg(long)]
    pub auto_graph: bool,

    /// Expose the guest's Docker daemon socket to the host as a Unix socket
    /// (DOCKER_HOST=unix://…). Requires dockerd running in the VM.
    #[arg(long)]
    pub docker_socket: bool,

    /// Publish every TCP port a process in the machine listens on at the same
    /// port on host loopback while it listens (dev servers, `docker run -p`).
    /// A host port already in use is skipped; ports below 1024 are not
    /// published automatically. Applies when the CLI starts the machine.
    #[arg(long)]
    pub auto_ports: bool,

    /// Never publish this guest port automatically (repeatable). Implies
    /// --auto-ports.
    #[arg(long = "auto-ports-exclude", value_name = "PORT")]
    pub auto_ports_exclude: Vec<u16>,

    /// Inject a secret from a host env var (GUEST_VAR=HOST_VAR), resolved at
    /// each launch. Only the reference is persisted, never the value.
    #[arg(long = "secret-env", value_name = "GUEST_VAR=HOST_VAR")]
    pub secret_env: Vec<String>,

    /// Inject a secret from a host file (GUEST_VAR=/abs/path), resolved at
    /// each launch. Only the reference is persisted, never the value.
    #[arg(long = "secret-file", value_name = "GUEST_VAR=PATH")]
    pub secret_file: Vec<String>,

    /// Inject a secret from the host keychain (GUEST_VAR=SERVICE or
    /// GUEST_VAR=SERVICE/ACCOUNT): a macOS Keychain generic password, or a
    /// Linux Secret Service item, read at launch and never persisted.
    #[arg(
        long = "secret-keychain",
        value_name = "GUEST_VAR=SERVICE[/ACCOUNT]",
        help_heading = "Security"
    )]
    pub secret_keychain: Vec<String>,

    /// Load configuration from a Smolfile (TOML)
    #[arg(long = "smolfile", visible_short_alias = 's', value_name = "PATH")]
    pub smolfile: Option<PathBuf>,

    /// Create from a `.smolmachine` pack or restore a `.smolcheckpoint`. The
    /// artifact supplies the defaults (a pack) or fixed state (a live
    /// checkpoint); flags and a Smolfile override the defaults, and a setting
    /// a checkpoint fixes is refused by name.
    #[arg(long, value_name = "PATH", conflicts_with = "image")]
    pub from: Option<PathBuf>,

    /// Read a machine spec (JSON) from stdin, as the embedded runtime hands
    /// one over; flags given alongside apply on top.
    #[arg(long, hide = true, conflicts_with = "smolfile")]
    pub spec_stdin: bool,

    /// With --from <checkpoint>: restore an earlier generation the checkpoint
    /// retains — `~N` (N back along its history), a generation id, or an id
    /// prefix. Quote `~N` in zsh, e.g. `--at '~2'`. See `machine checkpoint-log`.
    #[arg(long, value_name = "GENERATION", requires = "from")]
    pub at: Option<String>,

    /// Command to run as the machine's persistent workload (image machines).
    /// Launched as a detached container on every `start`, so it stays running
    /// (e.g. a pre-warmed browser to be branched). Without this, the image's own
    /// ENTRYPOINT/CMD is launched instead; if the image defines neither (e.g.
    /// a bare rootfs directory), the machine boots to just the agent and
    /// commands come from `exec`/`shell`.
    ///
    /// `last = true` requires the `--` separator. With the machine name now a
    /// flag, a bare positional (an old-style `machine create myvm`) must fail
    /// loudly instead of being silently captured as the workload command.
    #[arg(last = true, value_name = "COMMAND")]
    pub command: Vec<String>,
}

/// Parse and validate every `--disk` value.
///
/// Validation happens at create/run time rather than at boot: a machine
/// recorded against an unreadable device would otherwise fail every start with
/// a virtio-blk error that names neither the disk nor the reason.
/// Clap value parser for `--guest-subnet`: validate, and store the canonical form.
fn parse_stop_signal_arg(value: &str) -> Result<String, String> {
    smolvm::workload::validate_stop_settings(Some(value), None)?;
    Ok(value.to_string())
}

fn parse_stop_timeout_arg(value: &str) -> Result<u64, String> {
    let secs = value
        .parse::<u64>()
        .map_err(|_| format!("'{value}' is not a whole number of seconds"))?;
    smolvm::workload::validate_stop_settings(None, Some(secs))?;
    Ok(secs)
}

fn parse_guest_subnet(value: &str) -> Result<String, String> {
    value
        .parse::<smolvm_network::GuestSubnet>()
        .map(|subnet| subnet.to_string())
}

/// Parse and check a `--cache-disk` value, before anything is recorded.
fn parse_cache_disk(spec: Option<&str>) -> smolvm::Result<Option<smolvm::data::disk::CacheDisk>> {
    let Some(spec) = spec else {
        return Ok(None);
    };
    if cfg!(target_os = "windows") {
        return Err(smolvm::Error::config(
            "cache disk",
            "cache disks are not supported on Windows yet",
        ));
    }
    let cache = smolvm::data::disk::CacheDisk::parse(spec)
        .map_err(|e| smolvm::Error::config("cache disk", e))?;
    cache
        .validate()
        .map_err(|e| smolvm::Error::config("cache disk", e))?;
    Ok(Some(cache))
}

fn parse_attached_disks(specs: &[String]) -> smolvm::Result<Vec<smolvm::data::disk::AttachedDisk>> {
    specs
        .iter()
        .map(|spec| {
            let mut disk = smolvm::data::disk::AttachedDisk::parse(spec)
                .map_err(|e| smolvm::Error::agent("attach disk", e))?;
            disk.validate()
                .map_err(|e| smolvm::Error::agent("attach disk", e))?;
            disk.pin_format();
            Ok(disk)
        })
        .collect()
}

impl CreateCmd {
    pub fn run(self) -> smolvm::Result<()> {
        let record = self.create()?;
        vm_common::print_created(&record);
        Ok(())
    }

    /// Create the machine this command describes and return its record,
    /// without reporting it. Front ends that wrap `machine create` (the `smol`
    /// CLI) call this so every option takes the one path.
    pub fn create(mut self) -> smolvm::Result<smolvm::VmRecord> {
        let host = crate::cli::host_network::HostNetwork::resolve(
            self.use_host_proxy,
            self.trust_host_certs,
            !self.credential.is_empty(),
        )?;
        self.env = host
            .env
            .into_iter()
            .chain(std::mem::take(&mut self.env))
            .collect();
        self.volume.extend(host.volumes);
        self.net |= self.use_host_proxy;
        // Everything after `--` is the workload, so machine options written
        // there are handed to the guest command and quietly do not configure the
        // machine — a swallowed `--mem`/`--storage` boots a machine at the
        // defaults with no diagnostic. Rejecting them is not an option (a
        // workload may legitimately take an option of the same name), so name
        // them. Checked before the `--from` branch so both create paths warn.
        let stray_flags = create_flags_in_workload(&self.command);
        if !stray_flags.is_empty() {
            eprintln!(
                "note: {} came after `--`, so {} passed to the workload and did not \
                 configure the machine. Machine options go before `--`.",
                stray_flags.join(", "),
                if stray_flags.len() == 1 {
                    "it was"
                } else {
                    "they were"
                }
            );
        }

        // --max-image-size raises the archive cap for this invocation by setting
        // the env var the resolver reads (image_source::max_archive_bytes).
        if let Some(bytes) = self.max_image_size {
            std::env::set_var("SMOLVM_MAX_IMAGE_BYTES", bytes.to_string());
        }
        let (image, spec, caller) = self.create_spec()?;

        // --from: a .smolmachine pack or a live checkpoint.
        if let Some(ref sidecar_path) = self.from {
            if image.is_some() {
                return Err(smolvm::Error::config(
                    "create machine",
                    "the Smolfile names an image, but --from already supplies the machine's \
                     root filesystem; remove one of them",
                ));
            }
            return self.run_from_smolmachine(sidecar_path, spec, caller);
        }

        // A registry --image can name a smolmachine PACK artifact (e.g.
        // registry.smolmachines.com/library/alpine), whose single "layer" is a
        // full .smolmachine sidecar — not an OCI filesystem layer the in-guest
        // puller could unpack (its multi-GiB storage.ext4 would fill the guest
        // disk). Probe the manifest on the host and, if so, pull the sidecar
        // and continue exactly as `--from`; a failed probe falls back to the
        // normal in-guest pull.
        if let Some(img) = image.as_deref() {
            if let Some(sidecar) = smolvm::data::pack_ref::resolve_pack_ref_blocking(img)? {
                return self.run_from_smolmachine(&sidecar, spec, caller);
            }
        }

        // Resolve the image source on the host now, AFTER the CLI flag and the
        // Smolfile have been merged, so both take the same path: a registry
        // reference passes through; a local `docker save` archive or unpacked
        // rootfs directory is staged into the content-addressed cache and the
        // resulting `local:…` reference persisted, so `start` re-derives the
        // mount without a registry pull. Resolving only the flag here left a
        // Smolfile `image = "./x.tar"` stored verbatim, and `start` then asked
        // the registry for it.
        let image = match image {
            Some(img) => {
                use smolvm::data::image_source::{classify, resolve, ResolvedImage};
                Some(match resolve(classify(&img))? {
                    ResolvedImage::Registry(reference) => reference,
                    ResolvedImage::Local { reference, .. } => reference,
                })
            }
            None => None,
        };
        let resolved = smolvm::machine_spec::resolve(
            smolvm::machine_spec::SpecSource::from_image(image.as_deref()),
            spec,
            caller,
        )?;
        let name = self
            .name
            .clone()
            .unwrap_or_else(smolvm::util::generate_machine_name);
        let record = resolved.to_record(&name)?;
        vm_common::warn_record_hosts_blocked_by_private_floor(&record);
        let reservation = vm_common::CreateVmReservation::reserve(&name)?;
        reservation.commit(&record)?;
        Ok(record)
    }

    /// The machine this command asks for: its flags merged over a Smolfile,
    /// or over the spec an embedder hands in on stdin (`--spec-stdin`), and
    /// who is asking. The image is returned apart, since `--from` replaces it.
    ///
    /// Every field is named, so a new flag does not compile until it reaches
    /// the spec or is named as something else (the source, the name).
    pub(crate) fn create_spec(
        &self,
    ) -> smolvm::Result<(
        Option<String>,
        smolvm::machine_spec::CreateSpec,
        smolvm::machine_spec::Caller,
    )> {
        let CreateCmd {
            // How a stored checkpoint is fetched, not what the machine is.
            restore_cache: _,
            keep_identity,
            // The machine's name is not an option of it.
            name: _,
            labels,
            image,
            // Applied by `run` for this invocation's image resolution.
            max_image_size: _,
            cpus,
            mem,
            storage,
            overlay,
            block_io,
            disk_durability,
            disk,
            cache_disk,
            volume,
            allow_system_mounts,
            port,
            net,
            net_backend,
            dns,
            dns_option,
            shm_size,
            guest_subnet,
            network_name,
            allow_cidr,
            deny_cidr,
            allow_udp,
            allow_host,
            allow_host_pattern,
            // Folded into env, volume and net by `run` before this.
            use_host_proxy: _,
            trust_host_certs: _,
            credential,
            outbound_localhost_only,
            block_private,
            allow_private,
            gpu,
            nested_virt,
            gpu_vram_mib,
            rosetta,
            oci_platform,
            expose_socket,
            mount_socket,
            init,
            env,
            workdir,
            user,
            ssh_agent,
            stop_on_exit,
            stop_signal,
            stop_timeout,
            cuda,
            auto_graph,
            docker_socket,
            auto_ports,
            auto_ports_exclude,
            secret_env,
            secret_file,
            secret_keychain,
            smolfile,
            spec_stdin,
            // The source.
            from: _,
            at: _,
            command,
        } = self;

        let (cli_allow_cidrs, cli_net, cli_dns_filter_hosts) = resolve_egress_flags(
            allow_cidr.clone(),
            allow_host.clone(),
            allow_host_pattern.clone(),
            *outbound_localhost_only,
            *net,
        )?;
        let crate::cli::smolfile::CliSpec {
            image,
            volumes,
            spec: mut cli,
        } = crate::cli::smolfile::build_create_spec(
            image.clone(),
            None, // entrypoint: from a Smolfile only
            command.clone(),
            *cpus,
            *mem,
            volume.clone(),
            port.clone(),
            cli_net,
            *net_backend,
            *dns,
            network_name.clone(),
            init.clone(),
            env.clone(),
            workdir.clone(),
            user.clone(),
            smolfile.clone(),
            *storage,
            *overlay,
            *block_io,
            cli_allow_cidrs,
            smolvm::util::parse_labels(labels)?,
        )?;

        // Volume specs: storage-disk paths, remote volumes and host directories.
        let (volume_specs, disk_volumes) =
            smolvm::data::storage::split_disk_volume_specs(&volumes)?;
        let (host_specs, remote_volumes) = smolvm::remote_volume::split_specs(&volume_specs)?;
        cli.mounts = HostMount::parse_with_system_mounts(&host_specs, *allow_system_mounts)?;
        cli.remote_volumes = remote_volumes;
        cli.disk_volumes = disk_volumes;

        // Flags a Smolfile has no key for, and flags that add to one.
        if *block_private || !allow_private.is_empty() {
            let exceptions = cli.block_private.get_or_insert_with(Vec::new);
            for cidr in allow_private {
                if !exceptions.contains(cidr) {
                    exceptions.push(cidr.clone());
                }
            }
            cli.net = true;
        }
        if !dns_option.is_empty() {
            cli.dns_options = dns_option.clone();
        }
        if shm_size.is_some() {
            cli.shm_size = shm_size.clone();
        }
        if !deny_cidr.is_empty() {
            let mut rules = vm_common::deny_cidr_rules(deny_cidr);
            rules.append(&mut cli.egress_rules);
            cli.egress_rules = rules;
            cli.net = true;
        }
        if !allow_udp.is_empty() {
            cli.egress_rules.extend_from_slice(allow_udp);
            cli.net = true;
        }
        cli.nested_virt |= *nested_virt;
        if guest_subnet.is_some() {
            cli.guest_subnet = guest_subnet.clone();
        }
        if disk_durability.is_some() {
            cli.disk_durability = *disk_durability;
        }
        // Attached host disks are validated at create, not at start: a machine
        // recorded against an unreadable device would fail every start with a
        // virtio-blk error that says nothing about which disk or why.
        cli.disks = parse_attached_disks(disk)?;
        cli.cache_disk = parse_cache_disk(cache_disk.as_deref())?;
        if *auto_graph {
            smolvm::util::enable_cuda_auto_graph_env(&mut cli.env);
            cli.cuda = true;
        }
        cli.allowed_hosts = match (cli.allowed_hosts.take(), cli_dns_filter_hosts) {
            (Some(mut from_smolfile), Some(mut from_cli)) => {
                from_smolfile.append(&mut from_cli);
                Some(from_smolfile)
            }
            (Some(from_smolfile), None) => Some(from_smolfile),
            (None, some) => some,
        };
        if !credential.is_empty() {
            let policy = cli.credentials.get_or_insert_with(Default::default);
            for spec in credential {
                policy.credentials.push(
                    smolvm::credentials::parse_credential_flag(spec)
                        .map_err(|e| smolvm::Error::config("--credential", e))?,
                );
            }
            cli.net = true;
        }
        cli.published_sockets = parse_published_sockets(expose_socket, mount_socket)?;
        // CLI `--secret-*` refs win over Smolfile `[secrets]` of the same name.
        for (key, r) in parse_cli_secret_refs(secret_env, secret_file, secret_keychain)? {
            cli.secret_refs.insert(key, r);
        }
        cli.ssh_agent |= *ssh_agent;
        cli.stop_on_exit |= *stop_on_exit;
        if stop_signal.is_some() {
            cli.stop_signal = stop_signal.clone();
        }
        if stop_timeout.is_some() {
            cli.stop_timeout_secs = *stop_timeout;
        }
        cli.cuda |= *cuda;
        cli.docker_socket |= *docker_socket;
        cli.auto_ports =
            merge_auto_ports_flags(cli.auto_ports.take(), *auto_ports, auto_ports_exclude);
        cli.gpu |= *gpu;
        cli.rosetta |= *rosetta;
        if oci_platform.is_some() {
            cli.oci_platform = oci_platform.clone();
        }
        // CLI --gpu-vram takes precedence over Smolfile gpu_vram.
        if gpu_vram_mib.is_some() {
            cli.gpu_vram_mib = *gpu_vram_mib;
        }
        cli.keep_identity |= *keep_identity;

        if *spec_stdin {
            // An embedder's spec, with any flags given alongside on top.
            let mut json = String::new();
            std::io::Read::read_to_string(&mut std::io::stdin(), &mut json)
                .map_err(|e| smolvm::Error::config("--spec-stdin", e.to_string()))?;
            let base: smolvm::machine_spec::CreateSpec = serde_json::from_str(&json)
                .map_err(|e| smolvm::Error::config("--spec-stdin", e.to_string()))?;
            return Ok((
                image,
                base.overlay(cli),
                smolvm::machine_spec::Caller::Embedded,
            ));
        }
        Ok((image, cli, smolvm::machine_spec::Caller::Cli))
    }

    /// Create a machine from a .smolmachine artifact: a pack, or a live
    /// checkpoint to restore.
    fn run_from_smolmachine(
        &self,
        sidecar_path: &std::path::Path,
        spec: smolvm::machine_spec::CreateSpec,
        caller: smolvm::machine_spec::Caller,
    ) -> smolvm::Result<smolvm::VmRecord> {
        if !sidecar_path.exists() {
            return Err(smolvm::Error::config(
                "create from .smolmachine",
                format!("file not found: {}", sidecar_path.display()),
            ));
        }

        // Read manifest from the sidecar to get image metadata.
        let footer = if sidecar_path.is_dir() {
            None
        } else {
            Some(smolvm::portable_checkpoint::verified_sidecar_footer(
                sidecar_path,
            )?)
        };
        // A delta carries only changed objects. Complete it from the held base
        // before the stored-checkpoint path attempts to materialize its files.
        let imported = if footer.is_some()
            && smolvm_pack::packer::read_manifest_from_sidecar(sidecar_path)
                .map_err(|e| smolvm::Error::agent("read .smolmachine", e.to_string()))?
                .checkpoint
                .as_ref()
                .is_some_and(|checkpoint| checkpoint.base.is_some())
        {
            smolvm::checkpoint_delta::import(sidecar_path)?
        } else {
            None
        };
        // A verified single file carrying its history unpacks into a directory
        // checkpoint; everything below then follows the stored-checkpoint path.
        let unpacked = if footer.is_some() && imported.is_none() {
            smolvm::portable_checkpoint::unpack_verified_history_file(sidecar_path)?
        } else {
            None
        };
        let sidecar_path: &std::path::Path = imported
            .as_ref()
            .map(|checkpoint| checkpoint.directory.as_path())
            .or_else(|| unpacked.as_ref().map(|d| d.path()))
            .unwrap_or(sidecar_path);
        let stored = sidecar_path.is_dir();
        let footer = if stored { None } else { footer };
        let generation =
            smolvm::portable_checkpoint::resolve_generation(sidecar_path, self.at.as_deref())?;
        let manifest = if stored {
            smolvm::checkpoint_store::read_manifest_at(sidecar_path, generation.as_deref())
                .map_err(|e| smolvm::Error::agent("read stored checkpoint", e.to_string()))?
        } else {
            smolvm_pack::packer::read_manifest_from_sidecar(sidecar_path)
                .map_err(|e| smolvm::Error::agent("read .smolmachine", e.to_string()))?
        };
        let checkpoint = manifest.checkpoint.clone();

        // Reject a cross-architecture artifact up front: a packed VM/image carries
        // native binaries and cannot boot under a different-arch guest kernel. Only
        // the guest arch must match — the host OS does not (see the fn's docs).
        smolvm::platform::ensure_artifact_arch_matches_host(&manifest.platform)?;

        // Every option, from the flags, a Smolfile or an embedder, against
        // what the artifact supplies or fixes: one set of rules for every
        // creation path. Refusals happen here, before any disk work.
        let resolved = smolvm::machine_spec::resolve(
            smolvm::machine_spec::SpecSource::from_manifest(&manifest),
            spec,
            caller,
        )?;

        // A VM-mode pack (`--from-vm`) carries the source VM's overlay+storage
        // DISKS (the real rootfs), not OCI layers. The disks are seeded from
        // the templates after extraction below, or the machine boots the bare
        // agent-rootfs with no /bin/sh (mirrors pack_run + the serve API create
        // path).
        struct VmModeSeed {
            overlay_template: Option<String>,
            storage_template: Option<String>,
            overlay_logical_size: Option<u64>,
            storage_logical_size: Option<u64>,
        }
        let vm_seed = if checkpoint.is_none() && manifest.mode == smolvm_pack::format::PackMode::Vm
        {
            Some(VmModeSeed {
                overlay_template: manifest
                    .assets
                    .overlay_template
                    .as_ref()
                    .map(|t| t.path.clone()),
                storage_template: manifest
                    .assets
                    .storage_template
                    .as_ref()
                    .map(|t| t.path.clone()),
                overlay_logical_size: manifest.assets.overlay_logical_size,
                storage_logical_size: manifest.assets.storage_logical_size,
            })
        } else {
            None
        };

        // Resolve the canonical path for storage in VmRecord.
        let canonical_path = sidecar_path
            .canonicalize()
            .unwrap_or_else(|_| sidecar_path.to_path_buf())
            .to_string_lossy()
            .into_owned();

        let name = self
            .name
            .clone()
            .unwrap_or_else(smolvm::util::generate_machine_name);
        let name_for_layers = name.clone();

        // A restored guest resumes with the devices it was captured with: a
        // checkpoint of a machine with a cache disk restores over the same
        // base, and one without takes none.
        let cache_base = match checkpoint.as_ref() {
            Some(checkpoint) => smolvm::portable_checkpoint::resolve_cache_base(
                checkpoint,
                resolved.cache_disk.as_ref(),
            )?,
            None => None,
        };

        let mut record = resolved.to_record(&name)?;
        vm_common::warn_record_hosts_blocked_by_private_floor(&record);
        // The pack whose layers this machine mounts. An ordinary checkpoint's
        // transport pack is never an OCI-layer source and must not add a
        // virtiofs device; a packed-layer checkpoint's source pack is attached
        // again below once it has been verified.
        record.source_smolmachine = (checkpoint.is_none()
            || checkpoint
                .as_ref()
                .is_some_and(|checkpoint| checkpoint.packed_layers.is_some()))
        .then_some(canonical_path);
        let reservation = vm_common::CreateVmReservation::reserve(&name_for_layers)?;

        // Create the machine data dir while the DB reservation is held, then
        // extract before publishing the VM row. Other processes either see the
        // reservation conflict or the finished VM, never a half-created record.
        let create_result = (|| -> smolvm::Result<()> {
            let manager = AgentManager::for_vm_with_sizes(
                &name_for_layers,
                record.storage_gb,
                record.overlay_gb,
            )?;

            if checkpoint.is_none() {
                if let Some(size) =
                    smolvm::pack_seed::try_seed(&name_for_layers, sidecar_path, record.storage_gb)?
                {
                    record.packed_image_on_storage = true;
                    record.storage_gb = Some(size);
                    reservation.commit(&record)?;
                    return Ok(());
                }
            }

            let cache_dir = smolvm::agent::machine_layers_cache_dir(&name_for_layers);
            smolvm_pack::extract::force_detach_layers_volume(&cache_dir);
            match std::fs::remove_dir_all(&cache_dir) {
                Ok(()) => {}
                Err(e) if e.kind() == std::io::ErrorKind::NotFound => {}
                Err(e) => {
                    return Err(smolvm::Error::agent(
                        "clear packed layers cache",
                        e.to_string(),
                    ));
                }
            }

            println!("Extracting .smolmachine assets...");
            let result = if stored {
                smolvm::portable_checkpoint::materialize_for_restore_at(
                    sidecar_path,
                    &cache_dir,
                    generation.as_deref(),
                    self.restore_cache.cache(),
                )?;
                Ok((cache_dir.clone(), None))
            } else if smolvm_pack::extract::shared_extract_enabled() {
                #[cfg(target_os = "linux")]
                {
                    let lease = smolvm::artifact_cache::materialize_shared_pack_lease(
                        sidecar_path,
                        footer.as_ref().expect("file artifact has a footer"),
                        &cache_dir,
                        false,
                    )
                    .map_err(|e| smolvm::Error::agent("extract sidecar (shared)", e.to_string()))?;
                    Ok((lease.shared_dir, Some(lease.artifact_sha256)))
                }
                #[cfg(not(target_os = "linux"))]
                unreachable!("shared pack extraction is Linux-only")
            } else {
                smolvm_pack::extract::extract_sidecar_for_machine(
                    sidecar_path,
                    &cache_dir,
                    footer.as_ref().expect("file artifact has a footer"),
                )
                .map(|()| (cache_dir.clone(), None::<String>))
                .map_err(|e| smolvm::Error::agent("extract sidecar", e.to_string()))
            };
            // Detach unconditionally: extraction mounts the case-sensitive volume on
            // macOS even when it later fails, so the detach must run on both success
            // and failure paths to honor the "mounted iff running" invariant.
            smolvm_pack::extract::force_detach_layers_volume(&cache_dir);
            let (pack_content_dir, artifact_sha256) = result?;

            // VM-mode pack: seed this machine's overlay+storage disks from the
            // packed templates so a start boots the source VM's rootfs rather than
            // the bare agent-rootfs. Shared with the serve API create path: it
            // resizes the truncated templates into valid raw disks and removes the
            // manager's default `.qcow2` overlays so the start resolves these.
            // (Writing the resized copy onto `manager.overlay_path()` — the default
            // `.qcow2` — handed the guest raw bytes named `.qcow2`, the /bin/sh-missing
            // bug's disk counterpart.)
            if let Some(seed) = &vm_seed {
                let disk_dir = manager
                    .storage_path()
                    .parent()
                    .map(std::path::Path::to_path_buf)
                    .unwrap_or_else(|| smolvm::agent::vm_data_dir(&name_for_layers));
                smolvm::storage::seed_vm_mode_disks(
                    &disk_dir,
                    &pack_content_dir,
                    smolvm::storage::VmModeDiskSeedSpec {
                        artifact_sha256: artifact_sha256.as_deref(),
                        overlay_template: seed.overlay_template.as_deref(),
                        storage_template: seed.storage_template.as_deref(),
                        overlay_logical_size: seed.overlay_logical_size,
                        storage_logical_size: seed.storage_logical_size,
                        overlay_gb: record.overlay_gb,
                        storage_gb: record.storage_gb,
                    },
                )
                .map_err(|e| smolvm::Error::agent("seed VM-mode disks", e.to_string()))?;
            }

            if let Some(ref checkpoint) = checkpoint {
                let vm_data_dir = smolvm::agent::vm_data_dir(&name_for_layers);
                smolvm::portable_checkpoint::install(
                    &pack_content_dir,
                    &vm_data_dir,
                    checkpoint,
                    cache_base.as_deref(),
                )?;
                smolvm::portable_checkpoint::discard_transport_pack(&vm_data_dir)?;
                if let Some((sidecar, reference)) =
                    smolvm::portable_checkpoint::attach_cached_checkpoint_pack(
                        &name_for_layers,
                        checkpoint,
                    )?
                {
                    record.source_smolmachine = Some(sidecar);
                    record.source_registry_ref = reference;
                }
                if let Some(image) =
                    smolvm::portable_checkpoint::fetch_checkpoint_host_image_blocking(checkpoint)?
                {
                    image.apply(&mut record);
                }
                smolvm::portable_checkpoint::mark_image_on_storage(checkpoint, &mut record);
            }

            reservation.commit(&record)?;
            Ok(())
        })();

        if let Err(e) = create_result {
            smolvm_pack::extract::force_detach_layers_volume(
                &smolvm::agent::machine_layers_cache_dir(&name_for_layers),
            );
            let data_dir = smolvm::agent::vm_data_dir(&name_for_layers);
            if let Err(remove_err) = std::fs::remove_dir_all(&data_dir) {
                if remove_err.kind() != std::io::ErrorKind::NotFound {
                    tracing::warn!(
                        machine = %name_for_layers,
                        dir = %data_dir.display(),
                        error = %remove_err,
                        "failed to remove machine data dir after create failure"
                    );
                }
            }
            return Err(e);
        }

        Ok(record)
    }
}

// ============================================================================
// Start Command
// ============================================================================

/// Start a machine.
///
/// Starts the VM process. If no name is given, starts the default VM.
#[derive(Args, Debug)]
pub struct StartCmd {
    /// Machine to start (default: "default")
    #[arg(short = 'n', long, value_name = "NAME", env = smolvm::data::consts::ENV_SMOLVM_MACHINE_NAME)]
    pub name: Option<String>,

    /// Start as a branch source: back guest RAM with a memfd (CoW-cloneable) and
    /// expose a control socket so the running machine can later be branched.
    #[arg(long = "branchable", visible_alias = "forkable")]
    pub forkable: bool,

    /// Plan a CUDA branch pool with this many runnable children. Smolvm reports a
    /// safe per-session VRAM share before the source initializes, so vLLM and
    /// similar runtimes size private caches without workload changes. Implies
    /// --branchable.
    #[arg(
        long = "branch-pool-size",
        visible_alias = "fork-pool-size",
        value_name = "CHILDREN"
    )]
    pub fork_pool_size: Option<std::num::NonZeroU32>,

    /// Override the automatic logical VRAM budget for each source/child CUDA
    /// session. The workload still needs no changes. Requires --branch-pool-size.
    #[arg(long, value_name = "MIB", requires = "fork_pool_size")]
    pub cuda_vram_limit_mib: Option<std::num::NonZeroU64>,

    /// Provision the machine (pull the image, run init) but do not launch the
    /// image's workload — the machine boots to the bare agent. Used by the
    /// `--oci-cache`/init bake to cache an image without running it, and without
    /// depending on a runnable no-op existing inside the image.
    #[arg(long = "no-workload", hide = true)]
    pub no_workload: bool,

    /// Read registry credentials for the first start's image pull as one JSON
    /// line (`{"username":…,"password":…}`) on stdin. Used by the image seed
    /// builder for a private image whose credentials came with an API start;
    /// stdin keeps them off the command line and out of the VM's environment.
    #[arg(long = "registry-auth-stdin", hide = true)]
    pub registry_auth_stdin: bool,

    /// Reuse an image digest resolved at most this many seconds ago when
    /// seeding the first start, skipping the per-start registry check inside
    /// the window. Default: resolve and authorize at the registry every start.
    #[arg(long, value_name = "SECONDS")]
    pub seed_digest_ttl: Option<u64>,

    /// Route outbound TCP through a host interceptor. Requires
    /// SMOLVM_INTERCEPTOR_TOKEN (64 hex digits). Other outbound datagrams except DNS are denied.
    #[arg(long, value_name = "ADDR", requires = "name")]
    pub egress_interceptor: Option<std::net::SocketAddr>,

    /// Require a pre-dial host decision for each outbound TCP flow.
    #[arg(long, requires = "egress_interceptor")]
    pub mediated_egress: bool,

    #[arg(
        long,
        env = "SMOLVM_INTERCEPTOR_TOKEN",
        hide = true,
        hide_env_values = true,
        value_parser = clap::builder::StringValueParser::new().map(smolvm::secrets::Secret::new)
    )]
    pub egress_interceptor_token: Option<smolvm::secrets::Secret>,

    #[command(flatten, next_help_heading = "Network")]
    pub proxy_opts: crate::cli::proxy_opts::ProxyOpts,
}

impl StartCmd {
    pub fn run(self) -> smolvm::Result<()> {
        let external_interceptor = parse_external_interceptor(
            self.egress_interceptor,
            self.egress_interceptor_token.as_ref(),
        )?;
        let explicit_name = self.name.is_some();
        let name = self.name.unwrap_or_else(|| "default".to_string());
        let proxy = self.proxy_opts.resolved_proxy()?;
        let no_proxy = self.proxy_opts.no_proxy();
        let registry_auth = if self.registry_auth_stdin {
            let mut line = String::new();
            std::io::stdin()
                .read_line(&mut line)
                .map_err(|e| smolvm::Error::config("registry auth", e.to_string()))?;
            Some(
                serde_json::from_str::<smolvm::registry::RegistryAuth>(&line).map_err(|_| {
                    smolvm::Error::config("registry auth", "stdin is not a credential JSON line")
                })?,
            )
        } else {
            None
        };
        // Forkable start: memfd-back guest RAM and register a control socket at a
        // known path so `machine fork` can later freeze this machine as a CoW base.
        let fork = if self.forkable || self.fork_pool_size.is_some() {
            let mut launch = vm_common::forkable_launch();
            launch.pool_size = self.fork_pool_size.map(std::num::NonZeroU32::get);
            launch.vram_limit_mib = self.cuda_vram_limit_mib.map(std::num::NonZeroU64::get);
            launch
        } else {
            vm_common::ForkLaunch::default()
        };
        match vm_common::start_vm_named(
            &name,
            proxy.as_deref(),
            no_proxy.as_deref(),
            /* from_snapshot */ false,
            fork,
            vm_common::StartOptions {
                no_workload: self.no_workload,
                external_interceptor,
                seed_digest_ttl: self.seed_digest_ttl,
                mediated_egress: self.mediated_egress,
                registry_auth,
            },
        ) {
            Ok(()) => Ok(()),
            Err(smolvm::Error::VmNotFound { .. }) if !explicit_name => {
                // Only fall back to creating a default VM when no --name was given.
                // With an explicit --name, VmNotFound is a real error.
                vm_common::start_vm_default(proxy.as_deref(), no_proxy.as_deref())
            }
            Err(e) => Err(e),
        }
    }
}

fn parse_external_interceptor(
    addr: Option<std::net::SocketAddr>,
    token: Option<&smolvm::secrets::Secret>,
) -> smolvm::Result<Option<smolvm_protocol::InterceptEndpoint>> {
    addr.map(|addr| {
        let encoded = token.ok_or_else(|| {
            smolvm::Error::config(
                "egress interceptor",
                "set SMOLVM_INTERCEPTOR_TOKEN to 64 random hex digits",
            )
        })?;
        let mut token = [0; smolvm_protocol::intercept::TOKEN_LEN];
        if hex::decode_to_slice(encoded.expose(), &mut token).is_err() || token == [0; 32] {
            return Err(smolvm::Error::config(
                "egress interceptor",
                "SMOLVM_INTERCEPTOR_TOKEN must contain 64 hex digits and must not be all zeros",
            ));
        }
        Ok(smolvm_protocol::InterceptEndpoint { addr, token })
    })
    .transpose()
}

// ============================================================================
// Fork Command
// ============================================================================

/// Branch a running branchable machine into a new independent child.
///
/// Captures the source through its control socket, copy-on-write
/// branches its disks, and boots the new machine from the source's in-memory
/// checkpoint instead of cold-booting. Linux/x86_64 resumes the source after the
/// boundary; other hosts retain it as the frozen copy-on-write base.
///
/// The source must have been started with `--branchable`.
#[derive(Args, Debug)]
pub struct ForkCmd {
    /// The running, branchable source machine to branch from.
    #[arg(long = "from", visible_alias = "golden", value_name = "NAME")]
    pub golden: String,

    /// Name for the new child machine.
    #[arg(short = 'n', long = "name", value_name = "NAME")]
    pub clone: Option<String>,

    /// Number of children to create from one checkpoint. Batch branches wait for the
    /// standard `smolvm-branch-ready` boundary automatically (`--no-wait-ready`
    /// checkpoints the source where it is instead, as the API does). Direct batches
    /// receive one shared `SMOLVM_BRANCH_BATCH_ID` and `SMOLVM_BRANCH_BATCH_SIZE`;
    /// held slots remain independent until assigned by their controller.
    #[arg(long, default_value = "1", value_name = "COUNT")]
    pub count: std::num::NonZeroU32,

    /// Name batch children PREFIX-0 through PREFIX-(COUNT-1). With a prefix (or
    /// --hold) even a count of one is a batch: it waits for the boundary and
    /// releases the child with its identity, unlike a plain --name branch.
    #[arg(long, value_name = "PREFIX")]
    pub name_prefix: Option<String>,

    /// Maximum number of child boots in flight during a batch branch.
    #[arg(long, default_value = "4", value_name = "COUNT")]
    pub parallel: std::num::NonZeroU32,

    /// Wait for `smolvm-branch-ready` in a single-child branch. Batch branches always
    /// wait; unless held, they release children only after identity and branch env
    /// are installed.
    #[arg(long)]
    pub wait_ready: bool,

    /// Checkpoint the source where it is now instead of waiting for its workload to
    /// run `smolvm-branch-ready`: the host decides the branch point, which is what a
    /// workload that never declares one (a CI runner, a server) needs, and the
    /// default of the API's `/branches/batch`. Children still receive their identity
    /// and branch environment at boot.
    #[arg(long, conflicts_with_all = ["wait_ready", "hold"])]
    pub no_wait_ready: bool,

    /// Keep each child parked at the inherited branch point as an already-booted
    /// pool slot. Assign and release a slot later with `machine branch-release`.
    /// A consumed slot is disposable; delete and replenish it from the source
    /// rather than reusing mutated training state.
    #[arg(long)]
    pub hold: bool,

    /// Leave the source paused as a reusable branch base. Subsequent branches
    /// reuse its checkpoint without adding source disk layers.
    #[arg(long)]
    pub freeze_source: bool,

    /// Maximum time to wait for the source workload's branch boundary.
    #[arg(
        long,
        default_value = "10m",
        value_parser = parse_duration,
        value_name = "DURATION",
    )]
    pub ready_timeout: Duration,

    /// Count a batch child as branched only once its workload has run
    /// `smolvm-worker-ready`; a child that does not within the window is torn
    /// down with the rest of the batch. Held slots take this at release.
    #[arg(long, conflicts_with = "hold")]
    pub wait_worker_ready: bool,

    /// Window for `--wait-worker-ready`.
    #[arg(
        long,
        default_value = "5m",
        value_parser = parse_duration,
        value_name = "DURATION",
        requires = "wait_worker_ready",
    )]
    pub worker_ready_timeout: Duration,

    /// Make the child itself branchable (memfd RAM + control socket), so it can
    /// in turn be branched.
    #[arg(
        long = "branchable",
        visible_aliases = ["forkable", "checkpointable"]
    )]
    pub forkable: bool,

    /// Pin the child's inbound port forwards (single port or one-to-one range, repeatable).
    /// Without this, the source's forwards are remapped to freshly-allocated host ports.
    #[arg(short = 'p', long = "port", value_parser = PortMappingSpec::parse, value_name = "PORT[-END]|HOST[-END]:GUEST[-END]", help_heading = "Network")]
    pub port: Vec<PortMappingSpec>,

    /// Share the source's loaded CUDA weights with this child instead of
    /// copying them — sibling children then keep ONE copy of the base model in
    /// VRAM. Correct when the base stays frozen (LoRA/QLoRA fine-tuning,
    /// inference); use a plain branch when the child trains the base weights.
    #[arg(long)]
    pub share_weights: bool,

    /// Label the child (repeatable, KEY=VALUE). A child inherits the source's
    /// labels; a key given here replaces the inherited value.
    #[arg(long = "label", value_name = "KEY=VALUE")]
    pub labels: Vec<String>,

    /// Per-branch parameter (repeatable, KEY=VALUE). Reaches the child through
    /// `smolvm-branch-ready`: the program it runs (`-- prog`) gets it in its
    /// environment, a shell gets it from `eval "$(smolvm-branch-ready)"`, and
    /// later `machine exec` sessions see it too. This is how sweep/rollout
    /// children learn which variant they are — no shared-mount claim files needed.
    #[arg(short = 'e', long = "env", value_name = "KEY=VALUE")]
    pub env: Vec<String>,

    /// Inject a per-branch secret from a host env var (GUEST_VAR=HOST_VAR),
    /// resolved fresh on every `exec` in the child. Unlike `--env`, the value is
    /// never written to the child's record, the overlay/pack, or the branch-env
    /// guest file — and each child's secrets are its own, invisible to the
    /// source and siblings.
    #[arg(
        long = "secret-env",
        value_name = "GUEST_VAR=HOST_VAR",
        help_heading = "Security"
    )]
    pub secret_env: Vec<String>,

    /// Inject a per-branch secret from a host file (GUEST_VAR=/abs/path), resolved
    /// fresh on every `exec` in the child. Never persisted to the record,
    /// overlay/pack, or branch-env guest file. See `--secret-env`.
    #[arg(
        long = "secret-file",
        value_name = "GUEST_VAR=PATH",
        help_heading = "Security"
    )]
    pub secret_file: Vec<String>,

    /// Inject a secret from the host keychain (GUEST_VAR=SERVICE or
    /// GUEST_VAR=SERVICE/ACCOUNT): a macOS Keychain generic password, or a
    /// Linux Secret Service item, read at launch and never persisted.
    #[arg(
        long = "secret-keychain",
        value_name = "GUEST_VAR=SERVICE[/ACCOUNT]",
        help_heading = "Security"
    )]
    pub secret_keychain: Vec<String>,

    /// Rebind a host egress interceptor for each branched child.
    #[arg(long, value_name = "ADDR")]
    pub egress_interceptor: Option<std::net::SocketAddr>,

    #[arg(
        long,
        env = "SMOLVM_INTERCEPTOR_TOKEN",
        hide = true,
        hide_env_values = true,
        value_parser = clap::builder::StringValueParser::new().map(smolvm::secrets::Secret::new)
    )]
    pub egress_interceptor_token: Option<smolvm::secrets::Secret>,
}

impl ForkCmd {
    pub fn run(self) -> smolvm::Result<()> {
        let external_interceptor = parse_external_interceptor(
            self.egress_interceptor,
            self.egress_interceptor_token.as_ref(),
        )?;
        let ports = PortMappingSpec::expand_all(&self.port)
            .map_err(|e| smolvm::Error::config("branch ports", e))?;
        // A branch gets fresh host ports for the source's UDP forwards on its
        // own; pins name TCP ports.
        if let Some(udp) = ports
            .iter()
            .find(|port| port.protocol == smolvm::data::network::PortProtocol::Udp)
        {
            return Err(smolvm::Error::config(
                "branch ports",
                format!(
                    "{} cannot be pinned: a branch pins TCP ports, and gets fresh host ports for UDP forwards automatically",
                    udp.label()
                ),
            ));
        }
        let ports: Vec<(u16, u16)> = ports.into_iter().map(|port| port.to_tuple()).collect();
        // Parse per-fork secret refs (TrustedLocal — host env/absolute file);
        // they merge into the clone's secret_refs and resolve fresh per exec.
        let fork_secrets =
            parse_cli_secret_refs(&self.secret_env, &self.secret_file, &self.secret_keychain)?;
        let labels: Vec<(String, String)> = smolvm::util::parse_labels(&self.labels)?
            .into_iter()
            .collect();
        let count = self.count.get();
        let wait_ready = if self.no_wait_ready {
            None
        } else {
            forkpoint_timeout(
                is_plain_branch(count, self.name_prefix.is_some(), self.hold),
                self.wait_ready,
                self.ready_timeout,
            )
        };
        if count > 1024 {
            return Err(smolvm::Error::config(
                "branch",
                "--count cannot exceed 1024 children per batch",
            ));
        }
        if self.hold && self.forkable {
            return Err(smolvm::Error::config(
                "branch",
                "--hold cannot be combined with --branchable; pool slots are disposable leaves",
            ));
        }

        if is_plain_branch(count, self.name_prefix.is_some(), self.hold) {
            let clone = match (self.clone, self.name_prefix) {
                (Some(clone), None) => clone,
                (None, Some(prefix)) => format!("{prefix}-0"),
                (Some(_), Some(_)) => {
                    return Err(smolvm::Error::config(
                        "branch",
                        "use either --name or --name-prefix, not both",
                    ));
                }
                (None, None) => {
                    return Err(smolvm::Error::config(
                        "branch",
                        "--name is required for one child; use --name-prefix with --count for a batch",
                    ));
                }
            };
            let fork_env = render_indexed_fork_env(&self.env, 0, &clone, false, None);
            return vm_common::fork_vm(
                &self.golden,
                &clone,
                vm_common::ForkVmOptions {
                    clone_forkable: self.forkable,
                    pinned_ports: &ports,
                    share_weights: self.share_weights,
                    fork_env: &fork_env,
                    fork_secrets: &fork_secrets,
                    wait_ready,
                    hold: self.hold,
                    freeze_source: self.freeze_source,
                    external_interceptor,
                    labels: &labels,
                },
            );
        }

        if self.clone.is_some() && count > 1 {
            return Err(smolvm::Error::config(
                "branch",
                "--name cannot be used with --count greater than 1; use --name-prefix",
            ));
        }
        if self.clone.is_some() && self.name_prefix.is_some() {
            return Err(smolvm::Error::config(
                "branch",
                "use either --name or --name-prefix, not both",
            ));
        }
        let (prefix, names): (String, Vec<String>) = match (self.clone, self.name_prefix) {
            (Some(name), None) => (name.clone(), vec![name]),
            (None, Some(prefix)) => {
                let names = (0..count).map(|i| format!("{prefix}-{i}")).collect();
                (prefix, names)
            }
            _ => {
                return Err(smolvm::Error::config(
                    "branch",
                    "--name-prefix is required with --count greater than 1",
                ));
            }
        };
        if self.forkable {
            return Err(smolvm::Error::config(
                "branch",
                "--branchable is not supported for batch children",
            ));
        }
        if !ports.is_empty() {
            return Err(smolvm::Error::config(
                "branch",
                "pinned --port mappings are not supported for a batch; inherited ports are remapped automatically",
            ));
        }

        let batch = (!self.hold).then(|| ForkBatchIdentity {
            id: fork_batch_id(&self.golden, &prefix),
            size: count,
        });
        let worker_ready = self.wait_worker_ready.then_some(self.worker_ready_timeout);
        let clones = names
            .into_iter()
            .enumerate()
            .map(|(index, name)| {
                let index = index as u32;
                let mut env =
                    render_indexed_fork_env(&self.env, index, &name, true, batch.as_ref());
                if let Some(timeout) = worker_ready {
                    let token = smolvm::agent::fork::random_worker_ready_token()?;
                    smolvm::agent::fork::add_worker_ready_assignment(&mut env, &token, timeout)?;
                }
                Ok((name, env))
            })
            .collect::<smolvm::Result<Vec<_>>>()?;
        vm_common::fork_vm_batch(
            &self.golden,
            &clones,
            vm_common::ForkBatchOptions {
                share_weights: self.share_weights,
                fork_secrets: &fork_secrets,
                wait_ready,
                parallel: self.parallel.get() as usize,
                hold: self.hold,
                freeze_source: self.freeze_source,
                worker_ready,
                external_interceptor,
                labels: &labels,
            },
        )
    }
}

/// Assign job-specific parameters and release one held branch-pool slot.
#[derive(Args, Debug)]
pub struct ForkReleaseCmd {
    /// Held child to assign and release.
    #[arg(short = 'n', long = "name", value_name = "NAME", env = smolvm::data::consts::ENV_SMOLVM_MACHINE_NAME)]
    pub name: String,

    /// Assignment parameter (repeatable, KEY=VALUE). Values override matching
    /// parameters installed when the slot was provisioned.
    #[arg(short = 'e', long = "env", value_name = "KEY=VALUE")]
    pub env: Vec<String>,

    /// Report the slot as released only once its workload has run
    /// `smolvm-worker-ready`; a slot that does not within the window is torn
    /// down, since a consumed slot cannot be returned to the pool anyway.
    #[arg(long)]
    pub wait_worker_ready: bool,

    /// Window for `--wait-worker-ready`.
    #[arg(
        long,
        default_value = "5m",
        value_parser = parse_duration,
        value_name = "DURATION",
        requires = "wait_worker_ready",
    )]
    pub worker_ready_timeout: Duration,
}

impl ForkReleaseCmd {
    pub fn run(self) -> smolvm::Result<()> {
        let mut env = smolvm::util::parse_env_list(&self.env);
        let worker_ready = self.wait_worker_ready.then_some(self.worker_ready_timeout);
        if let Some(timeout) = worker_ready {
            let token = smolvm::agent::fork::random_worker_ready_token()?;
            smolvm::agent::fork::add_worker_ready_assignment(&mut env, &token, timeout)?;
        }
        vm_common::release_held_fork(&self.name, &env, worker_ready)
    }
}

/// One child by `--name` is a plain branch: the source is checkpointed wherever
/// it is and the child keeps the parked helper. Anything with `--name-prefix`
/// or `--hold` is a batch of that size, even one, so a pool of one slot gets
/// the same boundary, identity and release as a pool of eight.
fn is_plain_branch(count: u32, has_prefix: bool, hold: bool) -> bool {
    count == 1 && !has_prefix && !hold
}

fn render_indexed_fork_env(
    specs: &[String],
    index: u32,
    name: &str,
    include_identity: bool,
    batch: Option<&ForkBatchIdentity>,
) -> Vec<(String, String)> {
    let mut env = smolvm::util::parse_env_list(specs);
    for (_, value) in &mut env {
        *value = value
            .replace("{index}", &index.to_string())
            .replace("{name}", name);
    }
    if include_identity {
        env.retain(|(key, _)| {
            !matches!(
                key.as_str(),
                "SMOLVM_BRANCH_INDEX"
                    | "SMOLVM_BRANCH_NAME"
                    | "SMOLVM_BRANCH_BATCH_ID"
                    | "SMOLVM_BRANCH_BATCH_SIZE"
                    | "SMOLVM_FORK_INDEX"
                    | "SMOLVM_FORK_NAME"
                    | "SMOLVM_FORK_BATCH_ID"
                    | "SMOLVM_FORK_BATCH_SIZE"
            )
        });
        env.push(("SMOLVM_BRANCH_INDEX".to_string(), index.to_string()));
        env.push(("SMOLVM_BRANCH_NAME".to_string(), name.to_string()));
        env.push(("SMOLVM_FORK_INDEX".to_string(), index.to_string()));
        env.push(("SMOLVM_FORK_NAME".to_string(), name.to_string()));
        if let Some(batch) = batch {
            env.push(("SMOLVM_BRANCH_BATCH_ID".to_string(), batch.id.clone()));
            env.push((
                "SMOLVM_BRANCH_BATCH_SIZE".to_string(),
                batch.size.to_string(),
            ));
            env.push(("SMOLVM_FORK_BATCH_ID".to_string(), batch.id.clone()));
            env.push(("SMOLVM_FORK_BATCH_SIZE".to_string(), batch.size.to_string()));
        }
    }
    env
}

#[derive(Debug)]
struct ForkBatchIdentity {
    id: String,
    size: u32,
}

fn fork_batch_id(golden: &str, prefix: &str) -> String {
    let created = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_nanos();
    let mut digest = Sha256::new();
    digest.update(golden.as_bytes());
    digest.update([0]);
    digest.update(prefix.as_bytes());
    digest.update([0]);
    digest.update(std::process::id().to_le_bytes());
    digest.update(created.to_le_bytes());
    hex::encode(digest.finalize())[..32].to_string()
}

/// A batch always waits for the source's branchpoint and releases each child
/// there; a plain branch waits only when asked.
fn forkpoint_timeout(
    plain: bool,
    explicitly_requested: bool,
    timeout: Duration,
) -> Option<Duration> {
    (!plain || explicitly_requested).then_some(timeout)
}

// ============================================================================
// Stop Command
// ============================================================================

/// Stop a running machine.
///
/// Gracefully stops the VM process. Running containers will be terminated.
#[derive(Args, Debug)]
pub struct StopCmd {
    /// Machine to stop (default: "default")
    #[arg(short = 'n', long, value_name = "NAME", env = smolvm::data::consts::ENV_SMOLVM_MACHINE_NAME)]
    pub name: Option<String>,

    /// Seconds the workload gets to exit after its stop signal before it is
    /// killed, instead of the machine's stop timeout (0 kills it at once)
    #[arg(short = 't', long, value_name = "SECONDS", value_parser = parse_stop_timeout_arg)]
    pub timeout: Option<u64>,
}

#[derive(Args, Debug)]
pub struct PauseCmd {
    #[arg(short = 'n', long, env = smolvm::data::consts::ENV_SMOLVM_MACHINE_NAME)]
    pub name: String,
}

impl PauseCmd {
    pub fn run(self) -> smolvm::Result<()> {
        smolvm::embedded::EmbeddedRuntime::new()?.pause_machine(&self.name)?;
        println!("Machine '{}' paused", self.name);
        Ok(())
    }
}

#[derive(Args, Debug)]
pub struct ResumeCmd {
    #[arg(short = 'n', long, env = smolvm::data::consts::ENV_SMOLVM_MACHINE_NAME)]
    pub name: String,
}

impl ResumeCmd {
    pub fn run(self) -> smolvm::Result<()> {
        smolvm::embedded::EmbeddedRuntime::new()?.resume_machine_detached(&self.name)?;
        println!("Machine '{}' resumed", self.name);
        Ok(())
    }
}

impl StopCmd {
    pub fn run(self) -> smolvm::Result<()> {
        let name = vm_common::resolve_vm_name(self.name)?;
        let timeout = self.timeout.map(std::time::Duration::from_secs);
        match &name {
            Some(name) => vm_common::stop_vm_named_with_timeout(name, timeout),
            None => vm_common::stop_vm_default(timeout),
        }
    }
}

// ============================================================================
// Delete Command
// ============================================================================

/// Delete a machine configuration.
///
/// Removes the VM configuration and its data directory, disks included.
#[derive(Args, Debug)]
pub struct DeleteCmd {
    /// Machine to delete
    #[arg(short = 'n', long, value_name = "NAME", env = smolvm::data::consts::ENV_SMOLVM_MACHINE_NAME)]
    pub name: String,

    /// Skip confirmation prompt
    #[arg(short, long)]
    pub force: bool,

    /// Also delete any children branched from this machine. A branch source
    /// cannot be removed while its children's disks depend on it; --cascade
    /// removes children first. Implies no confirmation.
    #[arg(long)]
    pub cascade: bool,
}

impl DeleteCmd {
    pub fn run(&self) -> smolvm::Result<()> {
        vm_common::delete_vm(
            &self.name,
            self.force,
            DeleteVmOptions {
                // Stop the VM before removing its config and data dir.
                // Without this, deleting a running machine orphans the
                // `_boot-vm` process (leaking host RAM) and removes the data
                // dir out from under the live VM. The API delete handler and
                // `delete_vm`'s own teardown already do this.
                stop_if_running: true,
                // Delete dependent clones too when requested, instead of
                // refusing on a fork base.
                cascade: self.cascade,
            },
        )
    }
}

// ============================================================================
// Status Command
// ============================================================================

/// Show machine status.
///
/// Displays whether the VM is running and its process ID.
#[derive(Args, Debug)]
pub struct StatusCmd {
    /// Machine to check (default: "default")
    #[arg(short = 'n', long, value_name = "NAME", env = smolvm::data::consts::ENV_SMOLVM_MACHINE_NAME)]
    pub name: Option<String>,

    /// Output in JSON format
    #[arg(long)]
    pub json: bool,
}

impl StatusCmd {
    pub fn run(self) -> smolvm::Result<()> {
        if self.json {
            return vm_common::status_vm_json(&self.name);
        }
        vm_common::status_vm(&self.name)
    }
}

// ============================================================================
// Stats Command
// ============================================================================

/// Show a running machine's CPU and memory usage.
///
/// CPU is the machine's process on the host, sampled over half a second, where
/// 100% is one busy CPU. Memory is the guest's own account, as in `status`.
#[derive(Args, Debug)]
pub struct StatsCmd {
    /// Machine to sample (default: "default")
    #[arg(short = 'n', long, value_name = "NAME", env = smolvm::data::consts::ENV_SMOLVM_MACHINE_NAME)]
    pub name: Option<String>,

    /// Output in JSON format
    #[arg(long)]
    pub json: bool,
}

impl StatsCmd {
    pub fn run(self) -> smolvm::Result<()> {
        vm_common::stats_vm(&self.name, self.json)
    }
}

// ============================================================================
// Logs Command
// ============================================================================

/// Show a machine's workload output.
///
/// A machine's workload (its image ENTRYPOINT/CMD or Smolfile command) writes
/// stdout and stderr to `workload.log` in the machine's data directory. The
/// log is kept across restarts, rotated by size, and readable while the
/// machine is stopped.
#[derive(Args, Debug)]
pub struct LogsCmd {
    /// Machine whose workload output to show (default: "default")
    #[arg(short = 'n', long, value_name = "NAME", env = smolvm::data::consts::ENV_SMOLVM_MACHINE_NAME)]
    pub name: Option<String>,

    /// Keep printing output as the workload writes it
    #[arg(short = 'f', long)]
    pub follow: bool,

    /// Show only the last N lines
    #[arg(long, value_name = "N")]
    pub tail: Option<usize>,
}

impl LogsCmd {
    pub fn run(self) -> smolvm::Result<()> {
        use std::io::Write;
        let name = vm_common::resolve_vm_name(self.name)?.unwrap_or_else(|| "default".into());
        if smolvm::db::SmolvmDb::open()?.get_vm(&name)?.is_none() {
            return Err(smolvm::Error::vm_not_found(&name));
        }
        let log = smolvm::workload_log::workload_log_path(&smolvm::agent::vm_data_dir(&name));
        let read_err = |e: std::io::Error| smolvm::Error::agent("read workload log", e.to_string());
        let shown = match self.tail {
            Some(lines) => smolvm::workload_log::tail(&log, lines).map_err(read_err)?,
            None => smolvm::workload_log::read_all(&log).map_err(read_err)?,
        };
        let mut stdout = std::io::stdout().lock();
        stdout.write_all(&shown).map_err(read_err)?;
        stdout.flush().map_err(read_err)?;
        if self.follow {
            let offset = std::fs::metadata(&log).map(|m| m.len()).unwrap_or(0);
            smolvm::workload_log::follow(
                &log,
                offset,
                &mut stdout,
                std::time::Duration::from_millis(200),
                || false,
            )
            .map_err(read_err)?;
        }
        Ok(())
    }
}

// ============================================================================
// EgressEvents Command
// ============================================================================

/// Show the machine's egress denials.
///
/// Lists outbound connects and sendtos the egress policy refused — the record
/// of what a confined workload tried and failed to reach. Empty for machines
/// without an egress policy, or with no denials.
#[derive(Args, Debug)]
pub struct EgressEventsCmd {
    /// Machine to inspect (default: "default")
    #[arg(short = 'n', long, value_name = "NAME", env = smolvm::data::consts::ENV_SMOLVM_MACHINE_NAME)]
    pub name: Option<String>,

    /// Maximum number of events to show (newest kept)
    #[arg(long, default_value_t = 200)]
    pub limit: usize,

    /// Output in JSON format
    #[arg(long)]
    pub json: bool,
}

impl EgressEventsCmd {
    pub fn run(self) -> smolvm::Result<()> {
        let name = self.name.as_deref().unwrap_or("default");
        let events = smolvm::agent::read_egress_denials(name, self.limit);
        // Write through the io API instead of println!: piping into a pager
        // that exits early (`| head`) closes stdout, and println! turns that
        // EPIPE into a panic. A closed pipe just means the reader is done.
        let stdout = std::io::stdout();
        let mut out = stdout.lock();
        let result = (|| -> std::io::Result<()> {
            use std::io::Write;
            if self.json {
                writeln!(
                    out,
                    "{}",
                    serde_json::to_string_pretty(&events).unwrap_or_default()
                )?;
                return Ok(());
            }
            if events.is_empty() {
                writeln!(out, "No egress denials recorded for '{name}'.")?;
                return Ok(());
            }
            writeln!(out, "{:<30} {:<9} DESTINATION", "TIMESTAMP", "OP")?;
            for e in &events {
                writeln!(out, "{:<30} {:<9} {}", e.timestamp, e.operation, e.dest)?;
            }
            Ok(())
        })();
        match result {
            Err(e) if e.kind() == std::io::ErrorKind::BrokenPipe => Ok(()),
            Err(e) => Err(smolvm::Error::config("egress-events", e.to_string())),
            Ok(()) => Ok(()),
        }
    }
}

// ============================================================================
// Ls Command
// ============================================================================

/// List all machines.
///
/// Shows all configured VMs with their state, resources, and configuration.
#[derive(Args, Debug)]
pub struct LsCmd {
    /// Show detailed configuration (mounts, ports, PID)
    #[arg(short, long)]
    pub verbose: bool,

    /// Output in JSON format
    #[arg(long)]
    pub json: bool,

    /// Print only machine names, one per line
    #[arg(short, long, conflicts_with = "verbose")]
    pub quiet: bool,
}

impl LsCmd {
    pub fn run(&self) -> smolvm::Result<()> {
        vm_common::list_vms(self.verbose, self.json, self.quiet)
    }
}

// ============================================================================
// Resize Command
// ============================================================================

/// Resize a machine's resources without rebooting a running workload.
///
/// Running machines online added resources immediately when the runtime and
/// guest support hot-add. Several resources in one command are checked
/// together before any changes, then applied RAM first, CPUs, then disks.
/// Stopped machines retain disk expansion support; use `update` for stopped
/// CPU/RAM settings. Sizes are absolute targets.
/// CPU shrinking requires Linux x86_64 and a compatible runtime and agent.
/// RAM and disk shrinking are rejected without reducing capacity.
///
/// Examples:
///   smolvm machine resize --name my-vm --storage 50
///   smolvm machine resize --name my-vm --overlay 20
///   smolvm machine resize --name my-vm --storage 50 --overlay 20
///   smolvm machine resize --storage 50  # default VM
///   smolvm machine resize --name my-vm --cpus 4
///   smolvm machine resize --name my-vm --mem 4096
///   smolvm machine resize --name my-vm --cpus 4 --mem 4096
#[derive(Args, Debug)]
#[command(group(
    clap::ArgGroup::new("resize-target")
        .required(true)
        .args(["cpus", "mem", "storage", "overlay"])
        .multiple(true)
))]
pub struct ResizeCmd {
    /// Machine to resize (default: "default")
    #[arg(short = 'n', long, value_name = "NAME", env = smolvm::data::consts::ENV_SMOLVM_MACHINE_NAME)]
    pub name: Option<String>,

    /// Target online vCPU count (shrink supported on compatible Linux x86_64 runtimes)
    #[arg(long, value_name = "COUNT", value_parser = clap::value_parser!(u8).range(1..))]
    pub cpus: Option<u8>,

    /// Target usable RAM in MiB (grow only; platform hot-add alignment applies)
    #[arg(long, value_name = "MiB", value_parser = clap::value_parser!(u32).range(1..))]
    pub mem: Option<u32>,

    /// Storage disk size in GiB (expand only)
    #[arg(long, value_name = "GiB")]
    pub storage: Option<u64>,

    /// Overlay disk size in GiB (expand only)
    #[arg(long, value_name = "GiB")]
    pub overlay: Option<u64>,
}

impl ResizeCmd {
    pub fn run(self) -> smolvm::Result<()> {
        let name = vm_common::resolve_vm_name(self.name)?;
        let name_str = name.as_deref().unwrap_or("default");

        vm_common::resize_vm(name_str, self.cpus, self.mem, self.storage, self.overlay)
    }
}

// ============================================================================
// Update Command
// ============================================================================

/// Modify settings on a stopped machine, or the allow list of a running one.
///
/// Changes are applied to the DB record and take effect on the next
/// `machine start`. The machine must be stopped, except to add or remove
/// allowed hosts and CIDRs on a machine started with an allow list: those take
/// effect on its next connection or DNS lookup.
///
/// Examples:
///   smolvm machine update --name myvm -v ./src:/app -p 8080:8080
///   smolvm machine update --name myvm --cpus 4 --mem 4096
///   smolvm machine update --name myvm --remove-volume ./src:/app
///   smolvm machine update --name myvm --net -e DEBUG=1
///   smolvm machine update --name myvm --allow-host pypi.org   # while running
///   smolvm machine update --name myvm --auto-ports
#[derive(Args, Debug)]
pub struct UpdateCmd {
    /// Machine to update
    #[arg(short = 'n', long, value_name = "NAME", env = smolvm::data::consts::ENV_SMOLVM_MACHINE_NAME)]
    pub name: String,

    /// Add volume mount. A staged mount is guest-local until sync or graceful stop,
    /// which mirror it onto the host source, deleting host files the copy lacks.
    /// A guest path alone adds a
    /// directory on the machine's own disk.
    #[arg(short = 'v', long = "volume", value_name = "HOST:GUEST[:ro|rw|staged]")]
    pub volume: Vec<String>,

    /// Allow adding trusted read-only host `/etc` and `/var/log` mounts below
    /// `/host`. This exposes sensitive host data to the guest.
    #[arg(long)]
    pub allow_system_mounts: bool,

    /// Remove volume mount (HOST:GUEST)
    #[arg(long, value_name = "HOST:GUEST")]
    pub remove_volume: Vec<String>,

    /// Add port mapping or one-to-one range (append /udp for UDP)
    #[arg(short = 'p', long = "port", value_parser = PortMappingSpec::parse, value_name = "PORT[-END]|HOST[-END]:GUEST[-END][/udp]")]
    pub port: Vec<PortMappingSpec>,

    /// Remove port mapping or one-to-one range
    #[arg(long, value_parser = PortMappingSpec::parse, value_name = "PORT[-END]|HOST[-END]:GUEST[-END]")]
    pub remove_port: Vec<PortMappingSpec>,

    /// Publish every TCP port the guest listens on at the same host port on
    /// loopback, from the next start
    #[arg(long)]
    pub auto_ports: bool,

    /// Stop publishing listening ports automatically, from the next start
    #[arg(long, conflicts_with_all = ["auto_ports", "auto_ports_exclude"])]
    pub no_auto_ports: bool,

    /// Replace the guest ports auto ports never publish (repeatable).
    /// Implies --auto-ports.
    #[arg(long = "auto-ports-exclude", value_name = "PORT")]
    pub auto_ports_exclude: Vec<u16>,

    /// Set vCPU count
    #[arg(long, value_name = "N")]
    pub cpus: Option<u8>,

    /// Set memory in MiB
    #[arg(long, value_name = "MiB")]
    pub mem: Option<u32>,

    /// Enable outbound network access
    #[arg(long)]
    pub net: bool,

    /// Disable outbound network access
    #[arg(long, conflicts_with = "net")]
    pub no_net: bool,

    /// Remove the external egress interceptor requirement from a stopped machine.
    #[arg(long)]
    pub no_egress_interceptor: bool,

    /// Allow egress to a hostname and its subdomains, as `machine create
    /// --allow-host` does (can be used multiple times). An allow list is
    /// enforced by the virtio-net backend only.
    #[arg(
        long = "allow-host",
        value_name = "HOSTNAME",
        conflicts_with = "no_net"
    )]
    pub allow_host: Vec<String>,

    /// Allow egress to an exact hostname or `*.domain` subdomains only.
    #[arg(
        long = "allow-host-pattern",
        value_name = "PATTERN",
        conflicts_with = "no_net"
    )]
    pub allow_host_pattern: Vec<String>,

    /// Allow egress to a CIDR range (can be used multiple times).
    #[arg(long = "allow-cidr", value_parser = parse_cidr, value_name = "CIDR", conflicts_with = "no_net")]
    pub allow_cidr: Vec<String>,

    /// Restrict outbound to localhost, as `machine create
    /// --outbound-localhost-only` does: adds 127.0.0.0/8 and ::1/128 to the
    /// allowed CIDRs. Undo entry by entry with --remove-allow-cidr.
    #[arg(long, conflicts_with = "no_net")]
    pub outbound_localhost_only: bool,

    /// Remove an allowed hostname or pattern, written as it was added.
    #[arg(long = "remove-allow-host", value_name = "HOSTNAME|PATTERN")]
    pub remove_allow_host: Vec<String>,

    /// Remove an allowed CIDR range.
    #[arg(long = "remove-allow-cidr", value_parser = parse_cidr, value_name = "CIDR")]
    pub remove_allow_cidr: Vec<String>,

    #[arg(
        long = "allow-udp",
        value_parser = smolvm::smolfile::parse_allow_udp,
        value_name = "CIDR[:PORT[-END]]",
        conflicts_with = "no_net",
        help = "Allow UDP to a CIDR, optionally on one port or a range, as `machine create --allow-udp` does, also under an egress interceptor (can be used multiple times). Applies live, like --allow-cidr, on a machine started with an allow list"
    )]
    pub allow_udp: Vec<smolvm_protocol::EgressRule>,

    #[arg(
        long = "remove-allow-udp",
        value_parser = smolvm::smolfile::parse_allow_udp,
        value_name = "CIDR[:PORT[-END]]",
        help = "Remove a UDP allow, written as it was added. Applies live, like --remove-allow-cidr, on a machine started with an allow list"
    )]
    pub remove_allow_udp: Vec<smolvm_protocol::EgressRule>,

    /// Start from an empty allow list before applying this update's
    /// --allow-host, --allow-host-pattern and --allow-cidr entries, so the
    /// machine ends up with exactly those and nothing it allowed before. With
    /// --net and no entries the machine may reach every host.
    #[arg(
        long = "reset-allow-list",
        conflicts_with_all = ["remove_allow_host", "remove_allow_cidr"]
    )]
    pub reset_allow_list: bool,

    /// Add/replace environment variable (KEY=VALUE)
    #[arg(short = 'e', long = "env", value_name = "KEY=VALUE")]
    pub env: Vec<String>,

    /// Remove environment variable by key
    #[arg(long, value_name = "KEY")]
    pub remove_env: Vec<String>,

    /// Set working directory
    #[arg(short = 'w', long, value_name = "DIR")]
    pub workdir: Option<String>,

    /// Enable GPU acceleration
    #[arg(long)]
    pub gpu: bool,

    /// Disable GPU acceleration
    #[arg(long, conflicts_with = "gpu")]
    pub no_gpu: bool,

    /// Enable Rosetta 2 for x86_64 binary translation
    #[arg(long)]
    pub rosetta: bool,

    /// Disable Rosetta 2
    #[arg(long, conflicts_with = "rosetta")]
    pub no_rosetta: bool,

    /// Storage disk size in GiB (expand only)
    #[arg(long, value_name = "GiB")]
    pub storage: Option<u64>,

    /// Overlay disk size in GiB (expand only)
    #[arg(long, value_name = "GiB")]
    pub overlay: Option<u64>,

    /// Set the host block I/O engine for the next start.
    #[arg(long = "block-io", value_enum)]
    pub block_io: Option<smolvm::data::resources::BlockIoEngine>,

    /// Set whether a guest flush waits for the host's disk (full) or guest
    /// writes reach it on the host's schedule (deferred), for the next start.
    #[arg(long = "disk-durability", value_enum)]
    pub disk_durability: Option<smolvm::data::resources::DiskDurability>,

    /// Replace the guest resolv.conf options (repeatable, in order), as
    /// `machine create --dns-option` sets them. Written when the guest next
    /// boots; a machine waiting to resume a checkpoint resumes with the file it
    /// was captured with and boots with these afterwards.
    #[arg(long = "dns-option", value_name = "OPTION", value_parser = parse_dns_option, conflicts_with = "clear_dns_options")]
    pub dns_option: Vec<String>,

    /// Size of the workload's /dev/shm: bytes with a k/m/g suffix (`512m`,
    /// `2g`) or a share of guest RAM (`25%`). Defaults to half the RAM.
    #[arg(long = "shm-size", value_name = "SIZE", value_parser = parse_shm_size)]
    pub shm_size: Option<String>,

    /// Remove every guest resolv.conf option.
    #[arg(long)]
    pub clear_dns_options: bool,

    /// Set a label, replacing any value the key had (repeatable). Labels are
    /// host-side metadata, so they alone can change while the machine runs.
    #[arg(long = "label", value_name = "KEY=VALUE")]
    pub labels: Vec<String>,

    /// Remove a label by key (repeatable). A key the machine lacks is ignored.
    #[arg(long = "remove-label", value_name = "KEY")]
    pub remove_labels: Vec<String>,
}

impl UpdateCmd {
    /// The record's egress after this update's allow-list flags, or `None`
    /// when none were given. The merge and its guards live on the record
    /// ([`smolvm::config::VmRecord::updated_egress`]), shared with the API's
    /// egress endpoint.
    fn next_egress(
        &self,
        record: &smolvm::config::VmRecord,
    ) -> smolvm::Result<Option<smolvm::config::VmRecord>> {
        record.updated_egress(&smolvm::config::EgressUpdate {
            allow_hosts: self.allow_host.clone(),
            allow_host_patterns: self.allow_host_pattern.clone(),
            allow_cidrs: self.allow_cidr.clone(),
            remove_allow_hosts: self.remove_allow_host.clone(),
            remove_allow_cidrs: self.remove_allow_cidr.clone(),
            outbound_localhost_only: self.outbound_localhost_only,
            allow_all: self.net,
            reset_allow_list: self.reset_allow_list,
            allow_udp: self.allow_udp.clone(),
            remove_allow_udp: self.remove_allow_udp.clone(),
        })
    }

    /// Whether this update changes the allow list and nothing else, one of the
    /// changes a running machine takes.
    fn changes_only_egress(&self) -> bool {
        let (egress, ports, labels, other) = self.changed_settings();
        egress && !ports && !labels && !other
    }

    fn changes_only_labels(&self) -> bool {
        let (egress, ports, labels, other) = self.changed_settings();
        labels && !egress && !ports && !other
    }

    /// Apply this update's label changes to `labels`: `--remove-label` keys
    /// first, then the parsed `--label` entries in `set`, so a key removed and
    /// set at once ends up set. Returns a line per change.
    fn apply_labels(
        &self,
        labels: &mut std::collections::BTreeMap<String, String>,
        set: &std::collections::BTreeMap<String, String>,
    ) -> Vec<String> {
        let mut changes = Vec::new();
        for key in &self.remove_labels {
            if labels.remove(key).is_some() && !set.contains_key(key) {
                changes.push(format!("  removed label: {key}"));
            }
        }
        for (key, value) in set {
            changes.push(format!("  label: {key}={value}"));
            labels.insert(key.clone(), value.clone());
        }
        changes
    }

    /// Save a label-only update. Labels never reach the guest, so the
    /// machine's state does not matter.
    fn update_labels(
        &self,
        db: &smolvm::db::SmolvmDb,
        set: &std::collections::BTreeMap<String, String>,
    ) -> smolvm::Result<()> {
        let mut changes = Vec::new();
        let saved = db.update_vm(&self.name, |r| {
            changes = self.apply_labels(&mut r.labels, set);
        })?;
        if saved.is_none() {
            return Err(smolvm::Error::config(
                "update",
                format!("machine '{}' disappeared during update", self.name),
            ));
        }
        if changes.is_empty() {
            println!("No changes specified.");
            return Ok(());
        }
        println!("Updated machine '{}':", self.name);
        for change in &changes {
            println!("{change}");
        }
        Ok(())
    }

    fn changes_only_ports(&self) -> bool {
        let (egress, ports, labels, other) = self.changed_settings();
        ports && !egress && !labels && !other
    }

    /// Which kinds of setting this update changes: the allow list, published
    /// ports, labels, and anything else (which needs a stopped machine).
    fn changed_settings(&self) -> (bool, bool, bool, bool) {
        let Self {
            name: _,
            volume,
            allow_system_mounts: _,
            remove_volume,
            port,
            remove_port,
            auto_ports,
            no_auto_ports,
            auto_ports_exclude,
            cpus,
            mem,
            net,
            no_net,
            no_egress_interceptor,
            allow_host,
            allow_host_pattern,
            allow_cidr,
            outbound_localhost_only,
            remove_allow_host,
            remove_allow_cidr,
            allow_udp,
            remove_allow_udp,
            reset_allow_list,
            env,
            remove_env,
            workdir,
            gpu,
            no_gpu,
            rosetta,
            no_rosetta,
            storage,
            overlay,
            block_io,
            disk_durability,
            dns_option,
            clear_dns_options,
            shm_size,
            labels,
            remove_labels,
        } = self;
        let egress = *net
            || *outbound_localhost_only
            || !allow_host.is_empty()
            || !allow_host_pattern.is_empty()
            || !allow_cidr.is_empty()
            || !remove_allow_host.is_empty()
            || !remove_allow_cidr.is_empty()
            || !allow_udp.is_empty()
            || !remove_allow_udp.is_empty()
            || *reset_allow_list;
        let ports = !port.is_empty() || !remove_port.is_empty();
        let other = !volume.is_empty()
            || !remove_volume.is_empty()
            || *auto_ports
            || *no_auto_ports
            || !auto_ports_exclude.is_empty()
            || cpus.is_some()
            || mem.is_some()
            || *no_net
            || *no_egress_interceptor
            || !env.is_empty()
            || !remove_env.is_empty()
            || workdir.is_some()
            || *gpu
            || *no_gpu
            || *rosetta
            || *no_rosetta
            || storage.is_some()
            || overlay.is_some()
            || block_io.is_some()
            || disk_durability.is_some()
            || !dns_option.is_empty()
            || *clear_dns_options
            || shm_size.is_some();
        let labels = !labels.is_empty() || !remove_labels.is_empty();
        (egress, ports, labels, other)
    }

    fn next_ports(&self, record: &smolvm::config::VmRecord) -> smolvm::Result<Vec<PortMapping>> {
        let add_ports = PortMappingSpec::expand_all(&self.port)
            .map_err(|e| smolvm::Error::config("update ports", e))?;
        let remove_ports = PortMappingSpec::expand_all(&self.remove_port)
            .map_err(|e| smolvm::Error::config("update remove ports", e))?;
        let mut final_ports: Vec<PortMapping> = record
            .port_mappings()
            .into_iter()
            .filter(|existing| !remove_ports.contains(existing))
            .collect();
        for p in &add_ports {
            if !final_ports.contains(p) {
                final_ports.push(*p);
            }
        }
        if final_ports.len() > MAX_PORT_MAPPINGS {
            return Err(smolvm::Error::config(
                "update",
                format!(
                    "port mappings expand to {} entries; the maximum per machine is {MAX_PORT_MAPPINGS}",
                    final_ports.len()
                ),
            ));
        }
        PortMapping::check_duplicates(&final_ports)
            .map_err(|e| smolvm::Error::config("update", e))?;
        Ok(final_ports)
    }

    fn update_running_ports(
        &self,
        db: &smolvm::db::SmolvmDb,
        record: &smolvm::config::VmRecord,
    ) -> smolvm::Result<()> {
        let all = self.next_ports(record)?;
        // A UDP port is bound for the runtime's life; only TCP ones change live.
        let udp = |ports: &[PortMapping]| {
            let mut udp: Vec<PortMapping> = ports
                .iter()
                .filter(|p| p.protocol == PortProtocol::Udp)
                .copied()
                .collect();
            udp.sort_by_key(|p| (p.host, p.guest));
            udp
        };
        if udp(&all) != udp(&record.port_mappings()) {
            return Err(smolvm::Error::config(
                "update",
                "published UDP ports cannot change on a running machine; stop it first",
            ));
        }
        let next: Vec<(u16, u16)> = all
            .iter()
            .filter(|p| p.protocol == PortProtocol::Tcp)
            .map(PortMapping::to_tuple)
            .collect();
        smolvm::agent::apply_live_published_ports(&self.name, &next)?;
        let saved = db.update_vm(&self.name, |r| r.ports = next.clone());
        if !matches!(saved, Ok(Some(_))) {
            let _ = smolvm::agent::apply_live_published_ports(&self.name, &record.ports);
            saved?;
            return Err(smolvm::Error::config(
                "update",
                format!("machine '{}' disappeared during update", self.name),
            ));
        }
        println!("Updated machine '{}' (running; applies now):", self.name);
        for &(host, guest) in &record.ports {
            if !next.contains(&(host, guest)) {
                println!("  removed port: {host}:{guest}");
            }
        }
        for &(host, guest) in &next {
            if !record.ports.contains(&(host, guest)) {
                println!("  added port: {host}:{guest}");
            }
        }
        Ok(())
    }

    /// Change a running machine's allow list: the record, and the policy its
    /// network runtime follows from its next connection or lookup.
    fn update_running_egress(
        &self,
        db: &smolvm::db::SmolvmDb,
        record: &smolvm::config::VmRecord,
    ) -> smolvm::Result<()> {
        let _egress_lock = smolvm::agent::lock_live_egress(&self.name)?;
        let record = &db.get_vm(&self.name)?.unwrap_or_else(|| record.clone());
        let next = self
            .next_egress(record)?
            .ok_or_else(|| smolvm::Error::config("update", "no egress changes given"))?;
        record.check_live_egress(&next)?;
        let rules_change = next.egress_rules != record.egress_rules;
        smolvm::agent::apply_live_egress_policy(&self.name, &next, rules_change)?;
        let saved = db.update_vm(&self.name, |r| {
            r.network = next.network;
            r.allowed_cidrs = next.allowed_cidrs.clone();
            r.dns_filter_hosts = next.dns_filter_hosts.clone();
            r.egress_rules = next.egress_rules.clone();
        });
        if !matches!(saved, Ok(Some(_))) {
            // The record keeps the old allow list, so the running machine must too.
            let _ = smolvm::agent::apply_live_egress_policy(&self.name, record, rules_change);
            saved?;
            return Err(smolvm::Error::config(
                "update",
                format!("machine '{}' disappeared during update", self.name),
            ));
        }
        println!("Updated machine '{}' (running; applies now):", self.name);
        for cidr in next.allowed_cidrs.as_deref().unwrap_or(&[]) {
            println!("  allow cidr: {cidr}");
        }
        for host in next.dns_filter_hosts.as_deref().unwrap_or(&[]) {
            println!("  allow host: {host}");
        }
        for rule in &next.egress_rules {
            if !record.egress_rules.contains(rule) {
                println!("  allow udp: {}", smolvm::smolfile::udp_allow_label(rule));
            }
        }
        for rule in &record.egress_rules {
            if !next.egress_rules.contains(rule) {
                println!(
                    "  removed udp allow: {}",
                    smolvm::smolfile::udp_allow_label(rule)
                );
            }
        }
        if !self.remove_allow_host.is_empty() && next.allowed_cidrs.is_some() {
            println!(
                "Allowed CIDRs stay allowed, including addresses `machine create --allow-host` \
                 resolved; remove them with --remove-allow-cidr."
            );
        }
        Ok(())
    }

    pub fn run(self) -> smolvm::Result<()> {
        use smolvm::config::RecordState;
        use smolvm::data::storage::HostMount;

        let db = smolvm::db::SmolvmDb::open()?;
        let record = db.get_vm(&self.name)?.ok_or_else(|| {
            smolvm::Error::config("update", format!("machine '{}' not found", self.name))
        })?;

        let set_labels = smolvm::util::parse_labels(&self.labels)?;
        let state = record.actual_state();
        if self.changes_only_labels() {
            return self.update_labels(&db, &set_labels);
        }
        if state == RecordState::Running && self.changes_only_egress() {
            return self.update_running_egress(&db, &record);
        }
        if state == RecordState::Running && self.changes_only_ports() {
            return self.update_running_ports(&db, &record);
        }

        // Must be stopped (same check as resize)
        match state {
            RecordState::Stopped | RecordState::Created => {}
            _ => {
                return Err(smolvm::Error::InvalidState {
                    expected: "stopped".into(),
                    actual: format!("{:?}", state),
                });
            }
        }

        // Validate proposed resource values using the same logic as machine start.
        // Construct a temporary VmResources with the new values (falling back to
        // the record's current values) and run validate() — single source of truth.
        let proposed = smolvm::agent::VmResources {
            cpus: self.cpus.unwrap_or(record.cpus),
            memory_mib: self.mem.unwrap_or(record.mem),
            block_io: self.block_io.unwrap_or(record.block_io),
            disk_durability: self.disk_durability.unwrap_or(record.disk_durability),
            ..record.vm_resources()
        };
        proposed.validate()?;

        // Validate env specs have KEY=VALUE format with non-empty key
        for spec in &self.env {
            match spec.split_once('=') {
                Some((key, _)) if !key.is_empty() => {}
                _ => {
                    return Err(smolvm::Error::config(
                        "update",
                        format!("invalid env format '{}': expected KEY=VALUE", spec),
                    ));
                }
            }
        }

        // The egress allow list after this update, validated as a whole before
        // anything is written (#1299).
        let egress = self.next_egress(&record)?;

        // Parse and validate new mounts (after state check so
        // "machine is running" takes priority over "directory not found")
        let (volume_specs, new_disk_volumes) =
            smolvm::data::storage::split_disk_volume_specs(&self.volume)?;
        let new_mounts =
            HostMount::parse_with_system_mounts(&volume_specs, self.allow_system_mounts)?;
        let add_ports = PortMappingSpec::expand_all(&self.port)
            .map_err(|e| smolvm::Error::config("update ports", e))?;
        let remove_ports = PortMappingSpec::expand_all(&self.remove_port)
            .map_err(|e| smolvm::Error::config("update remove ports", e))?;

        self.next_ports(&record)?;

        // Compute the complete mount set in its rich form so changing a stopped
        // machine cannot lose the staged/live distinction or mount order.
        let mut final_mounts = record.host_mounts();
        for rm in &self.remove_volume {
            let rm_without_mode = rm
                .strip_suffix(":ro")
                .or_else(|| rm.strip_suffix(":rw"))
                .or_else(|| rm.strip_suffix(":staged"))
                .unwrap_or(rm);
            let canonical_rm = if let Some((rm_src, rm_tgt)) = rm_without_mode.rsplit_once(':') {
                let resolved = std::fs::canonicalize(rm_src)
                    .unwrap_or_else(|_| std::path::PathBuf::from(rm_src));
                Some((resolved, std::path::PathBuf::from(rm_tgt)))
            } else {
                None
            };
            final_mounts.retain(|mount| {
                canonical_rm.as_ref().is_none_or(|(source, target)| {
                    mount.source != *source || mount.target != *target
                })
            });
        }
        for mount in &new_mounts {
            if !final_mounts
                .iter()
                .any(|current| current.source == mount.source && current.target == mount.target)
            {
                final_mounts.push(mount.clone());
            }
        }
        HostMount::ensure_unique_targets(&final_mounts)?;
        let (final_live_mounts, final_staged_mounts) =
            HostMount::split_storage_tuples(&final_mounts);

        // Disk volumes are removed by their guest path alone. Their data stays
        // on the machine's disk, so adding the path back restores it.
        let (_, removed_disk_volumes) =
            smolvm::data::storage::split_disk_volume_specs(&self.remove_volume)?;
        let mut final_disk_volumes: Vec<String> = record
            .disk_volumes
            .iter()
            .filter(|target| !removed_disk_volumes.contains(target))
            .cloned()
            .collect();
        for target in &new_disk_volumes {
            if !final_disk_volumes.contains(target) {
                final_disk_volumes.push(target.clone());
            }
        }
        smolvm::data::storage::ensure_disk_volumes_distinct(
            &final_disk_volumes,
            final_mounts.iter().filter_map(|m| m.target.to_str()),
        )?;

        // Expand physical disk files before the DB write. If expansion fails,
        // no DB changes are made — the record stays consistent.
        let mut changes: Vec<String> = Vec::new();
        if self.storage.is_some() || self.overlay.is_some() {
            let disk_changes =
                vm_common::expand_disks(&self.name, &record, self.storage, self.overlay)?;
            changes.extend(disk_changes);
        }

        // Single DB transaction: all settings + disk sizes together.
        db.update_vm(&self.name, |r| {
            // Disk sizes (must match the physical expansion above)
            if let Some(s) = self.storage {
                r.storage_gb = Some(s);
            }
            if let Some(o) = self.overlay {
                r.overlay_gb = Some(o);
            }
            if !self.remove_volume.is_empty() || !new_mounts.is_empty() {
                for rm in &self.remove_volume {
                    changes.push(format!("  removed volume: {rm}"));
                }
                for mount in &new_mounts {
                    let mode = if mount.staged {
                        ":staged"
                    } else if mount.read_only {
                        ":ro"
                    } else {
                        ""
                    };
                    changes.push(format!(
                        "  added volume: {}:{}{}",
                        mount.source.display(),
                        mount.target.display(),
                        mode
                    ));
                }
                r.mounts = final_live_mounts.clone();
                r.staged_mounts = final_staged_mounts.clone();
            }
            if r.disk_volumes != final_disk_volumes {
                for target in &new_disk_volumes {
                    changes.push(format!("  added disk volume: {target}"));
                }
                r.disk_volumes = final_disk_volumes.clone();
            }

            // Ports: add new, remove specified
            let mut ports = r.port_mappings();
            for rm in &remove_ports {
                let before = ports.len();
                ports.retain(|existing| existing != rm);
                if ports.len() < before {
                    changes.push(format!("  removed port: {}", rm.label()));
                }
            }
            for p in &add_ports {
                if !ports.contains(p) {
                    changes.push(format!("  added port: {}", p.label()));
                    ports.push(*p);
                }
            }
            r.set_port_mappings(&ports);
            if self.no_auto_ports && r.auto_ports.is_some() {
                changes.push("  auto ports: disabled".to_string());
                r.auto_ports = None;
            }
            if self.auto_ports || !self.auto_ports_exclude.is_empty() {
                let next = smolvm::data::network::AutoPorts::excluding(
                    if self.auto_ports_exclude.is_empty() {
                        r.auto_ports.take().unwrap_or_default().exclude
                    } else {
                        self.auto_ports_exclude.clone()
                    },
                );
                changes.push(if next.exclude.is_empty() {
                    "  auto ports: enabled".to_string()
                } else {
                    format!(
                        "  auto ports: enabled, excluding {}",
                        next.exclude
                            .iter()
                            .map(u16::to_string)
                            .collect::<Vec<_>>()
                            .join(", ")
                    )
                });
                r.auto_ports = Some(next);
            }

            // Resources
            if let Some(cpus) = self.cpus {
                changes.push(format!("  cpus: {} → {}", r.cpus, cpus));
                r.cpus = cpus;
            }
            if let Some(mem) = self.mem {
                changes.push(format!("  memory: {} MiB → {} MiB", r.mem, mem));
                r.mem = mem;
            }
            if let Some(block_io) = self.block_io {
                changes.push(format!("  block I/O: {:?} → {:?}", r.block_io, block_io));
                r.block_io = block_io;
            }
            if let Some(durability) = self.disk_durability {
                changes.push(format!(
                    "  disk durability: {:?} → {:?}",
                    r.disk_durability, durability
                ));
                r.disk_durability = durability;
            }

            // Network
            if self.net {
                changes.push("  network: enabled".to_string());
                r.network = true;
            }
            if self.no_net {
                changes.push("  network: disabled".to_string());
                r.network = false;
                // Clear egress policy — allow_cidrs and dns_filter_hosts imply
                // networking. Leaving them set would re-enable egress on start.
                if r.allowed_cidrs.is_some() {
                    changes.push("  cleared allow_cidrs".to_string());
                    r.allowed_cidrs = None;
                }
                if r.dns_filter_hosts.is_some() {
                    changes.push("  cleared dns_filter_hosts".to_string());
                    r.dns_filter_hosts = None;
                }
                if !r.egress_rules.is_empty() {
                    changes.push("  cleared egress_rules".to_string());
                    r.egress_rules.clear();
                }
                if r.external_interceptor_required || r.mediated_egress_required {
                    changes.push("  cleared egress interceptor requirement".to_string());
                    r.external_interceptor_required = false;
                    r.mediated_egress_required = false;
                }
                // virtio-net without networking or published ports is rejected
                // at launch, so a machine that keeps the backend could never
                // start again. Published ports still need it.
                if r.ports.is_empty() && r.udp_ports.is_empty() && r.network_backend.is_some() {
                    changes.push("  cleared network backend".to_string());
                    r.network_backend = None;
                }
            }
            if let Some(ref next) = egress {
                if r.allowed_cidrs != next.allowed_cidrs {
                    changes.push(format!(
                        "  allowed CIDRs: {}",
                        next.allowed_cidrs
                            .as_deref()
                            .map_or("any".into(), |c| c.join(", "))
                    ));
                }
                if r.dns_filter_hosts != next.dns_filter_hosts {
                    changes.push(format!(
                        "  allowed hosts: {}",
                        next.dns_filter_hosts
                            .as_deref()
                            .map_or("any".into(), |h| h.join(", "))
                    ));
                }
                for rule in &next.egress_rules {
                    if !r.egress_rules.contains(rule) {
                        changes.push(format!(
                            "  allow udp: {}",
                            smolvm::smolfile::udp_allow_label(rule)
                        ));
                    }
                }
                for rule in &r.egress_rules {
                    if !next.egress_rules.contains(rule) {
                        changes.push(format!(
                            "  removed udp allow: {}",
                            smolvm::smolfile::udp_allow_label(rule)
                        ));
                    }
                }
                r.egress_rules = next.egress_rules.clone();
                r.network = next.network;
                r.allowed_cidrs = next.allowed_cidrs.clone();
                r.dns_filter_hosts = next.dns_filter_hosts.clone();
            }
            if self.no_egress_interceptor && r.external_interceptor_required {
                r.external_interceptor_required = false;
                r.mediated_egress_required = false;
                changes.push("  external egress interceptor requirement: removed".to_string());
            }
            if self.no_egress_interceptor {
                let before = r.egress_rules.len();
                r.egress_rules
                    .retain(|rule| rule.action != smolvm_protocol::RuleAction::Redirect);
                if r.egress_rules.len() != before {
                    changes.push("  removed redirect egress rules".to_string());
                }
            }

            // Env vars
            for rm_key in &self.remove_env {
                let before = r.env.len();
                r.env.retain(|(k, _)| k != rm_key);
                if r.env.len() < before {
                    changes.push(format!("  removed env: {}", rm_key));
                }
            }
            for spec in &self.env {
                if let Some((key, val)) = spec.split_once('=') {
                    r.env.retain(|(k, _)| k != key);
                    r.env.push((key.to_string(), val.to_string()));
                    changes.push(format!("  env: {}={}", key, val));
                }
            }

            // Workdir
            if let Some(ref wd) = self.workdir {
                changes.push(format!("  workdir: {}", wd));
                r.workdir = Some(wd.clone());
            }

            changes.extend(self.apply_labels(&mut r.labels, &set_labels));

            // Resolver options
            if !self.dns_option.is_empty() {
                changes.push(format!("  dns options: {}", self.dns_option.join(" ")));
                r.dns_options = self.dns_option.clone();
            } else if self.clear_dns_options {
                changes.push("  dns options: none".to_string());
                r.dns_options.clear();
            }

            // /dev/shm size, applied when the workload container next starts
            if let Some(ref size) = self.shm_size {
                changes.push(format!("  shm size: {size}"));
                r.shm_size = Some(size.clone());
            }

            // GPU
            if self.gpu {
                changes.push("  gpu: enabled".to_string());
                r.gpu = Some(true);
            }
            if self.no_gpu {
                changes.push("  gpu: disabled".to_string());
                r.gpu = Some(false);
            }
            if self.rosetta {
                changes.push("  rosetta: enabled".to_string());
                r.rosetta = Some(true);
            }
            if self.no_rosetta {
                changes.push("  rosetta: disabled".to_string());
                r.rosetta = Some(false);
            }
        })?;

        if changes.is_empty() {
            println!("No changes specified.");
        } else {
            println!("Updated machine '{}':", self.name);
            for change in &changes {
                println!("{}", change);
            }
            println!("\nStart with: smolvm machine start --name {}", self.name);
        }

        Ok(())
    }
}

// ============================================================================
// Data Dir Command
// ============================================================================

/// Print the on-disk data directory for a named machine.
///
/// Equivalent to calling `smolvm::agent::vm_data_dir(name)` — exposed as a
/// CLI command so shell scripts and external tooling have a single source
/// of truth for the path computation (which is hash-derived, not
/// name-derived).
#[derive(Args, Debug)]
pub struct DataDirCmd {
    /// Machine name.
    #[arg(short = 'n', long, value_name = "NAME", env = smolvm::data::consts::ENV_SMOLVM_MACHINE_NAME)]
    pub name: String,
}

impl DataDirCmd {
    pub fn run(self) -> smolvm::Result<()> {
        // Error (exit 1) for a machine that does not exist, rather than
        // printing a computed path for a name that was never created —
        // consistent with `status`/`start`/`delete`.
        let config = smolvm::config::SmolvmConfig::load()?;
        if config.get_vm(&self.name).is_none() {
            return Err(smolvm::Error::vm_not_found(&self.name));
        }
        let dir = smolvm::agent::vm_data_dir(&self.name);
        println!("{}", dir.display());
        Ok(())
    }
}

// ============================================================================
// Network Test Command
// ============================================================================

/// Test network connectivity directly from machine (debug TSI).
#[derive(Args, Debug)]
pub struct NetworkTestCmd {
    /// Named machine to test (omit for default)
    #[arg(long, env = smolvm::data::consts::ENV_SMOLVM_MACHINE_NAME)]
    pub name: Option<String>,

    /// URL to test
    #[arg(default_value = "http://1.1.1.1")]
    pub url: String,
}

impl NetworkTestCmd {
    pub fn run(self) -> smolvm::Result<()> {
        // Test a running machine as it is. Booting one here would launch it
        // without its recorded mounts, ports and resources, or fail outright
        // for a machine that was never started.
        let (manager, mut client) = vm_common::ensure_running_and_connect(&self.name)?;
        println!("Testing network from machine: {}", self.url);
        let result = client.network_test(&self.url);
        manager.detach();
        let result = result?;

        println!(
            "Result: {}",
            serde_json::to_string_pretty(&result).unwrap_or_default()
        );
        Ok(())
    }
}

// ============================================================================
// Images Command
// ============================================================================

/// List cached images and storage usage.
///
/// Shows all OCI images cached in the machine's storage, along with their
/// sizes and layer counts. Also displays total storage usage.
///
/// Examples:
///   smolvm machine images --name myvm
///   smolvm machine images --name myvm --json
#[derive(Args, Debug)]
pub struct ImagesCmd {
    /// Machine to query
    #[arg(long, required = true, value_name = "NAME", env = smolvm::data::consts::ENV_SMOLVM_MACHINE_NAME)]
    pub name: String,

    /// Output in JSON format
    #[arg(long)]
    pub json: bool,
}

impl ImagesCmd {
    pub fn run(self) -> smolvm::Result<()> {
        // Validate VM exists before creating storage (for_vm creates dirs).
        let db = smolvm::db::SmolvmDb::open()?;
        let record = db.get_vm(&self.name)?.ok_or_else(|| {
            smolvm::Error::config("images", format!("machine '{}' not found", self.name))
        })?;

        let manager =
            AgentManager::for_vm_with_sizes(&self.name, record.storage_gb, record.overlay_gb)?;

        let started_for_query = if manager.try_connect_existing().is_some() {
            manager.detach();
            false
        } else {
            eprintln!("Starting machine '{}' to query storage...", self.name);
            manager.start()?;
            true
        };
        let mut client = AgentClient::connect_with_retry(manager.vsock_socket())?;

        let status = client.storage_status()?;
        let images = client.list_images()?;

        if self.json {
            let output = serde_json::json!({
                "storage": {
                    "total_bytes": status.total_bytes,
                    "used_bytes": status.used_bytes,
                    "layer_count": status.layer_count,
                    "image_count": status.image_count,
                },
                "images": images,
            });
            let json = serde_json::to_string_pretty(&output)
                .map_err(|e| smolvm::Error::config("serialize json", e.to_string()))?;
            println!("{}", json);
        } else {
            println!("Storage Usage:");
            println!("  Total:  {}", format_bytes(status.total_bytes));
            println!("  Used:   {}", format_bytes(status.used_bytes));
            println!("  Layers: {}", status.layer_count);
            println!();

            if images.is_empty() {
                println!("No cached images.");
            } else {
                println!("Cached Images:");
                println!("{:<40} {:>10} {:>8}", "IMAGE", "SIZE", "LAYERS");
                println!("{}", "-".repeat(60));

                for image in &images {
                    let name = if image.reference.len() > 38 {
                        format!("{}...", &image.reference[..35])
                    } else {
                        image.reference.clone()
                    };
                    println!(
                        "{:<40} {:>10} {:>8}",
                        name,
                        format_bytes(image.size),
                        image.layer_count
                    );
                }

                println!();
                println!("Total: {} images", images.len());
            }
        }

        if started_for_query {
            let _ = manager.stop();
        }

        Ok(())
    }
}

// ============================================================================
// Prune Command
// ============================================================================

/// Remove unused images and layers to free disk space.
///
/// This removes layers that are not referenced by any cached image manifest.
/// Use --dry-run to see what would be removed without actually deleting.
///
/// Examples:
///   smolvm machine prune --name myvm --dry-run
///   smolvm machine prune --name myvm
///   smolvm machine prune --name myvm --all
#[derive(Args, Debug)]
pub struct PruneCmd {
    /// Machine to prune
    #[arg(long, required = true, value_name = "NAME", env = smolvm::data::consts::ENV_SMOLVM_MACHINE_NAME)]
    pub name: String,

    /// Show what would be removed without actually removing
    #[arg(long)]
    pub dry_run: bool,

    /// Remove all cached images (not just unreferenced layers)
    #[arg(long)]
    pub all: bool,
}

impl PruneCmd {
    pub fn run(self) -> smolvm::Result<()> {
        // Validate VM exists before creating storage (for_vm creates dirs).
        let db = smolvm::db::SmolvmDb::open()?;
        let record = db.get_vm(&self.name)?.ok_or_else(|| {
            smolvm::Error::config("prune", format!("machine '{}' not found", self.name))
        })?;

        let manager =
            AgentManager::for_vm_with_sizes(&self.name, record.storage_gb, record.overlay_gb)?;

        // Regular prune (unreferenced layers only) is safe on a running VM —
        // referenced layers can't be collected. --all deletes manifests for
        // layers that may be in active use, so it requires a stop first.
        let already_running = manager.try_connect_existing().is_some();
        let started_for_prune;

        if already_running && self.all {
            manager.detach();
            return Err(smolvm::Error::agent(
                "prune",
                format!("cannot prune --all while machine '{}' is running. Stop it first with: smolvm machine stop --name {}", self.name, self.name),
            ));
        } else if already_running {
            started_for_prune = false;
            manager.detach();
        } else {
            eprintln!("Starting machine...");
            manager.start()?;
            started_for_prune = true;
        }

        let mut client = AgentClient::connect_with_retry(manager.vsock_socket())?;

        if self.all {
            let images = client.list_images()?;

            if images.is_empty() {
                println!("No cached images to remove.");
            } else if record.image.is_some() {
                // An image-backed machine needs its cached image to restart, so
                // purging it would brick a *stopped* machine ("image not found"
                // on the next start). Keep the cache and reclaim only
                // unreferenced layers; to reclaim everything, delete the machine.
                let total_size: u64 = images.iter().map(|i| i.size).sum();
                if self.dry_run {
                    let would_free = client.garbage_collect(true, false)?;
                    println!(
                        "Machine '{}' is image-backed: would keep {} cached image(s) ({}) it needs to restart, and free {} of unreferenced layers.",
                        self.name,
                        images.len(),
                        format_bytes(total_size),
                        format_bytes(would_free)
                    );
                } else {
                    let freed = client.garbage_collect(false, false)?;
                    println!(
                        "Kept {} cached image(s) in use by machine '{}'; freed {} of unreferenced layers.",
                        images.len(),
                        self.name,
                        format_bytes(freed)
                    );
                    eprintln!(
                        "(--all keeps images a machine needs to restart; to reclaim everything: smolvm machine delete --name {})",
                        self.name
                    );
                }
            } else {
                // Bare VM: nothing depends on the image cache, so purge all.
                let total_size: u64 = images.iter().map(|i| i.size).sum();
                if self.dry_run {
                    println!(
                        "Would remove {} images ({})",
                        images.len(),
                        format_bytes(total_size)
                    );
                    for image in &images {
                        println!(
                            "  - {} ({}, {} layers)",
                            image.reference,
                            format_bytes(image.size),
                            image.layer_count
                        );
                    }
                } else {
                    println!("Removing all cached images...");
                    let freed = client.garbage_collect(false, true)?;
                    println!(
                        "Removed {} images, freed {}",
                        images.len(),
                        format_bytes(freed)
                    );
                }
            }
        } else if self.dry_run {
            println!("Scanning for unreferenced layers...");
            let would_free = client.garbage_collect(true, false)?;

            if would_free > 0 {
                println!(
                    "Would free {} of unreferenced layers",
                    format_bytes(would_free)
                );
            } else {
                println!("No unreferenced layers to remove.");
            }
        } else {
            println!("Removing unreferenced layers...");
            let freed = client.garbage_collect(false, false)?;

            if freed > 0 {
                println!("Freed {}", format_bytes(freed));
            } else {
                println!("No unreferenced layers to remove.");
            }
        }

        // Only stop the VM if we started it for this prune operation.
        // If the user's machine was already running, leave it running.
        if started_for_prune {
            let _ = manager.stop();
        }

        Ok(())
    }
}

// ============================================================================
// Cp (File Copy) Command
// ============================================================================

/// Copy files between host and a running machine.
///
/// Uses `machine:path` syntax to specify the remote side. A host directory
/// is uploaded recursively like `cp -r`: into an existing guest directory
/// under its own name, or as the destination path itself. Symlinks are
/// followed and each file keeps its permission bits unless --mode is given.
///
/// Examples:
///   smolvm machine cp ./script.py myvm:/workspace/script.py    # upload
///   smolvm machine cp ./src myvm:/workspace                     # upload a directory
///   smolvm machine cp myvm:/workspace/output.json ./output.json # download
#[derive(Args, Debug)]
pub struct CpCmd {
    /// Source path (local file or directory, or machine:path)
    #[arg(value_name = "SRC")]
    pub src: String,

    /// Destination path (local file or machine:path)
    #[arg(value_name = "DST")]
    pub dst: String,

    /// Set the mode of every uploaded file (octal, e.g. 644)
    #[arg(long, value_name = "OCTAL")]
    pub mode: Option<String>,

    /// Set the file's owner uid on upload (default: root)
    #[arg(long, value_name = "UID")]
    pub uid: Option<u32>,

    /// Set the file's owner gid on upload (default: root)
    #[arg(long, value_name = "GID")]
    pub gid: Option<u32>,
}

/// Parse a chmod-style octal mode ("644", "0755", "0o600").
fn parse_octal_mode(s: &str) -> smolvm::Result<u32> {
    let digits = s.trim_start_matches("0o");
    u32::from_str_radix(digits, 8)
        .ok()
        .filter(|m| *m <= 0o7777)
        .ok_or_else(|| {
            smolvm::Error::config(
                "cp",
                format!("invalid octal mode '{s}' (expected e.g. 644)"),
            )
        })
}

impl CpCmd {
    pub fn run(self) -> smolvm::Result<()> {
        // Parse src/dst to determine direction
        let (machine_name, guest_path, local_path, is_upload) =
            if let Some((name, path)) = self.src.split_once(':') {
                // Download: machine:path -> local
                (name.to_string(), path.to_string(), self.dst.clone(), false)
            } else if let Some((name, path)) = self.dst.split_once(':') {
                // Upload: local -> machine:path
                (name.to_string(), path.to_string(), self.src.clone(), true)
            } else {
                return Err(smolvm::Error::config(
                    "cp",
                    "one of SRC or DST must use machine:path syntax (e.g., myvm:/workspace/file)",
                ));
            };

        if !is_upload && (self.mode.is_some() || self.uid.is_some() || self.gid.is_some()) {
            return Err(smolvm::Error::config(
                "cp",
                "--mode/--uid/--gid apply to uploads only (host -> machine)",
            ));
        }

        let (manager, mut client) =
            vm_common::ensure_running_and_connect(&Some(machine_name.clone()))?;
        // Detach so the VM keeps running after cp exits.
        manager.detach();

        // Copy into the filesystem the machine's commands run in: an image
        // machine's container overlay, or a bare machine's own root.
        let record = smolvm::db::SmolvmDb::open()
            .ok()
            .and_then(|db| db.get_vm(&machine_name).ok().flatten());
        let target = record
            .as_ref()
            .map_or(smolvm::agent::WorkloadTarget::Vm, |record| {
                smolvm::workload::machine_target(record)
            });
        client.use_target(target)?;

        if is_upload {
            let meta = smolvm::agent::FileWriteMeta {
                mode: self.mode.as_deref().map(parse_octal_mode).transpose()?,
                uid: self.uid,
                gid: self.gid,
            };
            if Path::new(&local_path).is_dir() {
                return upload_directory(
                    &mut client,
                    &machine_name,
                    record.as_ref(),
                    &local_path,
                    &guest_path,
                    meta,
                );
            }
            // Stream from file — only one chunk (~1 MiB) in memory at a time.
            let file = std::fs::File::open(&local_path).map_err(|e| {
                smolvm::Error::agent("read local file", format!("{}: {}", local_path, e))
            })?;
            let size = file.metadata().map(|m| m.len()).map_err(|e| {
                smolvm::Error::agent("stat local file", format!("{}: {}", local_path, e))
            })?;
            let mut bar = crate::cli::ProgressBar::new(
                format!("Uploading {} -> {}", local_path, guest_path),
                Some(size),
            );
            client.write_file_from_reader_with_progress(&guest_path, file, size, meta, |sent| {
                bar.update(sent)
            })?;
            bar.finish(size);
        } else {
            // Stream to file — only one chunk (~16 MiB) in memory at a time.
            let mut bar = crate::cli::ProgressBar::new(
                format!("Downloading {} -> {}", guest_path, local_path),
                None,
            );
            let local = std::path::Path::new(&local_path);
            let size =
                client.read_file_to_path(&guest_path, local, |received| bar.update(received))?;
            bar.finish(size);
        }

        Ok(())
    }
}

/// Upload a host directory the way `cp -r` would: into `guest_path` under
/// the source's basename when that is an existing directory, otherwise as
/// `guest_path` itself. The protocol moves one file at a time, so the tree is
/// planned on the host, every guest directory is created by one `mkdir -p`,
/// and each file is then written with the single-file call. Host permission
/// bits are kept unless `--mode` was given; `--uid`/`--gid` apply to the
/// directories as well as the files.
fn upload_directory(
    client: &mut AgentClient,
    machine_name: &str,
    record: Option<&smolvm::config::VmRecord>,
    local_path: &str,
    guest_path: &str,
    meta: smolvm::agent::FileWriteMeta,
) -> smolvm::Result<()> {
    use crate::cli::cp_tree;

    let source = Path::new(local_path);
    let basename = source
        .canonicalize()
        .ok()
        .and_then(|p| p.file_name().map(|n| n.to_string_lossy().into_owned()))
        .ok_or_else(|| {
            smolvm::Error::config(
                "cp",
                format!("cannot copy '{local_path}': it has no directory name"),
            )
        })?;
    let plan = cp_tree::plan_directory(source)
        .map_err(|e| smolvm::Error::agent("read local directory", format!("{local_path}: {e}")))?;
    for (path, reason) in &plan.skipped {
        eprintln!("warning: skipping {local_path}/{path}: {reason}");
    }

    // An existing guest directory receives the copy inside it; a missing path
    // (or anything a listing refuses) becomes the copy, and `mkdir -p` then
    // reports a file in the way.
    let dst_is_dir = client.list_directory(guest_path).is_ok();
    let dest_root = cp_tree::resolve_destination(guest_path, &basename, dst_is_dir);

    let owner = match (meta.uid, meta.gid) {
        (None, None) => None,
        (uid, gid) => Some((uid.unwrap_or(0), gid.unwrap_or(0))),
    };
    let mkdir = cp_tree::mkdir_command(&dest_root, &plan.dirs, owner);
    let (code, _, stderr) = exec_in_machine(client, machine_name, record, mkdir)?;
    if code != 0 {
        return Err(smolvm::Error::agent(
            "create guest directories",
            String::from_utf8_lossy(&stderr).trim().to_string(),
        ));
    }

    let total_files = plan.files.len();
    let total_bytes = plan.total_bytes();
    let mut bar = crate::cli::ProgressBar::new(
        format!("Uploading {local_path} -> {dest_root}"),
        Some(total_bytes),
    );
    bar.set_files(0, total_files);
    let mut bytes_done = 0u64;
    for (index, file) in plan.files.iter().enumerate() {
        let guest_file = cp_tree::guest_join(&dest_root, &file.relative);
        let handle = std::fs::File::open(&file.host).map_err(|e| {
            smolvm::Error::agent("read local file", format!("{}: {}", file.host.display(), e))
        })?;
        let file_meta = smolvm::agent::FileWriteMeta {
            mode: Some(meta.mode.unwrap_or(file.mode)),
            ..meta
        };
        bar.set_files(index, total_files);
        client.write_file_from_reader_with_progress(
            &guest_file,
            handle,
            file.size,
            file_meta,
            |sent| bar.update(bytes_done + sent),
        )?;
        bytes_done += file.size;
    }
    bar.set_files(total_files, total_files);
    bar.finish(total_bytes);
    Ok(())
}

/// Run one shell command where the machine's files live: a bare machine's
/// root, or the image machine's persistent overlay with its mounts in place.
fn exec_in_machine(
    client: &mut AgentClient,
    machine_name: &str,
    record: Option<&smolvm::config::VmRecord>,
    script: String,
) -> smolvm::Result<(i32, Vec<u8>, Vec<u8>)> {
    let command = vec!["/bin/sh".to_string(), "-c".to_string(), script];
    let timeout = Some(Duration::from_secs(60));
    match record.and_then(|r| r.image.as_deref().map(|image| (r, image))) {
        Some((record, image)) => {
            let config = RunConfig::new(image, command)
                .in_machine(record, machine_name, &[])
                .with_mounts(mounts_to_virtiofs_bindings(&record.host_mounts()))
                .with_timeout(timeout);
            client.run_non_interactive(config)
        }
        None => client.vm_exec(command, Vec::new(), None, timeout, None),
    }
}

// ============================================================================
// Sync Command
// ============================================================================

/// Synchronize staged mounts from a running machine to their host sources.
#[derive(Args, Debug)]
pub struct SyncCmd {
    /// Machine to synchronize (default: "default")
    #[arg(short = 'n', long, value_name = "NAME", env = smolvm::data::consts::ENV_SMOLVM_MACHINE_NAME)]
    pub name: Option<String>,
}

impl SyncCmd {
    pub fn run(self) -> smolvm::Result<()> {
        let name = self.name.unwrap_or_else(|| "default".to_string());
        let db = smolvm::db::SmolvmDb::open()?;
        let record = db
            .get_vm(&name)?
            .ok_or_else(|| smolvm::Error::vm_not_found(&name))?;
        if record.staged_mounts.is_empty() {
            println!("Machine '{name}' has no staged mounts");
            return Ok(());
        }
        if let Some(error) = smolvm::staged_mount::refuse_detached_sync(&record, &name) {
            return Err(error);
        }

        let _source_lock = smolvm::agent::fork::lock_fork_source(&name)?;
        let (manager, mut client) = vm_common::ensure_running_and_connect(&Some(name.clone()))?;
        // This command observes an existing persistent VM; a failed sync must
        // leave it running so the user can fix the cause and retry.
        manager.detach();
        smolvm::staged_mount::sync_staged_mounts(&record, &mut client)?;
        println!("Synchronized staged mounts for '{name}'");
        Ok(())
    }
}

// ============================================================================
// Monitor Command
// ============================================================================

/// Monitor a running machine with health checks and restart policy.
///
/// Runs in the foreground, watching the machine and restarting on crash
/// or health check failure. Uses the restart policy from the machine's
/// config (set via Smolfile [restart] or --restart flag on create).
///
/// Ctrl+C stops monitoring; the machine keeps running.
///
/// Examples:
///   smolvm machine monitor --name myvm
///   smolvm machine monitor --name myvm --health-cmd "curl -f http://localhost:8080/health"
///   smolvm machine monitor --name myvm --restart always --interval 10
#[derive(Args, Debug)]
pub struct MonitorCmd {
    /// Machine to monitor (default: "default")
    #[arg(short = 'n', long, value_name = "NAME", env = smolvm::data::consts::ENV_SMOLVM_MACHINE_NAME)]
    pub name: Option<String>,

    /// Override restart policy (never, always, on-failure, unless-stopped)
    #[arg(long, value_name = "POLICY")]
    pub restart: Option<String>,

    /// Health check command (run inside the VM via sh -c)
    #[arg(long, value_name = "CMD")]
    pub health_cmd: Option<String>,

    /// Health check timeout in seconds [default: the Smolfile's, else 5]
    #[arg(long, value_name = "SECS")]
    pub health_timeout: Option<u64>,

    /// Check interval in seconds [default: the Smolfile's, else 5]
    #[arg(long, value_name = "SECS")]
    pub interval: Option<u64>,

    /// Health check failures before triggering restart [default: the Smolfile's, else 3]
    #[arg(long, value_name = "N")]
    pub health_retries: Option<u32>,

    /// Rebind the host egress interceptor on each automatic restart.
    /// Requires SMOLVM_INTERCEPTOR_TOKEN (64 hex digits).
    #[arg(long, value_name = "ADDR")]
    pub egress_interceptor: Option<std::net::SocketAddr>,

    #[arg(
        long,
        env = "SMOLVM_INTERCEPTOR_TOKEN",
        hide = true,
        hide_env_values = true,
        value_parser = clap::builder::StringValueParser::new().map(smolvm::secrets::Secret::new)
    )]
    pub egress_interceptor_token: Option<smolvm::secrets::Secret>,
}

impl MonitorCmd {
    /// Health check timeout, retries and check interval: a flag wins over the
    /// machine's Smolfile `[health]` value, which wins over the default.
    fn health_settings(&self, record: &smolvm::config::VmRecord) -> (Duration, u32, Duration) {
        let timeout = self
            .health_timeout
            .or(record.health_timeout_secs)
            .unwrap_or(5);
        let retries = self.health_retries.or(record.health_retries).unwrap_or(3);
        let interval = self.interval.or(record.health_interval_secs).unwrap_or(5);
        (
            Duration::from_secs(timeout),
            retries,
            Duration::from_secs(interval),
        )
    }

    pub fn run(self) -> smolvm::Result<()> {
        use smolvm::config::{RecordState, RestartPolicy};
        use smolvm::db::SmolvmDb;
        use smolvm::Error;
        use std::sync::atomic::{AtomicBool, Ordering};
        use std::sync::Arc;

        let external_interceptor = parse_external_interceptor(
            self.egress_interceptor,
            self.egress_interceptor_token.as_ref(),
        )?;
        let name = self.name.clone().unwrap_or_else(|| "default".to_string());

        // Load machine config from DB
        let db = SmolvmDb::open()?;
        let record = db
            .get_vm(&name)?
            .ok_or_else(|| Error::vm_not_found(&name))?;
        if let Some(endpoint) = external_interceptor.as_ref() {
            smolvm::agent::validate_external_interceptor(
                endpoint,
                &record.vm_resources(),
                record.credential_policy.is_some(),
                false,
            )?;
        }
        if record.external_interceptor_required && external_interceptor.is_none() {
            return Err(Error::config(
                "egress interceptor",
                "this machine requires an external interceptor on every start; pass --egress-interceptor and set SMOLVM_INTERCEPTOR_TOKEN",
            ));
        }

        // Build restart config: CLI override > VmRecord config
        let mut restart = record.restart.clone();
        if let Some(ref policy_str) = self.restart {
            restart.policy = policy_str
                .parse::<RestartPolicy>()
                .map_err(|e| Error::config("--restart", e))?;
        }

        // Resolve health check: CLI override > VmRecord config
        let health_cmd = self
            .health_cmd
            .clone()
            .map(|c| vec!["sh".into(), "-c".into(), c])
            .or_else(|| record.health_cmd.clone());
        let (health_timeout, health_retries, interval) = self.health_settings(&record);
        let startup_grace = record
            .health_startup_grace_secs
            .map(Duration::from_secs)
            .unwrap_or(Duration::ZERO);

        drop(db);

        // Ensure machine is running
        let manager = AgentManager::for_vm(&name)
            .map_err(|e| Error::agent("create agent manager", e.to_string()))?;

        if external_interceptor.is_some()
            && !record.external_interceptor_required
            && smolvm::agent::state_probe::resolve_state(&name, &record) == RecordState::Running
        {
            return Err(Error::config(
                "egress interceptor",
                "the running machine was not started with an external interceptor; stop and start it with --egress-interceptor before monitoring",
            ));
        }
        if !manager.is_process_alive() {
            println!("Machine '{}' is not running, starting...", name);
            vm_common::start_vm_named(
                &name,
                None,
                None,
                /* from_snapshot */ false,
                vm_common::ForkLaunch::default(),
                vm_common::StartOptions {
                    external_interceptor,
                    ..Default::default()
                },
            )?;
        }

        println!(
            "Monitoring machine '{}' (policy: {}, interval: {}s)",
            name,
            restart.policy,
            interval.as_secs()
        );
        if health_cmd.is_some() {
            println!(
                "  Health check: retries={}, timeout={}s",
                health_retries,
                health_timeout.as_secs()
            );
        }

        // Ctrl+C handler via SIGINT
        //
        // SAFETY: `stop` is an Arc<AtomicBool> that lives until the end of this
        // function. The cloned Arc below keeps a strong reference alive for the
        // duration of the monitor loop, so the raw pointer stored in STOP_FLAG
        // remains valid until after we break out of the loop and the function
        // returns. The handler only does an atomic store, which is async-signal-safe.
        let stop = Arc::new(AtomicBool::new(false));
        {
            let stop = stop.clone();
            unsafe {
                let _ = libc::signal(libc::SIGINT, {
                    static mut STOP_FLAG: *const AtomicBool = std::ptr::null();
                    STOP_FLAG = Arc::as_ptr(&stop);
                    extern "C" fn handler(_: libc::c_int) {
                        unsafe {
                            if !STOP_FLAG.is_null() {
                                (*STOP_FLAG).store(true, Ordering::SeqCst);
                            }
                        }
                    }
                    handler as *const () as libc::sighandler_t
                });
            }
        }

        let mut consecutive_health_failures: u32 = 0;
        let mut last_check = std::time::Instant::now();
        let mut last_start = std::time::Instant::now(); // tracks startup grace period

        loop {
            std::thread::sleep(interval);

            if stop.load(Ordering::SeqCst) {
                break;
            }

            // Detect sleep/wake: if the elapsed wall time is much longer than
            // the expected interval, the machine was likely suspended (laptop lid
            // closed). Reset health failures and skip this cycle to give the VM
            // time to recover network connections.
            let elapsed = last_check.elapsed();
            last_check = std::time::Instant::now();
            if elapsed > interval * 3 {
                let sleep_secs = elapsed.as_secs() - interval.as_secs();
                println!(
                    "  detected suspend (~{}s) — skipping health check for recovery",
                    sleep_secs
                );
                consecutive_health_failures = 0;
                continue;
            }

            // Refresh manager to pick up PID changes after restart
            let manager = match AgentManager::for_vm(&name) {
                Ok(m) => m,
                Err(_) => continue,
            };

            if manager.is_process_alive() {
                // Skip health checks during startup grace period
                if !startup_grace.is_zero() && last_start.elapsed() < startup_grace {
                    continue;
                }

                // Machine is alive — run health check if configured
                if let Some(ref cmd) = health_cmd {
                    match AgentClient::connect_with_short_timeout(manager.vsock_socket()) {
                        Ok(mut client) => {
                            match client.vm_exec(
                                cmd.clone(),
                                vec![],
                                None,
                                Some(health_timeout),
                                None,
                            ) {
                                Ok((0, _, _)) => {
                                    if consecutive_health_failures > 0 {
                                        println!("  health check passed (recovered)");
                                    }
                                    consecutive_health_failures = 0;
                                }
                                Ok((code, _, stderr)) => {
                                    consecutive_health_failures += 1;
                                    println!(
                                        "  health check failed (exit {}, {}/{}): {}",
                                        code,
                                        consecutive_health_failures,
                                        health_retries,
                                        String::from_utf8_lossy(&stderr).trim()
                                    );
                                }
                                Err(e) => {
                                    consecutive_health_failures += 1;
                                    println!(
                                        "  health check error ({}/{}): {}",
                                        consecutive_health_failures, health_retries, e
                                    );
                                }
                            }

                            if consecutive_health_failures >= health_retries {
                                println!("  unhealthy — stopping machine for restart");
                                let _ = vm_common::stop_vm_named(&name);
                                continue;
                            }
                        }
                        Err(_) => {
                            consecutive_health_failures += 1;
                            println!(
                                "  cannot connect to agent ({}/{})",
                                consecutive_health_failures, health_retries
                            );
                        }
                    }
                }
            } else {
                // Machine is dead
                consecutive_health_failures = 0;

                let exit_code = manager.child_pid().and_then(smolvm::process::try_wait);

                println!(
                    "  machine exited (exit code: {})",
                    exit_code
                        .map(|c| c.to_string())
                        .unwrap_or_else(|| "unknown".into())
                );

                // Update DB state
                if let Ok(db) = SmolvmDb::open() {
                    let _ = db.update_vm(&name, |r| {
                        r.state = RecordState::Stopped;
                        r.pid = None;
                        r.last_exit_code = exit_code;
                    });
                }

                if restart.should_restart(exit_code) {
                    let backoff = restart.backoff_duration();
                    restart.restart_count += 1;

                    println!(
                        "  restarting (attempt {}, backoff {}s)...",
                        restart.restart_count,
                        backoff.as_secs()
                    );

                    if let Ok(db) = SmolvmDb::open() {
                        let _ = db.update_vm(&name, |r| {
                            r.restart.restart_count = restart.restart_count;
                        });
                    }

                    std::thread::sleep(backoff);

                    if stop.load(Ordering::SeqCst) {
                        break;
                    }

                    match vm_common::start_vm_named(
                        &name,
                        None,
                        None,
                        /* from_snapshot */ false,
                        vm_common::ForkLaunch::default(),
                        vm_common::StartOptions {
                            external_interceptor,
                            ..Default::default()
                        },
                    ) {
                        Ok(()) => {
                            println!("  machine restarted");
                            last_start = std::time::Instant::now();
                        }
                        Err(e) => println!("  restart failed: {}", e),
                    }
                } else {
                    println!(
                        "  not restarting (policy: {}, count: {}/{})",
                        restart.policy,
                        restart.restart_count,
                        if restart.max_retries > 0 {
                            restart.max_retries.to_string()
                        } else {
                            "unlimited".into()
                        }
                    );
                    break;
                }
            }
        }

        // Mark user stopped
        if let Ok(db) = SmolvmDb::open() {
            let _ = db.update_vm(&name, |r| {
                r.restart.user_stopped = true;
            });
        }

        println!(
            "\nStopped monitoring. Machine '{}' may still be running.",
            name
        );
        Ok(())
    }
}

/// clap value parser for `--dns-option`: the same validation the guest agent
/// applies, so an option the agent would drop is refused at the command line.
pub(crate) fn parse_shm_size(value: &str) -> Result<String, String> {
    smolvm_protocol::guest_env::shm_size_option(value)
}

pub(crate) fn parse_dns_option(value: &str) -> Result<String, String> {
    smolvm_protocol::resolv::validate_option(value).map(|()| value.to_string())
}

/// Attached mounts: host directories mounted into a running machine.
#[derive(Subcommand, Debug)]
pub enum MountCmd {
    /// Mount a host directory into a running machine, without restarting it.
    /// The mount lasts until the machine stops; use `machine update -v` to
    /// keep one across restarts
    Add(MountAddCmd),
    /// Unmount a directory added with `mount add`, without restarting
    #[command(visible_alias = "rm")]
    Remove(MountRemoveCmd),
    /// List the directories mounted with `mount add` since the machine started
    Ls(MountLsCmd),
}

impl MountCmd {
    pub fn run(self) -> smolvm::Result<()> {
        match self {
            MountCmd::Add(cmd) => cmd.run(),
            MountCmd::Remove(cmd) => cmd.run(),
            MountCmd::Ls(cmd) => cmd.run(),
        }
    }
}

/// The record of machine `name`, failing unless it exists, and whether it runs.
fn mount_target_machine(name: &str) -> smolvm::Result<(smolvm::config::VmRecord, bool)> {
    let record = smolvm::db::SmolvmDb::open()?
        .get_vm(name)?
        .ok_or_else(|| smolvm::Error::vm_not_found(name))?;
    let running = AgentManager::for_vm(name)?.is_process_alive();
    Ok((record, running))
}

/// Mount a host directory into a running machine.
#[derive(Args, Debug)]
pub struct MountAddCmd {
    /// Running machine (default: "default")
    #[arg(short = 'n', long, value_name = "NAME", env = smolvm::data::consts::ENV_SMOLVM_MACHINE_NAME)]
    pub name: Option<String>,

    /// Host directory and guest path, as for `-v` (HOST:GUEST[:ro])
    #[arg(short = 'v', long = "volume", value_name = "HOST:GUEST[:ro]")]
    pub volume: String,
}

impl MountAddCmd {
    pub fn run(self) -> smolvm::Result<()> {
        let name = vm_common::vm_label(&self.name);
        let mount = HostMount::parse(std::slice::from_ref(&self.volume))?
            .pop()
            .ok_or_else(|| smolvm::Error::config("mount add", "a mount is required"))?;
        if mount.staged {
            return Err(smolvm::Error::config(
                "mount add",
                "a staged mount is copied in at boot; add it with `machine update -v` and restart",
            ));
        }
        let (record, running) = mount_target_machine(&name)?;
        if !running {
            return Err(smolvm::Error::config(
                "mount add",
                format!("machine '{name}' is not running; use `machine update -v` for a stopped machine"),
            ));
        }
        let boot_targets: Vec<String> = record.mounts.iter().map(|m| m.1.clone()).collect();
        let attached = smolvm::attach::attach(
            &name,
            &mount.source,
            &mount.target,
            mount.read_only,
            &boot_targets,
        )?;
        println!(
            "Mounted {} at {}{} in '{name}' until it stops",
            attached.source,
            attached.target,
            if attached.read_only {
                " (read-only)"
            } else {
                ""
            }
        );
        Ok(())
    }
}

/// Unmount a directory added with `mount add`.
#[derive(Args, Debug)]
pub struct MountRemoveCmd {
    /// Running machine (default: "default")
    #[arg(short = 'n', long, value_name = "NAME", env = smolvm::data::consts::ENV_SMOLVM_MACHINE_NAME)]
    pub name: Option<String>,

    /// Guest path the directory is mounted at
    #[arg(short = 't', long, value_name = "GUEST")]
    pub target: std::path::PathBuf,
}

impl MountRemoveCmd {
    pub fn run(self) -> smolvm::Result<()> {
        let name = vm_common::vm_label(&self.name);
        let (_, running) = mount_target_machine(&name)?;
        if !running {
            return Err(smolvm::Error::config(
                "mount remove",
                format!("machine '{name}' is not running, so nothing is attached"),
            ));
        }
        let detached = smolvm::attach::detach(&name, &self.target)?;
        println!("Unmounted {} from '{name}'", detached.target);
        Ok(())
    }
}

/// List directories mounted with `mount add`.
#[derive(Args, Debug)]
pub struct MountLsCmd {
    /// Machine (default: "default")
    #[arg(short = 'n', long, value_name = "NAME", env = smolvm::data::consts::ENV_SMOLVM_MACHINE_NAME)]
    pub name: Option<String>,

    /// Output in JSON format
    #[arg(long)]
    pub json: bool,
}

impl MountLsCmd {
    pub fn run(self) -> smolvm::Result<()> {
        let name = vm_common::vm_label(&self.name);
        let (_, running) = mount_target_machine(&name)?;
        // A stopped machine has nothing attached: its next boot starts empty.
        let mounts = if running {
            smolvm::attach::list(&name)?
        } else {
            Vec::new()
        };
        if self.json {
            println!(
                "{}",
                serde_json::to_string_pretty(&mounts).unwrap_or_default()
            );
            return Ok(());
        }
        if mounts.is_empty() {
            println!("No directories mounted with `mount add` in '{name}'");
            return Ok(());
        }
        for m in mounts {
            println!(
                "{} -> {}{}",
                m.source,
                m.target,
                if m.read_only { " (ro)" } else { "" }
            );
        }
        Ok(())
    }
}
