//! HTTP API server for smolvm.
//!
//! This module provides an HTTP API for managing machines, containers, and images
//! without CLI overhead.
//!
//! # Example
//!
//! ```bash
//! # Start the server on the default Unix socket
//! smolvm serve start
//!
//! # Or start the server on TCP explicitly
//! smolvm serve start --listen 127.0.0.1:8080
//!
//! # Create a machine
//! curl -X POST http://localhost:8080/api/v1/machines \
//!   -H "Content-Type: application/json" \
//!   -d '{"name": "test"}'
//! ```

pub mod admission;
pub(crate) mod cache_base_budget;
pub(crate) mod cache_base_fetch;
#[cfg(target_os = "linux")]
pub(crate) mod device_handoff;
#[path = "errors.rs"]
pub mod error;
pub mod guest_rollout;
pub mod handlers;
pub mod inflight;
pub mod memory_pressure;
pub mod pool_controller;
pub mod progress;
pub mod resize_controller;
pub mod rollout;
pub mod state;
pub mod supervisor;
pub mod types;

use axum::{
    extract::{DefaultBodyLimit, Request},
    http::{HeaderValue, StatusCode},
    middleware::{self, Next},
    response::Response,
    routing::{delete, get, post, put},
    Router,
};
use std::sync::Arc;
use std::time::Duration;
use tower_http::{
    cors::{AllowOrigin, CorsLayer},
    timeout::TimeoutLayer,
    trace::TraceLayer,
};
use utoipa::OpenApi;
use utoipa_swagger_ui::SwaggerUi;

use self::error::ApiError;
use state::ApiState;

/// OpenAPI documentation for the smolvm API.
#[derive(OpenApi)]
#[openapi(
    info(
        title = "smolvm API",
        version = "0.5.2",
        description = "smolvm API for managing machines and images.",
        license(name = "Apache-2.0", url = "https://www.apache.org/licenses/LICENSE-2.0")
    ),
    tags(
        (name = "Health", description = "Health check endpoints"),
        (name = "Node", description = "Node capacity introspection"),
        (name = "Machines", description = "Machine lifecycle management"),
        (name = "Pools", description = "Automatic held-fork worker pools"),
        (name = "Rollouts", description = "Framework-aware fused multi-policy rollout executors"),
        (name = "Execution", description = "Command execution in machines"),
        (name = "Logs", description = "Log streaming"),
        (name = "Images", description = "OCI image management"),
        (name = "Files", description = "File upload and download")
    ),
    paths(
        // Health
        handlers::health::health,
        // Node
        handlers::node::capacity,
        // Execution
        handlers::exec::exec_command,
        handlers::exec::exec_stream,
        handlers::exec::run_command,
        handlers::exec::stream_logs,
        // Files
        handlers::files::upload_file,
        handlers::files::download_file,
        // Images
        handlers::images::list_images,
        handlers::images::pull_image,
        // Machines
        handlers::machines::create_machine,
        handlers::machines::list_machines,
        handlers::machines::get_machine,
        handlers::machines::get_machine_egress_events,
        handlers::machines::get_machine_mediation_events,
        handlers::machines::start_machine,
        handlers::machines::branch_machine,
        handlers::machines::fork_machine,
        handlers::machines::release_held_fork,
        handlers::machines::stop_machine,
        handlers::machines::pause_machine,
        handlers::machines::resume_machine,
        handlers::machines::sync_machine,
        handlers::machines::delete_machine,
        handlers::machines::resize_machine,
        handlers::machines::set_machine_ports,
        handlers::machines::set_machine_cpu_limit,
        handlers::mounts::list_mounts,
        handlers::mounts::attach_mount,
        handlers::mounts::detach_mount,
        handlers::machines::publish_cache_disk,
        handlers::machines::delete_cache_base,
        handlers::machines::update_machine_egress,
        handlers::machines::put_credential_values,
        handlers::machines::export_machine,
        // Pools
        handlers::pools::create_pool,
        handlers::pools::list_pools,
        handlers::pools::get_pool,
        handlers::pools::resize_pool,
        handlers::pools::delete_pool,
        handlers::pools::acquire_lease,
        handlers::pools::acquire_lease_batch,
        handlers::pools::get_lease,
        handlers::pools::heartbeat_lease,
        handlers::pools::complete_lease,
        // Fused rollouts
        handlers::rollouts::create_executor,
        handlers::rollouts::list_executors,
        handlers::rollouts::get_executor,
        handlers::rollouts::delete_executor,
        handlers::rollouts::publish_policy,
        handlers::rollouts::publish_device_policy,
        handlers::rollouts::retire_policy,
        handlers::rollouts::generate,
        handlers::rollouts::generate_batch,
    ),
    components(schemas(
        // Request types
        types::CreateMachineRequest,
        types::RestartSpec,
        types::MountSpec,
        types::PortSpec,
        types::ResourceSpec,
        types::ExecRequest,
        types::RunRequest,
        types::EnvVar,
        types::PullImageRequest,
        types::DeleteQuery,
        types::LogsQuery,
        types::ResizeMachineRequest,
        types::SetPortsRequest,
        types::SetCpuLimitRequest,
        types::CacheDiskSpec,
        types::PublishCacheDiskRequest,
        types::PublishCacheDiskResponse,
        types::UpdateEgressRequest,
        types::CredentialValuesRequest,
        types::ForkRequest,
        types::ForkReleaseRequest,
        types::ExportRequest,
        types::StartMachineQuery,
        types::CreateForkPoolRequest,
        types::DeleteForkPoolQuery,
        types::AcquireForkLeaseRequest,
        types::AcquireForkLeaseBatchRequest,
        types::RolloutLeaseAccess,
        types::ForkLeasePayloadFile,
        types::ResizeForkPoolRequest,
        rollout::CreateRolloutExecutorRequest,
        rollout::PublishRolloutPolicyRequest,
        rollout::PublishDeviceRolloutPolicyRequest,
        rollout::RolloutPrompt,
        rollout::RolloutSamplingParams,
        rollout::RolloutCohort,
        rollout::RolloutGenerateRequest,
        rollout::RolloutBatchRequest,
        // Response types
        types::HealthResponse,
        types::CapacityResponse,
        types::CudaDeviceCapacity,
        types::MachineInfo,
        types::EgressDenialInfo,
        crate::agent::EgressSignal,
        crate::agent::EgressFlowSummary,
        crate::agent::GuestPressure,
        crate::agent::PressureStall,
        types::EgressEventsResponse,
        types::MountInfo,
        types::ListMachinesResponse,
        types::ExecResponse,
        types::ExportResponse,
        types::ImageInfo,
        types::ListImagesResponse,
        types::PullImageResponse,
        types::StartResponse,
        types::StopResponse,
        types::DeleteResponse,
        types::ApiErrorResponse,
        types::ForkPoolInfo,
        types::ListForkPoolsResponse,
        types::ForkLeaseInfo,
        types::ForkLeaseBatchItemResponse,
        types::AcquireForkLeaseBatchResponse,
        rollout::RolloutExecutorInfo,
        rollout::RolloutPolicyInfo,
        rollout::RolloutCompletion,
        rollout::RolloutUsage,
        rollout::RolloutGenerateResponse,
        rollout::RolloutBatchItemResponse,
        rollout::RolloutBatchResponse,
    ))
)]
pub struct ApiDoc;

/// Default timeout for bounded API requests (5 minutes).
///
/// Operations whose duration is controlled by the caller (exec/run), or by an
/// explicit longer transfer deadline (image pulls), are deliberately not
/// wrapped in this timeout.
const API_REQUEST_TIMEOUT_SECS: u64 = 300;

/// Timeout for creating a machine. Creating one from an image builds its image
/// seed, which pulls the whole image inside the request, and a large image from
/// a customer's own registry runs past [`API_REQUEST_TIMEOUT_SECS`]. Each image
/// pull is already bounded at ten minutes (`IMAGE_PULL_TIMEOUT_SECS`), so this
/// window sits above that and the pull, not the request, decides when it is
/// stuck. The control plane's create timeout matches it.
const CREATE_REQUEST_TIMEOUT_SECS: u64 = 900;
const _: () = assert!(
    CREATE_REQUEST_TIMEOUT_SECS > crate::agent::IMAGE_PULL_TIMEOUT_SECS,
    "a machine create must outlast the image pull it waits on"
);

/// Body cap for the file-upload route. axum's 2 MiB default silently 413s larger
/// uploads before the handler runs; the control plane permits 1 GiB, so match
/// it here. A body of declared length streams into the guest, so this costs no
/// memory; the agent enforces the true ceiling.
pub(crate) const MAX_FILE_UPLOAD_BYTES: usize = 1024 * 1024 * 1024;
/// Cap for an upload without a Content-Length, which is read whole into memory
/// before it is written.
pub(crate) const MAX_BUFFERED_UPLOAD_BYTES: usize = 100 * 1024 * 1024;
/// Bounded but large enough for cohorts of pre-tokenized RL prompts.
const MAX_ROLLOUT_REQUEST_BYTES: usize = 20 * 1024 * 1024;

/// Linux refuses an `execve` argument of 128 KiB or more (its terminating NUL
/// counts toward the limit).
const MAX_COMMAND_ARG_BYTES: usize = 128 * 1024 - 1;
/// The whole argument list shares a ~2 MiB limit with the environment and the
/// runtime's own arguments; keep well under it.
const MAX_COMMAND_TOTAL_BYTES: usize = 1024 * 1024;

/// Validate an API command payload: not empty, and small enough for the guest
/// to start. A larger one would only fail inside the guest as a bare
/// "Argument list too long".
pub fn validate_command(cmd: &[String]) -> Result<(), ApiError> {
    if cmd.is_empty() {
        return Err(ApiError::BadRequest("command cannot be empty".into()));
    }
    let too_big = |what: String| {
        ApiError::BadRequest(format!(
            "{what}; upload a long script as a file and run that file instead"
        ))
    };
    if let Some((index, arg)) = cmd
        .iter()
        .enumerate()
        .find(|(_, arg)| arg.len() > MAX_COMMAND_ARG_BYTES)
    {
        return Err(too_big(format!(
            "command argument {index} is {} bytes; one argument can be at most {MAX_COMMAND_ARG_BYTES} bytes",
            arg.len()
        )));
    }
    let total: usize = cmd.iter().map(|arg| arg.len() + 1).sum();
    if total > MAX_COMMAND_TOTAL_BYTES {
        return Err(too_big(format!(
            "command is {total} bytes; all arguments together can be at most {MAX_COMMAND_TOTAL_BYTES} bytes"
        )));
    }
    Ok(())
}

/// Create the API router with all endpoints.
///
/// `cors_origins` specifies allowed CORS origins. If empty, defaults to
/// localhost:8080 and localhost:3000 (both http and 127.0.0.1 variants).
pub fn create_router(state: Arc<ApiState>, cors_origins: Vec<String>) -> Router {
    // Health check route. `/health` is liveness (pure-async, always answers);
    // `/readyz` is a dispatch-path readiness probe that exercises the blocking pool
    // so the control can detect — and cordon — a node whose start/exec are wedged
    // even while `/health` still returns 200.
    let health_route = Router::new()
        .route("/health", get(handlers::health::health))
        .route("/readyz", get(handlers::health::readyz));

    // Node capacity introspection (polled by a fleet node-agent over HTTP).
    let capacity_route = Router::new().route("/capacity", get(handlers::node::capacity));

    // Explicit, control-initiated node drain (decommission). Stops all VMs
    // cleanly. Control-only by construction (the listener is mTLS-gated; the
    // loopback door is localhost).
    let drain_route = Router::new().route("/drain", post(handlers::machines::drain_node));

    // Brokered P2P blob serving: hand a cached layer blob to a sibling node so a
    // create on another node can pull it from a peer instead of the registry.
    // Read-only, content-addressed, and mTLS-gated by the listener by
    // construction (like /drain, see the comment above). No request timeout:
    // blobs can be large.
    let p2p_route = Router::new().route("/p2p/blob/{digest}", get(handlers::p2p::serve_blob));

    // Control-initiated artifact pre-warm: pull a `.smolmachine` layer into this
    // node's blob cache before any machine needs it, so a create finds it warm
    // instead of racing a cold multi-hundred-MB download against a client's
    // readiness timeout. mTLS-gated by the listener like `/drain` and `/p2p`
    // above. No request timeout: the transfer is as large as a blob pull, and
    // it runs off the critical path where slowness costs nothing.
    let warm_route = Router::new().route("/artifacts/warm", post(handlers::prewarm::warm_artifact));
    // Upload of a checkpoint captured with `defer_upload`: no request timeout,
    // as large as the capture it follows, and mTLS-gated like the routes above.
    let held_checkpoint_route = Router::new()
        .route(
            "/checkpoints/{key}/upload",
            post(handlers::machines::upload_held_checkpoint),
        )
        // The owner deleted the checkpoint: drop this node's copies of it.
        .route(
            "/checkpoints/{key}",
            delete(handlers::machines::forget_checkpoint),
        );

    // Long-lived streaming routes (no request timeout): SSE logs and the
    // interactive PTY WebSocket both outlive the 5-minute API timeout.
    let logs_route = Router::new()
        .route("/{id}/logs", get(handlers::exec::stream_logs))
        .route(
            "/{id}/checkpoint",
            post(handlers::machines::capture_portable_checkpoint)
                .put(handlers::machines::restore_portable_checkpoint),
        )
        .route(
            "/{id}/exec/interactive",
            get(handlers::exec::exec_interactive),
        );

    // Bounded metadata and lifecycle routes. These have no caller-selected
    // runtime and transfer no unbounded payload, so a stuck request should not
    // occupy a server task forever.
    let bounded_machine_routes = Router::new()
        .route("/", get(handlers::machines::list_machines))
        .route("/{id}", get(handlers::machines::get_machine))
        .route(
            "/{id}/egress-events",
            get(handlers::machines::get_machine_egress_events),
        )
        .route(
            "/{id}/mediation-events",
            get(handlers::machines::get_machine_mediation_events),
        )
        .route("/{id}/branches", post(handlers::machines::branch_machine))
        .route("/{id}/fork", post(handlers::machines::fork_machine))
        .route(
            "/{id}/branch-release",
            post(handlers::machines::release_held_fork),
        )
        .route(
            "/{id}/fork-release",
            post(handlers::machines::release_held_fork),
        )
        .route("/{id}/stop", post(handlers::machines::stop_machine))
        .route("/{id}/pause", post(handlers::machines::pause_machine))
        .route(
            "/{id}/pause/checkpoint",
            get(handlers::machines::paused_checkpoint),
        )
        .route("/{id}/resume", post(handlers::machines::resume_machine))
        .route("/{id}/sync", post(handlers::machines::sync_machine))
        .route("/{id}/resize", post(handlers::machines::resize_machine))
        .route("/{id}/ports", put(handlers::machines::set_machine_ports))
        .route(
            "/{id}/cpu-limit",
            put(handlers::machines::set_machine_cpu_limit),
        )
        .route(
            "/{id}/mounts",
            get(handlers::mounts::list_mounts)
                .post(handlers::mounts::attach_mount)
                .delete(handlers::mounts::detach_mount),
        )
        .route(
            "/{id}/egress",
            post(handlers::machines::update_machine_egress),
        )
        .route(
            "/{id}/credential-values",
            put(handlers::machines::put_credential_values),
        )
        .route("/{id}/export", post(handlers::machines::export_machine))
        .route("/{id}", delete(handlers::machines::delete_machine))
        // File I/O routes. Without a raised limit axum's 2 MiB default rejects
        // any larger upload with a bare 413 "Failed to buffer the request
        // body"; the control plane permits 1 GiB here, so match it. The
        // handler streams a body of declared length and caps one without at
        // MAX_BUFFERED_UPLOAD_BYTES. Per-route so only uploads get the large
        // cap; the agent enforces the true maximum (FILE_TRANSFER_MAX_TOTAL).
        .route(
            "/{id}/files/{*path}",
            put(handlers::files::upload_file).layer(DefaultBodyLimit::max(MAX_FILE_UPLOAD_BYTES)),
        )
        .route("/{id}/files/{*path}", get(handlers::files::download_file))
        .route("/{id}/images", get(handlers::images::list_images))
        .layer(TimeoutLayer::with_status_code(
            StatusCode::REQUEST_TIMEOUT,
            Duration::from_secs(API_REQUEST_TIMEOUT_SECS),
        ));

    let create_route = Router::new()
        .route("/", post(handlers::machines::create_machine))
        .layer(TimeoutLayer::with_status_code(
            StatusCode::REQUEST_TIMEOUT,
            Duration::from_secs(CREATE_REQUEST_TIMEOUT_SECS),
        ));

    // Long operations own their deadline. In particular, exec and run pass
    // `timeout_secs` through to the guest agent; wrapping them in the generic
    // five-minute timeout used to turn a valid 30-minute exec into an HTTP 408
    // at 300 seconds. Image pulls already carry a ten-minute agent deadline.
    let long_machine_routes = Router::new()
        .route("/{id}/start", post(handlers::machines::start_machine))
        .route("/{id}/exec", post(handlers::exec::exec_command))
        .route("/{id}/exec/stream", post(handlers::exec::exec_stream))
        .route("/{id}/run", post(handlers::exec::run_command))
        .route("/{id}/images/pull", post(handlers::images::pull_image))
        // Flattening and uploading a cache disk scales with its size: a 32 GB
        // publish ran past the five-minute timeout every time and answered 408
        // while its upload was still going. It gives up only once it stops
        // making progress instead.
        .route(
            "/{id}/cache-disk/publish",
            post(handlers::machines::publish_cache_disk)
                .layer(axum::middleware::from_fn(progress::idle_timeout)),
        );

    // Machine routes
    let machine_routes = Router::new()
        .merge(logs_route)
        .merge(bounded_machine_routes)
        .merge(create_route)
        .merge(long_machine_routes);

    // Automatic pool operations are bounded by the same request timeout as
    // machine lifecycle calls. Pool fill and worker replacement happen in the
    // background controller, so create/delete themselves stay quick.
    let pool_routes = Router::new()
        .route("/", post(handlers::pools::create_pool))
        .route("/", get(handlers::pools::list_pools))
        .route("/{name}", get(handlers::pools::get_pool))
        .route("/{name}", delete(handlers::pools::delete_pool))
        .route("/{name}/size", put(handlers::pools::resize_pool))
        .route("/{name}/leases", post(handlers::pools::acquire_lease))
        .route(
            "/{name}/lease-batches",
            post(handlers::pools::acquire_lease_batch),
        )
        .route("/{name}/leases/{lease}", get(handlers::pools::get_lease))
        .route(
            "/{name}/leases/{lease}/heartbeat",
            post(handlers::pools::heartbeat_lease),
        )
        .route(
            "/{name}/leases/{lease}/complete",
            post(handlers::pools::complete_lease),
        )
        .layer(TimeoutLayer::with_status_code(
            StatusCode::REQUEST_TIMEOUT,
            Duration::from_secs(API_REQUEST_TIMEOUT_SECS),
        ));

    // Volume provisioning (node-side storage for the control plane): create the
    // backing storage on THIS worker and return its host path. See
    // handlers::volumes.
    let volume_routes = Router::new()
        .route("/", post(handlers::volumes::provision_volume))
        .route("/{id}", delete(handlers::volumes::deprovision_volume));

    // Fused rollout handlers own their deadlines so cancelled clients abort the
    // backend HTTP request instead of inheriting the generic lifecycle timeout.
    let rollout_routes = Router::new()
        .route("/", post(handlers::rollouts::create_executor))
        .route("/", get(handlers::rollouts::list_executors))
        .route("/{name}", get(handlers::rollouts::get_executor))
        .route("/{name}", delete(handlers::rollouts::delete_executor))
        .route("/{name}/policies", post(handlers::rollouts::publish_policy))
        .route(
            "/{name}/device-policies",
            post(handlers::rollouts::publish_device_policy),
        )
        .route(
            "/{name}/policies/{policy}/{version}",
            delete(handlers::rollouts::retire_policy),
        )
        .route("/{name}/generate", post(handlers::rollouts::generate))
        .route("/{name}/batches", post(handlers::rollouts::generate_batch))
        .layer(DefaultBodyLimit::max(MAX_ROLLOUT_REQUEST_BYTES));

    // Cache bases this server holds: the control plane removes one a failed
    // publish left behind, or one whose cache disk was deleted.
    let cache_base_routes =
        Router::new().route("/{base}", delete(handlers::machines::delete_cache_base));

    // API v1 routes
    let api_v1 = Router::new()
        .nest("/machines", machine_routes)
        .nest("/pools", pool_routes)
        .nest("/rollout-executors", rollout_routes)
        .nest("/volumes", volume_routes)
        .nest("/cache-bases", cache_base_routes);

    let cors = build_cors(cors_origins);

    // Prometheus metrics
    let metrics_route = Router::new().route("/metrics", get(serve_metrics));

    // Combine all routes
    Router::new()
        .merge(health_route)
        .merge(capacity_route)
        .merge(drain_route)
        .merge(p2p_route)
        .merge(warm_route)
        .merge(held_checkpoint_route)
        .merge(metrics_route)
        .nest("/api/v1", api_v1)
        .merge(SwaggerUi::new("/swagger-ui").url("/api-docs/openapi.json", ApiDoc::openapi()))
        .layer(middleware::from_fn(trace_id_middleware))
        .layer(TraceLayer::new_for_http().make_span_with(|request: &axum::http::Request<axum::body::Body>| {
            tracing::debug_span!("request", method = %request.method(), path = request.uri().path())
        }))
        .layer(cors)
        // Outermost, so a request counts from arrival until its body is sent.
        .layer(middleware::from_fn_with_state(
            inflight::global(),
            inflight::track,
        ))
        .with_state(state)
}

/// Build the shared CORS layer from the configured origins (falling back to the
/// localhost defaults). Shared by [`create_router`] and [`create_local_router`].
fn build_cors(cors_origins: Vec<String>) -> CorsLayer {
    let default_origins = || {
        vec![
            "http://localhost:8080"
                .parse()
                .expect("hardcoded CORS origin"),
            "http://127.0.0.1:8080"
                .parse()
                .expect("hardcoded CORS origin"),
            "http://localhost:3000"
                .parse()
                .expect("hardcoded CORS origin"),
            "http://127.0.0.1:3000"
                .parse()
                .expect("hardcoded CORS origin"),
        ]
    };
    let origins: Vec<axum::http::HeaderValue> = if cors_origins.is_empty() {
        default_origins()
    } else {
        let mut valid = Vec::new();
        for origin in &cors_origins {
            match origin.parse() {
                Ok(v) => valid.push(v),
                Err(e) => {
                    tracing::warn!(origin = %origin, error = %e, "invalid CORS origin, skipping");
                }
            }
        }
        if valid.is_empty() {
            tracing::warn!("no valid CORS origins provided, falling back to defaults");
            default_origins()
        } else {
            valid
        }
    };
    CorsLayer::new()
        .allow_origin(AllowOrigin::list(origins))
        .allow_methods([
            axum::http::Method::GET,
            axum::http::Method::POST,
            axum::http::Method::PUT,
            axum::http::Method::DELETE,
        ])
        .allow_headers([axum::http::header::CONTENT_TYPE])
}

/// The router served on the plain-HTTP LOOPBACK door (fleet mode), as distinct
/// from the full [`create_router`] served on the mTLS network port.
///
/// The loopback door is unauthenticated by construction — anything that can
/// reach `127.0.0.1` on the node gets in. Serving the full router there exposed
/// the machine/file/exec API (`/api/v1/*`) to any local caller, and a crafted
/// registry reference (`127.0.0.1:<port>/...`) makes the node's OWN in-process
/// registry-pull client such a caller: it turns an attacker-supplied image ref
/// into unauthenticated reads/writes against `download_file` / `upload_file`.
///
/// The door's only legitimate job is liveness — a fleet node-agent polling
/// `/capacity` (plus `/health`/`/readyz`, read-only `/metrics`, and `/inflight`,
/// the request counts a roll waits on before restarting serve). Restricting
/// it to exactly those routes closes the SSRF pivot without touching the mTLS
/// control path, which keeps the full API. Everything else 404s on loopback.
pub fn create_local_router(state: Arc<ApiState>, cors_origins: Vec<String>) -> Router {
    let cors = build_cors(cors_origins);
    Router::new()
        .route("/health", get(handlers::health::health))
        .route("/readyz", get(handlers::health::readyz))
        .route("/capacity", get(handlers::node::capacity))
        .route("/metrics", get(serve_metrics))
        .route("/inflight", get(inflight::inflight_status))
        .layer(middleware::from_fn(trace_id_middleware))
        .layer(TraceLayer::new_for_http().make_span_with(|request: &axum::http::Request<axum::body::Body>| {
            tracing::debug_span!("request", method = %request.method(), path = request.uri().path())
        }))
        .layer(cors)
        .with_state(state)
}

#[cfg(test)]
mod loopback_router_test {
    use super::*;
    use axum::body::Body;
    use axum::http::{Request, StatusCode};
    use tower::ServiceExt;

    async fn status(router: axum::Router, method: &str, path: &str) -> StatusCode {
        router
            .oneshot(
                Request::builder()
                    .method(method)
                    .uri(path)
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap()
            .status()
    }

    // The loopback door must NOT expose the machine/file/exec API — that is the
    // SSRF pivot this router closes. Liveness routes must still answer.
    #[tokio::test]
    async fn loopback_router_excludes_machine_file_exec_api() {
        let dir = tempfile::TempDir::new().unwrap();
        let db = crate::db::SmolvmDb::open_at(&dir.path().join("t.db")).unwrap();
        let state = std::sync::Arc::new(crate::api::state::ApiState::with_db(db));
        let local = create_local_router(state.clone(), vec![]);

        // The attack surface — every one must be 404 (route absent) on loopback:
        for (m, p) in [
            ("GET", "/api/v1/machines"),
            ("GET", "/api/v1/machines/x/files/etc/passwd"),
            ("PUT", "/api/v1/machines/x/files/etc/cron.d/x"),
            ("POST", "/api/v1/machines/x/exec"),
            ("POST", "/api/v1/machines"),
        ] {
            assert_eq!(
                status(local.clone(), m, p).await,
                StatusCode::NOT_FOUND,
                "loopback door must NOT expose {m} {p}"
            );
        }
        // Liveness must still work (not 404) so the node-agent poll survives:
        assert_ne!(
            status(local.clone(), "GET", "/capacity").await,
            StatusCode::NOT_FOUND,
            "loopback /capacity must remain served"
        );
        assert_ne!(
            status(local.clone(), "GET", "/health").await,
            StatusCode::NOT_FOUND,
            "loopback /health must remain served"
        );
        assert_eq!(
            status(local.clone(), "GET", "/inflight").await,
            StatusCode::OK,
            "loopback /inflight must be served so a roll can wait for idle"
        );

        // Sanity: the FULL router (mTLS port) still DOES expose the API.
        let full = create_router(state, vec![]);
        assert_ne!(
            status(full, "GET", "/api/v1/machines").await,
            StatusCode::NOT_FOUND,
            "full router must still expose the machine API on the mTLS port"
        );
    }
}

/// Install the global Prometheus metrics recorder.
/// Returns None if a recorder is already installed (e.g., in tests).
pub fn install_metrics_recorder() -> Option<metrics_exporter_prometheus::PrometheusHandle> {
    metrics_exporter_prometheus::PrometheusBuilder::new()
        .install_recorder()
        .ok()
}

/// Serve Prometheus metrics as text.
async fn serve_metrics() -> String {
    METRICS_HANDLE.get().map(|h| h.render()).unwrap_or_default()
}

/// Global handle to the Prometheus recorder, set once at startup.
/// Only accessed by serve.rs (startup) and serve_metrics (handler).
pub static METRICS_HANDLE: std::sync::OnceLock<metrics_exporter_prometheus::PrometheusHandle> =
    std::sync::OnceLock::new();

/// Normalize a request path for Prometheus labels.
/// Replaces machine IDs with `:id` to prevent cardinality explosion.
/// Pull the machine id out of `/api/v1/machines/<id>/...` so request logs can be
/// attributed to a specific machine. Metrics deliberately normalize this segment
/// away (cardinality), but logs need it: without it a failed start is an
/// anonymous 5xx and answering "why did this customer's machine fail" means
/// grepping journals on every worker by hand.
fn machine_id_from_path(path: &str) -> Option<&str> {
    let parts: Vec<&str> = path.split('/').collect();
    if parts.len() >= 5 && parts[1] == "api" && parts[3] == "machines" {
        return parts.get(4).copied().filter(|s| !s.is_empty());
    }
    None
}

fn normalize_metrics_path(path: &str) -> String {
    let parts: Vec<&str> = path.split('/').collect();
    if parts.len() >= 4
        && parts[1] == "api"
        && matches!(parts[3], "machines" | "pools" | "rollout-executors")
    {
        if let Some(id_pos) = parts.get(4) {
            if !id_pos.is_empty() {
                let mut normalized = parts[..4].to_vec();
                normalized.push(":id");
                normalized.extend_from_slice(&parts[5..]);
                if parts[3] == "rollout-executors"
                    && normalized.get(5) == Some(&"policies")
                    && normalized.len() >= 8
                {
                    normalized[6] = ":policy";
                    normalized[7] = ":version";
                }
                return normalized.join("/");
            }
        }
    }
    path.to_string()
}

/// Trace ID for correlating API requests to agent operations.
#[derive(Clone, Debug)]
pub struct TraceId(pub String);

/// Middleware that generates a unique trace ID for each request and returns it
/// in the `X-Trace-Id` response header.
async fn trace_id_middleware(mut req: Request, next: Next) -> Response {
    use std::sync::atomic::{AtomicU64, Ordering};
    use tracing::Instrument;

    static REQUEST_SEQ: AtomicU64 = AtomicU64::new(0);
    let seq = REQUEST_SEQ.fetch_add(1, Ordering::Relaxed);
    let trace_id = format!("{:08x}{:08x}", seq, std::process::id());

    req.extensions_mut().insert(TraceId(trace_id.clone()));

    let method = req.method().to_string();
    // Normalize path to template to avoid cardinality explosion from machine IDs
    let path_template = normalize_metrics_path(req.uri().path());

    // Attach the machine id to the span so every line emitted while handling the
    // request — including the trace layer's response-failure log — is attributable.
    let machine = machine_id_from_path(req.uri().path())
        .unwrap_or("-")
        .to_string();
    let span = tracing::info_span!("request", trace_id = %trace_id, machine = %machine);
    let mut response = next.run(req).instrument(span).await;

    let status = response.status().as_u16().to_string();
    metrics::counter!("smolvm_api_requests_total", "method" => method, "status" => status, "path" => path_template).increment(1);

    if let Ok(val) = HeaderValue::from_str(&trace_id) {
        response.headers_mut().insert("x-trace-id", val);
    }
    response
}

#[cfg(test)]
mod tests {
    use super::{machine_id_from_path, normalize_metrics_path, validate_command};

    #[test]
    fn machine_id_is_extracted_from_machine_routes() {
        assert_eq!(
            machine_id_from_path("/api/v1/machines/my-vm"),
            Some("my-vm")
        );
        assert_eq!(
            machine_id_from_path("/api/v1/machines/my-vm/start"),
            Some("my-vm")
        );
        assert_eq!(
            machine_id_from_path("/api/v1/machines/my-vm/exec"),
            Some("my-vm")
        );
    }

    #[test]
    fn non_machine_routes_have_no_machine_id() {
        assert_eq!(machine_id_from_path("/health"), None);
        assert_eq!(machine_id_from_path("/api/v1/machines"), None);
        assert_eq!(machine_id_from_path("/api/v1/machines/"), None);
    }

    #[test]
    fn metrics_paths_hide_rollout_and_pool_identifiers() {
        assert_eq!(
            normalize_metrics_path("/api/v1/pools/team-a/leases"),
            "/api/v1/pools/:id/leases"
        );
        assert_eq!(
            normalize_metrics_path("/api/v1/rollout-executors/qwen/policies/experiment-1/step-400"),
            "/api/v1/rollout-executors/:id/policies/:policy/:version"
        );
        assert_eq!(
            normalize_metrics_path("/api/v1/rollout-executors/qwen/generate"),
            "/api/v1/rollout-executors/:id/generate"
        );
    }

    #[test]
    fn test_validate_command() {
        assert!(validate_command(&[]).is_err());
        assert!(validate_command(&["echo".to_string()]).is_ok());
        assert!(validate_command(&["echo".to_string(), "hello".to_string()]).is_ok());
        // The largest argument the guest can take, and one byte over it.
        let max = "x".repeat(super::MAX_COMMAND_ARG_BYTES);
        assert!(validate_command(&["sh".into(), "-c".into(), max.clone()]).is_ok());
        let over = validate_command(&["sh".into(), "-c".into(), format!("{max}x")]).unwrap_err();
        assert!(format!("{over:?}").contains("argument 2"));
        // Many arguments under the per-argument limit can still be too many.
        let many: Vec<String> = (0..10).map(|_| max.clone()).collect();
        assert!(validate_command(&many).is_err());
    }
}

#[cfg(test)]
mod nested_virt_gate_test {
    use super::*;
    use axum::body::Body;
    use axum::http::{Request, StatusCode};
    use tower::ServiceExt;

    async fn send(
        router: axum::Router,
        method: &str,
        path: &str,
        body: &str,
    ) -> (StatusCode, String) {
        let response = router
            .oneshot(
                Request::builder()
                    .method(method)
                    .uri(path)
                    .header("content-type", "application/json")
                    .body(Body::from(body.to_string()))
                    .unwrap(),
            )
            .await
            .unwrap();
        let status = response.status();
        let bytes = axum::body::to_bytes(response.into_body(), usize::MAX)
            .await
            .unwrap();
        (status, String::from_utf8_lossy(&bytes).into_owned())
    }

    // Nesting hands the guest the host's nested-KVM code, so a server refuses it
    // until started with --allow-nested-virt, and turning the flag off again
    // keeps machines created with it from starting.
    #[tokio::test]
    async fn nested_virt_needs_the_server_opt_in_to_create_and_to_start() {
        let dir = tempfile::TempDir::new().unwrap();
        let db = crate::db::SmolvmDb::open_at(&dir.path().join("t.db")).unwrap();
        let state = std::sync::Arc::new(crate::api::state::ApiState::with_db(db));
        let router = || create_router(state.clone(), vec![]);

        let (status, body) = send(
            router(),
            "POST",
            "/api/v1/machines",
            r#"{"name":"nest","nestedVirt":true}"#,
        )
        .await;
        assert_eq!(status, StatusCode::FORBIDDEN, "{body}");
        assert!(body.contains("--allow-nested-virt"), "{body}");
        assert!(
            state.db().get_vm("nest").unwrap().is_none(),
            "refused before anything is written"
        );

        state.set_allow_nested_virt(true);
        let (status, body) = send(
            router(),
            "POST",
            "/api/v1/machines",
            r#"{"name":"nest","nestedVirt":true}"#,
        )
        .await;
        assert!(status.is_success(), "{status}: {body}");
        let record = state.db().get_vm("nest").unwrap().expect("created");
        assert_eq!(record.nested_virt, Some(true));
        assert!(record.vm_resources().nested_virt);

        state.set_allow_nested_virt(false);
        let (status, body) = send(router(), "POST", "/api/v1/machines/nest/start", "{}").await;
        assert_eq!(status, StatusCode::FORBIDDEN, "{body}");
        assert!(body.contains("--allow-nested-virt"), "{body}");
    }

    #[tokio::test]
    async fn a_machine_without_the_field_is_not_nested() {
        let dir = tempfile::TempDir::new().unwrap();
        let db = crate::db::SmolvmDb::open_at(&dir.path().join("t.db")).unwrap();
        let state = std::sync::Arc::new(crate::api::state::ApiState::with_db(db));
        let (status, body) = send(
            create_router(state.clone(), vec![]),
            "POST",
            "/api/v1/machines",
            r#"{"name":"flat"}"#,
        )
        .await;
        assert!(status.is_success(), "{status}: {body}");
        let record = state.db().get_vm("flat").unwrap().expect("created");
        assert_eq!(record.nested_virt, None);
        assert!(!record.vm_resources().nested_virt);
    }

    #[test]
    fn the_resource_spec_round_trips_nesting() {
        let mut res = crate::data::resources::VmResources::default();
        assert!(!crate::api::state::vm_resources_to_spec(res.clone())
            .nested_virt
            .unwrap_or(false));
        res.nested_virt = true;
        let spec = crate::api::state::vm_resources_to_spec(res);
        assert_eq!(spec.nested_virt, Some(true));
        assert!(crate::api::state::resource_spec_to_vm_resources(&spec, false).nested_virt);
    }
}
