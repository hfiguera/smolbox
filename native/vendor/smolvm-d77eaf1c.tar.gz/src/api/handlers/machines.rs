//! Machine lifecycle handlers.
//!
//! These handlers manage persistent machines via the shared database,
//! accessible to both API and CLI commands.
//!
//! ## Limitations
//!
//! ### Name Length Limit
//!
//! Machine name length is bounded by the kernel's `sockaddr_un.sun_path`
//! limit (104 bytes on macOS, 108 on Linux). The full socket path is:
//!
//! ```text
//! ~/Library/Caches/smolvm/vms/{name}/agent.sock
//! ```
//!
//! Maximum usable name length therefore depends on the user's home directory.
//! For a typical macOS home (`/Users/<username>/`, ~20 chars), names can be
//! 50+ characters. The actual socket path is validated at create time via
//! [`crate::data::validate_socket_path_fits`] so overly-long names are
//! rejected with a clear error up front.
//!
//! Recommended: keep names short and descriptive (e.g., "dev-vm", "test-1").

use axum::{
    body::{Body, Bytes},
    extract::{Path, Query, State},
    http::{header, Response},
    Json,
};
use futures_util::StreamExt;
use std::future::Future;
use std::sync::Arc;
use std::time::Duration;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::sync::mpsc::UnboundedSender;

use crate::agent::{vm_data_dir, AgentClient, AgentManager, HostMount, PortMapping};
use crate::api::error::ApiError;
use crate::api::state::{
    vm_resources_to_spec, with_machine_client_traced, ApiState, MachineEntry, MachineRegistration,
    ReservationGuard,
};
use crate::api::types::{
    ApiErrorResponse, CreateMachineRequest, CredentialValuesRequest, DeleteQuery, DeleteResponse,
    EgressEventsResponse, ExportRequest, ExportResponse, ForkReleaseRequest, ForkRequest,
    ListMachinesResponse, MachineInfo, MountInfo, MountSpec, PortSpec, ResizeMachineRequest,
    ResourceSpec, SetCpuLimitRequest, SetPortsRequest, StartMachineQuery, UpdateEgressRequest,
};
use crate::config::{RecordState, VmRecord};
use crate::data::disk::{Overlay, Storage};
use crate::data::validate_vm_name;
use crate::process::{
    is_alive, is_our_process_strict, process_start_time, stop_vm_process, VM_SIGKILL_TIMEOUT,
    VM_SIGTERM_TIMEOUT,
};
use crate::storage::{expand_disk, DEFAULT_OVERLAY_SIZE_GIB, DEFAULT_STORAGE_SIZE_GIB};
use crate::util::generate_machine_name;
use crate::Error as SmolvmError;

/// Re-export of the shared resolver. The CLI and API list endpoints
/// must compute state the same way, otherwise `machine list` (CLI)
/// and `GET /api/v1/machines` (API) can disagree about whether a VM
/// is `Running`, `Stopped`, or `Unreachable`. Single source of truth
/// lives in `agent::state_probe`.
use crate::agent::state_probe::resolve_state as resolve_machine_state;

/// Convert VmRecord to MachineInfo (pure mapping, no I/O).
fn record_to_info(name: &str, record: &VmRecord) -> MachineInfo {
    let actual_state = resolve_machine_state(name, record);
    // Clear stale PID when the process is not actually running, so clients
    // never see state=stopped paired with a PID.
    let pid = if actual_state == RecordState::Stopped {
        None
    } else {
        record.pid
    };
    let stats = pid.and_then(crate::process::process_stats);
    // Cached and read-budgeted: the machine list maps every machine through
    // here, and an uncached `smaps_rollup` walk per VMM costs milliseconds per
    // resident GiB.
    let memory_stats = pid.and_then(|pid| {
        crate::process::process_memory_stats_cached(pid, stats.map(|s| s.rss_bytes))
    });
    MachineInfo {
        disk_chain_depth: None,
        runtime: pid.and_then(crate::agent::live_resize::RuntimeIdentity::observe),
        name: name.to_string(),
        image: record.display_image().map(str::to_string),
        state: actual_state.to_string(),
        state_reason: record.pause_reason.clone(),
        cpus: record.cpus,
        mem: record.mem,
        pid,
        mounts: record
            .host_mounts()
            .iter()
            .enumerate()
            .map(|(i, mount)| MountInfo {
                tag: HostMount::mount_tag(i),
                source: mount.source.to_string_lossy().into_owned(),
                target: mount.target.to_string_lossy().into_owned(),
                readonly: mount.read_only,
                staged: mount.staged,
            })
            .collect(),
        ports: record.port_mappings().iter().map(PortSpec::from).collect(),
        network: record.network,
        gpu: record.gpu.unwrap_or(false),
        cuda: record.cuda,
        network_backend: record.network_backend,
        allowed_cidrs: record.allowed_cidrs.clone(),
        egress_rules: record.egress_rules.clone(),
        allowed_hosts: record.dns_filter_hosts.clone(),
        // Report the RESOLVED provisioned disk sizes, not the request echo: a
        // machine created without an explicit size still gets a real disk at the
        // node default, and billing/telemetry need the actual allocated GiB, not
        // `None`. `open_or_create` provisions every VM a storage disk at
        // `DEFAULT_STORAGE_SIZE_GIB` (and an overlay at `DEFAULT_OVERLAY_SIZE_GIB`)
        // when unset.
        storage_gb: Some(record.storage_gb.unwrap_or(DEFAULT_STORAGE_SIZE_GIB)),
        overlay_gb: Some(record.overlay_gb.unwrap_or(DEFAULT_OVERLAY_SIZE_GIB)),
        disk_volumes: record.disk_volumes.clone(),
        block_io: record.block_io,
        disk_durability: record.disk_durability,
        cache_disk: record
            .cache_disk
            .as_ref()
            .map(crate::api::state::cache_disk_spec),
        branchable: crate::agent::branchable_now(record, &actual_state),
        forkable: crate::agent::branchable_now(record, &actual_state),
        parent_machine: record.golden.clone(),
        cuda_branch_pool_size: record.cuda_fork_pool_size,
        cuda_fork_pool_size: record.cuda_fork_pool_size,
        cuda_vram_limit_mib: record.cuda_vram_limit_mib,
        branchpoint_held: record.forkpoint_held,
        forkpoint_held: record.forkpoint_held,
        // Cumulative egress, read from the per-VM telemetry file the subprocess
        // flushes. Surfaced here so the control plane reads it from the machine
        // list exactly like disk size — no bespoke endpoint.
        egress_bytes: crate::agent::read_egress_telemetry(name),
        // Watchlist matches from the signal log the network stack writes, so
        // the control plane reads them from the machine list it already polls.
        egress_signals: crate::agent::read_egress_signals(name),
        // Set on the running VMM only, so a stopped machine has none.
        cpu_limit_millicpus: crate::agent::cpu_limit::read_active_cpu_limit(name, pid),
        egress_flows: crate::agent::read_egress_flows(name, actual_state == RecordState::Running),
        pressure: crate::agent::read_guest_pressure(name, actual_state == RecordState::Running),
        // Per-launch identity: stale once the process is gone, so only
        // reported while it runs.
        mediation_machine_id: pid
            .filter(|_| record.mediated_egress_required)
            .and_then(|_| crate::agent::read_mediation_machine_id(name)),
        // Live consumed CPU-seconds for the VMM child, sampled from the host
        // (user+system CPU time). Resets on restart — the control plane treats it
        // as a monotonic-with-resets counter and accumulates the durable total.
        // `None` when stopped (pid cleared) or the process vanished mid-sample.
        cpu_seconds: stats.map(|s| s.cpu_time_ns / 1_000_000_000),
        // Same consumed CPU in milliseconds — sub-second precision so consumers
        // don't quantize a barely-busy process up to a whole second.
        cpu_millis: stats.map(|s| s.cpu_time_ns / 1_000_000),
        // Current RSS (MiB) of the VMM process — an instantaneous gauge the
        // control plane integrates over time for active-memory billing.
        rss_mb: stats.map(|s| s.rss_bytes / (1024 * 1024)),
        pss_mb: memory_stats
            .and_then(|s| s.pss_bytes)
            .map(|v| v / (1024 * 1024)),
        private_memory_mb: memory_stats
            .and_then(|s| s.private_bytes)
            .map(|v| v / (1024 * 1024)),
        shared_memory_mapped_mb: memory_stats
            .and_then(|s| s.shared_mapped_bytes)
            .map(|v| v / (1024 * 1024)),
        // Actual used disk (sparse-image blocks) — a gauge for active-disk billing,
        // measured from the data dir regardless of whether the VMM is running.
        disk_used_mb: crate::agent::disk_used_mb(name),
        created_at: record.created_at,
    }
}

/// Node-local cache of portable checkpoint artifacts, keyed by the caller's
/// stable id (the control plane's checkpoint id).
///
/// A capture writes its artifact to a staging directory, streams it to the
/// control plane, and used to drop it — the node discarded the very bytes it had
/// just produced. A restore of that checkpoint then fetched the same bytes back
/// from the object store, which for a multi-gigabyte live checkpoint was almost
/// the entire restore time, and in practice the restore landed on the node that
/// captured it. Keeping the artifact turns that restore into a local hard link.
///
/// Entries are hard links, so handing one to a restore (which may move or
/// unlink what it is given) never disturbs the cached inode. The cache is
/// bounded by [`checkpoint_cache_max_bytes`] and evicts oldest-used first; the
/// artifact's own footer checksum is verified by every restore, so a cached
/// file needs no integrity record of its own.
fn checkpoint_cache_dir() -> Result<std::path::PathBuf, ApiError> {
    let dir = checkpoint_transfer_root()?.join("checkpoint-cache");
    std::fs::create_dir_all(&dir)
        .map_err(|error| ApiError::internal(format!("create checkpoint cache: {error}")))?;
    Ok(dir)
}

/// A cache key is an opaque id from the control plane; it becomes a file name,
/// so it is confined to a single conservative path segment.
fn checkpoint_cache_path(key: &str) -> Result<std::path::PathBuf, ApiError> {
    let ok = !key.is_empty()
        && key.len() <= 128
        && key
            .bytes()
            .all(|b| b.is_ascii_alphanumeric() || b == b'-' || b == b'_' || b == b'.');
    if !ok || key.starts_with('.') {
        return Err(ApiError::BadRequest(format!(
            "invalid checkpoint cache key {key:?}"
        )));
    }
    Ok(checkpoint_cache_dir()?.join(format!("{key}.smolcheckpoint")))
}

/// Byte ceiling for the checkpoint cache: `SMOLVM_CHECKPOINT_CACHE_MAX_BYTES`, or
/// a tenth of the filesystem holding it, floored at 8 GiB so at least a couple
/// of large checkpoints fit even on a small disk.
fn checkpoint_cache_max_bytes(dir: &std::path::Path) -> u64 {
    const FLOOR: u64 = 8 * 1024 * 1024 * 1024;
    if let Some(n) = std::env::var("SMOLVM_CHECKPOINT_CACHE_MAX_BYTES")
        .ok()
        .and_then(|s| s.trim().parse::<u64>().ok())
        .filter(|&n| n > 0)
    {
        return n;
    }
    filesystem_capacity_bytes(dir)
        .map(|total| (total / 10).max(FLOOR))
        .unwrap_or(FLOOR)
}

/// Total capacity of the filesystem holding `path` (unix); `None` elsewhere.
fn filesystem_capacity_bytes(path: &std::path::Path) -> Option<u64> {
    #[cfg(unix)]
    {
        use std::os::unix::ffi::OsStrExt;
        let c = std::ffi::CString::new(path.as_os_str().as_bytes()).ok()?;
        // SAFETY: valid NUL-terminated path; `stat` read only after success.
        unsafe {
            let mut stat: std::mem::MaybeUninit<libc::statvfs> = std::mem::MaybeUninit::uninit();
            if libc::statvfs(c.as_ptr(), stat.as_mut_ptr()) != 0 {
                return None;
            }
            let stat = stat.assume_init();
            #[allow(clippy::unnecessary_cast)]
            let total = (stat.f_blocks as u64).checked_mul(stat.f_frsize as u64)?;
            (total > 0).then_some(total)
        }
    }
    #[cfg(not(unix))]
    {
        let _ = path;
        None
    }
}

/// Link `artifact` into the cache under `key`, then evict oldest-used entries
/// until the cache fits its ceiling. Best-effort: a cache failure must never
/// fail the capture or restore that produced the artifact.
fn checkpoint_cache_put(key: &str, artifact: &std::path::Path) {
    let Ok(dest) = checkpoint_cache_path(key) else {
        return;
    };
    match replace_checkpoint_cache_entry(artifact, &dest) {
        Ok(()) => tracing::info!(key, "cached checkpoint artifact on this node"),
        Err(error) => {
            tracing::warn!(key, error = %error, "could not cache checkpoint artifact");
            return;
        }
    }
    if let Some(dir) = dest.parent() {
        checkpoint_cache_evict(dir, checkpoint_cache_max_bytes(dir));
    }
}

fn replace_checkpoint_cache_entry(
    artifact: &std::path::Path,
    destination: &std::path::Path,
) -> std::io::Result<()> {
    let parent = destination.parent().ok_or_else(|| {
        std::io::Error::new(std::io::ErrorKind::InvalidInput, "cache path has no parent")
    })?;
    let _lock = lock_checkpoint_cache_namespace(parent)?;
    link_checkpoint_cache_alias(artifact, destination, true)
}

fn link_checkpoint_cache_alias(
    source: &std::path::Path,
    destination: &std::path::Path,
    replace: bool,
) -> std::io::Result<()> {
    #[cfg(target_os = "linux")]
    {
        crate::artifact_cache::link_checkpoint_artifact(source, destination, replace)
    }
    #[cfg(not(target_os = "linux"))]
    {
        if replace {
            let parent = destination
                .parent()
                .ok_or_else(|| std::io::Error::other("cache destination has no parent"))?;
            let staging = tempfile::tempdir_in(parent)?;
            let link = staging.path().join("artifact");
            std::fs::hard_link(source, &link)?;
            std::fs::rename(link, destination)?;
        } else {
            std::fs::hard_link(source, destination)?;
        }
        let _ = std::fs::File::options()
            .append(true)
            .open(destination)
            .and_then(|file| {
                file.set_times(std::fs::FileTimes::new().set_accessed(std::time::SystemTime::now()))
            });
        Ok(())
    }
}

const CHECKPOINT_CACHE_LOCK: &str = ".checkpoint-cache.lock";

fn lock_checkpoint_cache_namespace(dir: &std::path::Path) -> std::io::Result<std::fs::File> {
    let lock = std::fs::OpenOptions::new()
        .read(true)
        .write(true)
        .create(true)
        .truncate(false)
        .open(dir.join(CHECKPOINT_CACHE_LOCK))?;
    lock.lock()?;
    Ok(lock)
}

// Readers may verify concurrently, but cache aliases must not change ctime
// between the verifier's two fstat calls. Keep the full identity check intact.
fn lock_checkpoint_cache_verification(dir: &std::path::Path) -> std::io::Result<std::fs::File> {
    let lock = std::fs::OpenOptions::new()
        .read(true)
        .write(true)
        .create(true)
        .truncate(false)
        .open(dir.join(CHECKPOINT_CACHE_LOCK))?;
    lock.lock_shared()?;
    Ok(lock)
}

fn discard_invalid_checkpoint_cache_entry(src: &std::path::Path) -> std::io::Result<()> {
    let parent = src
        .parent()
        .ok_or_else(|| std::io::Error::other("cache path has no parent"))?;
    let _lock = lock_checkpoint_cache_namespace(parent)?;
    // A publisher may have replaced the entry since the reader pinned it.
    // Recheck under the publication lock before removing the current name.
    if crate::portable_checkpoint::verified_sidecar_footer(src).is_err() {
        match std::fs::remove_file(src) {
            Ok(()) => {}
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => {}
            Err(error) => return Err(error),
        }
    }
    Ok(())
}

/// Look `key` up; on a hit, hard-link the entry to `artifact` (a fresh path in a
/// staging directory) and bump its use time. Returns whether `artifact` now
/// exists. A stale link failure just reports a miss.
/// On a hit, the returned verification pins `artifact`'s inode for the rest of
/// the request so machine creation can reuse it instead of re-reading the
/// payload (see [`crate::portable_checkpoint::VerifiedSidecar`]).
struct CachedCheckpoint {
    verified: Option<crate::portable_checkpoint::VerifiedSidecar>,
}

fn checkpoint_cache_take(key: &str, artifact: &std::path::Path) -> Option<CachedCheckpoint> {
    let src = checkpoint_cache_path(key).ok()?;
    take_checkpoint_cache_entry(key, &src, artifact)
}

fn take_checkpoint_cache_entry(
    key: &str,
    src: &std::path::Path,
    artifact: &std::path::Path,
) -> Option<CachedCheckpoint> {
    take_checkpoint_cache_entry_with_verifier(
        key,
        src,
        artifact,
        crate::portable_checkpoint::classify_sidecar_verification,
    )
}

fn take_checkpoint_cache_entry_with_verifier(
    key: &str,
    src: &std::path::Path,
    artifact: &std::path::Path,
    verify: impl FnOnce(
        &std::path::Path,
    ) -> crate::error::Result<crate::portable_checkpoint::SidecarVerification>,
) -> Option<CachedCheckpoint> {
    if !src.is_file() {
        return None;
    }
    let link_started = std::time::Instant::now();
    let linked = (|| -> std::io::Result<()> {
        let parent = src
            .parent()
            .ok_or_else(|| std::io::Error::other("cache source has no parent"))?;
        let _lock = lock_checkpoint_cache_namespace(parent)?;
        link_checkpoint_cache_alias(src, artifact, false)
    })();
    if let Err(error) = linked {
        tracing::warn!(key, error = %error, "cached checkpoint present but could not be linked");
        return None;
    }
    let link_ms = link_started.elapsed().as_millis() as u64;
    let verification_started = std::time::Instant::now();
    // The cache-link operation already recorded access and refreshed any local
    // provenance before verification captures its final inode identity.
    let outcome = (|| {
        let parent = src
            .parent()
            .ok_or_else(|| std::io::Error::other("cache source has no parent"))?;
        let _lock = lock_checkpoint_cache_verification(parent)?;
        verify(artifact)
    })();
    match outcome {
        Ok(crate::portable_checkpoint::SidecarVerification::Stable(verified)) => {
            tracing::info!(
                key,
                link_ms,
                verify_ms = verification_started.elapsed().as_millis() as u64,
                "restored checkpoint from the node-local cache"
            );
            Some(CachedCheckpoint {
                verified: Some(verified),
            })
        }
        #[cfg(unix)]
        Ok(crate::portable_checkpoint::SidecarVerification::ChangedDuringRead) => {
            // Hard-link publication/cleanup also changes ctime. A successful
            // checksum with unstable identity is not evidence of bad bytes.
            // Keep the pinned staging link but hand off no proof: creation
            // must perform the full verification again before using it.
            tracing::info!(
                key,
                "checkpoint identity changed during verification; requiring fresh verification"
            );
            Some(CachedCheckpoint { verified: None })
        }
        Err(error) => {
            tracing::warn!(
                key,
                %error,
                "discarding invalid cached checkpoint; retrying supplied source"
            );
            // This staging name can still alias a valid inode another reader
            // is checking, even if this request's verification failed.
            if let Some(parent) = src.parent() {
                if let Ok(_lock) = lock_checkpoint_cache_namespace(parent) {
                    let _ = std::fs::remove_file(artifact);
                }
            }
            if let Err(error) = discard_invalid_checkpoint_cache_entry(src) {
                tracing::warn!(key, %error, "could not discard invalid cached checkpoint");
            }
            None
        }
    }
}

/// Drop oldest-used entries until the directory's total is under `max`.
fn checkpoint_cache_evict(dir: &std::path::Path, max: u64) {
    let Ok(_lock) = lock_checkpoint_cache_namespace(dir) else {
        return;
    };
    let Ok(entries) = std::fs::read_dir(dir) else {
        return;
    };
    let mut files: Vec<(std::time::SystemTime, u64, std::path::PathBuf)> = entries
        .flatten()
        .filter_map(|e| {
            if e.file_name() == CHECKPOINT_CACHE_LOCK {
                return None;
            }
            let meta = e.metadata().ok()?;
            meta.is_file().then(|| {
                (
                    meta.accessed().unwrap_or(std::time::UNIX_EPOCH),
                    meta.len(),
                    e.path(),
                )
            })
        })
        .collect();
    let mut total: u64 = files.iter().map(|f| f.1).sum();
    if total <= max {
        return;
    }
    files.sort_by_key(|f| f.0);
    for (_, size, path) in files {
        if total <= max {
            break;
        }
        if std::fs::remove_file(&path).is_ok() {
            total = total.saturating_sub(size);
            tracing::info!(path = %path.display(), "evicted checkpoint from the node-local cache");
        }
    }
}

/// One cache take of a checkpoint, shared by every restore of it that overlaps.
///
/// Each take links a fresh alias of the cached artifact, and every link or
/// unlink changes the inode's ctime, which voids the verifications other
/// restores just made: a burst of N restores of one checkpoint then re-hashed
/// the whole artifact N times, one after another under the cache locks.
/// Restores that arrive while a take is alive reuse its pinned, verified alias
/// instead, so the inode stays still and its proofs keep holding. The alias is
/// released when the last of them finishes.
struct SharedCheckpointTake {
    _transfer: CheckpointTransfer,
    artifact: std::path::PathBuf,
    verified: Option<crate::portable_checkpoint::VerifiedSidecar>,
}

type SharedTakeSlot = std::sync::Arc<tokio::sync::Mutex<std::sync::Weak<SharedCheckpointTake>>>;

static SHARED_CHECKPOINT_TAKES: std::sync::LazyLock<
    std::sync::Mutex<std::collections::HashMap<String, SharedTakeSlot>>,
> = std::sync::LazyLock::new(Default::default);

/// How long a checkpoint's take outlives its last restore. A restore that links
/// a new alias changes the inode's ctime and so re-hashes the whole artifact;
/// restores minutes apart reuse the same take instead and skip that work.
const SHARED_TAKE_LINGER: Duration = Duration::from_secs(300);

/// At most this many takes linger, bounding the disk their pinned links hold.
const SHARED_TAKE_LINGER_MAX: usize = 8;

type LingeringTakes =
    std::collections::HashMap<String, (std::sync::Arc<SharedCheckpointTake>, std::time::Instant)>;

/// Takes kept alive past their last restore, with when they were last used.
static LINGERING_CHECKPOINT_TAKES: std::sync::LazyLock<std::sync::Mutex<LingeringTakes>> =
    std::sync::LazyLock::new(Default::default);

/// Keep `take` alive for [`SHARED_TAKE_LINGER`], dropping expired takes and,
/// past [`SHARED_TAKE_LINGER_MAX`], the least recently used one.
fn linger_checkpoint_take(key: &str, take: &std::sync::Arc<SharedCheckpointTake>) {
    let mut lingering = LINGERING_CHECKPOINT_TAKES
        .lock()
        .unwrap_or_else(|poisoned| poisoned.into_inner());
    let now = std::time::Instant::now();
    lingering.retain(|_, (_, used)| now.duration_since(*used) < SHARED_TAKE_LINGER);
    lingering.insert(key.to_string(), (take.clone(), now));
    while lingering.len() > SHARED_TAKE_LINGER_MAX {
        let Some(oldest) = lingering
            .iter()
            .min_by_key(|(_, (_, used))| *used)
            .map(|(key, _)| key.clone())
        else {
            break;
        };
        lingering.remove(&oldest);
    }
}

/// Release lingering takes once idle, so their links free disk without
/// waiting for the next restore to prune them.
fn spawn_checkpoint_take_reaper() {
    static STARTED: std::sync::Once = std::sync::Once::new();
    STARTED.call_once(|| {
        if let Ok(runtime) = tokio::runtime::Handle::try_current() {
            runtime.spawn(async {
                loop {
                    tokio::time::sleep(SHARED_TAKE_LINGER / 4).await;
                    let expired: Vec<_> = {
                        let mut lingering = LINGERING_CHECKPOINT_TAKES
                            .lock()
                            .unwrap_or_else(|poisoned| poisoned.into_inner());
                        let now = std::time::Instant::now();
                        let keys: Vec<String> = lingering
                            .iter()
                            .filter(|(_, (_, used))| {
                                now.duration_since(*used) >= SHARED_TAKE_LINGER
                            })
                            .map(|(key, _)| key.clone())
                            .collect();
                        keys.into_iter()
                            .filter_map(|key| lingering.remove(&key))
                            .collect()
                    };
                    // The take's cleanup locks and unlinks, so it runs off the runtime.
                    if !expired.is_empty() {
                        let _ = tokio::task::spawn_blocking(move || drop(expired)).await;
                    }
                }
            });
        }
    });
}

/// The live take of `key`, or a new one from the node-local cache; `None` on a miss.
async fn shared_checkpoint_take(
    key: &str,
) -> Result<Option<std::sync::Arc<SharedCheckpointTake>>, ApiError> {
    let slot = {
        let mut slots = SHARED_CHECKPOINT_TAKES
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner());
        // Forget slots nobody holds or waits on whose take has ended.
        slots.retain(|_, slot| {
            std::sync::Arc::strong_count(slot) > 1
                || slot.try_lock().map_or(true, |take| take.strong_count() > 0)
        });
        slots.entry(key.to_string()).or_default().clone()
    };
    // Held across the take so overlapping restores of `key` wait for it
    // rather than each linking an alias of their own.
    let mut live = slot.lock().await;
    spawn_checkpoint_take_reaper();
    if let Some(take) = live.upgrade() {
        linger_checkpoint_take(key, &take);
        return Ok(Some(take));
    }
    let transfer = tempfile::Builder::new()
        .prefix("checkpoint-restore-")
        .tempdir_in(checkpoint_transfer_root()?)
        .map_err(|error| ApiError::internal(format!("create checkpoint transfer: {error}")))?;
    let artifact = transfer.path().join("upload.smolcheckpoint");
    let transfer = CheckpointTransfer {
        _directory: Some(transfer),
        artifact: artifact.clone(),
    };
    let cached = {
        let (key, artifact) = (key.to_string(), artifact.clone());
        tokio::task::spawn_blocking(move || checkpoint_cache_take(&key, &artifact))
            .await
            .map_err(|error| ApiError::internal(format!("checkpoint cache task: {error}")))?
    };
    let Some(cached) = cached else {
        return Ok(None);
    };
    let take = std::sync::Arc::new(SharedCheckpointTake {
        _transfer: transfer,
        artifact,
        verified: cached.verified,
    });
    *live = std::sync::Arc::downgrade(&take);
    linger_checkpoint_take(key, &take);
    Ok(Some(take))
}

/// Hashes a checkpoint on a blocking thread as it is received, so verifying
/// it and naming it by SHA-256 need no further read of the written file.
/// Best-effort: if hashing stops, the artifact is simply verified by reading it.
struct ReceiveHasher {
    sender: Option<tokio::sync::mpsc::Sender<axum::body::Bytes>>,
    task: tokio::task::JoinHandle<smolvm_pack::extract::ReceivedArtifactHashes>,
}

impl ReceiveHasher {
    fn spawn() -> Self {
        let (sender, mut receiver) = tokio::sync::mpsc::channel::<axum::body::Bytes>(64);
        let task = tokio::task::spawn_blocking(move || {
            let mut hasher = smolvm_pack::extract::ArtifactStreamHasher::new();
            while let Some(chunk) = receiver.blocking_recv() {
                hasher.update(&chunk);
            }
            hasher.finish()
        });
        Self {
            sender: Some(sender),
            task,
        }
    }

    /// Queue the next received bytes; waits while the hasher is behind, so
    /// memory stays bounded.
    async fn update(&mut self, chunk: axum::body::Bytes) {
        if let Some(sender) = &self.sender {
            if sender.send(chunk).await.is_err() {
                self.sender = None;
            }
        }
    }

    /// Hashes of everything queued, or `None` if hashing stopped early.
    async fn finish(mut self) -> Option<smolvm_pack::extract::ReceivedArtifactHashes> {
        let complete = self.sender.take().is_some();
        let hashes = (&mut self.task).await.ok()?;
        complete.then_some(hashes)
    }
}

fn checkpoint_transfer_root() -> Result<std::path::PathBuf, ApiError> {
    let root = std::env::var_os("SMOLVM_PACK_STAGING")
        .map(std::path::PathBuf::from)
        .or_else(|| dirs::cache_dir().map(|cache| cache.join("smolvm")))
        .unwrap_or_else(std::env::temp_dir);
    std::fs::create_dir_all(&root)
        .map_err(|error| ApiError::internal(format!("create checkpoint staging root: {error}")))?;
    Ok(root)
}

/// Refresh local alias provenance before TempDir removes the transfer files.
struct CheckpointTransfer {
    _directory: Option<tempfile::TempDir>,
    artifact: std::path::PathBuf,
}

impl Drop for CheckpointTransfer {
    fn drop(&mut self) {
        // TempDir's unlink changes the same inode as the prepared cache. It
        // must participate even when provenance refresh declines the alias.
        let directory = self._directory.take();
        let artifact = self.artifact.clone();
        let cleanup = move || {
            let lock = checkpoint_cache_dir()
                .map_err(|error| std::io::Error::other(format!("{error:?}")))
                .and_then(|dir| lock_checkpoint_cache_namespace(&dir));
            let _lock = match lock {
                Ok(lock) => lock,
                Err(error) => {
                    // Keep the private transfer for the reaper rather than
                    // mutate an inode without the verification lease.
                    if let Some(directory) = directory {
                        tracing::warn!(path = %directory.keep().display(), %error, "checkpoint transfer cleanup deferred");
                    }
                    return;
                }
            };
            #[cfg(target_os = "linux")]
            crate::artifact_cache::release_checkpoint_artifact_alias(&artifact);
            #[cfg(not(target_os = "linux"))]
            let _ = &artifact;
            drop(directory);
        };
        if let Ok(runtime) = tokio::runtime::Handle::try_current() {
            runtime.spawn_blocking(cleanup);
        } else {
            cleanup();
        }
    }
}

fn max_checkpoint_upload_bytes() -> u64 {
    std::env::var("SMOLVM_MAX_CHECKPOINT_UPLOAD_BYTES")
        .ok()
        .and_then(|value| value.parse::<u64>().ok())
        .filter(|value| *value > 0)
        .unwrap_or(2 * 1024 * 1024 * 1024 * 1024)
}

/// Keep staging owned by the blocking task so cancellation cannot remove it
/// while capture is writing; return ownership only to a connected caller.
async fn with_owned_transfer<T: Send + 'static>(
    transfer: tempfile::TempDir,
    work: impl FnOnce(&std::path::Path) -> T + Send + 'static,
) -> Result<(tempfile::TempDir, T), ApiError> {
    tokio::task::spawn_blocking(move || {
        let out = work(transfer.path());
        (transfer, out)
    })
    .await
    .map_err(|error| ApiError::internal(format!("checkpoint transfer task failed: {error}")))
}

#[cfg(test)]
mod capture_transfer_tests {
    use super::{with_owned_operation, with_owned_transfer};
    use std::sync::mpsc;
    use std::time::{Duration, Instant};

    const WAIT: Duration = Duration::from_secs(10);

    #[tokio::test]
    async fn disconnected_preparation_keeps_lifecycle_until_completion() {
        let lifecycle = std::sync::Arc::new(tokio::sync::Mutex::new(()));
        let owned = lifecycle.clone();
        let (started, ready) = tokio::sync::oneshot::channel();
        let (finish, gate) = tokio::sync::oneshot::channel();
        let (completed, done) = tokio::sync::oneshot::channel();
        let request = tokio::spawn(with_owned_operation(move |reply| async move {
            let guard = owned.lock_owned().await;
            started.send(()).unwrap();
            gate.await.unwrap();
            drop(guard);
            let _ = reply.send(Ok(()));
            completed.send(()).unwrap();
        }));
        ready.await.unwrap();
        request.abort();
        assert!(request.await.unwrap_err().is_cancelled());
        assert!(lifecycle.try_lock().is_err());
        finish.send(()).unwrap();
        done.await.unwrap();
        assert!(lifecycle.try_lock().is_ok());
    }

    #[tokio::test]
    async fn disconnected_queued_operation_can_skip_preparation() {
        let (started, ready) = tokio::sync::oneshot::channel();
        let (release, gate) = tokio::sync::oneshot::channel();
        let (observed, observation) = tokio::sync::oneshot::channel();
        let request = tokio::spawn(with_owned_operation(move |reply| async move {
            started.send(()).unwrap();
            gate.await.unwrap();
            observed.send(reply.is_closed()).unwrap();
            let _ = reply.send(Ok(()));
        }));
        ready.await.unwrap();
        request.abort();
        assert!(request.await.unwrap_err().is_cancelled());
        release.send(()).unwrap();
        assert!(observation.await.unwrap());
    }

    #[tokio::test]
    async fn disconnected_queued_cleanup_still_completes() {
        let lifecycle = std::sync::Arc::new(tokio::sync::Mutex::new(()));
        let guard = lifecycle.lock().await;
        let owned = lifecycle.clone();
        let (started, ready) = tokio::sync::oneshot::channel();
        let (completed, done) = tokio::sync::oneshot::channel();
        let request = tokio::spawn(with_owned_operation(move |reply| async move {
            started.send(()).unwrap();
            let _guard = owned.lock_owned().await;
            completed.send(()).unwrap();
            let _ = reply.send(Ok(()));
        }));
        ready.await.unwrap();
        request.abort();
        assert!(request.await.unwrap_err().is_cancelled());
        drop(guard);
        done.await.unwrap();
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn disconnected_capture_holds_source_until_staged_not_until_packaged() {
        let root = tempfile::tempdir().unwrap();
        let source = std::sync::Arc::new(tokio::sync::Mutex::new(()));
        let guard = source.clone().lock_owned().await;
        let (started_tx, started_rx) = mpsc::channel();
        let (stage_tx, stage_rx) = mpsc::channel();
        let (staged_tx, staged_rx) = mpsc::channel();
        let (finish_tx, finish_rx) = mpsc::channel();
        let (finished_tx, finished_rx) = mpsc::channel();
        let request = tokio::spawn(with_owned_transfer(transfer_in(root.path()), move |_| {
            started_tx.send(()).unwrap();
            stage_rx.recv().unwrap();
            drop(guard);
            staged_tx.send(()).unwrap();
            finish_rx.recv().unwrap();
            DropSignal(finished_tx)
        }));
        started_rx.recv_timeout(WAIT).unwrap();
        request.abort();
        assert!(request.await.unwrap_err().is_cancelled());
        assert!(
            source.try_lock().is_err(),
            "disconnect released live source early"
        );
        stage_tx.send(()).unwrap();
        staged_rx.recv_timeout(WAIT).unwrap();
        assert!(source.try_lock().is_ok(), "packaging still owns the source");
        finish_tx.send(()).unwrap();
        finished_rx.recv_timeout(WAIT).unwrap();
    }

    /// Sends on drop, so the test can await the moment the task's result
    /// (and with it the `TempDir`) has been released.
    #[derive(Debug)]
    struct DropSignal(mpsc::Sender<()>);
    impl Drop for DropSignal {
        fn drop(&mut self) {
            let _ = self.0.send(());
        }
    }

    fn transfer_in(root: &std::path::Path) -> tempfile::TempDir {
        tempfile::Builder::new()
            .prefix("checkpoint-transfer-")
            .tempdir_in(root)
            .unwrap()
    }

    /// The client disconnects mid-capture (request future aborted) while the
    /// capture is parked; the capture then resumes, recreates its output
    /// directory the way `pack_artifact` does, and writes the artifact.
    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn cancelled_capture_request_never_leaves_an_orphan_transfer_dir() {
        let root = tempfile::tempdir().unwrap();
        let transfer = transfer_in(root.path());
        let dir = transfer.path().to_path_buf();
        let (started_tx, started_rx) = mpsc::channel();
        let (release_tx, release_rx) = mpsc::channel::<()>();
        let (released_tx, released_rx) = mpsc::channel();
        let request = tokio::spawn(with_owned_transfer(transfer, move |out| {
            started_tx.send(()).unwrap();
            release_rx.recv().unwrap();
            std::fs::create_dir_all(out).unwrap();
            std::fs::write(out.join("x.smolcheckpoint"), b"artifact").unwrap();
            DropSignal(released_tx)
        }));
        started_rx.recv_timeout(WAIT).unwrap();
        request.abort();
        assert!(request.await.unwrap_err().is_cancelled());
        // The cancelled request must not have taken the directory away from
        // the still-running capture.
        assert!(
            dir.exists(),
            "cancellation removed the directory under a running capture"
        );
        release_tx.send(()).unwrap();
        released_rx.recv_timeout(WAIT).unwrap();
        assert!(!dir.exists(), "orphan transfer directory left behind");
        assert_eq!(std::fs::read_dir(root.path()).unwrap().count(), 0);
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn connected_capture_hands_the_transfer_back_to_the_caller() {
        let root = tempfile::tempdir().unwrap();
        let transfer = transfer_in(root.path());
        let expected = transfer.path().to_path_buf();
        let (kept, out) = with_owned_transfer(transfer, |dir| {
            std::fs::write(dir.join("a.smolcheckpoint"), b"1").unwrap();
            7
        })
        .await
        .unwrap();
        assert_eq!(out, 7);
        assert_eq!(kept.path(), expected);
        assert!(expected.join("a.smolcheckpoint").exists());
        drop(kept);
        assert!(!expected.exists());
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn failed_or_panicking_capture_still_reclaims_the_transfer() {
        let root = tempfile::tempdir().unwrap();
        // A capture error is handed back with the directory; the handler's
        // early return drops it.
        let transfer = transfer_in(root.path());
        let dir = transfer.path().to_path_buf();
        let (kept, out) = with_owned_transfer(transfer, |dir| {
            std::fs::write(dir.join("partial"), b"x").unwrap();
            Err::<(), &str>("capture failed")
        })
        .await
        .unwrap();
        assert_eq!(out, Err("capture failed"));
        drop(kept);
        assert!(!dir.exists());
        // A panicking capture unwinds the task that owns the directory.
        let transfer = transfer_in(root.path());
        let dir = transfer.path().to_path_buf();
        let error = with_owned_transfer::<()>(transfer, |dir| {
            std::fs::write(dir.join("partial"), b"x").unwrap();
            panic!("capture panicked");
        })
        .await
        .expect_err("panic surfaces as an error");
        assert!(format!("{error:?}").contains("checkpoint transfer task failed"));
        let deadline = Instant::now() + WAIT;
        while dir.exists() && Instant::now() < deadline {
            tokio::time::sleep(Duration::from_millis(10)).await;
        }
        assert!(!dir.exists());
        assert_eq!(std::fs::read_dir(root.path()).unwrap().count(), 0);
    }
}

fn checkpoint_capture_error(error: crate::Error) -> ApiError {
    match error {
        crate::Error::Config { .. } => ApiError::BadRequest(error.to_string()),
        other => ApiError::from(other),
    }
}

/// Stream a running machine's complete live state as a `.checkpoint`.
/// Options for a checkpoint capture.
#[derive(Debug, Default, serde::Deserialize)]
pub struct CaptureCheckpointQuery {
    /// Stable id to file the produced artifact under in the node-local cache,
    /// so a later restore of this checkpoint on this node needs no download.
    pub cache_key: Option<String>,
    /// JSON array of pre-signed object-store URLs to PUT the artifact to,
    /// instead of streaming it back to the caller. The artifact is split into
    /// that many contiguous parts, uploaded concurrently in order, for the
    /// caller to join; the reply is then a small JSON summary and the artifact
    /// never crosses the control plane.
    pub upload_urls: Option<String>,
    /// Capture through the node's checkpoint store. The artifact is then a
    /// chunked file, and a delta of the checkpoint the machine continues from
    /// when this node holds it.
    pub incremental: Option<bool>,
    /// With `incremental`: export a complete file even when a base is held,
    /// so a caller can cap the chain of deltas a restore imports.
    pub force_full: Option<bool>,
    /// With a `cache_key`: reply as soon as the artifact is captured and held
    /// on this node, and leave its upload to `POST /checkpoints/{key}/upload`.
    /// Uploading a multi-gigabyte artifact took most of a checkpoint's time
    /// while the caller only needed the capture, which a restore on this node
    /// already serves from the node's copy. A caller may pass `upload_urls`
    /// as well: this node ignores them, and a node that predates
    /// `defer_upload` ignores it instead and uploads inline, so one request
    /// works on both and the reply (`captured` or `uploaded`) says which ran.
    pub defer_upload: Option<bool>,
}

/// Capture a live checkpoint of a running machine and stream it back as a
/// `.checkpoint` file, keeping a node-local copy when the caller
/// supplies a cache key.
pub async fn capture_portable_checkpoint(
    State(state): State<Arc<ApiState>>,
    Path(name): Path<String>,
    Query(capture_options): Query<CaptureCheckpointQuery>,
) -> Result<Response<Body>, ApiError> {
    // Serialize capture with start/stop/delete/fork so the saved vCPU state and
    // cloned qcow chains describe one stable machine generation.
    let lifecycle = state.lifecycle_lock(&name);
    let guard = lifecycle.lock_owned().await;
    // Resolve through state first so an unknown name fails before allocating a
    // potentially large staging directory. The capture core revalidates the
    // machine's state and checkpoint profile at the consistency boundary.
    state
        .lookup_vm(&name)
        .await?
        .ok_or_else(|| ApiError::NotFound(format!("machine '{name}' not found")))?;
    let upload_urls = capture_options
        .upload_urls
        .as_deref()
        .map(checked_upload_urls)
        .transpose()?;
    let defer_upload = capture_options.defer_upload.unwrap_or(false);
    if defer_upload {
        let Some(key) = capture_options.cache_key.as_deref() else {
            return Err(ApiError::BadRequest(
                "defer_upload needs a cache_key to upload the artifact by later".into(),
            ));
        };
        pending_checkpoint_upload_path(key)?;
    }

    let mut transfer_builder = tempfile::Builder::new();
    transfer_builder.prefix("checkpoint-transfer-");
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        transfer_builder.permissions(std::fs::Permissions::from_mode(0o700));
    }
    let transfer = transfer_builder
        .tempdir_in(checkpoint_transfer_root()?)
        .map_err(|error| ApiError::internal(format!("create checkpoint transfer: {error}")))?;
    let artifact = transfer.path().join(format!("{name}.smolcheckpoint"));
    let capture_name = name.clone();
    let capture_path = artifact.clone();
    let prepared_cache_budget_bytes = capture_options.cache_key.as_ref().map(|_| {
        std::env::var("SMOLVM_PREPARED_CHECKPOINT_CACHE_MAX_BYTES")
            .ok()
            .and_then(|value| value.parse::<u64>().ok())
            .unwrap_or_else(crate::portable_checkpoint::prepared_checkpoint_budget)
    });
    let incremental = capture_options.incremental.unwrap_or(false);
    let force_full = capture_options.force_full.unwrap_or(false);
    // Keep staging alive until the background capture finishes, even on disconnect.
    let (transfer, result) = with_owned_transfer(transfer, move |_dir| {
        if incremental {
            return crate::checkpoint_delta::capture(
                &capture_name,
                &capture_path,
                force_full,
                move || drop(guard),
            )
            .map(|capture| (capture.result.clone(), None, Some(capture)));
        }
        crate::portable_checkpoint::capture_to_path_deferring_retention(
            &capture_name,
            &capture_path,
            &crate::portable_checkpoint::CaptureOptions {
                prepared_cache_budget_bytes,
                ..Default::default()
            },
            crate::portable_checkpoint::DEFAULT_HISTORY,
            move || drop(guard),
        )
        .map(|(result, retention)| (result, retention, None))
    })
    .await?;
    let (result, retention, incremental) = result.map_err(checkpoint_capture_error)?;
    let incremental_headers: Vec<(&'static str, String)> = match &incremental {
        Some(capture) => vec![
            (
                "x-smolvm-checkpoint-kind",
                if capture.base.is_some() {
                    "delta"
                } else {
                    "full"
                }
                .to_string(),
            ),
            ("x-smolvm-checkpoint-id", capture.id.clone()),
            (
                "x-smolvm-checkpoint-parent",
                capture.base.clone().unwrap_or_default(),
            ),
            (
                "x-smolvm-checkpoint-store-ms",
                capture.store_elapsed.as_millis().to_string(),
            ),
            (
                "x-smolvm-checkpoint-export-ms",
                capture.export_elapsed.as_millis().to_string(),
            ),
            (
                "x-smolvm-checkpoint-new-bytes",
                capture.result.size_bytes.to_string(),
            ),
            (
                "x-smolvm-checkpoint-reused-bytes",
                capture.result.reused_bytes.to_string(),
            ),
        ],
        None => Vec::new(),
    };
    let transfer = CheckpointTransfer {
        _directory: Some(transfer),
        artifact: artifact.clone(),
    };
    // Retention reads the artifact, so it runs before the transfer is released,
    // but off the request path: nothing the caller does waits on it.
    let finish = move |transfer: CheckpointTransfer| {
        let Some(retention) = retention else {
            return;
        };
        tokio::task::spawn_blocking(move || {
            retention.run(&transfer.artifact);
            drop(transfer);
        });
    };

    if let Some(key) = capture_options.cache_key {
        let cached = key.clone();
        let source = artifact.clone();
        if let Err(error) =
            tokio::task::spawn_blocking(move || checkpoint_cache_put(&cached, &source)).await
        {
            tracing::warn!(%error, "checkpoint cache task failed");
        }
        if defer_upload {
            let source = artifact.clone();
            tokio::task::spawn_blocking(move || hold_checkpoint_for_upload(&key, &source))
                .await
                .map_err(|error| {
                    ApiError::internal(format!("hold checkpoint for upload: {error}"))
                })??;
            let size = match &incremental {
                Some(capture) => capture.export.bytes,
                None => result.size_bytes,
            };
            finish(transfer);
            return Ok(axum::response::IntoResponse::into_response(Json(
                with_lineage(
                    serde_json::json!({
                        "captured": true,
                        "sizeBytes": size,
                        "pauseMs": result.source_pause.as_millis() as u64,
                    }),
                    incremental.as_ref(),
                ),
            )));
        }
    }
    if let Some(urls) = upload_urls {
        let size = upload_checkpoint(&artifact, urls).await?;
        finish(transfer);
        return Ok(axum::response::IntoResponse::into_response(Json(
            with_lineage(
                serde_json::json!({
                    "uploaded": true,
                    "sizeBytes": size,
                    "pauseMs": result.source_pause.as_millis() as u64,
                }),
                incremental.as_ref(),
            ),
        )));
    }
    #[cfg(target_os = "linux")]
    let prepared_reference = crate::artifact_cache::prepared_checkpoint_reference(&artifact).ok();
    let mut file = tokio::fs::File::open(&artifact)
        .await
        .map_err(|error| ApiError::internal(format!("open checkpoint artifact: {error}")))?;
    let size = match &incremental {
        Some(capture) => capture.export.bytes,
        None => result.size_bytes,
    };
    let stream = async_stream::stream! {
        // Keeping the TempDir in the stream owns the artifact until the client
        // finishes or disconnects; dropping the body cleans it up either way.
        let transfer = transfer;
        let mut buffer = vec![0_u8; 1024 * 1024];
        loop {
            match file.read(&mut buffer).await {
                Ok(0) => {
                    finish(transfer);
                    break;
                }
                Ok(count) => {
                    yield Ok::<Bytes, std::io::Error>(Bytes::copy_from_slice(&buffer[..count]));
                }
                Err(error) => {
                    yield Err(error);
                    break;
                }
            }
        }
    };
    let mut response = Response::builder();
    for (name, value) in incremental_headers {
        response = response.header(name, value);
    }
    #[cfg(target_os = "linux")]
    let response = if let Some(reference) = prepared_reference {
        response.header("x-smolvm-checkpoint-prepared", reference)
    } else {
        response
    };
    response
        .status(axum::http::StatusCode::OK)
        .header(
            header::CONTENT_TYPE,
            "application/vnd.smolmachines.checkpoint",
        )
        .header(header::CONTENT_LENGTH, size)
        .header(
            header::CONTENT_DISPOSITION,
            format!("attachment; filename=\"{name}.checkpoint\""),
        )
        .header(
            "x-smolvm-checkpoint-pause-ms",
            result.source_pause.as_millis().to_string(),
        )
        .body(Body::from_stream(stream))
        .map_err(|error| ApiError::internal(format!("build checkpoint response: {error}")))
}

/// Most parts a capture may be uploaded in; the object store joins at most 32.
const MAX_UPLOAD_PARTS: usize = 32;

/// Contiguous `(start, length)` ranges splitting `size` bytes into `parts`
/// near-equal pieces; trailing pieces are empty when there are more parts
/// than bytes.
fn upload_part_ranges(size: u64, parts: usize) -> Vec<(u64, u64)> {
    let part_size = size.div_ceil(parts as u64);
    (0..parts as u64)
        .map(|index| {
            let start = (index * part_size).min(size);
            (start, part_size.min(size - start))
        })
        .collect()
}

/// Captured artifacts waiting for `POST /checkpoints/{key}/upload`. Kept apart
/// from the checkpoint cache, whose eviction could drop one before its upload
/// runs; an upload removes its entry, and one never uploaded is swept after a
/// day.
fn pending_checkpoint_upload_dir() -> Result<std::path::PathBuf, ApiError> {
    let dir = checkpoint_transfer_root()?.join("checkpoint-pending-upload");
    std::fs::create_dir_all(&dir).map_err(|error| {
        ApiError::internal(format!("create pending checkpoint uploads: {error}"))
    })?;
    Ok(dir)
}

fn pending_checkpoint_upload_path(key: &str) -> Result<std::path::PathBuf, ApiError> {
    let cached = checkpoint_cache_path(key)?;
    let name = cached
        .file_name()
        .ok_or_else(|| ApiError::internal("checkpoint cache path has no name"))?;
    Ok(pending_checkpoint_upload_dir()?.join(name))
}

/// How long a captured artifact waits for its upload before it is swept.
const PENDING_CHECKPOINT_UPLOAD_TTL: std::time::Duration =
    std::time::Duration::from_secs(24 * 60 * 60);

/// Hold `artifact` for a later upload under `key`, sweeping holds never
/// uploaded. A hard link, so the capture's own staging can go.
fn hold_checkpoint_for_upload(key: &str, artifact: &std::path::Path) -> Result<(), ApiError> {
    let destination = pending_checkpoint_upload_path(key)?;
    hold_checkpoint_at(&destination, artifact)
        .map_err(|error| ApiError::internal(format!("hold checkpoint for upload: {error}")))
}

/// Link `artifact` to `destination` in the pending-upload directory, after
/// removing holds there older than [`PENDING_CHECKPOINT_UPLOAD_TTL`].
fn hold_checkpoint_at(
    destination: &std::path::Path,
    artifact: &std::path::Path,
) -> std::io::Result<()> {
    let dir = destination
        .parent()
        .ok_or_else(|| std::io::Error::other("hold path has no parent"))?;
    if let Ok(entries) = std::fs::read_dir(dir) {
        let now = std::time::SystemTime::now();
        for entry in entries.flatten() {
            let stale = entry
                .metadata()
                .and_then(|meta| meta.modified())
                .is_ok_and(|modified| {
                    now.duration_since(modified).unwrap_or_default() > PENDING_CHECKPOINT_UPLOAD_TTL
                });
            if stale {
                let _ = std::fs::remove_file(entry.path());
            }
        }
    }
    link_checkpoint_cache_alias(artifact, destination, true)
}

/// Options for uploading a held checkpoint.
#[derive(Debug, serde::Deserialize)]
pub struct UploadHeldCheckpointQuery {
    /// JSON array of pre-signed object-store URLs, one contiguous part each.
    pub upload_urls: String,
}

/// Upload a checkpoint captured with `defer_upload` to pre-signed object-store
/// URLs, then release the node's hold on it. The node's cached copy is the
/// fallback when the hold is gone.
pub async fn upload_held_checkpoint(
    Path(key): Path<String>,
    Query(query): Query<UploadHeldCheckpointQuery>,
) -> Result<Json<serde_json::Value>, ApiError> {
    let urls = checked_upload_urls(&query.upload_urls)?;
    let held = pending_checkpoint_upload_path(&key)?;
    let source = if held.exists() {
        held.clone()
    } else {
        let cached = checkpoint_cache_path(&key)?;
        if !cached.exists() {
            return Err(ApiError::NotFound(format!(
                "checkpoint {key} is not held on this node"
            )));
        }
        cached
    };
    let size = upload_checkpoint(&source, urls).await?;
    if source == held {
        let _ = std::fs::remove_file(&held);
    }
    Ok(Json(
        serde_json::json!({ "uploaded": true, "sizeBytes": size }),
    ))
}

/// Options for forgetting a checkpoint.
#[derive(Debug, Default, serde::Deserialize)]
pub struct ForgetCheckpointQuery {
    /// Lineage id of the checkpoint in this node's incremental checkpoint
    /// store, as the capture reported it.
    pub lineage: Option<String>,
}

/// Remove what this node keeps of a checkpoint its owner deleted: the cached
/// artifact filed under `key`, a capture still held for upload under it, and,
/// with `lineage`, the stored checkpoint of that id in the node's incremental
/// checkpoint store. A stored checkpoint a machine here continues from, or one
/// a restore is reading, stays until that ends (`"lineage": "deferred"`);
/// retention then removes it. Idempotent: forgetting what this node does not
/// hold succeeds.
pub async fn forget_checkpoint(
    State(state): State<Arc<ApiState>>,
    Path(key): Path<String>,
    Query(query): Query<ForgetCheckpointQuery>,
) -> Result<Json<serde_json::Value>, ApiError> {
    let cached = checkpoint_cache_path(&key)?;
    let held = pending_checkpoint_upload_path(&key)?;
    if let Some(lineage) = query.lineage.as_deref() {
        if !crate::checkpoint_store::is_checkpoint_id(lineage) {
            return Err(ApiError::BadRequest(format!(
                "invalid checkpoint lineage id {lineage:?}"
            )));
        }
    }
    let db = state.db().clone();
    tokio::task::spawn_blocking(move || -> Result<serde_json::Value, ApiError> {
        let removed = |path: &std::path::Path| match std::fs::remove_file(path) {
            Ok(()) => Ok(true),
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => Ok(false),
            Err(error) => Err(ApiError::internal(format!(
                "remove {}: {error}",
                path.display()
            ))),
        };
        // Restores take their own link of a cached artifact under this lock,
        // so removing the cache's name never disturbs one in progress.
        let cache_removed = match cached.parent().map(lock_checkpoint_cache_namespace) {
            Some(Ok(_lock)) => removed(&cached)?,
            Some(Err(error)) => {
                return Err(ApiError::internal(format!(
                    "lock checkpoint cache: {error}"
                )))
            }
            None => false,
        };
        let hold_removed = removed(&held)?;
        let lineage = match query.lineage {
            Some(id) => {
                let store = crate::checkpoint_delta::node_store();
                let keep = crate::checkpoint_retention::Keep::from_db(&db, &store)?;
                let outcome = crate::checkpoint_retention::forget(&store, &id, &keep)
                    .map_err(|error| ApiError::internal(format!("forget checkpoint: {error}")))?;
                tracing::info!(key = %key, lineage = %id, ?outcome, "checkpoint forgotten");
                Some(match outcome {
                    crate::checkpoint_retention::Forgotten::Removed => "removed",
                    crate::checkpoint_retention::Forgotten::Absent => "absent",
                    crate::checkpoint_retention::Forgotten::Deferred => "deferred",
                })
            }
            None => None,
        };
        if lineage == Some("removed") {
            // Reclaim the objects only it held.
            crate::checkpoint_retention::request();
        }
        Ok(serde_json::json!({
            "cacheRemoved": cache_removed,
            "holdRemoved": hold_removed,
            "lineage": lineage,
        }))
    })
    .await
    .map_err(|error| ApiError::internal(format!("forget checkpoint task: {error}")))?
    .map(Json)
}

/// An incremental capture's lineage in a JSON reply, which the streamed reply
/// carries as `x-smolvm-checkpoint-*` headers: whether the artifact is a delta,
/// the checkpoint's lineage id, and the base a delta needs imported first.
fn with_lineage(
    mut reply: serde_json::Value,
    capture: Option<&crate::checkpoint_delta::IncrementalCapture>,
) -> serde_json::Value {
    if let (Some(capture), Some(fields)) = (capture, reply.as_object_mut()) {
        fields.insert(
            "checkpointKind".into(),
            if capture.base.is_some() {
                "delta"
            } else {
                "full"
            }
            .into(),
        );
        fields.insert("lineageId".into(), capture.id.clone().into());
        if let Some(base) = &capture.base {
            fields.insert("baseLineageId".into(), base.clone().into());
        }
        fields.insert("reusedBytes".into(), capture.result.reused_bytes.into());
    }
    reply
}

fn checked_upload_urls(raw: &str) -> Result<Vec<reqwest::Url>, ApiError> {
    let urls: Vec<String> = serde_json::from_str(raw)
        .map_err(|error| ApiError::BadRequest(format!("invalid upload_urls: {error}")))?;
    if urls.is_empty() || urls.len() > MAX_UPLOAD_PARTS {
        return Err(ApiError::BadRequest(format!(
            "upload_urls must name 1 to {MAX_UPLOAD_PARTS} parts"
        )));
    }
    urls.iter()
        .map(|url| checked_checkpoint_source(url))
        .collect()
}

/// PUT a captured artifact to pre-signed object-store URLs, one contiguous part
/// per URL, all at once. One stream to the store tops out far below what a node
/// can push, so the parts go in parallel.
///
/// The object store acknowledges a single-request upload only once the object
/// is durable, so a success here means every part is safely stored.
async fn upload_checkpoint(
    artifact: &std::path::Path,
    urls: Vec<reqwest::Url>,
) -> Result<u64, ApiError> {
    let file = std::fs::File::open(artifact)
        .map_err(|error| ApiError::internal(format!("open checkpoint artifact: {error}")))?;
    upload_checkpoint_file(file, urls, crate::api::progress::Progress::default()).await
}

/// Read `length` bytes at `offset` of `file` as a body stream, positionally, so
/// parts uploading at once never share a cursor and the descriptor's file may
/// already be unlinked.
fn checkpoint_part_stream(
    file: Arc<std::fs::File>,
    offset: u64,
    length: u64,
    progress: crate::api::progress::Progress,
) -> impl futures_util::Stream<Item = std::io::Result<axum::body::Bytes>> {
    const CHUNK: u64 = 1024 * 1024;
    futures_util::stream::try_unfold((file, offset, length), move |(file, offset, left)| {
        let progress = progress.clone();
        async move {
            if left == 0 {
                return Ok(None);
            }
            let want = left.min(CHUNK) as usize;
            let reader = file.clone();
            let chunk = tokio::task::spawn_blocking(move || {
                let mut buffer = vec![0_u8; want];
                let mut filled = 0;
                while filled < want {
                    #[cfg(unix)]
                    let read = std::os::unix::fs::FileExt::read_at(
                        &*reader,
                        &mut buffer[filled..],
                        offset + filled as u64,
                    )?;
                    #[cfg(windows)]
                    let read = std::os::windows::fs::FileExt::seek_read(
                        &*reader,
                        &mut buffer[filled..],
                        offset + filled as u64,
                    )?;
                    if read == 0 {
                        return Err(std::io::Error::new(
                            std::io::ErrorKind::UnexpectedEof,
                            "checkpoint artifact shrank during upload",
                        ));
                    }
                    filled += read;
                }
                Ok(axum::body::Bytes::from(buffer))
            })
            .await
            .map_err(std::io::Error::other)??;
            let read = chunk.len() as u64;
            // The body asks for the next chunk only once the last one is sent.
            progress.touch();
            Ok(Some((chunk, (file, offset + read, left - read))))
        }
    })
}

/// Upload an open checkpoint artifact to `urls` in contiguous parts at once.
async fn upload_checkpoint_file(
    file: std::fs::File,
    urls: Vec<reqwest::Url>,
    progress: crate::api::progress::Progress,
) -> Result<u64, ApiError> {
    let size = file
        .metadata()
        .map_err(|error| ApiError::internal(format!("stat checkpoint artifact: {error}")))?
        .len();
    let file = Arc::new(file);
    // Same policy as the restore fetch: no redirects, so the host allow-list
    // cannot be escaped by a 302.
    let client = reqwest::Client::builder()
        .redirect(reqwest::redirect::Policy::none())
        .connect_timeout(Duration::from_secs(30))
        .timeout(Duration::from_secs(1800))
        .build()
        .map_err(|error| ApiError::internal(format!("build checkpoint upload client: {error}")))?;
    let ranges = upload_part_ranges(size, urls.len());
    let uploads =
        urls.into_iter()
            .zip(ranges)
            .enumerate()
            .map(|(index, (url, (start, length)))| {
                let client = client.clone();
                let file = file.clone();
                let progress = progress.clone();
                async move {
                    let body = reqwest::Body::wrap_stream(checkpoint_part_stream(
                        file, start, length, progress,
                    ));
                    let response = client
                        .put(url)
                        .header(header::CONTENT_TYPE, "application/octet-stream")
                        .header(header::CONTENT_LENGTH, length)
                        .body(body)
                        .send()
                        .await
                        .map_err(|error| {
                            ApiError::internal(format!(
                                "upload checkpoint part {index} to object store: {}",
                                error.without_url()
                            ))
                        })?;
                    if !response.status().is_success() {
                        return Err(ApiError::internal(format!(
                            "object store refused checkpoint part {index}: {}",
                            response.status()
                        )));
                    }
                    Ok(())
                }
            });
    futures_util::future::try_join_all(uploads).await?;
    Ok(size)
}

/// Create a machine by streaming a `.checkpoint` into this node.
#[derive(Debug, Default, serde::Deserialize)]
pub struct RestoreCheckpointQuery {
    /// JSON port mappings for this host; guest ports must match the checkpoint.
    pub ports: Option<String>,
    /// Pre-signed object-store URL to pull the checkpoint from, instead of the
    /// caller streaming it in the request body.
    ///
    /// A live checkpoint is gigabytes. Relaying it through the control plane
    /// costs a second full copy over the wire and pins it to the control's
    /// throughput — measured at roughly a fifth of what the node reaches
    /// fetching the same object itself, and the dominant term in a restore that
    /// then boots in three seconds. The URL carries its own scoped, expiring
    /// authorisation, so the node needs no object-store credentials of its own.
    pub source_url: Option<String>,
    /// Stable id of the checkpoint; when this node captured it (or restored it
    /// before) the artifact is served from the node-local cache and
    /// `source_url` is never fetched.
    pub cache_key: Option<String>,
    /// Only import a chunked checkpoint into this node's store (so deltas of
    /// it can restore here); create no machine.
    pub import_only: Option<bool>,
    /// JSON cache disk (see [`crate::api::types::CacheDiskSpec`]) for a
    /// checkpoint of a machine with one: the base it was captured over, which
    /// this node fetches from `sourceUrl` when it does not have it yet.
    pub cache_disk: Option<String>,
}

/// Object-store hosts a checkpoint may be fetched from.
///
/// The node is being handed a URL by its control plane and asked to retrieve it,
/// which is a request-forgery primitive if left open: a caller that can reach
/// this endpoint could otherwise aim it at link-local metadata, a loopback
/// admin port, or a peer on the private network. Restricting the host to the
/// object store — and refusing redirects at the call site — keeps the parameter
/// to the one job it exists for.
const CHECKPOINT_SOURCE_HOSTS: [&str; 2] = ["storage.googleapis.com", "storage.cloud.google.com"];

/// Validate a checkpoint source URL, returning it only when it is an HTTPS URL
/// pointing at [`CHECKPOINT_SOURCE_HOSTS`] (or a bucket subdomain of one).
fn checked_checkpoint_source(raw: &str) -> Result<reqwest::Url, ApiError> {
    let url = reqwest::Url::parse(raw)
        .map_err(|error| ApiError::BadRequest(format!("invalid checkpoint source url: {error}")))?;
    if url.scheme() != "https" {
        return Err(ApiError::BadRequest(
            "checkpoint source url must be https".to_string(),
        ));
    }
    let host = url
        .host_str()
        .ok_or_else(|| ApiError::BadRequest("checkpoint source url has no host".to_string()))?;
    let allowed = CHECKPOINT_SOURCE_HOSTS
        .iter()
        .any(|h| host == *h || host.ends_with(&format!(".{h}")));
    if !allowed {
        return Err(ApiError::BadRequest(format!(
            "checkpoint source host {host} is not an allowed object store"
        )));
    }
    Ok(url)
}

#[cfg(test)]
mod checkpoint_upload_tests {
    use super::{checked_upload_urls, checkpoint_part_stream, upload_part_ranges};

    /// Parts read at once from one descriptor reassemble the file exactly, even
    /// after its name is gone, as when a resume consumes a paused checkpoint.
    #[tokio::test]
    async fn concurrent_parts_reassemble_an_unlinked_artifact() {
        use futures_util::TryStreamExt;
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("artifact");
        let content: Vec<u8> = (0..5_000_003_u32).map(|i| (i * 31 % 251) as u8).collect();
        std::fs::write(&path, &content).unwrap();
        let file = std::sync::Arc::new(std::fs::File::open(&path).unwrap());
        std::fs::remove_file(&path).unwrap();
        let ranges = upload_part_ranges(content.len() as u64, 4);
        let parts = futures_util::future::try_join_all(ranges.iter().map(|&(start, length)| {
            checkpoint_part_stream(
                file.clone(),
                start,
                length,
                crate::api::progress::Progress::default(),
            )
            .try_fold(Vec::new(), |mut acc, chunk| async move {
                acc.extend_from_slice(&chunk);
                Ok(acc)
            })
        }))
        .await
        .unwrap();
        assert_eq!(parts.concat(), content);
    }

    #[test]
    fn part_ranges_cover_the_artifact_exactly_once() {
        for (size, parts) in [(0, 4), (3, 4), (4, 4), (10, 4), (2_855_851_366, 4), (7, 1)] {
            let ranges = upload_part_ranges(size, parts);
            assert_eq!(ranges.len(), parts);
            let mut next = 0;
            for (start, length) in ranges {
                assert_eq!(start, next.min(size));
                next = start + length;
            }
            assert_eq!(next, size, "size {size} in {parts} parts");
        }
    }

    #[test]
    fn upload_urls_are_bounded_and_limited_to_the_object_store() {
        let url = "https://bucket.storage.googleapis.com/o?X-Goog-Signature=x";
        assert_eq!(
            checked_upload_urls(&format!(r#"["{url}","{url}"]"#))
                .unwrap()
                .len(),
            2
        );
        assert!(checked_upload_urls("[]").is_err());
        let many = serde_json::to_string(&vec![url; 33]).unwrap();
        assert!(checked_upload_urls(&many).is_err());
        assert!(checked_upload_urls(r#"["https://169.254.169.254/latest"]"#).is_err());
        assert!(checked_upload_urls(r#"["http://storage.googleapis.com/o"]"#).is_err());
        assert!(checked_upload_urls("not json").is_err());
    }
}

#[cfg(test)]
mod held_checkpoint_tests {
    use super::{hold_checkpoint_at, PENDING_CHECKPOINT_UPLOAD_TTL};

    /// A deferred capture holds its artifact apart from the cache, so cache
    /// eviction cannot drop it before the upload, and a hold never uploaded is
    /// swept rather than kept forever.
    #[test]
    fn a_hold_survives_its_source_and_stale_holds_are_swept() {
        let dir = tempfile::tempdir().unwrap();
        let pending = dir.path().join("pending");
        std::fs::create_dir_all(&pending).unwrap();
        let stale = pending.join("ckpt-old.smolcheckpoint");
        std::fs::write(&stale, b"old").unwrap();
        std::fs::File::options()
            .write(true)
            .open(&stale)
            .unwrap()
            .set_modified(
                std::time::SystemTime::now()
                    - PENDING_CHECKPOINT_UPLOAD_TTL
                    - std::time::Duration::from_secs(60),
            )
            .unwrap();
        let fresh = pending.join("ckpt-recent.smolcheckpoint");
        std::fs::write(&fresh, b"recent").unwrap();

        let artifact = dir.path().join("staging.smolcheckpoint");
        std::fs::write(&artifact, b"captured").unwrap();
        let held = pending.join("ckpt-new.smolcheckpoint");
        hold_checkpoint_at(&held, &artifact).unwrap();
        // The capture's staging goes away; the hold keeps the bytes.
        std::fs::remove_file(&artifact).unwrap();

        assert_eq!(std::fs::read(&held).unwrap(), b"captured");
        assert!(!stale.exists(), "a hold past its TTL is swept");
        assert!(fresh.exists(), "a recent hold is kept");
    }
}

#[cfg(test)]
mod checkpoint_cache_tests {
    use super::{
        checkpoint_cache_evict, checkpoint_cache_path, discard_invalid_checkpoint_cache_entry,
        lock_checkpoint_cache_namespace, replace_checkpoint_cache_entry,
        take_checkpoint_cache_entry,
    };

    #[test]
    fn cache_verification_excludes_alias_changes_but_allows_other_readers() {
        let dir = tempfile::tempdir().unwrap();
        let cached = dir.path().join("cached.smolcheckpoint");
        let upload = dir.path().join("upload");
        let manifest = smolvm_pack::format::PackManifest::new(
            "vm://concurrent-cache".into(),
            "none".into(),
            "linux/amd64".into(),
            "linux/amd64".into(),
        );
        smolvm_pack::packer::Packer::new(manifest)
            .pack_artifact(&cached)
            .unwrap();
        let hit =
            super::take_checkpoint_cache_entry_with_verifier("test", &cached, &upload, |path| {
                let competing = std::fs::OpenOptions::new()
                    .read(true)
                    .write(true)
                    .open(dir.path().join(super::CHECKPOINT_CACHE_LOCK))
                    .unwrap();
                assert!(
                    competing.try_lock().is_err(),
                    "alias publication must wait until verification finishes"
                );
                eventually(|| competing.try_lock_shared())
                    .expect("independent verifiers may run concurrently");
                crate::portable_checkpoint::classify_sidecar_verification(path)
            })
            .unwrap();
        let verified = hit.verified.unwrap();
        #[cfg(unix)]
        assert!(verified.covers(&upload));
        #[cfg(not(unix))]
        assert!(
            !verified.covers(&upload),
            "non-Unix verification is never reusable"
        );
        let competing = std::fs::OpenOptions::new()
            .read(true)
            .write(true)
            .open(dir.path().join(super::CHECKPOINT_CACHE_LOCK))
            .unwrap();
        eventually(|| competing.try_lock())
            .expect("verification releases the lease before VM creation");
    }

    /// Retries a lock attempt briefly. A process another test is spawning
    /// shares this process's open files until it execs, so for that moment
    /// it holds the same flock and a lock that was released looks held.
    fn eventually(
        mut attempt: impl FnMut() -> Result<(), std::fs::TryLockError>,
    ) -> Result<(), std::fs::TryLockError> {
        let deadline = std::time::Instant::now() + std::time::Duration::from_secs(2);
        loop {
            match attempt() {
                Err(std::fs::TryLockError::WouldBlock) if std::time::Instant::now() < deadline => {
                    std::thread::sleep(std::time::Duration::from_millis(5));
                }
                result => return result,
            }
        }
    }

    #[test]
    fn stale_invalid_reader_does_not_remove_repaired_entry() {
        let dir = tempfile::tempdir().unwrap();
        let cached = dir.path().join("cached.smolcheckpoint");
        let reader = dir.path().join("reader");
        let replacement = dir.path().join("replacement");
        std::fs::write(&cached, b"invalid").unwrap();
        std::fs::hard_link(&cached, &reader).unwrap();
        let manifest = smolvm_pack::format::PackManifest::new(
            "vm://cache-test".into(),
            "none".into(),
            "linux/amd64".into(),
            "linux/amd64".into(),
        );
        smolvm_pack::packer::Packer::new(manifest)
            .pack_artifact(&replacement)
            .unwrap();
        replace_checkpoint_cache_entry(&replacement, &cached).unwrap();
        assert!(crate::portable_checkpoint::verified_sidecar_footer(&reader).is_err());
        discard_invalid_checkpoint_cache_entry(&cached).unwrap();
        assert!(crate::portable_checkpoint::verified_sidecar_footer(&cached).is_ok());
        assert_eq!(std::fs::read(reader).unwrap(), b"invalid");
    }

    #[test]
    fn eviction_preserves_namespace_lock_and_pinned_reader() {
        let dir = tempfile::tempdir().unwrap();
        let pinned_dir = tempfile::tempdir().unwrap();
        let cached = dir.path().join("cached.smolcheckpoint");
        let pinned = pinned_dir.path().join("reader");
        std::fs::write(&cached, b"payload").unwrap();
        std::fs::hard_link(&cached, &pinned).unwrap();
        let lock = lock_checkpoint_cache_namespace(dir.path()).unwrap();
        drop(lock);
        checkpoint_cache_evict(dir.path(), 0);
        assert!(!cached.exists());
        assert!(dir.path().join(super::CHECKPOINT_CACHE_LOCK).exists());
        assert_eq!(std::fs::read(pinned).unwrap(), b"payload");
    }

    #[test]
    fn invalid_cache_hit_is_removed_before_fresh_upload() {
        let dir = tempfile::tempdir().unwrap();
        let cached = dir.path().join("cached");
        let upload = dir.path().join("upload");
        std::fs::write(&cached, b"not a checkpoint").unwrap();
        assert!(take_checkpoint_cache_entry("test", &cached, &upload).is_none());
        assert!(!cached.exists());
        assert!(!upload.exists());
        std::fs::OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(upload)
            .unwrap();
    }

    #[cfg(unix)]
    #[test]
    fn changing_cache_identity_preserves_hit_but_does_not_handoff_proof() {
        let dir = tempfile::tempdir().unwrap();
        let cached = dir.path().join("cached.smolcheckpoint");
        let upload = dir.path().join("upload");
        let manifest = smolvm_pack::format::PackManifest::new(
            "vm://cache-test".into(),
            "none".into(),
            "linux/amd64".into(),
            "linux/amd64".into(),
        );
        smolvm_pack::packer::Packer::new(manifest)
            .pack_artifact(&cached)
            .unwrap();
        let hit =
            super::take_checkpoint_cache_entry_with_verifier("test", &cached, &upload, |_| {
                Ok(crate::portable_checkpoint::SidecarVerification::ChangedDuringRead)
            })
            .expect("unstable identity is still a cache hit");
        assert!(
            hit.verified.is_none(),
            "creation must verify the artifact again"
        );
        assert!(cached.exists());
        assert!(upload.exists());
        assert!(crate::portable_checkpoint::verified_sidecar_footer(&upload).is_ok());
    }

    #[test]
    fn cache_hit_preserves_artifact_modification_time() {
        let dir = tempfile::tempdir().unwrap();
        let cached = dir.path().join("cached.smolcheckpoint");
        let upload = dir.path().join("upload");
        let manifest = smolvm_pack::format::PackManifest::new(
            "vm://cache-test".into(),
            "none".into(),
            "linux/amd64".into(),
            "linux/amd64".into(),
        );
        smolvm_pack::packer::Packer::new(manifest)
            .pack_artifact(&cached)
            .unwrap();
        let old = std::time::SystemTime::now() - std::time::Duration::from_secs(300);
        std::fs::File::options()
            .write(true)
            .open(&cached)
            .unwrap()
            .set_modified(old)
            .unwrap();
        let before = std::fs::metadata(&cached).unwrap().modified().unwrap();
        assert!(take_checkpoint_cache_entry("test", &cached, &upload).is_some());
        assert_eq!(
            std::fs::metadata(&cached).unwrap().modified().unwrap(),
            before
        );
        assert_eq!(
            std::fs::metadata(&upload).unwrap().modified().unwrap(),
            before
        );
    }

    #[test]
    fn publication_replaces_old_entry_without_changing_active_reader() {
        let dir = tempfile::tempdir().unwrap();
        let cached = dir.path().join("cached");
        let active = dir.path().join("active");
        let valid = dir.path().join("valid");
        std::fs::write(&cached, b"old").unwrap();
        std::fs::hard_link(&cached, &active).unwrap();
        std::fs::write(&valid, b"new").unwrap();
        replace_checkpoint_cache_entry(&valid, &cached).unwrap();
        assert_eq!(std::fs::read(&cached).unwrap(), b"new");
        assert_eq!(std::fs::read(&active).unwrap(), b"old");
    }

    #[test]
    fn failed_publication_preserves_existing_entry() {
        let dir = tempfile::tempdir().unwrap();
        let cached = dir.path().join("cached");
        std::fs::write(&cached, b"valid").unwrap();
        assert!(replace_checkpoint_cache_entry(&dir.path().join("missing"), &cached).is_err());
        assert_eq!(std::fs::read(cached).unwrap(), b"valid");
    }

    /// The key becomes a file name inside the cache directory, so it must never
    /// be able to name anything outside it.
    #[test]
    fn cache_key_cannot_escape_the_cache_directory() {
        for bad in [
            "../etc",
            "a/b",
            ".hidden",
            "",
            "x\0y",
            "ckpt-…",
            &"a".repeat(129),
        ] {
            assert!(
                checkpoint_cache_path(bad).is_err(),
                "{bad:?} must be refused"
            );
        }
        let ok = checkpoint_cache_path("ckpt-5e726c0e26aa459b88b1e6ef735b4102").unwrap();
        assert!(ok.ends_with("ckpt-5e726c0e26aa459b88b1e6ef735b4102.smolcheckpoint"));
    }

    /// Eviction removes oldest-used entries only until the directory fits, and
    /// never touches the newest.
    #[test]
    fn eviction_drops_oldest_until_under_the_ceiling() {
        let dir = tempfile::tempdir().unwrap();
        let mk = |name: &str, size: usize, age_secs: u64| {
            let p = dir.path().join(name);
            std::fs::write(&p, vec![0u8; size]).unwrap();
            let t = std::time::SystemTime::now() - std::time::Duration::from_secs(age_secs);
            std::fs::File::options()
                .append(true)
                .open(&p)
                .unwrap()
                .set_times(std::fs::FileTimes::new().set_accessed(t))
                .unwrap();
            p
        };
        let oldest = mk("a.smolcheckpoint", 300, 300);
        let middle = mk("b.smolcheckpoint", 300, 200);
        let newest = mk("c.smolcheckpoint", 300, 100);
        checkpoint_cache_evict(dir.path(), 650);
        assert!(!oldest.exists(), "oldest must go first");
        assert!(middle.exists(), "eviction must stop once under the ceiling");
        assert!(newest.exists(), "newest must survive");
        checkpoint_cache_evict(dir.path(), 10_000);
        assert!(
            middle.exists() && newest.exists(),
            "no-op when already under"
        );
    }
}

#[cfg(test)]
mod checkpoint_source_tests {
    use super::checked_checkpoint_source;

    /// The node fetches whatever URL its control plane names, so the allow-list
    /// is the only thing standing between this parameter and a request-forgery
    /// primitive. These are the targets that matter on a cloud host.
    #[test]
    fn refuses_everything_outside_the_object_store() {
        for raw in [
            "http://169.254.169.254/computeMetadata/v1/instance/service-accounts/default/token",
            "https://169.254.169.254/computeMetadata/v1/",
            "http://127.0.0.1:8080/api/v1/machines",
            "https://127.0.0.1/",
            "http://[::1]:8080/",
            "https://10.0.0.2/",
            "file:///etc/shadow",
            "https://storage.googleapis.com.evil.test/o",
            "https://evil.test/storage.googleapis.com",
            "gopher://storage.googleapis.com/",
        ] {
            assert!(
                checked_checkpoint_source(raw).is_err(),
                "{raw} must be refused as a checkpoint source"
            );
        }
    }

    /// Plain HTTP is refused even for an allowed host: a signed URL in the clear
    /// hands the bearer token to anything on the path.
    #[test]
    fn refuses_plaintext_even_for_an_allowed_host() {
        assert!(checked_checkpoint_source("http://storage.googleapis.com/b/o").is_err());
    }

    /// The real shapes a signed URL arrives in: the bucket may be a subdomain or
    /// the first path segment.
    #[test]
    fn accepts_signed_object_store_urls() {
        for raw in [
            "https://storage.googleapis.com/smolmachines-snapshots/o.smolcheckpoint?x-goog-signature=ab",
            "https://smolmachines-snapshots.storage.googleapis.com/o.smolcheckpoint?x-goog-signature=ab",
            "https://storage.cloud.google.com/smolmachines-snapshots/o.smolcheckpoint",
        ] {
            assert!(
                checked_checkpoint_source(raw).is_ok(),
                "{raw} is a legitimate signed checkpoint source"
            );
        }
    }
}

/// Import a live checkpoint, optionally rebinding its host-side published ports.
pub async fn restore_portable_checkpoint(
    State(state): State<Arc<ApiState>>,
    Path(name): Path<String>,
    Query(options): Query<RestoreCheckpointQuery>,
    request: axum::extract::Request,
) -> Result<Response<Body>, ApiError> {
    validate_vm_name(&name, "machine name").map_err(ApiError::BadRequest)?;
    // Pull credential for the pack a checkpoint's layers come from, sent as a
    // header so it stays out of URLs and request logs.
    let registry_token = request
        .headers()
        .get("x-smolvm-registry-token")
        .and_then(|value| value.to_str().ok())
        .map(str::to_string);
    let ports: Vec<PortSpec> = options
        .ports
        .as_deref()
        .map(serde_json::from_str)
        .transpose()
        .map_err(|error| ApiError::BadRequest(format!("invalid restore ports: {error}")))?
        .unwrap_or_default();
    let cache_disk: Option<serde_json::Value> = options
        .cache_disk
        .as_deref()
        .map(serde_json::from_str)
        .transpose()
        .map_err(|error| ApiError::BadRequest(format!("invalid restore cache disk: {error}")))?;
    // A cached artifact is hard-linked straight into a staging directory:
    // nothing is created or fetched, and the cache's own inode is untouched by
    // whatever the restore does with its copy. Overlapping restores of the same
    // checkpoint share one such link (see `SharedCheckpointTake`).
    let shared_take = match options.cache_key.as_deref() {
        Some(key) => shared_checkpoint_take(key).await?,
        None => None,
    };
    let cache_hit = shared_take.is_some();
    // Each request owns its own descriptor of the shared proof.
    let verified = shared_take
        .as_ref()
        .and_then(|take| take.verified.as_ref())
        .and_then(|proof| proof.try_clone().ok());
    // A miss uploads into a staging directory of this request's own.
    let (artifact, _transfer) = match &shared_take {
        Some(take) => (take.artifact.clone(), None),
        None => {
            let transfer = tempfile::Builder::new()
                .prefix("checkpoint-restore-")
                .tempdir_in(checkpoint_transfer_root()?)
                .map_err(|error| {
                    ApiError::internal(format!("create checkpoint transfer: {error}"))
                })?;
            let artifact = transfer.path().join("upload.smolcheckpoint");
            let transfer = CheckpointTransfer {
                _directory: Some(transfer),
                artifact: artifact.clone(),
            };
            (artifact, Some(transfer))
        }
    };
    let limit = max_checkpoint_upload_bytes();
    let mut received_hashes = None;
    let received: u64 = if cache_hit {
        std::fs::metadata(&artifact).map(|m| m.len()).unwrap_or(0)
    } else {
        let mut file = tokio::fs::OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(&artifact)
            .await
            .map_err(|error| ApiError::internal(format!("create checkpoint upload: {error}")))?;
        // Checked once the file exists and again once it is complete: only a
        // file nobody else could write between the two is verified from the
        // bytes as they were received instead of being read back.
        let service_only = smolvm_pack::extract::only_service_can_write(&artifact);
        let mut hasher = ReceiveHasher::spawn();
        let mut received = 0_u64;
        if let Some(raw) = options.source_url.as_deref() {
            // Pull the checkpoint ourselves. `none()` redirects: a signed URL needs
            // no hop, and following one would let the allow-list above be escaped by
            // a 302 to somewhere it forbids.
            let url = checked_checkpoint_source(raw)?;
            let client = reqwest::Client::builder()
                .redirect(reqwest::redirect::Policy::none())
                .connect_timeout(std::time::Duration::from_secs(30))
                .read_timeout(std::time::Duration::from_secs(120))
                .timeout(std::time::Duration::from_secs(1800))
                .build()
                .map_err(|error| {
                    ApiError::internal(format!("build checkpoint fetch client: {error}"))
                })?;
            let response = client.get(url).send().await.map_err(|error| {
                ApiError::internal(format!(
                    "fetch checkpoint from source url: {}",
                    error.without_url()
                ))
            })?;
            if !response.status().is_success() {
                return Err(ApiError::BadRequest(format!(
                    "checkpoint source url returned {}",
                    response.status()
                )));
            }
            let mut stream = response.bytes_stream();
            while let Some(chunk) = stream.next().await {
                let chunk = chunk.map_err(|error| {
                    ApiError::internal(format!(
                        "read checkpoint from source url: {}",
                        error.without_url()
                    ))
                })?;
                received = received.checked_add(chunk.len() as u64).ok_or_else(|| {
                    ApiError::BadRequest("checkpoint upload size overflow".to_string())
                })?;
                if received > limit {
                    return Err(ApiError::BadRequest(format!(
                        "checkpoint exceeds the configured {limit}-byte upload limit"
                    )));
                }
                file.write_all(&chunk)
                    .await
                    .map_err(|error| ApiError::internal(format!("write checkpoint: {error}")))?;
                hasher.update(chunk).await;
            }
        } else {
            let mut body = request.into_body().into_data_stream();
            while let Some(chunk) = body.next().await {
                let chunk = chunk.map_err(|error| {
                    ApiError::BadRequest(format!("read checkpoint upload: {error}"))
                })?;
                received = received.checked_add(chunk.len() as u64).ok_or_else(|| {
                    ApiError::BadRequest("checkpoint upload size overflow".to_string())
                })?;
                if received > limit {
                    return Err(ApiError::BadRequest(format!(
                        "checkpoint exceeds the configured {limit}-byte upload limit"
                    )));
                }
                file.write_all(&chunk).await.map_err(|error| {
                    ApiError::internal(format!("write checkpoint upload: {error}"))
                })?;
                hasher.update(chunk).await;
            }
        }
        file.flush()
            .await
            .map_err(|error| ApiError::internal(format!("flush checkpoint upload: {error}")))?;
        // No fsync: this file only carries the checkpoint into extraction and
        // is removed afterwards. Everything installed from it is made durable
        // where it is installed, and a node cache entry made from it is
        // verified on every later use, so forcing it to disk first only made
        // the restore wait for a write nothing depends on.
        drop(file);
        received_hashes = hasher.finish().await.map(|hashes| (hashes, service_only));
        received
    };
    if received > limit {
        return Err(ApiError::BadRequest(format!(
            "checkpoint exceeds the configured {limit}-byte upload limit"
        )));
    }
    if received == 0 {
        return Err(ApiError::BadRequest(
            "checkpoint upload is empty".to_string(),
        ));
    }
    // A miss was hashed while it arrived; when that covers what the footer
    // checksum covers, creation uses it instead of reading the file again.
    let verified = match received_hashes {
        Some((hashes, service_only)) => {
            let artifact = artifact.clone();
            tokio::task::spawn_blocking(move || {
                crate::portable_checkpoint::verified_from_received(&artifact, &hashes, service_only)
            })
            .await
            .map_err(|error| ApiError::internal(format!("checkpoint verification task: {error}")))?
        }
        None => verified,
    };

    // A chunked checkpoint, complete or a delta, is imported into the node's
    // store and materialized once into the shared extraction its footer
    // names; creation then reuses that tree like any extracted checkpoint.
    {
        let import_only = options.import_only.unwrap_or(false);
        let input = artifact.clone();
        let needs_verification = verified.is_none();
        let started = std::time::Instant::now();
        let prepared = tokio::task::spawn_blocking(move || -> crate::Result<Option<String>> {
            // Classic artifacts take the ordinary path, which verifies them.
            let chunked = smolvm_pack::packer::read_manifest_from_sidecar(&input)
                .ok()
                .and_then(|manifest| manifest.checkpoint)
                .is_some_and(|checkpoint| {
                    checkpoint.payload == smolvm_pack::format::CheckpointLayout::Chunked
                });
            if !chunked && !import_only {
                return Ok(None);
            }
            if needs_verification {
                crate::portable_checkpoint::verified_sidecar_footer(&input)?;
            }
            if import_only {
                return crate::checkpoint_delta::import(&input)
                    .map(|imported| imported.map(|imported| imported.id));
            }
            crate::checkpoint_delta::prepare_restore(&input)
                .map(|tree| tree.map(|tree| tree.display().to_string()))
        })
        .await
        .map_err(|error| ApiError::internal(format!("chunked checkpoint task: {error}")))?
        .map_err(ApiError::from)?;
        if prepared.is_some() {
            crate::portable_checkpoint::log_phase(&name, "api_restore_chunked_prepare", &mut {
                started
            });
        }
        if import_only {
            let Some(id) = prepared else {
                return Err(ApiError::BadRequest(
                    "only chunked checkpoints can be imported".to_string(),
                ));
            };
            if let Some(key) = options.cache_key {
                let artifact = artifact.clone();
                let _ = tokio::task::spawn_blocking(move || checkpoint_cache_put(&key, &artifact))
                    .await;
            }
            return Ok(axum::response::IntoResponse::into_response(Json(
                serde_json::json!({ "imported": id, "elapsedMs": started.elapsed().as_millis() as u64 }),
            )));
        }
    }

    // Prepared state is an optional optimization: eviction or missing metadata
    // falls back to the durable artifact before machine creation starts.
    #[cfg(target_os = "linux")]
    let prepared = if cache_hit && smolvm_pack::extract::shared_extract_enabled() {
        let artifact = artifact.clone();
        tokio::task::spawn_blocking(move || {
            crate::artifact_cache::open_prepared_checkpoint_for_sidecar(&artifact).ok()
        })
        .await
        .map_err(|error| ApiError::internal(format!("prepared checkpoint task: {error}")))?
    } else {
        None
    };
    let restore_path = artifact.clone();
    #[cfg(target_os = "linux")]
    let restore_path = prepared
        .as_ref()
        .map(|input| input.path.clone())
        .unwrap_or(restore_path);

    let request: CreateMachineRequest = serde_json::from_value(serde_json::json!({
        "name": name,
        "from": restore_path.to_string_lossy(),
        "ports": ports,
        "registryIdentityToken": registry_token,
        "cacheDisk": cache_disk,
    }))
    .map_err(|error| ApiError::internal(format!("build checkpoint restore request: {error}")))?;
    // create_machine consumes and verifies the artifact before this TempDir is
    // dropped, installing owned checkpoint payloads and exact qcow chains.
    // The cache take verified this request's pinned artifact; hand that
    // verification over so creation does not read the payload a second time.
    // It only applies if the path creation uses still names that exact inode.
    let result = create_machine_inner(State(state), Json(request), verified, cache_hit).await;
    #[cfg(target_os = "linux")]
    drop(prepared);
    // The restore no longer leases the checkpoint's shared extraction.
    #[cfg(target_os = "linux")]
    if result.is_ok() {
        crate::artifact_cache::trim_unleased_shared_packs_soon();
    }
    // A hit is already cached; re-linking it would only change the inode's
    // ctime under the restores still sharing it.
    if result.is_ok() && !cache_hit {
        if let Some(key) = options.cache_key {
            if let Err(error) =
                tokio::task::spawn_blocking(move || checkpoint_cache_put(&key, &artifact)).await
            {
                tracing::warn!(%error, "checkpoint cache task failed");
            }
        }
    }
    result.map(axum::response::IntoResponse::into_response)
}

/// Build a MachineEntry from a VmRecord and AgentManager.
///
/// Used by `start_machine` to register a machine in ApiState after boot
/// or during registry repair. Centralizes the record→entry conversion
/// so the two branches don't drift.
pub(crate) fn machine_entry_from_record(record: &VmRecord, manager: AgentManager) -> MachineEntry {
    let mounts = record.host_mounts().iter().map(MountSpec::from).collect();
    let ports = record.port_mappings().iter().map(PortSpec::from).collect();
    MachineEntry {
        manager,
        cache_disk: record.cache_disk.clone(),
        image: record.image.clone(),
        credentials: crate::credentials::CredentialLaunch::for_record(&record.name, record),
        external_interceptor: None,
        mounts,
        ports,
        resources: ResourceSpec {
            // VmResources carries no hostname allow-list, so graft it back from the
            // record — otherwise a reloaded machine would silently lose allowed_hosts.
            allowed_hosts: record.dns_filter_hosts.clone(),
            ..vm_resources_to_spec(record.vm_resources())
        },
        restart: record.restart.clone(),
        network: record.network,
        secret_refs: record.secret_refs.clone(),
        source_smolmachine: record.packed_layer_source().map(str::to_owned),
        packed_image_on_storage: record.packed_image_on_storage,
        forkable: record.forkable_on_start(),
        cuda_fork_pool_size: record.cuda_fork_pool_size,
        cuda_vram_limit_mib: record.cuda_vram_limit_mib,
        forkpoint_held: record.forkpoint_held,
    }
}

/// Reconcile both control-plane representations after a VM process is confirmed dead.
///
/// `ApiState` keeps a long-lived `AgentManager` whose open `vm.lock` file owns the
/// per-machine flock, while SQLite is shared with out-of-process CLI commands. A CLI
/// stop or an unexpected process exit can therefore make the database truthful while
/// leaving the serve process's cached manager in `Running`. Callers must hold the
/// machine lifecycle and fork-source locks and must have confirmed process exit before
/// entering here; releasing the cached flock for a live process would permit a second
/// VMM to start with the same disks.
async fn reconcile_confirmed_stopped_machine(
    state: &Arc<ApiState>,
    name: &str,
    explicitly_stopped: bool,
) -> Result<VmRecord, ApiError> {
    if let Ok(entry) = state.get_machine(name) {
        entry.lock().manager.mark_stopped();
    }

    state
        .update_vm(name, move |record| {
            record.state = RecordState::Stopped;
            record.pid = None;
            record.pid_start_time = None;
            if explicitly_stopped {
                // An explicit stop must suppress the restart supervisor even when
                // the process had already exited before this request arrived.
                record.restart.user_stopped = true;
            }
        })
        .await?
        .ok_or_else(|| {
            ApiError::NotFound(format!(
                "machine '{name}' disappeared from database while reconciling its stopped state"
            ))
        })
}

/// How long to wait for a SIGKILLed VM process to exit before a delete gives up.
///
/// A killed process exits as soon as it leaves the kernel, but a VMM blocked in
/// disk I/O stays until that I/O returns, which on a worker whose disk is
/// saturated (a burst of captures and restores) takes seconds to tens of
/// seconds. It is certain to exit, so giving up early only turns a slow delete
/// into a failed one that the caller has to retry.
const KILLED_VM_EXIT_TIMEOUT: std::time::Duration = std::time::Duration::from_secs(60);

/// Stop after confirmed guest quiescence, or discard an explicitly deleted VM.
///
/// Uses verified signals to prevent killing an unrelated process if the
/// PID was recycled by the OS. Returns true if the process is confirmed
/// dead (or was never running), false if it may still be alive.
/// `graceful`: when true (stop), require a safe shutdown acknowledgment before
/// sending any termination signal. When false (delete), the machine's
/// disks are discarded immediately after, so there is nothing to flush — SIGKILL
/// at once instead of waiting out the guest's graceful shutdown (the bulk of the
/// ~1.9s DELETE latency on metal).
fn shutdown_machine_process(
    name: &str,
    pid: Option<i32>,
    pid_start_time: Option<u64>,
    graceful: bool,
) -> bool {
    // Try graceful shutdown via vsock first.
    // If vsock connects, this confirms the process is our VM (identity verification).
    let manager = AgentManager::for_vm(name).ok();
    let mut shutdown_acknowledged = false;
    if let Some(manager) = manager.as_ref().filter(|_| graceful) {
        if let Ok(mut client) = AgentClient::connect(manager.vsock_socket()) {
            shutdown_acknowledged = client.shutdown().is_ok();
        }
    }

    if graceful && !shutdown_acknowledged {
        if pid.is_some_and(|pid| !is_alive(pid)) {
            sweep_machine_scope(name);
            return true;
        }
        tracing::warn!(
            name,
            "guest shutdown was not acknowledged; preserving the live VM and its disks"
        );
        return false;
    }

    // PID-based signal handling.
    if let Some(pid) = pid {
        // Identity check: vsock acknowledgement OR strict PID start-time match.
        // We intentionally do NOT use the lenient is_our_process() here because
        // it treats any alive PID as "ours" when start_time is None — which risks
        // killing an unrelated process if the OS reused the PID.
        let identity_ok = shutdown_acknowledged || is_our_process_strict(pid, pid_start_time);

        if identity_ok {
            // On delete the disks are removed right after, so skip the SIGTERM
            // grace and SIGKILL immediately (ZERO grace). On stop keep the grace
            // so the guest can flush to its persistent overlay first.
            let sigterm = if graceful {
                VM_SIGTERM_TIMEOUT
            } else {
                Duration::ZERO
            };
            crate::vm_exit::mark_stop_requested(&crate::agent::vm_data_dir(name), pid);
            let _ = stop_vm_process(pid, sigterm, VM_SIGKILL_TIMEOUT);
        } else {
            tracing::debug!(pid, name, "PID already dead");
        }

        // Post-check: verify the process is actually gone. If it outlived the
        // pid-targeted SIGKILL (or the recorded pid is wrong), fall back to
        // killing the systemd transient scope — its cgroup owns every process the
        // VM spawned — then wait briefly for the SIGKILL to land. Only give up if
        // STILL alive.
        if is_alive(pid) {
            let _ = crate::systemd_scope::kill_scope(name);
            let deadline = std::time::Instant::now() + KILLED_VM_EXIT_TIMEOUT;
            while is_alive(pid) && std::time::Instant::now() < deadline {
                std::thread::sleep(std::time::Duration::from_millis(100));
            }
            if is_alive(pid) {
                tracing::warn!(pid, name, "process still alive after shutdown + scope kill");
                return false;
            }
        }
    } else {
        // No recorded pid — the pid-based kill can't run at all, which is exactly
        // how a stuck/crash-looping VM becomes an un-deletable orphan (delete 500s
        // "still alive; not removing" while the node keeps running the VM). Kill
        // the transient scope's cgroup directly and confirm via vsock that the VM
        // is actually gone.
        let _ = crate::systemd_scope::kill_scope(name);
        let deadline = std::time::Instant::now() + KILLED_VM_EXIT_TIMEOUT;
        while std::time::Instant::now() < deadline {
            let reachable = manager
                .as_ref()
                .and_then(|m| AgentClient::connect(m.vsock_socket()).ok())
                .map(|mut c| c.ping().is_ok())
                .unwrap_or(false);
            if !reachable {
                if let Err(error) = crate::agent::cleanup_dead_vm_runtime(name) {
                    tracing::warn!(%name, %error, "failed to clean runtime after VM teardown");
                }
                return true;
            }
            std::thread::sleep(std::time::Duration::from_millis(300));
        }
        tracing::warn!(
            name,
            "VM still reachable via vsock after scope kill; no PID to signal"
        );
        return false;
    }

    sweep_machine_scope(name);
    if let Err(error) = crate::agent::cleanup_dead_vm_runtime(name) {
        tracing::warn!(%name, %error, "failed to clean runtime after VM teardown");
    }
    true
}

/// Once the recorded VM process is gone, kill whatever else is left in the
/// machine's scope. A second VM booted for the same machine joins its scope
/// without becoming the recorded process, so only the scope reaches it; left
/// alone it outlives the machine. An empty or missing scope is left as is.
fn sweep_machine_scope(name: &str) {
    let Some(left) = crate::systemd_scope::scope_process_count(name).filter(|&n| n > 0) else {
        return;
    };
    tracing::warn!(%name, processes = left, "killing processes left in the machine's scope after its VM exited");
    if let Err(error) = crate::systemd_scope::kill_scope(name) {
        tracing::warn!(%name, %error, "could not sweep the machine's scope after teardown");
    }
}

/// Disks to restore for a VM-mode (`--from-vm`) pack. Unlike an image pack (OCI
/// layers), a VM-mode `.smolmachine` carries the source VM's overlay + storage
/// DISKS — the actual rootfs (`/bin/sh`, files written before packing). They must
/// be seeded onto the new machine's disks or it boots with only the bare
/// agent-rootfs. `pack run` does this; the API create path must too.
struct VmModeSeed {
    overlay_template: Option<String>,
    storage_template: Option<String>,
    /// Original (pre-truncation) virtual size of the overlay disk. The packed
    /// template has its trailing zero extent stripped, so the disk must be
    /// ftruncated back to this before boot or it isn't a valid full filesystem.
    overlay_logical_size: Option<u64>,
    /// Original virtual size of the packed persistent storage disk.
    storage_logical_size: Option<u64>,
    /// Requested disk sizes (GiB) from the create request, honored as a lower
    /// bound on the seeded disks (the guest grows the inherited fs with resize2fs).
    storage_gb: Option<u64>,
    overlay_gb: Option<u64>,
}

/// Create a new machine.
#[utoipa::path(
    post,
    path = "/api/v1/machines",
    tag = "Machines",
    request_body = CreateMachineRequest,
    responses(
        (status = 200, description = "Machine created", body = MachineInfo),
        (status = 400, description = "Invalid request", body = ApiErrorResponse),
        (status = 409, description = "Machine already exists", body = ApiErrorResponse)
    )
)]
pub async fn create_machine(
    State(state): State<Arc<ApiState>>,
    Json(req): Json<CreateMachineRequest>,
) -> Result<Json<MachineInfo>, ApiError> {
    create_machine_inner(State(state), Json(req), None, false).await
}

/// Run a create to its end whether or not its client is still waiting.
///
/// A request future is dropped when its client disconnects. Dropped mid-create,
/// it abandoned blocking work (a pack extraction) that kept writing the
/// machine's data directory after the name had been released, which left the
/// data on disk with no machine. In a task of its own the create either
/// finishes, leaving a machine the client can find and delete, or fails and
/// rolls back, before anything is released.
async fn create_machine_inner(
    state: State<Arc<ApiState>>,
    req: Json<CreateMachineRequest>,
    verified: Option<crate::portable_checkpoint::VerifiedSidecar>,
    cached_checkpoint: bool,
) -> Result<Json<MachineInfo>, ApiError> {
    tokio::spawn(create_machine_to_end(
        state,
        req,
        verified,
        cached_checkpoint,
    ))
    .await
    .map_err(|e| ApiError::internal(format!("create task: {e}")))?
}

/// [`create_machine`], optionally reusing a verification of the `from`
/// artifact that this same request already performed on a pinned descriptor.
/// The reuse is granted only when the path about to be used still resolves to
/// that unchanged inode; otherwise the artifact is verified afresh here. This
/// is a private request-scoped handoff, not a public option.
async fn create_machine_to_end(
    State(state): State<Arc<ApiState>>,
    Json(mut req): Json<CreateMachineRequest>,
    verified: Option<crate::portable_checkpoint::VerifiedSidecar>,
    cached_checkpoint: bool,
) -> Result<Json<MachineInfo>, ApiError> {
    // Refused before any image pull or disk work, so a server that has not opted
    // in never builds a nested machine.
    state.ensure_nested_virt_allowed(req.nested_virt)?;
    #[cfg(target_os = "linux")]
    let _prepared = if let Some(reference) = req
        .from
        .as_ref()
        .filter(|value| value.starts_with("checkpoint://"))
    {
        let reference = reference.clone();
        let prepared = tokio::task::spawn_blocking(move || {
            crate::artifact_cache::open_prepared_checkpoint(&reference)
        })
        .await
        .map_err(|error| ApiError::internal(error.to_string()))?
        .map_err(|error| ApiError::BadRequest(error.to_string()))?;
        req.from = Some(prepared.path.to_string_lossy().into_owned());
        Some(prepared)
    } else {
        None
    };
    #[cfg(target_os = "linux")]
    let cached_checkpoint = cached_checkpoint || _prepared.is_some();
    let mut checkpoint_phase = std::time::Instant::now();
    // Validate: registry_ref, from, and image are mutually exclusive
    let source_count = [
        req.registry_ref.is_some(),
        req.from.is_some(),
        req.image.is_some(),
    ]
    .iter()
    .filter(|&&b| b)
    .count();
    if source_count > 1 {
        return Err(ApiError::BadRequest(
            "'registryRef', 'from', and 'image' are mutually exclusive".to_string(),
        ));
    }

    // Resolve local images after validating the exclusive source choice, before
    // creating or registering the machine. This persists a stable local: ref.
    if let Some(image) = req.image.take() {
        req.image = Some(resolve_api_image(&state, image).await?);
    }

    // Published ports need the inbound path that only virtio-net has. With an
    // UNSET backend the launcher auto-selects virtio-net when ports are present
    // (see `plan_launch_network`), so ports "just work" without per-request
    // wiring — mirroring the CLI and `validate_requested_network_backend`. Only
    // an EXPLICIT TSI choice alongside ports is a misconfig (TSI is
    // outbound-only and would silently never accept connections).
    let guest_subnet = req
        .guest_subnet
        .as_deref()
        .map(|subnet| {
            subnet
                .parse::<smolvm_network::GuestSubnet>()
                .map(|subnet| subnet.to_string())
                .map_err(ApiError::BadRequest)
        })
        .transpose()?;
    if guest_subnet.is_some() && req.network_backend == Some(crate::network::NetworkBackend::Tsi) {
        return Err(ApiError::BadRequest(
            "guestSubnet requires networkBackend 'virtio-net' (TSI has no guest link); \
             omit networkBackend or set it to 'virtio-net'"
                .to_string(),
        ));
    }
    if !req.ports.is_empty() && req.network_backend == Some(crate::network::NetworkBackend::Tsi) {
        return Err(ApiError::BadRequest(
            "published ports require networkBackend 'virtio-net' (TSI is outbound-only); \
             omit networkBackend or set it to 'virtio-net'"
                .to_string(),
        ));
    }

    // If registry_ref is set, pull the artifact from the registry and treat as `from`
    // Where a pack came from, kept on the machine so a live checkpoint of it can
    // name the pack for a host that has to fetch it.
    let mut pack_registry_ref: Option<String> = None;
    if let Some(ref registry_ref) = req.registry_ref.clone() {
        let pulled_path = pull_from_registry(
            registry_ref,
            req.registry_identity_token.as_deref(),
            &req.blob_peers,
        )
        .await?;
        req.from = Some(pulled_path);
        req.registry_ref = None;
        pack_registry_ref = Some(registry_ref.clone());
    }

    // An `image` can also name a smolmachine pack artifact (e.g.
    // registry.smolmachines.com/library/alpine), whose single "layer" is a
    // full .smolmachine sidecar, not an OCI filesystem layer — the in-guest
    // OCI puller would unpack its multi-GiB storage.ext4 into the guest disk.
    // Probe the manifest on the host and reroute through the same from-sidecar
    // flow as `registryRef`; a failed probe falls back to the in-guest pull.
    if let Some(image) = req.image.clone() {
        let sidecar = crate::data::pack_ref::resolve_pack_ref(
            &image,
            req.registry_identity_token.as_deref(),
            &req.blob_peers,
        )
        .await
        .map_err(|e| ApiError::internal(e.to_string()))?;
        if let Some(sidecar) = sidecar {
            req.from = Some(sidecar.to_string_lossy().into_owned());
            req.image = None;
            pack_registry_ref = Some(image);
        }
    }

    // `cmd`/`entrypoint` are the machine's persistent workload, launched only as
    // a container from an image or `.smolmachine` artifact (registryRef and any
    // image-pack-ref have already been folded into `from` above). Reject them on
    // an imageless machine up front — it boots the bare-agent rootfs with nothing
    // to launch them in, so silently accepting them would strand a caller whose
    // command never runs (drive an imageless machine via `exec` instead).
    validate_workload_image_source(
        req.image.is_some(),
        req.from.is_some(),
        &req.cmd,
        &req.entrypoint,
    )
    .map_err(ApiError::BadRequest)?;

    // Generate name if not provided, then validate. The on-disk layout uses
    // a hash-derived directory (see `vm_data_dir`) so name length doesn't
    // affect the socket path — only character sanity + a generous length
    // cap are needed.
    let name = req.name.clone().unwrap_or_else(generate_machine_name);
    validate_vm_name(&name, "machine name").map_err(ApiError::BadRequest)?;

    // Fetch a cache disk base this node lacks before any other work, so a bad
    // base is a 400 and not a half-made machine.
    let cache_disk = match req.cache_disk.as_ref() {
        Some(spec) => {
            fetch_cache_base(&state, spec).await?;
            Some(state.resolve_cache_disk(spec)?)
        }
        None => None,
    };
    let spec = create_spec_from_request(&req, cache_disk)?;

    // SHA-256 taken while a restored checkpoint was received, handed to the
    // shared extraction so it does not hash the artifact again.
    let mut received_digest: Option<smolvm_pack::extract::ArtifactDigestProof> = None;
    let mut source_smolmachine: Option<String> = None;
    let mut vm_seed: Option<VmModeSeed> = None;
    // If `from` is set, verify the artifact and read its manifest.
    let manifest = if let Some(ref sidecar_path) = req.from {
        let path = std::path::Path::new(sidecar_path);
        if !path.exists() {
            return Err(ApiError::BadRequest(format!(
                "sidecar file not found: {}",
                sidecar_path
            )));
        }
        // Cache lookup and creation are separate phases. Another restore may
        // have changed link metadata in between; reverify under the same lease
        // used by lookup, publication, eviction and transfer cleanup.
        let verification_path = path.to_path_buf();
        received_digest = tokio::task::spawn_blocking(move || {
            let _lock = if cached_checkpoint {
                Some(lock_checkpoint_cache_verification(&checkpoint_cache_dir()?)
                    .map_err(|e| ApiError::internal(format!("lock checkpoint verification: {e}")))?)
            } else {
                None
            };
            let mut digest = None;
            if let Some(input) = verified.as_ref().filter(|input| input.covers(&verification_path)) {
                tracing::info!(
                    artifact = %verification_path.display(),
                    "reusing this request's pinned checkpoint verification; skipping a second checksum pass"
                );
                digest = input.digest_proof();
            } else {
                crate::portable_checkpoint::verified_sidecar_footer(&verification_path)
                    .map_err(|e| ApiError::BadRequest(e.to_string()))?;
            }
            Ok::<_, ApiError>(digest)
        }).await.map_err(|e| ApiError::internal(format!("checkpoint verification task: {e}")))??;
        let manifest = smolvm_pack::packer::read_manifest_from_sidecar(path)
            .map_err(|e| ApiError::internal(format!("read .smolmachine: {}", e)))?;
        // Reject a cross-architecture artifact up front (400, not a mid-boot 500):
        // a packed VM/image carries native binaries that cannot run under a
        // different-arch guest kernel. Guest arch must match; host OS need not.
        crate::platform::ensure_artifact_arch_matches_host(&manifest.platform)
            .map_err(|e| ApiError::BadRequest(e.to_string()))?;
        // Extraction happens after the agent manager creates this machine's data
        // dir (below), so the layers land in the machine's own dir, not here.
        source_smolmachine = Some(
            path.canonicalize()
                .unwrap_or_else(|_| path.to_path_buf())
                .to_string_lossy()
                .into_owned(),
        );
        // VM-mode packs carry disks, not layers — capture the templates so the
        // machine's overlay/storage disks can be seeded from them below.
        if manifest.checkpoint.is_none() && manifest.mode == smolvm_pack::format::PackMode::Vm {
            vm_seed = Some(VmModeSeed {
                overlay_template: manifest
                    .assets
                    .overlay_template
                    .as_ref()
                    .map(|t| t.path.clone()),
                storage_template: manifest
                    .assets
                    .storage_template
                    .as_ref()
                    .map(|t| t.path.clone()),
                overlay_logical_size: manifest.assets.overlay_logical_size,
                storage_logical_size: manifest.assets.storage_logical_size,
                storage_gb: req.storage_gb,
                overlay_gb: req.overlay_gb,
            });
        }
        Some(manifest)
    } else {
        None
    };
    let manifest_checkpoint = manifest
        .as_ref()
        .and_then(|manifest| manifest.checkpoint.clone());

    // Every option against what the source supplies or fixes, by the rules
    // every creation path uses. Refusals happen here, before any disk work.
    let source = match manifest.as_ref() {
        Some(manifest) => crate::machine_spec::SpecSource::from_manifest(manifest),
        None => crate::machine_spec::SpecSource::from_image(req.image.as_deref()),
    };
    let resolved = crate::machine_spec::resolve(source, spec, crate::machine_spec::Caller::Api)
        .map_err(|error| ApiError::BadRequest(error.to_string()))?;
    // A checkpoint can bring nested virtualization with it.
    state.ensure_nested_virt_allowed(resolved.nested_virt)?;
    // A restored guest resumes with the devices it was captured with: a
    // checkpoint of a machine with a cache disk restores over the same base,
    // and one without takes none.
    let restore_cache_base = match manifest_checkpoint.clone() {
        Some(checkpoint) => {
            let cache_disk = resolved.cache_disk.clone();
            tokio::task::spawn_blocking(move || {
                crate::portable_checkpoint::resolve_cache_base(&checkpoint, cache_disk.as_ref())
            })
            .await
            .map_err(|e| ApiError::internal(format!("task error: {e}")))?
            .map_err(|error| ApiError::BadRequest(error.to_string()))?
        }
        None => None,
    };
    let image = resolved.image.clone();
    let restored_storage_gb = resolved.storage_gb;
    let restored_overlay_gb = resolved.overlay_gb;

    if manifest_checkpoint.is_some() {
        crate::portable_checkpoint::log_phase(&name, "api_restore_verify", &mut checkpoint_phase);
    }
    // Reserve the name atomically (prevents concurrent creation)
    let guard = ReservationGuard::new(&state, name.clone())?;

    // A machine without networking has its registry image fetched on the host
    // at start, which repoints it at the fetched archive and seeds from that.
    // A seed of the registry image made here would only be discarded then.
    let start_fetches_on_host = image.as_deref().is_some_and(|image| {
        matches!(
            crate::data::image_source::classify(image),
            crate::data::image_source::ImageSource::Registry(_)
        )
    }) && !crate::network::plan_launch_network_with(
        &resolved.vm_resources(),
        resolved.allowed_hosts.as_deref(),
        resolved.ports.len(),
        resolved.credentials.is_some(),
    )
    .has_network();

    // A registry-image machine gets its storage disk on a shared seed of its
    // image (see `image_seed`), so its first start skips the pull. The manager
    // below then opens that disk instead of creating a blank one.
    let seed_image = (source_smolmachine.is_none()
        && manifest_checkpoint.is_none()
        && vm_seed.is_none()
        && !start_fetches_on_host)
        .then(|| crate::image_seed::seedable_image(&name, image.as_deref(), restored_storage_gb))
        .flatten();

    // Create manager (does not boot the VM)
    let mut manager = tokio::task::spawn_blocking({
        let name = name.clone();
        let storage_gb = restored_storage_gb;
        let overlay_gb = restored_overlay_gb;
        move || {
            if let Some(image) = seed_image {
                let seeded = crate::image_seed::builder_exe()
                    .map_err(|e| crate::Error::config("image seed", e.to_string()))
                    .and_then(|exe| {
                        crate::image_seed::seed_storage(
                            &exe,
                            &name,
                            &image,
                            &crate::registry::PullAuth::FromConfig,
                            storage_gb,
                            None,
                            None,
                            None,
                        )
                    });
                if let Err(error) = seeded {
                    tracing::warn!(machine = %name, %error, "no image seed; pulling in the guest");
                }
            }
            AgentManager::for_vm_with_sizes(&name, storage_gb, overlay_gb)
                .map_err(|e| ApiError::internal(format!("failed to create agent manager: {}", e)))
        }
    })
    .await
    .map_err(|e| ApiError::internal(format!("task error: {}", e)))??;

    if manifest_checkpoint.is_some() {
        crate::portable_checkpoint::log_phase(&name, "api_restore_prepare", &mut checkpoint_phase);
    }
    // Extract the bundle's OCI layers into this machine's own data dir (created
    // by the manager above) rather than the shared pack cache, so every start is
    // independent of the .smolmachine file surviving and the macOS layers volume
    // initially belongs only to this machine. Extraction mounts the volume on
    // macOS; detach it immediately so a created-but-unstarted machine leaves
    // nothing mounted (it has no children yet). The name was reserved above,
    // so this never clobbers another machine's layers.
    let mut packed_storage_gib = None;
    if let Some(ref sidecar_path) = source_smolmachine {
        let name = name.clone();
        let sidecar_path = sidecar_path.clone();
        let digest = received_digest.take();
        let is_checkpoint = manifest_checkpoint.is_some();
        packed_storage_gib =
            tokio::task::spawn_blocking(move || -> Result<Option<u64>, ApiError> {
                let path = std::path::Path::new(&sidecar_path);
                let cache_dir = crate::agent::machine_layers_cache_dir(&name);
                if !is_checkpoint {
                    match crate::pack_seed::try_seed(&name, path, restored_storage_gb) {
                        Ok(Some(size)) => return Ok(Some(size)),
                        Ok(None) => {}
                        Err(error) => {
                            let _ = std::fs::remove_dir_all(vm_data_dir(&name));
                            return Err(ApiError::internal(error.to_string()));
                        }
                    }
                }
                // The server outlives the restore, so checkpoint RAM can finish
                // reaching the disk after the machine is created.
                let options = smolvm_pack::extract::SharedExtractOptions {
                    digest,
                    defer_memory_sync: true,
                };
                let result = crate::portable_checkpoint::materialize_pack_layers_with_options(
                    &name, path, options,
                )
                .map_err(|e| ApiError::internal(e.to_string()));
                // Detach the case-sensitive volume mounted during extraction so a
                // created-but-unstarted machine leaves nothing mounted, and so the
                // rollback below can remove the data dir cleanly (macOS; no-op on Linux).
                smolvm_pack::extract::force_detach_layers_volume(&cache_dir);
                if let Err(e) = result {
                    // Extraction failed after the manager created the machine's data
                    // dir. guard.complete() will not run, so no DB record persists and
                    // the name is released on drop — but the on-disk dir would be left
                    // orphaned. Roll it back so a retry starts clean. Best-effort: a
                    // remove failure only leaves the orphan, never a worse state.
                    // cache_dir is <vm_data_dir>/pack, so its parent is the data dir.
                    if let Some(vm_dir) = cache_dir.parent() {
                        let _ = std::fs::remove_dir_all(vm_dir);
                    }
                    return Err(e);
                }
                Ok(None)
            })
            .await
            .map_err(|e| ApiError::internal(format!("task error: {}", e)))??;
    }

    if manifest_checkpoint.is_some() {
        crate::portable_checkpoint::log_phase(&name, "api_restore_extract", &mut checkpoint_phase);
    }
    // VM-mode pack: seed this machine's overlay + storage disks from the packed
    // templates (extracted above) so a start boots the source VM's rootfs rather
    // than the bare agent-rootfs (the /bin/sh-missing bug). `open_or_create_at`
    // reuses an existing disk, so seeding once at create persists across starts.
    // Mirrors `pack_run`'s VM-mode disk restore (`setup_vm_overlay` +
    // `create_or_copy_storage_disk`).
    if let Some(seed) = vm_seed {
        let name2 = name.clone();
        let disk_dir = manager
            .storage_path()
            .parent()
            .map(std::path::Path::to_path_buf)
            .unwrap_or_else(|| vm_data_dir(&name));
        let seed_result = tokio::task::spawn_blocking(move || -> Result<(), ApiError> {
            let cache_dir = crate::agent::machine_layers_cache_dir(&name2);
            // With the shared store, the pack contents live in `_shared/<checksum>`
            // (the per-machine `pack` dir is an empty mountpoint), so seed the
            // VM-mode disk templates from the shared copy. Falls back to the
            // per-machine dir when no pointer was written (macOS / kill-switch).
            let (pack_content_dir, artifact_sha256) =
                if let Some(shared_dir) = crate::agent::read_shared_pack_pointer(&cache_dir) {
                    let digest = smolvm_pack::extract::read_shared_artifact_sha256(&shared_dir)
                        .map_err(|e| {
                            ApiError::internal(format!(
                                "read shared artifact SHA-256 {}: {e}",
                                shared_dir.display()
                            ))
                        })?;
                    (shared_dir, Some(digest))
                } else {
                    (cache_dir, None)
                };
            crate::storage::seed_vm_mode_disks(
                &disk_dir,
                &pack_content_dir,
                crate::storage::VmModeDiskSeedSpec {
                    artifact_sha256: artifact_sha256.as_deref(),
                    overlay_template: seed.overlay_template.as_deref(),
                    storage_template: seed.storage_template.as_deref(),
                    overlay_logical_size: seed.overlay_logical_size,
                    storage_logical_size: seed.storage_logical_size,
                    overlay_gb: seed.overlay_gb,
                    storage_gb: seed.storage_gb,
                },
            )
            .map_err(|e| ApiError::internal(format!("seed VM-mode disks: {}", e)))
        })
        .await
        .map_err(|e| ApiError::internal(format!("task error: {}", e)))?;
        // On failure roll back the data dir the manager created, so a retry starts
        // clean (the reservation guard releases the name but leaves the dir).
        if let Err(e) = seed_result {
            let _ = std::fs::remove_dir_all(vm_data_dir(&name));
            return Err(e);
        }
    }

    if manifest_checkpoint.is_some() {
        crate::portable_checkpoint::log_phase(&name, "api_restore_seed", &mut checkpoint_phase);
    }
    // Install a live checkpoint only after the ordinary VM-mode templates have
    // been seeded. The checkpoint's exact qcow chains must be the final disk
    // publication; seeding afterwards would silently replace the captured
    // block topology and wedge device-state restore. Immutable payloads and
    // backing images keep owned hard links into the verified extraction cache.
    if let Some(checkpoint) = manifest_checkpoint.clone() {
        let name_for_checkpoint = name.clone();
        let install = tokio::task::spawn_blocking(move || -> Result<(), ApiError> {
            let cache_dir = crate::agent::machine_layers_cache_dir(&name_for_checkpoint);
            let content_dir = crate::agent::read_shared_pack_pointer(&cache_dir)
                .unwrap_or_else(|| cache_dir.clone());
            // RAM the extraction left for later reaches the disk after this
            // install, whether or not it succeeds, so it does not slow it down.
            let mut deferred =
                crate::portable_checkpoint::DeferredRestoreSync::for_extraction(&content_dir);
            let installed = crate::portable_checkpoint::install_deferring_sync(
                &content_dir,
                &vm_data_dir(&name_for_checkpoint),
                &checkpoint,
                restore_cache_base.as_deref(),
                &mut deferred,
            )
            .and_then(|()| {
                crate::portable_checkpoint::discard_transport_pack(&vm_data_dir(
                    &name_for_checkpoint,
                ))
            })
            .map_err(|error| ApiError::BadRequest(error.to_string()));
            deferred.start();
            installed
        })
        .await
        .map_err(|e| ApiError::internal(format!("task error: {e}")))?;
        if let Err(error) = install {
            let _ = std::fs::remove_dir_all(vm_data_dir(&name));
            return Err(error);
        }
    }

    // A checkpoint of a pack machine needs that pack's layers mounted again, so
    // the restored machine gets the same virtio-fs device it was captured with.
    let mut restored_pack: Option<(String, Option<String>)> = None;
    if let Some(packed) = manifest_checkpoint
        .as_ref()
        .and_then(|checkpoint| checkpoint.packed_layers.clone())
    {
        let attached = async {
            let sidecar = checkpoint_pack_sidecar(
                &packed,
                req.registry_identity_token.as_deref(),
                &req.blob_peers,
            )
            .await?;
            let name = name.clone();
            let sidecar_for_task = sidecar.clone();
            let packed_for_task = packed.clone();
            tokio::task::spawn_blocking(move || {
                crate::portable_checkpoint::verify_checkpoint_pack(
                    &sidecar_for_task,
                    &packed_for_task,
                )?;
                crate::portable_checkpoint::materialize_pack_layers(&name, &sidecar_for_task)
            })
            .await
            .map_err(|e| ApiError::internal(format!("task error: {e}")))?
            .map_err(|e| ApiError::BadRequest(e.to_string()))?;
            Ok::<_, ApiError>(sidecar)
        }
        .await;
        match attached {
            Ok(sidecar) => {
                restored_pack = Some((
                    sidecar.to_string_lossy().into_owned(),
                    packed.registry_ref.clone(),
                ))
            }
            Err(error) => {
                let _ = std::fs::remove_dir_all(vm_data_dir(&name));
                return Err(error);
            }
        }
    }

    // A checkpoint of a machine that booted a host-fetched registry image needs
    // that image fetched here and served the way the captured guest read it,
    // whatever the restored machine's network: the guest holds its device.
    let mut restored_host_image = None;
    if let Some(checkpoint) = manifest_checkpoint.as_ref() {
        match crate::portable_checkpoint::fetch_checkpoint_host_image(
            checkpoint,
            &crate::registry::PullAuth::FromConfig,
        )
        .await
        {
            Ok(image) => restored_host_image = image,
            Err(error) => {
                let _ = std::fs::remove_dir_all(vm_data_dir(&name));
                return Err(ApiError::from(error));
            }
        }
    }

    if manifest_checkpoint.is_some() {
        // Install may publish a disk under a different name than the one the
        // manager opened (a copy-on-write top is `.qcow2`, not `.raw`), so
        // resolve the disks again rather than launch from a stale handle.
        manager = tokio::task::spawn_blocking({
            let name = name.clone();
            move || {
                AgentManager::for_vm_with_sizes(&name, restored_storage_gb, restored_overlay_gb)
                    .map_err(|e| ApiError::internal(format!("reopen restored disks: {e}")))
            }
        })
        .await
        .map_err(|e| ApiError::internal(format!("task error: {e}")))??;
        crate::portable_checkpoint::log_phase(&name, "api_restore_install", &mut checkpoint_phase);
    }

    // Complete registration: persists to DB + registers in ApiState
    let complete_result = guard.complete(MachineRegistration {
        manager,
        resolved,
        host_image: restored_host_image,
        source_registry_ref: if manifest_checkpoint.is_some() {
            restored_pack
                .as_ref()
                .and_then(|(_, reference)| reference.clone())
        } else if source_smolmachine.is_some() {
            pack_registry_ref
        } else {
            None
        },
        source_smolmachine: if manifest_checkpoint.is_some() {
            // The checkpoint pack itself is a transport envelope, not an
            // OCI-layer source. Only the pack the captured machine mounted its
            // layers from (reattached above) belongs to the device topology.
            restored_pack.map(|(sidecar, _)| sidecar)
        } else {
            source_smolmachine
        },
        packed_storage_gib,
    });
    if let Err(e) = complete_result {
        let data_dir = vm_data_dir(&name);
        smolvm_pack::extract::force_detach_layers_volume(&crate::agent::machine_layers_cache_dir(
            &name,
        ));
        if let Err(remove_err) = std::fs::remove_dir_all(&data_dir) {
            if remove_err.kind() != std::io::ErrorKind::NotFound {
                tracing::warn!(
                    machine = %name,
                    dir = %data_dir.display(),
                    error = %remove_err,
                    "failed to remove machine data dir after create commit failure"
                );
            }
        }
        return Err(e);
    }

    // Fetch the persisted record for the response (off the reactor).
    let record = state
        .lookup_vm(&name)
        .await?
        .ok_or_else(|| ApiError::internal("machine disappeared after creation".to_string()))?;

    Ok(Json(record_to_info(&name, &record)))
}

/// Normalize an API image before the machine is registered. A registry
/// reference passes through. A local archive or rootfs directory is accepted
/// only under the server's `--local-image-dir`, after resolving symlinks, since
/// a path names the server's own files; an already-resolved `local:` /
/// `local-dir:` reference is never accepted from a caller. A request has no
/// stdin archive stream, so `-` fails. Hashing multi-GiB archives runs off the
/// Tokio reactor.
async fn resolve_api_image(state: &ApiState, image: String) -> Result<String, ApiError> {
    use crate::data::image_source::{
        classify, is_local_ref, resolve, ArchiveInput, ImageSource, ResolvedImage,
    };
    if is_local_ref(&image) {
        return Err(ApiError::BadRequest(
            "image names a resolved local source; give the archive or directory path".into(),
        ));
    }
    let path = match classify(&image) {
        ImageSource::Registry(_) => return Ok(image),
        ImageSource::Archive(ArchiveInput::Stdin) => {
            return Err(ApiError::BadRequest(
                "image '-' requires CLI stdin; give the API a server-local archive path".into(),
            ))
        }
        ImageSource::Unsupported { hint, .. } => return Err(ApiError::BadRequest(hint)),
        ImageSource::Archive(ArchiveInput::File(path)) | ImageSource::Directory(path) => path,
    };
    let dir = state.local_image_dir()?;
    let canonical = path.canonicalize().map_err(|error| {
        ApiError::BadRequest(format!("local image '{}': {error}", path.display()))
    })?;
    if !canonical.starts_with(&dir) {
        return Err(ApiError::BadRequest(format!(
            "local image '{}' is outside this server's local image directory",
            path.display()
        )));
    }
    let source = classify(&canonical.to_string_lossy());
    tokio::task::spawn_blocking(move || resolve(source))
        .await
        .map_err(|error| ApiError::internal(format!("image resolution task failed: {error}")))?
        .map(|resolved| match resolved {
            ResolvedImage::Registry(reference) | ResolvedImage::Local { reference, .. } => {
                reference
            }
        })
        .map_err(|error| ApiError::BadRequest(error.to_string()))
}

/// List all machines.
#[utoipa::path(
    get,
    path = "/api/v1/machines",
    tag = "Machines",
    responses(
        (status = 200, description = "List of machines", body = ListMachinesResponse),
        (status = 500, description = "Database error", body = ApiErrorResponse)
    )
)]
pub async fn list_machines(
    State(state): State<Arc<ApiState>>,
) -> Result<Json<ListMachinesResponse>, ApiError> {
    // Read off the reactor: an inline synchronous `list_vms()` here let a stalled
    // write park the worker pool and wedge the liveness probes (this is the path
    // the control plane polls every reconcile). See tests/reactor_wedge.rs.
    let vms = state.list_vm_records().await?;
    let machines: Vec<MachineInfo> = vms
        .iter()
        .map(|(name, record)| record_to_info(name, record))
        .collect();

    Ok(Json(ListMachinesResponse { machines }))
}

/// Get machine status.
#[utoipa::path(
    get,
    path = "/api/v1/machines/{name}",
    tag = "Machines",
    params(
        ("name" = String, Path, description = "Machine name")
    ),
    responses(
        (status = 200, description = "Machine details", body = MachineInfo),
        (status = 404, description = "Machine not found", body = ApiErrorResponse)
    )
)]
pub async fn get_machine(
    State(state): State<Arc<ApiState>>,
    Path(name): Path<String>,
) -> Result<Json<MachineInfo>, ApiError> {
    let record = state
        .lookup_vm(&name)
        .await?
        .ok_or_else(|| ApiError::NotFound(format!("machine '{}' not found", name)))?;

    let mut info = record_to_info(&name, &record);
    info.disk_chain_depth =
        tokio::task::spawn_blocking(move || crate::agent::fork::disk_chain_depth(&name))
            .await
            .map_err(|error| ApiError::internal(format!("disk depth task failed: {error}")))?;
    Ok(Json(info))
}

/// Query string for `GET /machines/{name}/egress-events`.
#[derive(Debug, serde::Deserialize, utoipa::IntoParams)]
pub struct EgressEventsQuery {
    /// Maximum number of events to return (newest kept). Default 200.
    pub limit: Option<usize>,
}

/// List the machine's egress denials — outbound connects and sendtos its
/// egress policy refused. Empty for a machine with no policy, no denials, or
/// one that has never booted.
#[utoipa::path(
    get,
    path = "/api/v1/machines/{name}/egress-events",
    tag = "Machines",
    params(
        ("name" = String, Path, description = "Machine name"),
        EgressEventsQuery
    ),
    responses(
        (status = 200, description = "Egress denial events", body = EgressEventsResponse),
        (status = 404, description = "Machine not found", body = ApiErrorResponse)
    )
)]
pub async fn get_machine_egress_events(
    State(state): State<Arc<ApiState>>,
    Path(name): Path<String>,
    axum::extract::Query(query): axum::extract::Query<EgressEventsQuery>,
) -> Result<Json<EgressEventsResponse>, ApiError> {
    state
        .lookup_vm(&name)
        .await?
        .ok_or_else(|| ApiError::NotFound(format!("machine '{}' not found", name)))?;

    let limit = query.limit.unwrap_or(200);
    let events = crate::agent::read_egress_denials(&name, limit)
        .into_iter()
        .map(Into::into)
        .collect();
    Ok(Json(EgressEventsResponse { events }))
}

/// Return the bounded host-side decision record for a mediated machine.
#[utoipa::path(
    get,
    path = "/api/v1/machines/{name}/mediation-events",
    tag = "Machines",
    params(
        ("name" = String, Path, description = "Machine name"),
        EgressEventsQuery
    ),
    responses(
        (status = 200, description = "Mediated egress decisions", body = crate::api::types::MediationEventsResponse),
        (status = 404, description = "Machine not found", body = ApiErrorResponse)
    )
)]
pub async fn get_machine_mediation_events(
    State(state): State<Arc<ApiState>>,
    Path(name): Path<String>,
    axum::extract::Query(query): axum::extract::Query<EgressEventsQuery>,
) -> Result<Json<crate::api::types::MediationEventsResponse>, ApiError> {
    state
        .lookup_vm(&name)
        .await?
        .ok_or_else(|| ApiError::NotFound(format!("machine '{name}' not found")))?;
    let limit = query.limit.unwrap_or(200).clamp(1, 1000);
    let events = tokio::task::spawn_blocking(move || {
        use std::io::{Read, Seek, SeekFrom};
        let path = vm_data_dir(&name).join(smolvm_network::EGRESS_DECISIONS_LOG);
        let mut events: Vec<crate::api::types::MediationDecisionEvent> = Vec::new();
        for path in [path.with_extension("jsonl.1"), path] {
            let mut file = match std::fs::File::open(path) {
                Ok(file) => file,
                Err(error) if error.kind() == std::io::ErrorKind::NotFound => continue,
                Err(error) => return Err(error),
            };
            let len = file.metadata()?.len();
            let start = len.saturating_sub(512 * 1024);
            file.seek(SeekFrom::Start(start))?;
            let mut bytes = String::new();
            file.read_to_string(&mut bytes)?;
            if start > 0 {
                bytes = bytes
                    .split_once('\n')
                    .map_or(String::new(), |(_, rest)| rest.to_owned());
            }
            events.extend(
                bytes
                    .lines()
                    .filter_map(|line| serde_json::from_str(line).ok()),
            );
        }
        if events.len() > limit {
            events.drain(..events.len() - limit);
        }
        Ok::<_, std::io::Error>(events)
    })
    .await
    .map_err(|error| ApiError::internal(format!("audit read task failed: {error}")))?
    .map_err(|error| ApiError::internal(format!("audit read failed: {error}")))?;
    Ok(Json(crate::api::types::MediationEventsResponse { events }))
}

/// Classify a VM launch/boot failure. A published host-port bind conflict — the
/// virtio-net runtime couldn't bind `0.0.0.0:<hostPort>` because something
/// (typically an orphaned VMM) still holds it — is surfaced as `PortConflict`
/// (409 `PORT_IN_USE`), which the control plane recognizes and retries on a
/// freshly-allocated port. An image archive that is not a container image is
/// the caller's to fix, so it is a 400. Everything else stays a 500. Matching is
/// scoped to the virtio-net path so an unrelated AddrInUse can't be mistaken for
/// it.
fn classify_launch_error(e: String) -> ApiError {
    if crate::api::error::is_invalid_image_archive(&e)
        || crate::api::error::is_refused_remote_volume(&e)
    {
        return ApiError::BadRequest(e);
    }
    let lc = e.to_ascii_lowercase();
    // Windows words the same bind failure as WSAEADDRINUSE (os error 10048).
    let in_use = lc.contains("address already in use") || lc.contains("os error 10048");
    if in_use && lc.contains("virtio") {
        ApiError::PortConflict(e)
    } else {
        ApiError::Internal(e)
    }
}

/// Reject `cmd`/`entrypoint` on a create request that names no image source.
///
/// A machine's `cmd`/`entrypoint` are launched only as a container workload from
/// an image or `.smolmachine` artifact (see the image-launch path in
/// [`start_machine`]). An imageless machine boots the bare-agent rootfs with
/// nothing to run them in, so accepting them silently would strand a caller whose
/// command never executes. Callers should fold `registryRef` and any pack-ref
/// into `from`/`image` before this check so only a genuinely imageless request is
/// rejected.
fn validate_workload_image_source(
    has_image: bool,
    has_from: bool,
    cmd: &[String],
    entrypoint: &[String],
) -> Result<(), String> {
    if !has_image && !has_from && (!cmd.is_empty() || !entrypoint.is_empty()) {
        return Err(
            "cmd/entrypoint require an image, from, or registryRef; an imageless \
             machine has no workload to launch them in (use exec instead)"
                .to_string(),
        );
    }
    Ok(())
}

/// Parse an optional JSON request body. No body, a whitespace-only body, or a
/// non-JSON content type all mean "no request"; many HTTP clients send
/// `Content-Type: application/json` on every call, including empty POSTs.
fn optional_json_body<T: serde::de::DeserializeOwned + Default>(
    headers: &axum::http::HeaderMap,
    body: &[u8],
) -> Result<T, ApiError> {
    let is_json = headers
        .get(header::CONTENT_TYPE)
        .and_then(|value| value.to_str().ok())
        .and_then(|value| value.split(';').next())
        .map(|essence| essence.trim().to_ascii_lowercase())
        .is_some_and(|essence| essence == "application/json" || essence.ends_with("+json"));
    if !is_json || body.iter().all(u8::is_ascii_whitespace) {
        return Ok(T::default());
    }
    serde_json::from_slice(body)
        .map_err(|error| ApiError::BadRequest(format!("invalid JSON request body: {error}")))
}

/// Start a machine.
#[utoipa::path(
    post,
    path = "/api/v1/machines/{name}/start",
    tag = "Machines",
    params(
        ("name" = String, Path, description = "Machine name"),
        ("forkable" = Option<bool>, Query, description = "Start as a fork base (memfd RAM + control socket)"),
        ("forkPoolSize" = Option<u32>, Query, description = "Planned runnable CUDA clones; implies forkable and enables automatic VRAM budgeting"),
        ("cudaVramLimitMib" = Option<u64>, Query, description = "Optional logical VRAM limit per golden/clone session; requires forkPoolSize")
    ),
    request_body = Option<crate::api::types::StartMachineRequest>,
    responses(
        (status = 200, description = "Machine started", body = MachineInfo),
        (status = 400, description = "Invalid or missing interceptor binding", body = ApiErrorResponse),
        (status = 404, description = "Machine not found", body = ApiErrorResponse),
        (status = 409, description = "A published host port is already in use (PORT_IN_USE)", body = ApiErrorResponse),
        (status = 500, description = "Failed to start", body = ApiErrorResponse)
    )
)]
pub async fn start_machine(
    State(state): State<Arc<ApiState>>,
    Path(name): Path<String>,
    Query(query): Query<StartMachineQuery>,
    // Optional: the route took only a query string before this existed, so a
    // caller that sends no body (or a non-JSON one) still starts normally.
    headers: axum::http::HeaderMap,
    body: Bytes,
) -> Result<Json<MachineInfo>, ApiError> {
    let request: crate::api::types::StartMachineRequest = optional_json_body(&headers, &body)?;
    let query = query.with_body(&request);
    let registry_auth: Option<crate::registry::RegistryAuth> =
        request.registry_auth.map(Into::into);
    let mediated_egress = request
        .egress_interceptor
        .as_ref()
        .is_some_and(|spec| spec.mediated);
    let external_interceptor = request
        .egress_interceptor
        .map(|spec| {
            spec.endpoint()
                .map_err(|error| ApiError::BadRequest(error.into()))
        })
        .transpose()?;
    // Hold the per-machine lifecycle lock across the whole start so a concurrent
    // stop/delete cannot detach the macOS layers volume between our acquire+mount
    // and the launch, nor launch a guest into the launcher's missing-dir error
    // (review finding #3). Acquired before the DB read and resolve_state probe
    // below so the "is it running?" decision and the launch happen under one held
    // lock; it is the outermost lock (the entry mutex is taken later, inside the
    // spawn_blocking). Linux: the guarded detach/mount are no-ops.
    let lifecycle = state.lifecycle_lock(&name);
    let _guard = lifecycle.lock().await;
    // Cross-process serialization with CLI/API fork preparation. Lifecycle
    // locks cover this server instance; the flock also prevents a direct CLI
    // fork from racing a restart and binding to a superseded VMM identity.
    let _source_lock = acquire_fork_source_lock(name.clone()).await?;

    // Get VM record from database (off the reactor)
    let mut record = state
        .lookup_vm(&name)
        .await?
        .ok_or_else(|| ApiError::NotFound(format!("machine '{}' not found", name)))?;

    if record.paused_checkpoint.is_some() {
        return Err(ApiError::Conflict(
            "machine has saved execution; use resume".into(),
        ));
    }
    // A machine created with nesting stays down once the server turns it off.
    state.ensure_nested_virt_allowed(record.nested_virt.unwrap_or(false))?;

    if let Some(endpoint) = external_interceptor.as_ref() {
        crate::agent::validate_external_interceptor(
            endpoint,
            &record.vm_resources(),
            record.credential_policy.is_some(),
            false,
        )
        .map_err(|error| ApiError::BadRequest(error.to_string()))?;
    }

    // Resolve via the shared probe (PID + vsock ping) so we don't
    // mistake a zombie VMM (live PID, dead agent) for Running — the
    // CLI's `start --name` handles this same case; the API must
    // match or a REST caller ends up with "start succeeded" followed
    // by every subsequent /exec failing.
    //
    // `resolve_state` does a short vsock ping, so run it on the
    // blocking pool rather than in the async task.
    let name_probe = name.clone();
    let record_probe = record.clone();
    let resolved = tokio::task::spawn_blocking(move || {
        crate::agent::state_probe::resolve_state(&name_probe, &record_probe)
    })
    .await
    .map_err(|e| ApiError::internal(format!("task error: {}", e)))?;

    if resolved == RecordState::Running {
        if external_interceptor.is_some() {
            return Err(ApiError::Conflict(
                "stop the running machine before binding an external interceptor".into(),
            ));
        }
        if !state.machine_exists(&name) {
            // Running in DB but not in registry (startup recovery case).
            let name_for_repair = name.clone();
            let storage_gb = record.storage_gb;
            let overlay_gb = record.overlay_gb;
            let manager = tokio::task::spawn_blocking(move || {
                AgentManager::for_vm_with_sizes(&name_for_repair, storage_gb, overlay_gb)
            })
            .await
            .map_err(|e| ApiError::internal(format!("task error: {}", e)))?
            .map_err(|e| {
                ApiError::internal(format!(
                    "machine '{}' is running but registry repair failed: {}",
                    name, e
                ))
            })?;

            state.insert_machine(&name, machine_entry_from_record(&record, manager));
        }
        return Ok(Json(record_to_info(&name, &record)));
    }

    if resolved == RecordState::Frozen {
        let db = state.db().clone();
        let golden = name.clone();
        let clones = tokio::task::spawn_blocking(move || {
            crate::agent::fork::restart_blocking_dependent_clones(&db, &golden)
        })
        .await
        .map_err(|e| ApiError::internal(format!("task error: {e}")))?
        .map_err(ApiError::database)?;
        let reason = if clones.is_empty() {
            "it retains a reusable fork checkpoint; stop it before restarting, or fork it again"
                .to_string()
        } else {
            format!(
                "it is the fork base for {} dependent clone(s) ({}); delete the clones first",
                clones.len(),
                clones.join(", ")
            )
        };
        return Err(ApiError::Conflict(format!(
            "machine '{name}' is frozen because {reason}"
        )));
    }

    if record.external_interceptor_required && external_interceptor.is_none() {
        return Err(ApiError::BadRequest(
            "this machine requires egressInterceptor.address and egressInterceptor.token on every start".into(),
        ));
    }

    let mut recovered_unreachable = false;
    if resolved == RecordState::Unreachable {
        // Zombie: verified-kill the VMM and clear the DB record
        // before falling through to a clean fresh start. Any stale
        // in-memory registry entry gets overwritten by the
        // `insert_machine` call later in this handler. If the zombie
        // cannot be confirmed dead, refuse the start instead of
        // booting on top of it.
        let name_recover = name.clone();
        recovered_unreachable = tokio::task::spawn_blocking(move || {
            crate::agent::state_probe::recover_if_unreachable(&name_recover)
        })
        .await
        .map_err(|e| ApiError::internal(format!("task error: {}", e)))?
        .map_err(|e| {
            ApiError::internal(format!(
                "machine '{name}' is unreachable and zombie cleanup failed: {e}"
            ))
        })?;
        if !recovered_unreachable {
            // Reachability changed between the two probes. Do not release the
            // cached manager's flock based on an observation that is no longer
            // true, and do not risk launching a second VMM over a recovered one.
            return Err(ApiError::Conflict(format!(
                "machine '{name}' changed state while unreachable recovery was in progress; retry start"
            )));
        }
    }

    // A successful unreachable recovery, a Running record resolved Stopped by
    // PID+agent probing, or a durable Stopped record written by an out-of-process
    // CLI stop all prove that no VMM should still own this machine. Reconcile the
    // serve process's cached manager before constructing a fresh manager below.
    // Without this, the cached manager retains vm.lock and every restart wedges
    // until the API server itself is restarted (issue #1124).
    if recovered_unreachable
        || (record.state == RecordState::Running && resolved == RecordState::Stopped)
        || record.state == RecordState::Stopped
    {
        record = reconcile_confirmed_stopped_machine(&state, &name, false).await?;
    }

    if let Some(pool_size) = query.fork_pool_size {
        if pool_size == 0 {
            return Err(ApiError::BadRequest(
                "forkPoolSize must be greater than zero".to_string(),
            ));
        }
        if !record.cuda {
            return Err(ApiError::BadRequest(
                "forkPoolSize requires a CUDA-enabled machine".to_string(),
            ));
        }
        record.cuda_fork_pool_size = Some(pool_size);
        state
            .update_vm(&name, move |r| r.cuda_fork_pool_size = Some(pool_size))
            .await?
            .ok_or_else(|| ApiError::NotFound(format!("machine '{}' not found", name)))?;
    }
    if let Some(limit_mib) = query.cuda_vram_limit_mib {
        if limit_mib == 0 {
            return Err(ApiError::BadRequest(
                "cudaVramLimitMib must be greater than zero".to_string(),
            ));
        }
        if query.fork_pool_size.is_none() {
            return Err(ApiError::BadRequest(
                "cudaVramLimitMib requires forkPoolSize".to_string(),
            ));
        }
        record.cuda_vram_limit_mib = Some(limit_mib);
        state
            .update_vm(&name, move |r| r.cuda_vram_limit_mib = Some(limit_mib))
            .await?
            .ok_or_else(|| ApiError::NotFound(format!("machine '{}' not found", name)))?;
    }

    // Like forkPoolSize above, an explicit forkable start is a durable launch
    // property rather than a one-process hint. Persist it before registering
    // the in-memory entry so the response is truthful and an API-service
    // restart preserves the machine's ability to fork.
    if query.forkable && !record.forkable {
        record.forkable = true;
        state
            .update_vm(&name, |r| r.forkable = true)
            .await?
            .ok_or_else(|| ApiError::NotFound(format!("machine '{}' not found", name)))?;
    }

    // A machine with no network cannot pull its registry image in-guest; the
    // host fetches it instead, authorized with the credentials this start
    // carries, as the guest's pull would be. A restore resumes a guest that
    // already has its image.
    if record.image_needs_host_fetch()
        && crate::portable_checkpoint::pending_dir(&vm_data_dir(&name)).is_none()
    {
        let auth = match &registry_auth {
            Some(auth) => crate::registry::PullAuth::Basic {
                username: auth.username.clone(),
                password: auth.password.clone(),
            },
            None => crate::registry::PullAuth::FromConfig,
        };
        let image = record.image.clone().unwrap_or_default();
        let fetched = crate::image_store::fetch_image_archive(&image, &auth).await?;
        record.pin_host_fetched_image(fetched.local.clone(), fetched.digest.clone());
        state
            .update_vm(&name, move |r| {
                r.pin_host_fetched_image(fetched.local, fetched.digest)
            })
            .await?
            .ok_or_else(|| ApiError::NotFound(format!("machine '{}' not found", name)))?;
    }

    let mounts = record.host_mounts();
    let ports = record.port_mappings();
    let resources = record.vm_resources();
    // Snapshot restore inherits the already-running workload. Remember this
    // before finalization consumes the one-shot payload so the API does not
    // launch a duplicate container afterwards.
    let restoring_checkpoint =
        crate::portable_checkpoint::pending_dir(&vm_data_dir(&name)).is_some();

    // Start agent VM in blocking task.
    // Uses subprocess launch to avoid macOS fork-in-multithreaded-process issue.
    let name_clone = name.clone();
    let storage_gb = record.storage_gb;
    let overlay_gb = record.overlay_gb;
    let source_smolmachine = record.packed_layer_source().map(str::to_owned);
    let image_on_storage = record.packed_image_on_storage;
    let launch_image = record.image.clone();
    let dns_filter_hosts = record.dns_filter_hosts.clone();
    let credential_launch = crate::credentials::CredentialLaunch::for_record(&name, &record);
    let record_golden = record.golden.clone();
    let record_fork_overlay_owner = record.vm_uid_owner().map(str::to_string);
    let cuda_fork_pool_size = record.cuda_fork_pool_size;
    let cuda_vram_limit_mib = record.cuda_vram_limit_mib;
    let restore_record = record.clone();
    let forkable = query.forkable || query.fork_pool_size.is_some() || record.forkable_on_start();
    // A fresh registry-image machine starts on a shared seed of its image (see
    // `image_seed`), authorized with the caller's registry credentials.
    let seed_image = crate::image_seed::wants_seed(&name, &record, restoring_checkpoint);
    let preseeded_image = (!record.init_completed
        && !restoring_checkpoint
        && record.source_smolmachine.is_none()
        && record.vm_uid_owner().is_none()
        && record.golden.is_none())
    .then(|| record.image.clone())
    .flatten();
    let start_has_credentials = registry_auth.is_some();
    let seed_auth = match &registry_auth {
        Some(auth) => crate::registry::PullAuth::Basic {
            username: auth.username.clone(),
            password: auth.password.clone(),
        },
        None => crate::registry::PullAuth::FromConfig,
    };
    let (manager, pid) = tokio::task::spawn_blocking(move || {
        let mut seed_image = seed_image;
        if let Some(image) = preseeded_image {
            match crate::image_seed::revalidate_seed(&name_clone, &image, &seed_auth) {
                Ok(true) => {}
                Ok(false) => {
                    seed_image = crate::image_seed::seedable_image(&name_clone, Some(&image), storage_gb);
                }
                Err(error) => {
                    // The rejected disk is gone, so the machine can take a seed
                    // of the image it boots now, such as its host-fetched archive.
                    tracing::warn!(machine = %name_clone, %error, "pre-created image seed rejected");
                    seed_image = crate::image_seed::seedable_image(&name_clone, Some(&image), storage_gb);
                }
            }
            // A fresh machine still has the blank disk its create made. When
            // this start is what makes its image seedable (an archive the host
            // fetched now, or a private image whose credentials only the start
            // carries), the disk holds nothing, so drop it and seed instead.
            if seed_image.is_none()
                && crate::image_seed::discard_unbooted_storage(
                    &name_clone,
                    &image,
                    start_has_credentials,
                )
            {
                seed_image = crate::image_seed::seedable_image(&name_clone, Some(&image), storage_gb);
            }
        }
        if let Some(image) = seed_image {
            let seeded = crate::image_seed::builder_exe()
                .map_err(|e| crate::Error::config("image seed", e.to_string()))
                .and_then(|exe| {
                    crate::image_seed::seed_storage(
                        &exe,
                        &name_clone,
                        &image,
                        &seed_auth,
                        storage_gb,
                        None,
                        None,
                        None,
                    )
                });
            if let Err(error) = seeded {
                tracing::warn!(machine = %name_clone, %error, "no image seed; pulling in the guest");
            }
        }
        let manager = AgentManager::for_vm_with_sizes(&name_clone, storage_gb, overlay_gb)
            .map_err(|e| format!("failed to create agent manager: {}", e))?;

        // Wire pre-extracted layers if this machine was created from a .smolmachine.
        let mut features = crate::api::state::build_launch_features(
            Some(&name_clone),
            source_smolmachine.as_deref(),
            image_on_storage,
            launch_image.as_deref(),
            dns_filter_hosts,
            credential_launch,
        )
        .map_err(|e| format!("failed to prepare packed layers: {}", e))?;
        // A fork clone shares its golden's uid. On a cold (re)start there is no
        // snapshot path to resolve it from, so pass the golden's data dir
        // explicitly — without it the clone claims a fresh uid that cannot
        // traverse the golden's 0700 dir to open its copy-on-write disk
        // backing, and the boot dies configuring virtio-blk.
        if let Some(owner) = record_fork_overlay_owner
            .as_deref()
            .or(record_golden.as_deref())
        {
            features.uid_share_dir = Some(crate::agent::vm_data_dir(owner));
        }
        // Forkable start: memfd-back guest RAM and expose a control socket at the
        // machine's known path so it can later be forked via the fork endpoint.
        if forkable {
            features.forkable = true;
        }
        features.cuda_fork_pool_size = cuda_fork_pool_size;
        features.cuda_vram_limit_mib = cuda_vram_limit_mib;
        features.external_interceptor = external_interceptor;
        features.mediated_egress = mediated_egress;
        let _ = manager
            .ensure_running_via_subprocess(mounts, ports, resources, features)
            .map_err(|e| format!("failed to start machine: {}", e))?;

        if restoring_checkpoint {
            if let Err(error) =
                crate::portable_checkpoint::finalize_live_restore(&name_clone, &restore_record)
                    .and_then(|()| crate::portable_checkpoint::consume(&vm_data_dir(&name_clone)))
            {
                let _ = manager.stop();
                return Err(format!("failed to finalize checkpoint restore: {error}"));
            }
        }

        let pid = manager.child_pid();
        Ok::<_, String>((manager, pid))
    })
    .await
    .map_err(|e| ApiError::internal(format!("task error: {}", e)))?
    .map_err(classify_launch_error)?;

    // Register in ApiState so exec/run/container endpoints can find it
    let mut entry = machine_entry_from_record(&record, manager);
    entry.external_interceptor = external_interceptor;
    state.insert_machine(&name, entry);

    // Image machines: launch the image's workload (its ENTRYPOINT+CMD) as a
    // detached container now that the VM is up — mirroring the CLI start path
    // (`vm_common.rs`). Without this, an image machine started via the API boots
    // only the bare agent VM and never runs its server, so a published port
    // forwards to a guest socket nothing is listening on (connection reset →
    // proxy 502). An empty command lets the agent resolve the image's own
    // ENTRYPOINT+CMD. This runs once per fresh start: the handler returns early
    // above when the machine is already Running, so the container is never
    // double-launched. Best-effort: a launch failure leaves a reachable VM
    // (Running, exec-able) rather than failing the start and stranding a retry
    // on the early-return path where the workload would never get launched.
    if let Some(image) = record.image.clone().filter(|_| !restoring_checkpoint) {
        let entry = state.get_machine(&name)?;
        let mut command = record.entrypoint.clone();
        command.extend(record.cmd.clone());
        let mut env = record.env.clone();
        env.extend(super::record_secret_refs_env(&entry)?);
        // Remote volumes mount inside the workload container; build the mount
        // script here and let the agent run it ahead of the image-resolved
        // command, so a service image's own entrypoint is preserved.
        let s3_volumes = crate::remote_volume::to_s3_volumes(&record.remote_volumes, &env);
        let workdir = record.workdir.clone();
        let user = record.user.clone();
        let mounts_config = {
            let e = entry.lock();
            e.mounts
                .iter()
                .enumerate()
                .map(|(i, m)| (HostMount::mount_tag(i), m.target.clone(), m.readonly))
                .collect::<Vec<_>>()
        };
        let overlay_id = crate::workload::persistent_overlay_owner_with_lineage(
            &name,
            record.golden.as_deref(),
            record.fork_overlay_owner.as_deref(),
        );
        // Pull the image FIRST, as a FATAL step. A pull failure — the image /
        // tag doesn't exist, is private without access, or the machine has no
        // network to reach the registry — is a permanent, user-fixable
        // condition. Failing the start here surfaces it to the control as a
        // clear 4xx and marks the machine `error`, instead of proceeding to
        // `Running` below and leaving a `started` ZOMBIE whose every exec then
        // fails (and, once billing is on, meters a machine that never worked).
        // A cached image (`query` returns Some) skips the pull, so this is a
        // no-op on the stop→restart path. Mirrors how the smolmachine source
        // fails a bad artifact at create.
        let image_pull = image.clone();
        // Caller-supplied credentials win over the node's own registry config:
        // that config is operator-level and shared by every tenant, so it can
        // never hold a customer's private-registry password. `PullOptions::auth`
        // is consulted before the config inside `pull`, so passing it here is
        // enough — and passing `None` leaves the previous behaviour untouched.
        let pull_auth = registry_auth.clone();
        let pull = with_machine_client_traced(&entry, None, move |c| {
            if c.query(&image_pull)?.is_none() {
                let mut opts = crate::agent::PullOptions::new().use_registry_config(true);
                if let Some(auth) = pull_auth {
                    opts = opts.auth(auth);
                }
                c.pull(&image_pull, opts)?;
            }
            Ok(())
        })
        .await;
        if let Err(e) = pull {
            // The agent VM booted above, but the image can't be pulled (bad or
            // private ref, or no route to the registry). The Running state + pid
            // are only persisted AFTER this block, so returning now would strand
            // the booted VM as an untracked orphan — its pid never reaches the
            // record, and a later delete then reports "process still alive after
            // shutdown; not removing" while the VM leaks. Tear the VM down so the
            // machine is stopped with no live process and is cleanly retryable
            // (e.g. once a transient registry outage
            // clears) and deletable — then surface the pull failure.
            let st = pid.and_then(process_start_time);
            let name_rb = name.clone();
            let stopped = tokio::task::spawn_blocking(move || {
                shutdown_machine_process(&name_rb, pid, st, false)
            })
            .await
            .unwrap_or(false);
            if stopped {
                reconcile_confirmed_stopped_machine(&state, &name, false).await?;
            } else {
                tracing::warn!(machine = %name, "image pull failed and VM teardown is incomplete; retaining the launch lock");
            }
            return Err(e);
        }
        // Launch the workload container. Best-effort past the pull: a transient
        // crun/overlay hiccup leaves a reachable (exec-able) VM rather than
        // failing an otherwise-pullable start — the image is already local, so a
        // retry or the health loop can bring the workload up.
        let stop_on_exit = record.stop_on_exit;
        let (stop_signal, stop_timeout) = (record.stop_signal.clone(), record.stop_timeout_secs);
        let launch = with_machine_client_traced(&entry, None, move |c| {
            let config = crate::agent::RunConfig::new(image, command)
                .with_env(env)
                .with_workdir(workdir)
                .with_user(user)
                .with_mounts(mounts_config)
                .with_persistent_overlay(Some(overlay_id))
                .with_s3_volumes(s3_volumes)
                .with_stop_vm_on_exit(stop_on_exit)
                .with_stop(stop_signal, stop_timeout);
            c.run_container_detached(config).map(|_| ())
        })
        .await;
        if let Err(e) = launch {
            tracing::warn!(
                machine = %name,
                error = ?e,
                "failed to launch image workload after start; VM is up but its server is not running"
            );
        }
    }

    // Capture start time for PID verification
    let pid_start_time = pid.and_then(process_start_time);
    // Past the fatal pull above, the machine's storage holds its image.
    let image_on_storage = record.image.is_some() && !restoring_checkpoint;

    // Persist state to database (off the reactor)
    let record = state
        .update_vm(&name, move |r| {
            r.state = RecordState::Running;
            r.pid = pid;
            r.pid_start_time = pid_start_time;
            r.engine_build = Some(crate::ENGINE_BUILD.to_string());
            if image_on_storage {
                r.mark_image_on_storage();
            }
            // An explicit start re-enables supervision: clear the user-stopped
            // flag and reset the retry budget so a machine that previously
            // exhausted max_retries can be restarted and supervised again.
            r.restart.user_stopped = false;
            r.restart.restart_count = 0;
        })
        .await?
        .ok_or_else(|| {
            ApiError::NotFound(format!(
                "machine '{}' disappeared from database during start",
                name
            ))
        })?;

    // Build response directly with state=running. We just confirmed the VM
    // is running (wait_for_ready passed), so we bypass actual_state() which
    // may falsely report "stopped" on macOS due to setsid/session-leader
    // PID visibility issues.
    let mut info = record_to_info(&name, &record);
    info.state = "running".to_string();
    info.pid = pid;
    Ok(Json(info))
}

/// Classify a fork-preparation failure into the right HTTP status. The golden
/// missing is a 404; the golden not being forkable / not yet ready, or the clone
/// name already being taken, is a 409; an unsupported descendant shape is a
/// 400; anything else is a 500.
fn classify_fork_error(e: SmolvmError) -> ApiError {
    // A refusal that says what it is keeps its status, whatever its wording.
    if let SmolvmError::Agent {
        kind: crate::error::AgentErrorKind::Conflict,
        ..
    } = &e
    {
        return ApiError::Conflict(e.to_string());
    }
    let msg = e.to_string();
    let lc = msg.to_ascii_lowercase();
    if lc.contains("branch needs at least") && lc.contains("effective host headroom") {
        ApiError::Unavailable(msg)
    } else if lc.contains("no reply to fork") {
        // The source's checkpoint outlasted the wait: a busy host, not a
        // broken source, which a retry gets past.
        ApiError::Unavailable(format!("{msg}; the host is busy, retry the branch"))
    } else if lc.contains("cuda fork descendants") || lc.contains("fork lineage would exceed") {
        ApiError::BadRequest(msg)
    } else if lc.contains("already exists")
        || lc.contains("not running forkable")
        || lc.contains("no memfd-backed ram")
        || lc.contains("not started as branchable")
        || lc.contains("control socket not responding")
        || lc.contains("not ready to fork")
    {
        // Clone name taken, or the golden isn't a ready fork base (never started
        // forkable, so it has no memfd-backed RAM to CoW-fork) — both 409, a
        // caller-fixable precondition, not a server fault a client should retry.
        ApiError::Conflict(msg)
    } else if lc.contains("not found") {
        ApiError::NotFound(msg)
    } else {
        ApiError::Internal(msg)
    }
}

async fn acquire_fork_source_lock(
    source: String,
) -> Result<crate::agent::fork::ForkSourceLock, ApiError> {
    tokio::task::spawn_blocking(move || crate::agent::fork::lock_fork_source(&source))
        .await
        .map_err(|error| ApiError::internal(format!("fork lock task failed: {error}")))?
        .map_err(classify_fork_error)
}

/// Fork a running, forkable golden machine into a new clone (copy-on-write
/// memory + disks).
#[utoipa::path(
    post,
    path = "/api/v1/machines/{name}/fork",
    tag = "Machines",
    params(
        ("name" = String, Path, description = "Golden (source) machine name")
    ),
    request_body = ForkRequest,
    responses(
        (status = 200, description = "Clone forked and running", body = MachineInfo),
        (status = 400, description = "Invalid or unsupported fork request", body = ApiErrorResponse),
        (status = 404, description = "Golden machine not found", body = ApiErrorResponse),
        (status = 409, description = "Golden not forkable, or clone name already exists", body = ApiErrorResponse),
        (status = 500, description = "Fork failed", body = ApiErrorResponse)
    )
)]
pub async fn fork_machine(
    State(state): State<Arc<ApiState>>,
    Path(golden): Path<String>,
    Json(req): Json<ForkRequest>,
) -> Result<Json<MachineInfo>, ApiError> {
    fork_machine_inner(state, golden, req).await.map(Json)
}

/// Branch a running, branchable source machine into a new independent child.
#[utoipa::path(
    post,
    path = "/api/v1/machines/{name}/branches",
    tag = "Machines",
    params(
        ("name" = String, Path, description = "Branch source machine name")
    ),
    request_body = ForkRequest,
    responses(
        (status = 200, description = "Child branched and running", body = MachineInfo),
        (status = 400, description = "Invalid or unsupported branch request", body = ApiErrorResponse),
        (status = 404, description = "Source machine not found", body = ApiErrorResponse),
        (status = 409, description = "Source is not branchable, or child name already exists", body = ApiErrorResponse),
        (status = 500, description = "Branch failed", body = ApiErrorResponse)
    )
)]
pub async fn branch_machine(
    State(state): State<Arc<ApiState>>,
    Path(source): Path<String>,
    Json(req): Json<ForkRequest>,
) -> Result<Json<MachineInfo>, ApiError> {
    fork_machine_inner(state, source, req).await.map(Json)
}

/// Internal fork entry point shared by the HTTP handler and pool reconciler.
pub(crate) async fn fork_machine_inner(
    state: Arc<ApiState>,
    golden: String,
    req: ForkRequest,
) -> Result<MachineInfo, ApiError> {
    // A branch of a nested machine is nested too (its saved guest expects VMX),
    // so it needs the same opt-in as creating one.
    if let Some(source) = state.lookup_vm(&golden).await? {
        state.ensure_nested_virt_allowed(source.nested_virt.unwrap_or(false))?;
    }
    if coalescable_branch(&req) {
        return with_owned_operation(move |reply| async move {
            state.queue_branch(&golden, crate::api::state::QueuedBranch { req, reply });
            serve_queued_branches(state, golden).await;
        })
        .await;
    }
    // A disconnected request must not drop lifecycle guards while its blocking
    // preparation still creates disks and registers the child. Once preparation
    // starts, finish boot or rollback before releasing those guards.
    with_owned_operation(move |reply| async move {
        let outcome = fork_machine_transaction(state, golden, req, &reply).await;
        let _ = reply.send(outcome);
    })
    .await
}

/// Upper bound on the children of one branch batch that boot at once.
const MAX_CONCURRENT_BRANCH_BOOTS: usize = 8;

/// Whether a branch request can share its source's transaction with other
/// requests queued for it. Every queued request was sent before the batch takes
/// its checkpoint, so one checkpoint taken then is a state of the source each
/// of them could have branched alone; for a running source this replaces one
/// checkpoint per child with one per batch. Pinned ports go with their child,
/// and a host port asked for twice fails only the later request. Held pool
/// slots keep the one-at-a-time path.
fn coalescable_branch(req: &ForkRequest) -> bool {
    !req.hold
}

/// Take the source as a single branch does, then serve every compatible
/// request queued for it, including those queued while it was busy (#1453).
/// The source stays locked through preparation, boot and any rollback, as for
/// a single branch; its children just boot together instead of one at a time.
/// When another holder already served this request, nothing is left to do.
async fn serve_queued_branches(state: Arc<ApiState>, golden: String) {
    let golden_lifecycle = state.lifecycle_lock(&golden);
    let _golden_guard = golden_lifecycle.lock().await;
    let source_lock = acquire_fork_source_lock(golden.clone()).await;
    loop {
        let batch = state.take_branch_batch(&golden);
        if batch.is_empty() {
            return;
        }
        match &source_lock {
            Ok(_) => branch_batch_transaction(&state, &golden, batch).await,
            Err(error) => {
                for queued in batch {
                    let _ = queued.reply.send(Err(error.clone()));
                }
            }
        }
    }
}

/// Branch every request in `batch` from `golden`, whose locks the caller
/// holds. Each request is checked on its own first, so an invalid one fails
/// alone; the rest are prepared from one checkpoint and booted concurrently,
/// and each request gets its own child's result.
async fn branch_batch_transaction(
    state: &Arc<ApiState>,
    golden: &str,
    batch: Vec<crate::api::state::QueuedBranch>,
) {
    let mut accepted = Vec::with_capacity(batch.len());
    let mut names = std::collections::HashSet::new();
    let mut host_ports = std::collections::HashSet::new();
    for queued in batch {
        match check_queued_branch(state, golden, &queued.req, &mut names, &mut host_ports).await {
            Ok(fork_env) => accepted.push((queued, fork_env)),
            Err(error) => {
                let _ = queued.reply.send(Err(error));
            }
        }
    }
    let Some((first, _)) = accepted.first() else {
        return;
    };
    // The batch shares one forkpoint wait and source policy
    // (`take_branch_batch` groups by both).
    let wait_ready = first.req.wait_ready;
    let source_policy = if first.req.freeze_source {
        crate::agent::fork::ForkSourcePolicy::Freeze
    } else {
        crate::agent::fork::ForkSourcePolicy::PlatformDefault
    };
    if wait_ready {
        let timeout = Duration::from_secs(first.req.ready_timeout_secs.unwrap_or(240));
        let golden_b = golden.to_string();
        let waited = tokio::task::spawn_blocking(move || {
            crate::agent::fork::wait_for_forkpoint(&golden_b, timeout)
        })
        .await
        .map_err(|e| ApiError::internal(format!("task error: {e}")))
        .and_then(|result| result.map_err(classify_fork_error));
        if let Err(error) = waited {
            for (queued, _) in accepted {
                let _ = queued.reply.send(Err(error.clone()));
            }
            return;
        }
    }

    // Lock every child's lifecycle, in name order, as a single branch does.
    let mut lock_names: Vec<String> = accepted.iter().map(|(q, _)| q.req.name.clone()).collect();
    lock_names.sort();
    let mut guards = Vec::with_capacity(lock_names.len());
    for name in &lock_names {
        guards.push(state.lifecycle_lock(name).lock_owned().await);
    }
    // A request cancelled while queued has nothing prepared yet.
    accepted.retain(|(queued, _)| !queued.reply.is_closed());
    if accepted.is_empty() {
        return;
    }

    // Admission sizes host headroom for every child of a batch at once, so a
    // batch can be refused where its requests, branched one at a time, would
    // each have been admitted. Give each such request its own attempt, as the
    // one-at-a-time path did; any other preparation failure answers the batch.
    if let Err((refused, error)) =
        prepare_and_boot_branches(state, golden, accepted, wait_ready, source_policy).await
    {
        if refused.len() > 1 && matches!(error, ApiError::Unavailable(_)) {
            tracing::info!(
                golden,
                children = refused.len(),
                "branch batch exceeds host headroom; branching its requests one at a time"
            );
            for one in refused {
                if let Err((refused, error)) =
                    prepare_and_boot_branches(state, golden, vec![one], wait_ready, source_policy)
                        .await
                {
                    for (queued, _) in refused {
                        let _ = queued.reply.send(Err(error.clone()));
                    }
                }
            }
        } else {
            for (queued, _) in refused {
                let _ = queued.reply.send(Err(error.clone()));
            }
        }
    }
    drop(guards);
}

/// A branch request that passed its own checks, with its parsed environment.
type AcceptedBranch = (crate::api::state::QueuedBranch, Vec<(String, String)>);

/// Prepare `accepted` from one checkpoint of `golden` and boot the children
/// concurrently, answering each request with its own child's result. When
/// preparation fails nothing was created, and the requests come back unanswered
/// with the error.
async fn prepare_and_boot_branches(
    state: &Arc<ApiState>,
    golden: &str,
    accepted: Vec<AcceptedBranch>,
    wait_ready: bool,
    source_policy: crate::agent::fork::ForkSourcePolicy,
) -> Result<(), (Vec<AcceptedBranch>, ApiError)> {
    let prepared = {
        let db = state.db().clone();
        let golden_b = golden.to_string();
        let children: Vec<_> = accepted
            .iter()
            .map(|(queued, fork_env)| {
                (
                    queued.req.name.clone(),
                    queued
                        .req
                        .ports
                        .iter()
                        .map(|p| (p.host, p.guest))
                        .collect::<Vec<(u16, u16)>>(),
                    queued.req.forkable,
                    fork_env.clone(),
                    queued.req.secrets.clone(),
                    queued
                        .req
                        .labels
                        .iter()
                        .map(|(k, v)| (k.clone(), v.clone()))
                        .collect::<Vec<(String, String)>>(),
                )
            })
            .collect();
        tokio::task::spawn_blocking(move || {
            let specs: Vec<_> = children
                .iter()
                .map(|(clone, ports, forkable, fork_env, secrets, labels)| {
                    crate::agent::fork::ForkSpec {
                        clone,
                        pinned_ports: ports,
                        clone_forkable: *forkable,
                        fork_env,
                        fork_secrets: secrets,
                        hold: false,
                        labels,
                    }
                })
                .collect();
            crate::agent::fork::prepare_forks(&db, &golden_b, &specs, source_policy)
        })
        .await
        .map_err(|e| ApiError::internal(format!("task error: {e}")))
        .and_then(|result| result.map_err(classify_fork_error))
    };
    let forks = match prepared {
        Ok(forks) => forks,
        Err(error) => return Err((accepted, error)),
    };

    let boots = forks
        .into_iter()
        .zip(accepted)
        .map(|(prep, (queued, fork_env))| {
            let state = state.clone();
            async move {
                let result = boot_prepared_fork_inner(
                    state,
                    queued.req.name.clone(),
                    prep,
                    PreparedForkBoot {
                        share_weights: queued.req.share_weights,
                        keep_machine_id: queued.req.keep_machine_id,
                        fork_env,
                        wait_ready,
                        hold: false,
                        cuda_worker_ready_timeout: None,
                        boot_permit: None,
                    },
                )
                .await;
                let succeeded = result.is_ok();
                let _ = queued.reply.send(result);
                succeeded
            }
        });
    run_bounded_futures(boots, MAX_CONCURRENT_BRANCH_BOOTS, |succeeded| succeeded).await;
    Ok(())
}

/// A branch request's pinned ports as `(host, guest)`. Pins name TCP ports: a
/// branch gets fresh host ports for its source's UDP forwards on its own.
fn branch_pins(ports: &[PortSpec]) -> Result<Vec<(u16, u16)>, ApiError> {
    if let Some(udp) = ports.iter().find(|p| !p.protocol.is_tcp()) {
        return Err(ApiError::BadRequest(format!(
            "{}:{}/udp cannot be pinned: a branch pins TCP ports, and gets fresh host ports for UDP forwards automatically",
            udp.host, udp.guest
        )));
    }
    Ok(ports.iter().map(|p| (p.host, p.guest)).collect())
}

/// The checks a single branch makes before preparing its child. Returns the
/// child's parsed environment. `names` collects the batch's child names.
/// Validate a branch's pinned ports as the create path does: a branch uses
/// these host ports as-is, so port 0 or a duplicated host port would otherwise
/// surface only as a confusing child-boot bind failure instead of a clean 400.
fn validate_pinned_ports(pinned_ports: &[(u16, u16)]) -> Result<(), ApiError> {
    let mut seen = std::collections::HashSet::new();
    for (host, guest) in pinned_ports {
        if *host == 0 || *guest == 0 {
            return Err(ApiError::BadRequest(
                "port 0 is not valid for VM port forwarding".to_string(),
            ));
        }
        if !seen.insert(*host) {
            return Err(ApiError::BadRequest(format!(
                "duplicate host port {host}: each host port can only be mapped once"
            )));
        }
    }
    Ok(())
}

async fn check_queued_branch(
    state: &ApiState,
    golden: &str,
    req: &ForkRequest,
    names: &mut std::collections::HashSet<String>,
    host_ports: &mut std::collections::HashSet<u16>,
) -> Result<Vec<(String, String)>, ApiError> {
    let pinned_ports = branch_pins(&req.ports)?;
    validate_pinned_ports(&pinned_ports)?;
    if let Some((host, _)) = pinned_ports
        .iter()
        .find(|(host, _)| host_ports.contains(host))
    {
        return Err(ApiError::Conflict(format!(
            "host port {host} is already pinned by another branch of '{golden}'"
        )));
    }
    crate::api::handlers::validate_fork_secrets(&req.secrets)?;
    let fork_env = crate::util::parse_request_env_list(&req.env).map_err(ApiError::BadRequest)?;
    crate::agent::fork::validate_fork_env(&fork_env)
        .map_err(|e| ApiError::BadRequest(e.to_string()))?;
    if req.name == golden {
        return Err(ApiError::Conflict(format!(
            "clone name '{}' is already used by the golden",
            req.name
        )));
    }
    if !names.insert(req.name.clone()) || state.lookup_vm(&req.name).await?.is_some() {
        return Err(ApiError::Conflict(format!(
            "machine '{}' already exists",
            req.name
        )));
    }
    host_ports.extend(pinned_ports.iter().map(|(host, _)| *host));
    Ok(fork_env)
}

async fn with_owned_operation<T, F, Fut>(work: F) -> Result<T, ApiError>
where
    T: Send + 'static,
    F: FnOnce(tokio::sync::oneshot::Sender<Result<T, ApiError>>) -> Fut + Send + 'static,
    Fut: std::future::Future<Output = ()> + Send + 'static,
{
    let (reply, result) = tokio::sync::oneshot::channel();
    tokio::spawn(work(reply));
    result
        .await
        .map_err(|error| ApiError::internal(format!("machine lifecycle task failed: {error}")))?
}

async fn fork_machine_transaction(
    state: Arc<ApiState>,
    golden: String,
    req: ForkRequest,
    reply: &tokio::sync::oneshot::Sender<Result<MachineInfo, ApiError>>,
) -> Result<MachineInfo, ApiError> {
    let clone = req.name.clone();
    let pinned_ports = branch_pins(&req.ports)?;
    let req_share_weights = req.share_weights;
    let req_keep_machine_id = req.keep_machine_id;
    let req_forkable = req.forkable;
    let req_hold = req.hold;
    let source_policy = if req.freeze_source {
        crate::agent::fork::ForkSourcePolicy::Freeze
    } else {
        crate::agent::fork::ForkSourcePolicy::PlatformDefault
    };
    let wait_ready = req.wait_ready || req_hold;
    let ready_timeout = std::time::Duration::from_secs(req.ready_timeout_secs.unwrap_or(240));
    let fork_env = crate::util::parse_request_env_list(&req.env).map_err(ApiError::BadRequest)?;
    // Per-fork secrets become the clone's persisted secret_refs (resolved fresh
    // on each exec, never at rest) — validate them at TrustedLocal like the
    // Smolfile-declared refs they join.
    crate::api::handlers::validate_fork_secrets(&req.secrets)?;
    let fork_secrets = req.secrets.clone();
    crate::agent::fork::validate_fork_env(&fork_env)
        .map_err(|e| ApiError::BadRequest(e.to_string()))?;
    if req_hold && req_forkable {
        return Err(ApiError::BadRequest(
            "hold and forkable cannot be combined; held pool slots are disposable leaves"
                .to_string(),
        ));
    }

    if clone == golden {
        return Err(ApiError::Conflict(format!(
            "clone name '{clone}' is already used by the golden"
        )));
    }

    validate_pinned_ports(&pinned_ports)?;

    // A failed clone finalization may need to roll back the golden and discard
    // the retained checkpoint that produced it. Keep that state transition in
    // one owner-level critical section so another fork/start/stop/delete cannot
    // observe the golden between failed-clone teardown and rollback.
    let golden_lifecycle = state.lifecycle_lock(&golden);
    let _golden_guard = golden_lifecycle.lock().await;
    let _source_lock = acquire_fork_source_lock(golden.clone()).await?;

    if state
        .lookup_vm(&golden)
        .await?
        .is_some_and(|record| record.external_interceptor_required)
        && state
            .get_machine(&golden)
            .ok()
            .and_then(|entry| entry.lock().external_interceptor)
            .is_none()
    {
        return Err(ApiError::BadRequest(
            "branch source interceptor binding is unavailable; rebind it before branching".into(),
        ));
    }

    // Reject an already-registered target before taking its lifecycle lock.
    // Besides avoiding a pointless forkpoint wait, this prevents two invalid
    // cross-forks (X -> Y and Y -> X) from each holding one golden while waiting
    // forever on the other machine's clone lock.
    if state.lookup_vm(&clone).await?.is_some() {
        return Err(ApiError::Conflict(format!(
            "machine '{clone}' already exists"
        )));
    }

    if wait_ready {
        let golden_b = golden.clone();
        tokio::task::spawn_blocking(move || {
            crate::agent::fork::wait_for_forkpoint(&golden_b, ready_timeout)
        })
        .await
        .map_err(|e| ApiError::internal(format!("task error: {e}")))?
        .map_err(classify_fork_error)?;
    }

    // Serialize lifecycle on the CLONE name so a concurrent start/stop/delete of
    // the same clone can't race the fork's register + boot. Golden is always
    // acquired before clone, matching the fork-pool lock order.
    let lifecycle = state.lifecycle_lock(&clone);
    let _guard = lifecycle.lock().await;

    // Cancellation while queued is still safe: no child has been prepared.
    // Check under the child lock so a concurrent delete either sees no child
    // or waits for the entire transaction, never for just its request future.
    if reply.is_closed() {
        return Err(ApiError::Conflict(
            "branch request cancelled before preparation".into(),
        ));
    }

    // Phase 1: freeze + snapshot the golden, register the clone with CoW disks.
    // This is unix-socket IO + disk work, so it runs on the blocking pool. Its
    // failures carry precondition semantics (404/409/400), mapped distinctly
    // from the boot failures below.
    let prep = {
        let db = state.db().clone();
        let golden_b = golden.clone();
        let clone_b = clone.clone();
        let ports = pinned_ports.clone();
        let env = fork_env.clone();
        let secrets = fork_secrets.clone();
        let labels: Vec<(String, String)> = req
            .labels
            .iter()
            .map(|(k, v)| (k.clone(), v.clone()))
            .collect();
        tokio::task::spawn_blocking(move || {
            if req_hold {
                crate::agent::fork::prepare_held_fork(
                    &db,
                    &golden_b,
                    &clone_b,
                    &ports,
                    &env,
                    &secrets,
                    &labels,
                    source_policy,
                )
            } else {
                crate::agent::fork::prepare_fork(
                    &db,
                    &golden_b,
                    &clone_b,
                    &ports,
                    req_forkable,
                    &env,
                    &secrets,
                    &labels,
                    source_policy,
                )
            }
        })
        .await
        .map_err(|e| ApiError::internal(format!("task error: {}", e)))?
        .map_err(classify_fork_error)?
    };

    boot_prepared_fork_inner(
        state.clone(),
        clone,
        prep,
        PreparedForkBoot {
            share_weights: req_share_weights,
            keep_machine_id: req_keep_machine_id,
            fork_env,
            wait_ready,
            hold: req_hold,
            cuda_worker_ready_timeout: None,
            boot_permit: None,
        },
    )
    .await
}

/// Prepare several clean held workers from one golden checkpoint and boot them
/// through a bounded queue. Preparation is all-or-nothing; once booting begins,
/// each result is reported as soon as it completes so successful workers can be
/// leased while the remainder of the batch is still restoring.
pub(crate) struct ForkBatchOutcome {
    pub retained_snapshot: Option<crate::agent::fork::RetainedForkSnapshot>,
}

pub(crate) struct ForkHeldBatch {
    pub golden: String,
    pub clones: Vec<String>,
    pub share_weights: bool,
    pub freeze_source: bool,
    pub ready_timeout: std::time::Duration,
    pub retained_snapshot: Option<crate::agent::fork::RetainedForkSnapshot>,
    pub boot_slots: Arc<tokio::sync::Semaphore>,
    pub snapshot_ready:
        Option<tokio::sync::oneshot::Sender<crate::agent::fork::RetainedForkSnapshot>>,
}

pub(crate) async fn fork_held_machines_inner(
    state: Arc<ApiState>,
    batch: ForkHeldBatch,
    result_tx: UnboundedSender<(String, Result<MachineInfo, ApiError>)>,
) -> Result<ForkBatchOutcome, ApiError> {
    if let Some(source) = state.lookup_vm(&batch.golden).await? {
        state.ensure_nested_virt_allowed(source.nested_virt.unwrap_or(false))?;
    }
    let ForkHeldBatch {
        golden,
        clones,
        share_weights,
        freeze_source,
        ready_timeout,
        retained_snapshot,
        boot_slots,
        mut snapshot_ready,
    } = batch;
    let source_policy = if freeze_source {
        crate::agent::fork::ForkSourcePolicy::Freeze
    } else {
        crate::agent::fork::ForkSourcePolicy::PlatformDefault
    };
    if clones.is_empty() {
        return Ok(ForkBatchOutcome { retained_snapshot });
    }

    let _source_lock = acquire_fork_source_lock(golden.clone()).await?;

    let golden_for_wait = golden.clone();
    tokio::task::spawn_blocking(move || {
        crate::agent::fork::wait_for_forkpoint(&golden_for_wait, ready_timeout)
    })
    .await
    .map_err(|e| ApiError::internal(format!("task error: {e}")))?
    .map_err(classify_fork_error)?;

    // Keep every clone lifecycle locked through registration and boot. Names are
    // sorted so this remains deadlock-free if another internal batch ever
    // overlaps it; pool-generated names are unique in normal operation.
    let mut lock_names = clones.clone();
    lock_names.sort();
    lock_names.dedup();
    let mut guards = Vec::with_capacity(lock_names.len());
    for clone in &lock_names {
        guards.push(state.lifecycle_lock(clone).lock_owned().await);
    }

    let prepared = {
        let db = state.db().clone();
        let golden_for_prep = golden.clone();
        let clones_for_prep = clones.clone();
        tokio::task::spawn_blocking(move || {
            let empty_secrets = std::collections::BTreeMap::new();
            let specs: Vec<_> = clones_for_prep
                .iter()
                .map(|clone| crate::agent::fork::ForkSpec {
                    clone,
                    pinned_ports: &[],
                    clone_forkable: false,
                    fork_env: &[],
                    fork_secrets: &empty_secrets,
                    hold: true,
                    labels: &[],
                })
                .collect();
            crate::agent::fork::prepare_forks_reusing(
                &db,
                &golden_for_prep,
                &specs,
                retained_snapshot.as_ref(),
                true,
                true,
                source_policy,
            )
        })
        .await
        .map_err(|e| ApiError::internal(format!("task error: {e}")))?
        .map_err(classify_fork_error)?
    };

    let reusable_snapshot = prepared.retained_snapshot.clone();
    let pending_boots = prepared.forks.len();
    let boots = prepared.forks.into_iter().zip(clones).map(|(prep, clone)| {
        let state = state.clone();
        let boot_slots = boot_slots.clone();
        async move {
            let result = match boot_slots.acquire_owned().await {
                Ok(boot_permit) => {
                    boot_prepared_fork_inner(
                        state,
                        clone.clone(),
                        prep,
                        PreparedForkBoot {
                            share_weights,
                            keep_machine_id: false,
                            fork_env: Vec::new(),
                            wait_ready: true,
                            hold: true,
                            cuda_worker_ready_timeout: Some(ready_timeout),
                            boot_permit: Some(boot_permit),
                        },
                    )
                    .await
                }
                Err(error) => Err(ApiError::internal(format!(
                    "fork boot scheduler closed: {error}"
                ))),
            };
            (clone, result)
        }
    });
    // Poll every boot future so an agent-ready clone can release its launch
    // permit and wait for CUDA reconstruction without blocking the next VM.
    // The semaphore, not this result stream, preserves the qualified launch
    // width; completed results are still reported as soon as each is usable.
    run_bounded_futures(boots, pending_boots, |result| {
        let succeeded = result.1.is_ok();
        if succeeded {
            if let (Some(sender), Some(snapshot)) =
                (snapshot_ready.take(), reusable_snapshot.clone())
            {
                let _ = sender.send(snapshot);
            }
        }
        if result_tx.send(result).is_err() {
            tracing::warn!("fork pool result receiver closed before provisioning completed");
        }
        succeeded
    })
    .await;

    drop(guards);
    Ok(ForkBatchOutcome {
        // A completed checkpoint remains the safe retry source even when every
        // clone boot fails. In-place golden rollback has proven capable of
        // resuming vCPUs while leaving virtio I/O wedged; keep the known-good
        // frozen snapshot instead.
        retained_snapshot: reusable_snapshot,
    })
}

async fn run_bounded_futures<F, T>(
    futures: impl IntoIterator<Item = F>,
    max_parallel: usize,
    mut on_complete: impl FnMut(T) -> bool,
) -> bool
where
    F: Future<Output = T>,
{
    let mut pending = futures_util::stream::iter(futures).buffer_unordered(max_parallel.max(1));
    let mut any_succeeded = false;
    while let Some(result) = pending.next().await {
        any_succeeded |= on_complete(result);
    }
    any_succeeded
}

struct PreparedForkBoot {
    share_weights: bool,
    /// Leave the source's machine-id in the clone (same-tenant cache affinity).
    keep_machine_id: bool,
    fork_env: Vec<(String, String)>,
    wait_ready: bool,
    hold: bool,
    cuda_worker_ready_timeout: Option<std::time::Duration>,
    boot_permit: Option<tokio::sync::OwnedSemaphorePermit>,
}

enum PreparedForkBootError {
    Launch(String),
    CloneIdentityRejuvenation(String),
}

impl From<String> for PreparedForkBootError {
    fn from(message: String) -> Self {
        Self::Launch(message)
    }
}

fn classify_prepared_fork_boot_error(error: PreparedForkBootError) -> ApiError {
    match error {
        PreparedForkBootError::Launch(message) => classify_launch_error(message),
        PreparedForkBootError::CloneIdentityRejuvenation(message) => {
            ApiError::CloneIdentityRejuvenationFailed(message)
        }
    }
}

async fn boot_prepared_fork_inner(
    state: Arc<ApiState>,
    clone: String,
    prep: crate::agent::fork::PreparedFork,
    boot: PreparedForkBoot,
) -> Result<MachineInfo, ApiError> {
    let inherited_interceptor = if prep.clone_record.external_interceptor_required {
        let source = prep.clone_record.golden.as_deref().ok_or_else(|| {
            ApiError::BadRequest("intercepted branch has no source machine".into())
        })?;
        let binding = state
            .get_machine(source)
            .ok()
            .and_then(|entry| entry.lock().external_interceptor);
        if binding.is_none() {
            // A reconciler can reach this path without the request preflight.
            // Dispose of its prepared child before returning a binding error.
            let _ = state.db().remove_vm(&clone);
            let _ = std::fs::remove_dir_all(vm_data_dir(&clone));
            return Err(ApiError::BadRequest(
                "branch source interceptor binding is unavailable; rebind it before branching"
                    .into(),
            ));
        }
        binding
    } else {
        None
    };
    let PreparedForkBoot {
        share_weights,
        keep_machine_id,
        fork_env,
        wait_ready,
        hold,
        cuda_worker_ready_timeout,
        mut boot_permit,
    } = boot;
    // Backstop for every fork path: a clone inherits its golden's nesting.
    state.ensure_nested_virt_allowed(prep.clone_record.nested_virt.unwrap_or(false))?;
    // Phase 2: boot the clone from the golden's in-memory snapshot (warm — its
    // processes are already running in the restored RAM, so unlike a cold start
    // there is no image workload to launch), then rejuvenate its identity.
    let clone_b = clone.clone();
    let db = state.db().clone();
    let (manager, pid, clone_record) = tokio::task::spawn_blocking(move || {
        let record = prep.clone_record;
        let mounts = record.host_mounts();
        let ports = record.port_mappings();
        let resources = record.vm_resources();

        let manager =
            AgentManager::for_vm_with_sizes(&clone_b, record.storage_gb, record.overlay_gb)
                .map_err(|e| format!("failed to create agent manager: {}", e))?;

        let mut features = crate::api::state::build_launch_features(
            Some(&clone_b),
            record.packed_layer_source(),
            record.packed_image_on_storage,
            record.image.as_deref(),
            record.dns_filter_hosts.clone(),
            crate::credentials::CredentialLaunch::for_record(&clone_b, &record),
        )
        .map_err(|e| format!("failed to prepare packed layers: {}", e))?;
        // Boot from the golden's snapshot instead of cold-booting.
        features.forkable = record.forkable;
        features.snapshot_dir = Some(prep.snapshot_dir);
        // A nested branch must keep the original lineage's UID, not allocate
        // a new UID from the immediate parent's snapshot directory.
        features.uid_share_dir = record.vm_uid_owner().map(crate::agent::vm_data_dir);
        features.cuda_share_weights = share_weights;
        features.cuda_preload_modules = record.cuda_preload_modules;
        features.cuda_fork_pool_size = record.cuda_fork_pool_size;
        features.cuda_vram_limit_mib = record.cuda_vram_limit_mib;
        features.external_interceptor = inherited_interceptor;
        features.mediated_egress = record.mediated_egress_required;

        if let Err(e) = manager.ensure_running_via_subprocess(mounts, ports, resources, features) {
            // Boot failed: roll back the clone registration so a failed fork
            // leaves nothing half-created.
            let _ = db.remove_vm(&clone_b);
            let _ = std::fs::remove_dir_all(vm_data_dir(&clone_b));
            return Err(format!("failed to boot clone: {}", e).into());
        }

        let pid = manager.child_pid();

        // Give the clone a fresh on-disk identity (hostname, machine-id, SSH
        // host keys, RNG) so it does not carry the golden's per-machine secrets
        // into a (possibly different) tenant. FAIL-CLOSED: if the reset can't be
        // confirmed, tear the booted clone down and fail the fork rather than
        // vend a clone that impersonates the golden.
        let teardown = || {
            manager.kill();
            manager.cleanup_data_dir();
            let _ = db.remove_vm(&clone_b);
        };
        crate::agent::fork::fail_closed_on_rejuvenation(
            crate::agent::fork::rejuvenate_clone_with(&clone_b, &record, keep_machine_id),
            teardown,
        )
        .map_err(|e| {
            PreparedForkBootError::CloneIdentityRejuvenation(format!(
                "clone identity rejuvenation failed: {e}"
            ))
        })?;
        // Per-fork parameters: same fail-closed contract — a clone that asked
        // for parameters but can't receive them must not be vended.
        crate::agent::fork::fail_closed_on_rejuvenation(
            crate::agent::fork::write_fork_env(&clone_b, &record, &fork_env),
            teardown,
        )
        .map_err(|e| format!("fork env delivery failed: {}", e))?;

        // Preserve the measured VM-launch bound, but do not make CUDA
        // reconstruction occupy that scarce slot. At this point the guest
        // agent and per-clone setup are complete, so another VM can safely
        // boot while this clone finishes rebuilding its isolated GPU state.
        drop(boot_permit.take());
        #[cfg(unix)]
        if record.cuda
            && cuda_worker_ready_timeout.is_some()
            && crate::cuda_daemon::clone_worker_readiness_supported()
            && std::env::var("SMOLVM_CUDA_WARM_DIAL").as_deref() != Ok("0")
        {
            let worker_ready = pid
                .and_then(|pid| process_start_time(pid).map(|started| (pid, started)))
                .ok_or_else(|| "clone process identity unavailable for CUDA readiness".to_string())
                .and_then(|(pid, started)| {
                    crate::cuda_daemon::wait_for_clone_worker_ready(
                        pid,
                        started,
                        cuda_worker_ready_timeout.expect("checked above"),
                    )
                    .map_err(|error| error.to_string())
                });
            if let Err(error) = worker_ready {
                teardown();
                return Err(format!("CUDA clone worker readiness failed: {error}").into());
            }
        }
        #[cfg(not(unix))]
        let _ = cuda_worker_ready_timeout;
        if wait_ready && !hold {
            crate::agent::fork::fail_closed_on_rejuvenation(
                crate::agent::fork::release_forkpoint(&clone_b, &fork_env),
                teardown,
            )
            .map_err(|e| format!("forkpoint release failed: {e}"))?;
        }

        Ok::<_, PreparedForkBootError>((manager, pid, record))
    })
    .await
    .map_err(|e| ApiError::internal(format!("task error: {}", e)))?
    .map_err(classify_prepared_fork_boot_error)?;

    // Register the clone so exec/run endpoints can reach it.
    let mut entry = machine_entry_from_record(&clone_record, manager);
    entry.external_interceptor = inherited_interceptor;
    state.insert_machine(&clone, entry);

    // A VMM that exited between boot and here must not be reported as running.
    // Without this check the caller gets a 200 and a `running` record for a dead
    // VM, and anyone reading the runtime database directly sees it as live until
    // the supervisor's next tick; a fleet controller built on that record then
    // dispatches work to a machine that is gone. Check the actual process now.
    let pid_start_time = pid.and_then(process_start_time);
    if let (Some(dead_pid), None) = (pid, pid_start_time) {
        let exit_code = crate::process::try_wait(dead_pid);
        let _ = state
            .update_vm(&clone, |r| {
                r.state = RecordState::Stopped;
                r.pid = None;
                r.pid_start_time = None;
            })
            .await;
        return Err(ApiError::internal(format!(
            "clone '{}' exited right after boot{}; the source is unchanged and the clone is recorded as stopped",
            clone,
            exit_code
                .map(|code| format!(" (exit code {code})"))
                .unwrap_or_default()
        )));
    }

    // Persist the running state.
    let record = state
        .update_vm(&clone, move |r| {
            r.state = RecordState::Running;
            r.pid = pid;
            r.pid_start_time = pid_start_time;
            r.engine_build = Some(crate::ENGINE_BUILD.to_string());
        })
        .await?
        .ok_or_else(|| {
            ApiError::NotFound(format!(
                "clone '{}' disappeared from database during fork",
                clone
            ))
        })?;

    let mut info = record_to_info(&clone, &record);
    info.state = "running".to_string();
    info.pid = pid;
    Ok(info)
}

/// Assign job parameters and release one held fork-pool slot.
#[utoipa::path(
    post,
    path = "/api/v1/machines/{name}/fork-release",
    tag = "Machines",
    params(("name" = String, Path, description = "Held clone name")),
    request_body = ForkReleaseRequest,
    responses(
        (status = 200, description = "Held clone assigned and released", body = MachineInfo),
        (status = 404, description = "Clone not found", body = ApiErrorResponse),
        (status = 409, description = "Machine is not a held fork slot", body = ApiErrorResponse),
        (status = 500, description = "Activation failed", body = ApiErrorResponse)
    )
)]
pub async fn release_held_fork(
    State(state): State<Arc<ApiState>>,
    Path(clone): Path<String>,
    Json(req): Json<ForkReleaseRequest>,
) -> Result<Json<MachineInfo>, ApiError> {
    let lifecycle = state.lifecycle_lock(&clone);
    let _guard = lifecycle.lock().await;
    let db = state.db().clone();
    let clone_for_pool = clone.clone();
    let pool_slot = tokio::task::spawn_blocking(move || db.get_fork_pool_slot(&clone_for_pool))
        .await
        .map_err(|e| ApiError::internal(format!("pool ownership task failed: {e}")))?
        .map_err(ApiError::database)?;
    if let Some(slot) = pool_slot {
        return Err(ApiError::Conflict(format!(
            "machine '{clone}' is managed by fork pool '{}'; acquire it through the pool lease API",
            slot.pool_name
        )));
    }
    let record = state
        .lookup_vm(&clone)
        .await?
        .ok_or_else(|| ApiError::NotFound(format!("machine '{clone}' not found")))?;
    if record.golden.is_none() || !record.forkpoint_held {
        return Err(ApiError::Conflict(format!(
            "machine '{clone}' is not a held fork-pool slot"
        )));
    }

    let assignment = crate::util::parse_request_env_list(&req.env).map_err(ApiError::BadRequest)?;
    crate::agent::fork::validate_fork_env(&assignment)
        .map_err(|e| ApiError::BadRequest(e.to_string()))?;
    let merged = crate::agent::fork::merge_fork_env(&record.fork_env, &assignment);
    // Claim in durable state before publishing the guest release marker. A
    // crash can strand one slot, but can never leave a running workload marked
    // assignable and run it twice. Replenishment from the golden is the safe
    // recovery for any ambiguous activation failure.
    let assignment_for_record = assignment.clone();
    let merged_for_record = merged.clone();
    let claimed = Arc::new(std::sync::atomic::AtomicBool::new(false));
    let claimed_in_update = claimed.clone();
    let updated = state
        .update_vm(&clone, move |entry| {
            if entry.forkpoint_held {
                crate::agent::fork::record_fork_activation(
                    entry,
                    &assignment_for_record,
                    merged_for_record,
                );
                claimed_in_update.store(true, std::sync::atomic::Ordering::Release);
            }
        })
        .await?
        .ok_or_else(|| {
            ApiError::NotFound(format!("clone '{clone}' disappeared before activation"))
        })?;
    if !claimed.load(std::sync::atomic::Ordering::Acquire) {
        return Err(ApiError::Conflict(format!(
            "held fork-pool slot '{clone}' was already claimed"
        )));
    }
    if let Ok(entry) = state.get_machine(&clone) {
        entry.lock().forkpoint_held = false;
    }

    let clone_b = clone.clone();
    let record_b = record.clone();
    let assignment_b = assignment.clone();
    let activated = tokio::task::spawn_blocking(move || {
        crate::agent::fork::activate_held_fork(&clone_b, &record_b, &assignment_b)
    })
    .await
    .map_err(|e| ApiError::internal(format!("task error: {e}")))?
    .map_err(|error| {
        ApiError::Internal(format!(
            "slot '{clone}' was claimed and will not be reused after activation failed: {error}"
        ))
    })?;
    debug_assert_eq!(activated, merged);
    Ok(Json(record_to_info(&clone, &updated)))
}

/// Optional identity used to fence delayed cloud retries.
#[derive(Default, serde::Deserialize)]
pub struct PauseOperationQuery {
    /// The same identifier must be reused for all attempts of one pause.
    pub operation_id: Option<String>,
    /// JSON array of pre-signed object-store URLs to upload the saved execution
    /// to in parallel parts, as a capture does, instead of streaming it back.
    pub upload_urls: Option<String>,
}

/// Save execution durably before stopping the machine.
#[utoipa::path(post, path = "/api/v1/machines/{name}/pause", tag = "Machines",
    params(("name" = String, Path, description = "Machine name")),
    responses((status = 200, description = "Machine paused", body = MachineInfo)))]
pub async fn pause_machine(
    State(state): State<Arc<ApiState>>,
    Path(name): Path<String>,
    Query(query): Query<PauseOperationQuery>,
) -> Result<Json<MachineInfo>, ApiError> {
    saved_execution_operation(state, name, false, query.operation_id).await
}

/// Resume saved execution under the same machine name.
#[utoipa::path(post, path = "/api/v1/machines/{name}/resume", tag = "Machines",
    params(("name" = String, Path, description = "Machine name")),
    responses((status = 200, description = "Machine resumed", body = MachineInfo)))]
pub async fn resume_machine(
    State(state): State<Arc<ApiState>>,
    Path(name): Path<String>,
    Query(query): Query<PauseOperationQuery>,
) -> Result<Json<MachineInfo>, ApiError> {
    saved_execution_operation(state, name, true, query.operation_id).await
}

async fn saved_execution_operation(
    state: Arc<ApiState>,
    name: String,
    resume: bool,
    operation: Option<String>,
) -> Result<Json<MachineInfo>, ApiError> {
    let guard = state.lifecycle_lock(&name).lock_owned().await;
    // The operation owns its lock even if the HTTP caller disconnects.
    tokio::task::spawn_blocking(move || {
        let _guard = guard;
        let runtime = crate::embedded::EmbeddedRuntime::with_db(state.db().clone());
        if resume {
            let record = state
                .db()
                .get_vm(&name)
                .map_err(ApiError::database)?
                .ok_or_else(|| ApiError::NotFound(format!("machine '{name}' not found")))?;
            if !record.is_process_alive() {
                if let Ok(entry) = state.get_machine(&name) {
                    entry.lock().manager.mark_stopped();
                }
            }
            match operation {
                Some(operation) => {
                    runtime.resume_machine_detached_with_operation(&name, &operation)
                }
                None => runtime.resume_machine_detached(&name),
            }
        } else if let Some(operation) = operation {
            runtime.pause_machine_with_operation(&name, &operation)
        } else {
            runtime.pause_machine(&name)
        }
        .map_err(ApiError::from)?;
        if !resume {
            if let Ok(entry) = state.get_machine(&name) {
                entry.lock().manager.mark_stopped();
            }
        }
        let record = state
            .db()
            .get_vm(&name)
            .map_err(ApiError::database)?
            .ok_or_else(|| ApiError::NotFound(format!("machine '{name}' not found")))?;
        Ok(Json(record_to_info(&name, &record)))
    })
    .await
    .map_err(ApiError::internal)?
}

/// Download a paused machine's saved execution without consuming it.
pub async fn paused_checkpoint(
    State(state): State<Arc<ApiState>>,
    Path(name): Path<String>,
    Query(query): Query<PauseOperationQuery>,
) -> Result<Response<Body>, ApiError> {
    let upload_urls = query
        .upload_urls
        .as_deref()
        .map(checked_upload_urls)
        .transpose()?;
    let guard = state.lifecycle_lock(&name).lock_owned().await;
    let file = tokio::task::spawn_blocking(move || {
        let _guard = guard;
        let _operation = crate::agent::fork::lock_saved_execution(&name)?;
        if let Some(operation) = query.operation_id {
            if !state.db().pause_operation_is_active(&name, &operation)? {
                return Err(SmolvmError::agent_conflict(
                    "download saved execution",
                    "pause operation is no longer active",
                ));
            }
        }
        let _source = crate::agent::fork::lock_fork_source(&name)?;
        let record = state
            .db()
            .get_vm(&name)?
            .ok_or_else(|| SmolvmError::vm_not_found(&name))?;
        if record.state != RecordState::Paused || record.is_process_alive() {
            return Err(SmolvmError::agent_conflict(
                "download paused checkpoint",
                "machine must be paused",
            ));
        }
        let path = record.paused_checkpoint.ok_or_else(|| {
            SmolvmError::agent_conflict(
                "download paused checkpoint",
                "machine has no saved execution",
            )
        })?;
        crate::portable_checkpoint::verified_sidecar_footer(&path)?;
        // A download leaves the host, so it carries the layers a pause pinned.
        // Only linking its inputs needs the locks: building it can take as long
        // as the pause did, and a resume waiting on them waited that long too.
        crate::portable_checkpoint::prepare_paused_export(&crate::agent::vm_data_dir(&name), &path)
    })
    .await?
    .map_err(ApiError::from)?;
    let file = match file {
        crate::portable_checkpoint::PausedExport::Ready(file) => file,
        crate::portable_checkpoint::PausedExport::Build(build) => {
            tokio::task::spawn_blocking(move || build.build())
                .await?
                .map_err(ApiError::from)?
        }
    };
    // The open descriptor survives deletion of the machine or a concurrent
    // resume; downloading never takes ownership of its recovery artifact.
    if let Some(urls) = upload_urls {
        // Straight to the store, so the artifact never crosses the control
        // plane: relaying it there cost a full copy, an fsync and one stream.
        let size =
            upload_checkpoint_file(file, urls, crate::api::progress::Progress::default()).await?;
        return Ok(axum::response::IntoResponse::into_response(Json(
            serde_json::json!({ "uploaded": true, "sizeBytes": size }),
        )));
    }
    let size = file.metadata().map_err(ApiError::internal)?.len();
    Response::builder()
        .header(
            header::CONTENT_TYPE,
            "application/vnd.smolmachines.checkpoint",
        )
        .header(header::CONTENT_LENGTH, size)
        .body(Body::from_stream(tokio_util::io::ReaderStream::new(
            tokio::fs::File::from_std(file),
        )))
        .map_err(ApiError::internal)
}

/// Stop a machine.
#[utoipa::path(
    post,
    path = "/api/v1/machines/{name}/stop",
    tag = "Machines",
    params(
        ("name" = String, Path, description = "Machine name"),
        ("timeout" = Option<u64>, Query, description = "Seconds the workload gets to exit after its stop signal before it is killed, instead of the machine's stop timeout; 0 kills it at once")
    ),
    responses(
        (status = 200, description = "Machine stopped", body = MachineInfo),
        (status = 404, description = "Machine not found", body = ApiErrorResponse),
        (status = 500, description = "Failed to stop", body = ApiErrorResponse)
    )
)]
pub async fn stop_machine(
    State(state): State<Arc<ApiState>>,
    Path(name): Path<String>,
    Query(query): Query<crate::api::types::StopQuery>,
) -> Result<Json<MachineInfo>, ApiError> {
    let stop_timeout = query.timeout;
    crate::workload::validate_stop_settings(None, stop_timeout).map_err(ApiError::BadRequest)?;
    let stop_timeout = stop_timeout.map(std::time::Duration::from_secs);
    // Hold the per-machine lifecycle lock across the whole stop so the layers
    // volume detach below cannot race a concurrent start's acquire+mount+launch
    // (review finding #3). Acquired before the DB read and liveness probe
    // so the liveness check and the detach act on the same held lock — without
    // it, stop could decide "running" off a snapshot a concurrent start has
    // already superseded, then detach a volume that start just mounted. Outermost
    // lock; the entry mutex is not taken here. Linux: detach is a no-op.
    let lifecycle = state.lifecycle_lock(&name);
    let _guard = lifecycle.lock().await;
    // Cross-process serialization with CLI/API fork preparation. Lifecycle
    // locks cover this server instance; the flock also prevents a direct CLI
    // fork from racing source shutdown between checkpoint and clone commit.
    let _source_lock = acquire_fork_source_lock(name.clone()).await?;

    // Get VM record from database (off the reactor)
    let record = state
        .lookup_vm(&name)
        .await?
        .ok_or_else(|| ApiError::NotFound(format!("machine '{}' not found", name)))?;

    if record.paused_checkpoint.is_some() {
        return Err(ApiError::Conflict(
            "machine has saved execution; use resume or delete".into(),
        ));
    }

    // Resolve the control-plane state, not only PID liveness. A non-Linux fork
    // base is genuinely Frozen and its source VMM owns the RAM backing, so it
    // must outlive its clones. A Linux fork-and-continue source is Running:
    // each clone has opened its RAM generation and its disk bases are retained
    // on disk, so stopping that source is safe and must remain possible.
    let name_probe = name.clone();
    let record_probe = record.clone();
    let resolved = tokio::task::spawn_blocking(move || {
        crate::agent::state_probe::resolve_state(&name_probe, &record_probe)
    })
    .await
    .map_err(|e| ApiError::internal(format!("task error: {e}")))?;
    if resolved == RecordState::Frozen {
        let db = state.db().clone();
        let golden = name.clone();
        let clones = tokio::task::spawn_blocking(move || {
            crate::agent::fork::stop_blocking_dependent_clones(&db, &golden)
        })
        .await
        .map_err(|e| ApiError::internal(format!("task error: {}", e)))?
        .map_err(ApiError::database)?;
        if !clones.is_empty() {
            return Err(ApiError::Conflict(format!(
                "machine '{}' is the fork base of {} running clone(s) ({}); they CoW-map its \
                 memory and disks — stop or delete those clones first",
                name,
                clones.len(),
                clones.join(", ")
            )));
        }
    }

    // An unreachable process is still live and must go through the verified
    // shutdown path below. Frozen-without-clones is also safe to terminate.
    if !matches!(
        resolved,
        RecordState::Running | RecordState::Frozen | RecordState::Unreachable
    ) {
        // Not running. If a prior start mounted the layers volume but the VM
        // then failed to boot (or the server crashed while running), the volume
        // could still be mounted — detach it unless fork children reference it.
        // actual_state() probed this process's liveness; the detach helper also
        // checks child pack references before unmounting. macOS hdiutil detach;
        // a no-op on Linux.
        if record.source_smolmachine.is_some() {
            let name_clone = name.clone();
            tokio::task::spawn_blocking(move || {
                smolvm_pack::extract::force_detach_layers_volume(
                    &crate::agent::machine_layers_cache_dir(&name_clone),
                );
            })
            .await
            .map_err(|e| ApiError::internal(format!("task error: {}", e)))?;
        }
        // The process is confirmed dead. This also handles an out-of-process
        // CLI stop: SQLite already says Stopped, but the serve process may still
        // cache the manager that owns vm.lock. Reconcile before the idempotent
        // return so either this request or a later start repairs the lifecycle.
        let record = if record.state == RecordState::Running || record.state == RecordState::Stopped
        {
            reconcile_confirmed_stopped_machine(&state, &name, true).await?
        } else {
            record
        };
        return Ok(Json(record_to_info(&name, &record)));
    }

    // A staged mount makes its guest-local copy authoritative while the VM is
    // running. Flush it before graceful shutdown; if synchronization fails,
    // leave the VM alive so the caller can retry instead of silently losing
    // the only current copy. An unreachable agent cannot be synchronized, but
    // its persistent storage disk remains available for a later restart.
    if !record.staged_mounts.is_empty() && resolved != RecordState::Unreachable {
        let sync_name = name.clone();
        let sync_record = record.clone();
        tokio::task::spawn_blocking(move || {
            let manager = AgentManager::for_vm(&sync_name)?;
            let mut client = AgentClient::connect_with_retry(manager.vsock_socket())?;
            crate::staged_mount::sync_staged_mounts(&sync_record, &mut client)
        })
        .await
        .map_err(|error| ApiError::internal(format!("task error: {error}")))?
        .map_err(|error| ApiError::internal(format!("sync staged mounts: {error}")))?;
    }

    // Get PID and start time from database record - this is the source of truth
    let pid = record.pid;
    let pid_start_time = record.pid_start_time;

    // Stop VM — prefer using the registered manager (which holds the flock)
    // over creating a throwaway one. This ensures the flock is released so
    // a subsequent start can re-acquire it.
    let entry = state.get_machine(&name).ok();
    let name_clone = name.clone();
    let frozen = resolved == RecordState::Frozen;
    let stopped = tokio::task::spawn_blocking(move || {
        // Carry WHY a stop failed, not just that it did. The reason is the only
        // thing that distinguishes a guest too slow to confirm its flush from a
        // wedged agent that will never answer, and a caller reading the API
        // response never sees this node's log.
        let outcome: Result<(), String> = if let Some(ref entry) = entry {
            let e = entry.lock();
            // A frozen fork base is snapshot-paused, so its agent cannot answer
            // a shutdown request and its filesystems were quiesced when the
            // checkpoint froze it. Asking anyway is how a machine that is safe
            // to terminate ends up unstoppable. Clones were already refused
            // above, so nothing still maps its memory or disks.
            let stop = if frozen {
                e.manager.stop_paused()
            } else if let Some(stop_timeout) = stop_timeout {
                e.manager.stop_with_timeout(stop_timeout)
            } else {
                e.manager.stop()
            };
            stop.map_err(|err| {
                tracing::warn!(name = %name_clone, error = %err, "graceful stop failed; preserving the live VM for retry");
                err.to_string()
            })
        } else if shutdown_machine_process(&name_clone, pid, pid_start_time, !frozen) {
            Ok(())
        } else {
            Err("the VM process did not exit".to_string())
        };
        if outcome.is_ok() {
            // Process is gone — detach this machine's case-sensitive layers
            // volume (macOS hdiutil mount; no-op on Linux). The volume lives
            // under the machine's data dir. The detach helper preserves it if
            // a continuing source still has children referencing its layers.
            smolvm_pack::extract::force_detach_layers_volume(
                &crate::agent::machine_layers_cache_dir(&name_clone),
            );
        }
        outcome
    })
    .await
    .map_err(|e| ApiError::internal(format!("task error: {}", e)))?;

    if let Err(reason) = stopped {
        return Err(ApiError::Internal(format!(
            "machine '{name}' is still running because the stop did not complete: {reason}"
        )));
    }

    // Persist stopped state and release the long-lived registry manager's flock
    // through the same path used for already-dead and out-of-process stops.
    let record = reconcile_confirmed_stopped_machine(&state, &name, true).await?;

    Ok(Json(record_to_info(&name, &record)))
}

/// Synchronize guest-local staged mounts without stopping the machine.
#[utoipa::path(
    post,
    path = "/api/v1/machines/{name}/sync",
    tag = "Machines",
    params(("name" = String, Path, description = "Machine name")),
    responses(
        (status = 200, description = "Staged mounts synchronized", body = MachineInfo),
        (status = 404, description = "Machine not found", body = ApiErrorResponse),
        (status = 409, description = "Machine is not running", body = ApiErrorResponse)
    )
)]
pub async fn sync_machine(
    State(state): State<Arc<ApiState>>,
    Path(name): Path<String>,
) -> Result<Json<MachineInfo>, ApiError> {
    let lifecycle = state.lifecycle_lock(&name);
    let _guard = lifecycle.lock().await;
    let _source_lock = acquire_fork_source_lock(name.clone()).await?;
    let record = state
        .lookup_vm(&name)
        .await?
        .ok_or_else(|| ApiError::NotFound(format!("machine '{name}' not found")))?;
    if record.staged_mounts.is_empty() {
        return Ok(Json(record_to_info(&name, &record)));
    }
    if let Some(error) = crate::staged_mount::refuse_detached_sync(&record, &name) {
        return Err(ApiError::Conflict(error.to_string()));
    }
    if crate::agent::state_probe::resolve_state(&name, &record) != RecordState::Running {
        return Err(ApiError::Conflict(format!(
            "machine '{name}' must be running to synchronize staged mounts"
        )));
    }

    let sync_name = name.clone();
    let sync_record = record.clone();
    tokio::task::spawn_blocking(move || {
        let manager = AgentManager::for_vm(&sync_name)?;
        let mut client = AgentClient::connect_with_retry(manager.vsock_socket())?;
        crate::staged_mount::sync_staged_mounts(&sync_record, &mut client)
    })
    .await
    .map_err(|error| ApiError::internal(format!("task error: {error}")))?
    .map_err(|error| ApiError::internal(error.to_string()))?;

    Ok(Json(record_to_info(&name, &record)))
}

/// `POST /drain` — explicit, control-initiated node drain (decommission).
///
/// Once serve restarts are lossless (per-VM systemd scopes + detach), drain is no
/// longer a side-effect of process shutdown — it's a deliberate decommission step.
/// The control plane (autoscaler scale-in) calls this BEFORE terminating the host
/// so VMs flush cleanly. Control-only by construction: the serve listener is mTLS-
/// gated, and the loopback door is localhost.
pub async fn drain_node(State(state): State<Arc<ApiState>>) -> axum::http::StatusCode {
    tracing::info!("drain requested via API (node decommission)");
    if drain_machines(&state).await {
        axum::http::StatusCode::OK
    } else {
        axum::http::StatusCode::SERVICE_UNAVAILABLE
    }
}

/// Gracefully stop every running VM. Two callers: the opt-in shutdown path
/// (`SMOLVM_DRAIN_ON_SHUTDOWN`, legacy — being retired now that restart is
/// lossless) and the explicit `POST /drain` decommission endpoint ([`drain_node`]).
/// Draining stops VMs cleanly — flushing disk state and marking them stopped so
/// the control plane can reschedule. Best-effort, concurrent, and bounded so it
/// fits inside the host's termination grace period.
pub async fn drain_machines(state: &Arc<ApiState>) -> bool {
    let running: Vec<(String, VmRecord)> = match state.list_vm_records().await {
        Ok(vms) => vms
            .into_iter()
            .filter(|(_, r)| r.actual_state() == RecordState::Running && r.is_process_alive())
            .collect(),
        Err(e) => {
            tracing::error!(error = ?e, "drain: failed to list machines");
            return false;
        }
    };
    if running.is_empty() {
        return true;
    }
    tracing::info!(
        count = running.len(),
        "draining running machines before shutdown"
    );

    let mut handles = Vec::with_capacity(running.len());
    for (name, record) in running {
        let state = state.clone();
        handles.push(tokio::spawn(async move {
            let name_for_kill = name.clone();
            let entry = state.get_machine(&name).ok();
            let stopped = tokio::task::spawn_blocking(move || {
                let _source_lock = match crate::agent::fork::lock_fork_source(&name_for_kill) {
                    Ok(lock) => lock,
                    Err(error) => {
                        tracing::warn!(machine = %name_for_kill, error = %error, "drain: failed to lock machine");
                        return false;
                    }
                };
                if !record.staged_mounts.is_empty() {
                    let sync_result = AgentManager::for_vm(&name_for_kill).and_then(|manager| {
                        let mut client = AgentClient::connect_with_retry(manager.vsock_socket())?;
                        crate::staged_mount::sync_staged_mounts(&record, &mut client)
                    });
                    if let Err(error) = sync_result {
                        tracing::warn!(machine = %name_for_kill, error = %error, "drain: staged mount sync failed; leaving machine running");
                        return false;
                    }
                }
                // Both paths require guest quiescence before verified signals.
                entry.as_ref().map(|e| e.lock().manager.stop().is_ok()).unwrap_or_else(||
                    shutdown_machine_process(
                        &name_for_kill,
                        record.pid,
                        record.pid_start_time,
                        true,
                    ))
            })
            .await
            .unwrap_or(false);
            if stopped {
                if let Ok(entry) = state.get_machine(&name) {
                    entry.lock().manager.mark_stopped();
                }
                let _ = state
                    .update_vm(&name, |r| {
                        r.state = RecordState::Stopped;
                        r.pid = None;
                        r.pid_start_time = None;
                        // A drain is a deliberate decommission: mark the machine
                        // user-stopped so the restart supervisor does not resurrect it
                        // in the window before the host is terminated (or if drain is
                        // used standalone). An explicit start elsewhere clears this.
                        r.restart.user_stopped = true;
                    })
                    .await;
            }
            tracing::info!(machine = %name, stopped, "drain: shutdown attempt finished");
            stopped
        }));
    }

    let drain_all = async {
        let mut complete = true;
        for h in handles {
            complete &= h.await.unwrap_or(false);
        }
        complete
    };
    match tokio::time::timeout(std::time::Duration::from_secs(130), drain_all).await {
        Ok(complete) => complete,
        Err(_) => {
            tracing::warn!("drain: deadline reached before all machines stopped");
            false
        }
    }
}

/// Delete a machine.
///
/// If data-directory inspection or removal fails, returns an error and retains
/// the machine record for a cleanup retry. Removal may have partially succeeded;
/// the retained record does not imply the machine can still be started.
#[utoipa::path(
    delete,
    path = "/api/v1/machines/{name}",
    tag = "Machines",
    params(
        ("name" = String, Path, description = "Machine name"),
        ("cascade" = Option<bool>, Query, description = "Also delete clones forked from this machine (fork base cannot be removed while its clones depend on it)")
    ),
    responses(
        (status = 200, description = "Machine deleted", body = DeleteResponse),
        (status = 404, description = "Machine not found", body = ApiErrorResponse),
        (status = 409, description = "Machine is a fork base with live clones (use cascade)", body = ApiErrorResponse),
        (status = 500, description = "Failed to delete", body = ApiErrorResponse)
    )
)]
pub async fn delete_machine(
    State(state): State<Arc<ApiState>>,
    Path(name): Path<String>,
    Query(query): Query<DeleteQuery>,
) -> Result<Json<DeleteResponse>, ApiError> {
    // Cascade: remove the entire lineage deepest-first so every qcow2 overlay
    // disappears before the image that backs it. The read is unlocked, but
    // delete_one re-checks direct dependants under each lifecycle lock, so a
    // concurrently-created child still refuses instead of dangling.
    if query.cascade {
        let db = state.db().clone();
        let golden = name.clone();
        let clones =
            tokio::task::spawn_blocking(move || db.dependent_descendants_postorder(&golden))
                .await
                .map_err(|e| ApiError::internal(format!("task error: {}", e)))?
                .map_err(ApiError::database)?;
        for clone in clones {
            // A clone can vanish between the lineage read and its delete, e.g.
            // when its fork pool is deleting its workers at the same time. That
            // clone is gone, which is what the cascade wants; failing here would
            // report the golden itself as not found and leave it half-deleted.
            match delete_one(state.clone(), clone).await {
                Ok(_) | Err(ApiError::NotFound(_)) => {}
                Err(error) => return Err(error),
            }
        }
    }
    delete_one(state, name).await.map(Json)
}

/// Delete a single machine (no cascade): stop it, delete its data directory,
/// then remove it from the registry and database. Refuses if it is a fork base
/// with live clones. Shared by [`delete_machine`] (once per golden, and once per
/// clone during a cascade).
pub(crate) async fn delete_one(
    state: Arc<ApiState>,
    name: String,
) -> Result<DeleteResponse, ApiError> {
    // A cleanup request may outlive its caller's deadline while waiting for a
    // branch. Keep it queued, and hold its locks through the blocking teardown.
    with_owned_operation(move |reply| async move {
        let result = delete_one_transaction(state, name).await;
        let _ = reply.send(result);
    })
    .await
}

/// Remove a stopped machine's data directory, retrying while something is
/// still adding entries to it. A delete under heavy guest I/O has failed with
/// "Directory not empty" and then succeeded seconds later, so the writer
/// settles: retry for a short while, and name what was left each time so the
/// writer can be found.
fn remove_data_dir_settling(name: &str, data_dir: &std::path::Path) -> std::io::Result<()> {
    const ATTEMPTS: u32 = 6;
    let mut attempt = 1;
    loop {
        match std::fs::remove_dir_all(data_dir) {
            Ok(()) => return Ok(()),
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(()),
            Err(error)
                if error.kind() == std::io::ErrorKind::DirectoryNotEmpty && attempt < ATTEMPTS =>
            {
                tracing::warn!(
                    machine = name,
                    attempt,
                    left = %data_dir_entries(data_dir).join(", "),
                    "machine data directory gained entries while it was removed; retrying"
                );
                std::thread::sleep(std::time::Duration::from_millis(250 << attempt.min(4)));
                attempt += 1;
            }
            Err(error) => return Err(error),
        }
    }
}

/// Up to 20 paths still under `dir`, relative to it, for a removal diagnostic.
fn data_dir_entries(dir: &std::path::Path) -> Vec<String> {
    let mut found = Vec::new();
    let mut pending = vec![dir.to_path_buf()];
    while let Some(next) = pending.pop() {
        let Ok(entries) = std::fs::read_dir(&next) else {
            continue;
        };
        for entry in entries.flatten() {
            let path = entry.path();
            found.push(
                path.strip_prefix(dir)
                    .unwrap_or(&path)
                    .display()
                    .to_string(),
            );
            if found.len() >= 20 {
                return found;
            }
            if entry.file_type().is_ok_and(|kind| kind.is_dir()) {
                pending.push(path);
            }
        }
    }
    found
}

// Called with the lifecycle and fork-source locks held, after confirmed shutdown.
// Keep filesystem and database I/O on the blocking thread.
fn remove_machine_data_and_record(
    state: &ApiState,
    name: &str,
    data_dir: &std::path::Path,
) -> Result<(), ApiError> {
    match std::fs::symlink_metadata(data_dir) {
        Ok(_) => {
            // Shutdown was confirmed before entering this helper. Release the
            // uid before removing its .vm-uid file, as in CLI deletion.
            crate::process::free_vm_uid(&crate::agent::vm_uid_registry_dir(), data_dir);
            remove_data_dir_settling(name, data_dir).map_err(|error| {
                ApiError::internal(format!(
                    "failed to remove data for machine '{name}': {error}; repair host storage and retry deletion"
                ))
            })?;
            // Layers a pause pinned beside the data directory go with it.
            if let Err(error) = crate::portable_checkpoint::remove_paused_layers(data_dir) {
                tracing::warn!(machine = name, %error, "could not remove pinned layers");
            }
        }
        // Storage may already be gone after an interrupted delete or DB failure.
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => {}
        // Path::exists would hide permission and I/O errors as absence.
        Err(error) => {
            return Err(ApiError::internal(format!(
                "failed to inspect data for machine '{name}': {error}; retry deletion after resolving the error"
            )));
        }
    }
    match state.remove_machine(name) {
        Ok(_) => Ok(()),
        Err(ApiError::NotFound(_)) => {
            // Startup recovery can leave a record without an in-memory entry.
            let removed = state.db().remove_vm(name).map_err(ApiError::database)?;
            if removed.is_none() {
                return Err(ApiError::NotFound(format!("machine '{name}' not found")));
            }
            Ok(())
        }
        Err(error) => Err(error),
    }
}

async fn delete_one_transaction(
    state: Arc<ApiState>,
    name: String,
) -> Result<DeleteResponse, ApiError> {
    // Hold the per-machine lifecycle lock across the whole delete so the layers
    // volume detach (before the data-dir removal) cannot race a concurrent
    // start's acquire+mount+launch (review finding #3). Acquired before the DB
    // read so the existence check, shutdown, detach, and removal all happen under
    // one held lock. Outermost lock; the entry mutex is not taken here. Linux:
    // detach is a no-op.
    let lifecycle = state.lifecycle_lock(&name);
    let _guard = lifecycle.lock().await;
    let _source_lock = acquire_fork_source_lock(name.clone()).await?;

    // Check if VM exists and get its state (off the reactor)
    let record = state
        .lookup_vm(&name)
        .await?
        .ok_or_else(|| ApiError::NotFound(format!("machine '{}' not found", name)))?;

    // A forked clone's block disks are copy-on-write overlays backed by this
    // machine's disks, so deleting a golden with live clones would destroy
    // their backing files (silent data loss the moment a clone re-opens its
    // disks). Refuse — mirroring the CLI `machine rm` guard.
    {
        let db = state.db().clone();
        let golden = name.clone();
        let clones = tokio::task::spawn_blocking(move || db.dependent_clones(&golden))
            .await
            .map_err(|e| ApiError::internal(format!("task error: {}", e)))?
            .map_err(ApiError::database)?;
        if !clones.is_empty() {
            return Err(ApiError::Conflict(format!(
                "machine '{}' is the fork base of {} live clone(s) ({}); their disks are \
                 backed by its disks — delete the clones first",
                name,
                clones.len(),
                clones.join(", ")
            )));
        }
    }

    // A running staged mount owns state that is newer than its host source.
    // Flush it before delete; on failure leave both the VM and its data dir
    // intact so the caller can repair and retry.
    if !record.staged_mounts.is_empty() {
        match crate::agent::state_probe::resolve_state(&name, &record) {
            RecordState::Running => {
                let sync_name = name.clone();
                let sync_record = record.clone();
                tokio::task::spawn_blocking(move || {
                    let manager = AgentManager::for_vm(&sync_name)?;
                    let mut client = AgentClient::connect_with_retry(manager.vsock_socket())?;
                    crate::staged_mount::sync_staged_mounts(&sync_record, &mut client)
                })
                .await
                .map_err(|error| ApiError::internal(format!("task error: {error}")))?
                .map_err(|error| ApiError::internal(format!("sync staged mounts: {error}")))?;
            }
            RecordState::Unreachable => {
                return Err(ApiError::Conflict(format!(
                    "machine '{name}' has unsynchronized staged mounts but its agent is unreachable"
                )));
            }
            _ => {}
        }
    }

    // Get PID and start time from database record
    let pid = record.pid;
    let pid_start_time = record.pid_start_time;

    // Stop if running (in blocking task)
    let name_clone = name.clone();
    let stopped = tokio::task::spawn_blocking(move || {
        let ok = shutdown_machine_process(&name_clone, pid, pid_start_time, false);
        if ok {
            // Process is gone — detach this machine's case-sensitive layers
            // volume (macOS hdiutil mount; no-op on Linux) before the data dir is
            // removed below, otherwise `rm -rf` fails with "Resource busy". The
            // dependent children were checked above; the detach helper also
            // preserves any remaining child pack references.
            smolvm_pack::extract::force_detach_layers_volume(
                &crate::agent::machine_layers_cache_dir(&name_clone),
            );
        }
        ok
    })
    .await
    .map_err(|e| ApiError::internal(format!("task error: {}", e)))?;

    if !stopped {
        return Err(ApiError::Internal(format!(
            "machine '{}' process (pid {}) is still alive after shutdown; not removing",
            name,
            pid.map(|p| p.to_string())
                .unwrap_or_else(|| "unknown".into()),
        )));
    }

    // Re-check for dependent clones now that the golden's process (and its fork
    // control socket) is down. API forks share the lifecycle lock held here, but
    // a separate CLI/embedded process has no access to that in-process lock and
    // could have registered a clone after the initial check. Abort BEFORE
    // removing the DB record or data dir — the clones' copy-on-write disks are
    // backed by this golden's disks, so removing them would be silent data loss.
    // The golden is left stopped with its disks intact; delete the clones and
    // retry.
    {
        let db = state.db().clone();
        let golden = name.clone();
        let clones = tokio::task::spawn_blocking(move || db.dependent_clones(&golden))
            .await
            .map_err(|e| ApiError::internal(format!("task error: {}", e)))?
            .map_err(ApiError::database)?;
        if !clones.is_empty() {
            return Err(ApiError::Conflict(format!(
                "machine '{}' gained {} clone(s) during deletion ({}); their disks are backed by \
                 its disks — delete the clones first",
                name,
                clones.len(),
                clones.join(", ")
            )));
        }
    }

    // Free the machine's data BEFORE the registry write, not after — the same
    // order `cli::vm_common::remove_vm_data_and_record` uses for the CLI path.
    //
    // The registry lives on a filesystem an operator may have sized to share
    // with VM storage, and a workload that fills it leaves the database with no
    // room to commit. Removing the record first then needs space the workload
    // has already taken: the delete fails, the machine is stopped but
    // undeletable, and every retry hits the same wall. Releasing the disk images
    // first makes the delete self-financing — it frees far more than the record
    // removal needs, so cleanup still works on a full disk.
    let state_rm = state.clone();
    let name_rm = name.clone();
    let cleanup = tokio::task::spawn_blocking(move || {
        remove_machine_data_and_record(&state_rm, &name_rm, &vm_data_dir(&name_rm))
    })
    .await
    .map_err(|e| ApiError::internal(format!("task error: {e}")))?;
    if let Err(error) = cleanup {
        // The process is confirmed dead, but its record must survive for retry.
        // Clear its PID so startup recovery does not discard it as a crashed VM,
        // and suppress automatic restarts over potentially half-removed disks.
        if let Ok(entry) = state.get_machine(&name) {
            entry.lock().restart.user_stopped = true;
        }
        reconcile_confirmed_stopped_machine(&state, &name, true)
            .await
            .map_err(|reconcile_error| {
                ApiError::internal(format!(
                    "cleanup failed: {error:?}; failed to persist stopped state: {reconcile_error:?}"
                ))
            })?;
        return Err(error);
    }
    // The machine may have held the last lease on a shared extraction.
    #[cfg(target_os = "linux")]
    crate::artifact_cache::trim_unleased_shared_packs_soon();

    if let Some(parent) = record.golden.clone() {
        let db = state.db().clone();
        let parent_for_log = parent.clone();
        let cleanup = tokio::task::spawn_blocking(move || {
            crate::agent::fork::collect_parent_generations_after_child_delete(&db, &parent)
        })
        .await;
        match cleanup {
            Ok(Ok(())) => {}
            Ok(Err(error)) => {
                tracing::warn!(parent = %parent_for_log, %error, "could not collect unreferenced fork generation")
            }
            Err(error) => {
                tracing::warn!(parent = %parent_for_log, %error, "fork-generation cleanup task failed")
            }
        }
    }

    crate::credentials::forget_values(&name);
    Ok(DeleteResponse { deleted: name })
}

/// Supply the values for a machine's credential bindings.
#[utoipa::path(
    put,
    path = "/api/v1/machines/{name}/credential-values",
    tag = "Machines",
    params(
        ("name" = String, Path, description = "Machine name")
    ),
    request_body = CredentialValuesRequest,
    responses(
        (status = 204, description = "Values held for the machine's next boot, and in use at once on a running machine"),
        (status = 400, description = "A value names no binding of the machine", body = ApiErrorResponse),
        (status = 404, description = "Machine not found", body = ApiErrorResponse),
        (status = 409, description = "The machine runs but could not take the values; they still apply from its next boot", body = ApiErrorResponse)
    )
)]
pub async fn put_credential_values(
    State(state): State<Arc<ApiState>>,
    Path(name): Path<String>,
    Json(req): Json<CredentialValuesRequest>,
) -> Result<axum::http::StatusCode, ApiError> {
    let record = state
        .lookup_vm(&name)
        .await?
        .ok_or_else(|| ApiError::NotFound(format!("machine '{}' not found", name)))?;
    let bindings: Vec<&str> = record
        .credential_policy
        .iter()
        .flat_map(|policy| policy.credentials.iter().map(|b| b.name.as_str()))
        .collect();
    if let Some(unknown) = req.values.keys().find(|k| !bindings.contains(&k.as_str())) {
        return Err(ApiError::BadRequest(format!(
            "machine '{name}' has no credential binding '{unknown}'"
        )));
    }
    let values: std::collections::BTreeMap<String, zeroize::Zeroizing<String>> = req
        .values
        .into_iter()
        .map(|(k, v)| (k, zeroize::Zeroizing::new(v)))
        .collect();
    // A running machine resolves from the values its boot was handed, so it
    // gets the new ones directly; the held copy covers its next boot.
    let running = record.actual_state() == RecordState::Running;
    let live = running.then(|| values.clone());
    crate::credentials::supply_values(&name, values);
    if let Some(values) = live {
        let machine = name.clone();
        tokio::task::spawn_blocking(move || {
            crate::agent::apply_live_credential_values(&machine, &values)
        })
        .await
        .map_err(|error| ApiError::internal(format!("credential values task failed: {error}")))?
        .map_err(|error| ApiError::Conflict(error.to_string()))?;
    }
    Ok(axum::http::StatusCode::NO_CONTENT)
}

/// Replace a machine's published ports, live when it runs.
#[utoipa::path(
    put,
    path = "/api/v1/machines/{name}/ports",
    tag = "Machines",
    params(
        ("name" = String, Path, description = "Machine name")
    ),
    request_body = SetPortsRequest,
    responses(
        (status = 200, description = "Ports set; a running machine is already serving them", body = MachineInfo),
        (status = 400, description = "Invalid ports, or a running machine that cannot change them", body = ApiErrorResponse),
        (status = 404, description = "Machine not found", body = ApiErrorResponse),
        (status = 409, description = "A host port is already in use (PORT_IN_USE), or a UDP change on a running machine", body = ApiErrorResponse)
    )
)]
pub async fn set_machine_ports(
    State(state): State<Arc<ApiState>>,
    Path(name): Path<String>,
    Json(req): Json<SetPortsRequest>,
) -> Result<Json<MachineInfo>, ApiError> {
    // Under the lifecycle lock so a start or stop cannot land between reading
    // the state and applying the ports.
    let lifecycle = state.lifecycle_lock(&name);
    let guard = lifecycle.lock_owned().await;
    let record = state
        .lookup_vm(&name)
        .await?
        .ok_or_else(|| ApiError::NotFound(format!("machine '{}' not found", name)))?;
    let running = record.actual_state() == RecordState::Running;
    let ports: Vec<PortMapping> = req.ports.iter().map(PortMapping::from).collect();
    let db = state.db().clone();
    let saved = tokio::task::spawn_blocking(move || {
        let _guard = guard;
        crate::agent::live_ports::set_published_ports(&db, &record, running, &ports)
    })
    .await
    .map_err(|error| ApiError::internal(format!("set ports task failed: {error}")))?
    .map_err(classify_set_ports_error)?;
    Ok(Json(record_to_info(&name, &saved)))
}

/// Set or clear a running machine's live CPU limit.
#[utoipa::path(
    put,
    path = "/api/v1/machines/{name}/cpu-limit",
    tag = "Machines",
    params(
        ("name" = String, Path, description = "Machine name")
    ),
    request_body = SetCpuLimitRequest,
    responses(
        (status = 200, description = "Limit applied to the running VMM", body = MachineInfo),
        (status = 400, description = "millicpus is 0 or above vCPUs × 1000, or this host has no cgroup CPU control", body = ApiErrorResponse),
        (status = 404, description = "Machine not found", body = ApiErrorResponse),
        (status = 409, description = "Machine is not running", body = ApiErrorResponse)
    )
)]
pub async fn set_machine_cpu_limit(
    State(state): State<Arc<ApiState>>,
    Path(name): Path<String>,
    Json(req): Json<SetCpuLimitRequest>,
) -> Result<Json<MachineInfo>, ApiError> {
    // Under the lifecycle lock so a stop or restart cannot replace the VMM
    // between reading the state and applying the quota.
    let lifecycle = state.lifecycle_lock(&name);
    let guard = lifecycle.lock_owned().await;
    state
        .lookup_vm(&name)
        .await?
        .ok_or_else(|| ApiError::NotFound(format!("machine '{}' not found", name)))?;
    let db = state.db().clone();
    let limit_name = name.clone();
    let record = tokio::task::spawn_blocking(move || {
        let _guard = guard;
        crate::agent::cpu_limit::set_cpu_limit(&db, &limit_name, req.millicpus)
    })
    .await
    .map_err(|error| ApiError::internal(format!("CPU limit task failed: {error}")))?
    .map_err(|error| match error {
        crate::Error::Config { .. } => ApiError::BadRequest(error.to_string()),
        other => ApiError::from(other),
    })?;
    Ok(Json(record_to_info(&name, &record)))
}

/// A host port something else holds is `PortConflict`, which the control plane
/// retries on another port; any other configuration refusal is the caller's.
fn classify_set_ports_error(error: crate::Error) -> ApiError {
    let message = error.to_string();
    let lc = message.to_ascii_lowercase();
    if lc.contains("address already in use") || lc.contains("os error 10048") {
        return ApiError::PortConflict(message);
    }
    match error {
        crate::Error::Config { .. } => ApiError::BadRequest(message),
        other => ApiError::from(other),
    }
}

/// Resize a machine's disk resources.
#[utoipa::path(
    post,
    path = "/api/v1/machines/{name}/resize",
    tag = "Machines",
    params(
        ("name" = String, Path, description = "Machine name")
    ),
    request_body = ResizeMachineRequest,
    responses(
        (status = 200, description = "Machine resized", body = MachineInfo),
        (status = 400, description = "Invalid request", body = ApiErrorResponse),
        (status = 404, description = "Machine not found", body = ApiErrorResponse),
        (status = 409, description = "Machine state or shared disks prevent resizing", body = ApiErrorResponse),
        (status = 500, description = "Resize failed", body = ApiErrorResponse)
    )
)]
pub async fn resize_machine(
    State(state): State<Arc<ApiState>>,
    Path(name): Path<String>,
    Json(req): Json<ResizeMachineRequest>,
) -> Result<Json<MachineInfo>, ApiError> {
    // Serialize against start/stop/delete/clone on the same machine: resize
    // reads the state, then grows the disk files and rewrites the record. Without
    // the per-machine lifecycle lock a concurrent start could boot the VM between
    // our "must be stopped" check and the on-disk expansion (and race the record
    // update), so hold the lock across the whole operation as the other lifecycle
    // handlers do — the state check below is only meaningful under it.
    let lifecycle = state.lifecycle_lock(&name);
    let guard = lifecycle.lock_owned().await;

    let record = state
        .lookup_vm(&name)
        .await?
        .ok_or_else(|| ApiError::NotFound(format!("machine '{}' not found", name)))?;

    let actual_state = record.actual_state();
    if actual_state == RecordState::Running {
        let resource_kinds = u8::from(req.cpus.is_some())
            + u8::from(req.mem.is_some())
            + u8::from(req.storage_gb.is_some() || req.overlay_gb.is_some());
        if resource_kinds > 1 {
            return Err(ApiError::BadRequest(
                "resize CPUs, RAM, and disks in separate requests".into(),
            ));
        }
        let db = state.db().clone();
        let resize_name = name.clone();
        let record = tokio::task::spawn_blocking(move || {
            // Keep lifecycle ownership if the HTTP request is cancelled while
            // a disk or filesystem operation is still running.
            let _guard = guard;
            let target = if let Some(cpus) = req.cpus {
                crate::db::ResizeTarget::Cpus(cpus)
            } else if let Some(mem) = req.mem {
                crate::db::ResizeTarget::Memory(mem)
            } else {
                crate::db::ResizeTarget::Disks {
                    storage: req.storage_gb,
                    overlay: req.overlay_gb,
                }
            };
            crate::agent::live_resize::grow_checked(
                &db,
                &resize_name,
                target,
                req.expected_runtime.as_ref(),
                req.operation_id.as_deref(),
            )
        })
        .await
        .map_err(|error| ApiError::internal(format!("live resize task failed: {error}")))?
        .map_err(|error| match error {
            crate::Error::Config { .. } => ApiError::BadRequest(error.to_string()),
            other => ApiError::from(other),
        })?;
        return match record {
            crate::agent::live_resize::ResizeOutcome::Applied(record) => {
                Ok(Json(record_to_info(&name, &record)))
            }
            crate::agent::live_resize::ResizeOutcome::Rejected {
                operation_id,
                runtime,
                message,
            } => Err(ApiError::ResizeRejected {
                operation_id,
                runtime,
                message,
            }),
        };
    }
    if req.expected_runtime.is_some() || req.operation_id.is_some() {
        return Err(ApiError::Conflict(
            "observed machine runtime is no longer running; inspect it before resizing".into(),
        ));
    }
    if req.cpus.is_some() || req.mem.is_some() {
        return Err(ApiError::BadRequest(
            "live CPU/RAM resize requires a running machine; use update for a stopped machine"
                .into(),
        ));
    }
    match actual_state {
        RecordState::Stopped | RecordState::Created => {}
        _ => {
            return Err(ApiError::Conflict(format!(
                "machine '{}' must be stopped before resizing. Current state: {:?}",
                name, actual_state
            )));
        }
    }

    // A fork base's disks are the copy-on-write backing for its clones' disks, so
    // growing them corrupts the clones. The state check above is not enough: a
    // golden whose VMM has died (e.g. after a host reboot) resolves to Stopped
    // while its clones still depend on it, so `actual_state` would pass. Refuse
    // explicitly, mirroring delete/stop and the CLI resize guard.
    {
        let db = state.db().clone();
        let golden = name.clone();
        let clones = tokio::task::spawn_blocking(move || db.dependent_clones(&golden))
            .await
            .map_err(|e| ApiError::internal(format!("task error: {}", e)))?
            .map_err(ApiError::database)?;
        if !clones.is_empty() {
            return Err(ApiError::Conflict(format!(
                "machine '{}' is the fork base of {} live clone(s) ({}); their disks are backed \
                 by its disks — delete the clones first",
                name,
                clones.len(),
                clones.join(", ")
            )));
        }
    }

    let current_storage_gb = record.storage_gb.unwrap_or(DEFAULT_STORAGE_SIZE_GIB);
    let current_overlay_gb = record.overlay_gb.unwrap_or(DEFAULT_OVERLAY_SIZE_GIB);

    if req.storage_gb.unwrap_or(current_storage_gb) < current_storage_gb {
        return Err(ApiError::BadRequest(format!(
            "storageGb cannot be smaller than current size ({} GiB)",
            current_storage_gb
        )));
    }
    if req.overlay_gb.unwrap_or(current_overlay_gb) < current_overlay_gb {
        return Err(ApiError::BadRequest(format!(
            "overlayGb cannot be smaller than current size ({} GiB)",
            current_overlay_gb
        )));
    }

    if req.storage_gb.is_none() && req.overlay_gb.is_none() {
        return Err(ApiError::BadRequest(
            "at least one of storageGb or overlayGb must be specified".into(),
        ));
    }

    let manager = AgentManager::for_vm(&name)
        .map_err(|e| ApiError::internal(format!("failed to get agent manager: {}", e)))?;

    if let Some(storage_gb) = req.storage_gb {
        if storage_gb > current_storage_gb {
            let storage_path = manager.storage_path();
            expand_disk::<Storage>(storage_path, storage_gb)
                .map_err(|e| ApiError::internal(format!("failed to expand storage: {}", e)))?;
        }
    }

    if let Some(overlay_gb) = req.overlay_gb {
        if overlay_gb > current_overlay_gb {
            let overlay_path = manager.overlay_path();
            expand_disk::<Overlay>(overlay_path, overlay_gb)
                .map_err(|e| ApiError::internal(format!("failed to expand overlay: {}", e)))?;
        }
    }

    let (storage_gb, overlay_gb) = (req.storage_gb, req.overlay_gb);
    let record = state
        .update_vm(&name, move |r| {
            if let Some(s) = storage_gb {
                r.storage_gb = Some(s);
            }
            if let Some(o) = overlay_gb {
                r.overlay_gb = Some(o);
            }
        })
        .await?
        .ok_or_else(|| {
            ApiError::NotFound(format!("machine '{}' disappeared during resize", name))
        })?;

    Ok(Json(record_to_info(&name, &record)))
}

/// Publish a stopped machine's cache disk, its base with everything the
/// machine wrote over it, as a new self-contained base in the server's cache
/// disk directory. The new base appears whole or not at all, and the old one is
/// left as it is, so machines still on it are unaffected.
#[utoipa::path(
    post,
    path = "/api/v1/machines/{name}/cache-disk/publish",
    tag = "Machines",
    params(
        ("name" = String, Path, description = "Machine name")
    ),
    request_body = crate::api::types::PublishCacheDiskRequest,
    responses(
        (status = 200, description = "Cache disk published as a new base", body = crate::api::types::PublishCacheDiskResponse),
        (status = 400, description = "Invalid request, no cache disk, or cache disks disabled", body = ApiErrorResponse),
        (status = 404, description = "Machine not found", body = ApiErrorResponse),
        (status = 409, description = "Machine is running, or the base name is taken", body = ApiErrorResponse),
    )
)]
pub async fn publish_cache_disk(
    State(state): State<Arc<ApiState>>,
    Path(name): Path<String>,
    progress: Option<axum::Extension<crate::api::progress::Progress>>,
    Json(req): Json<crate::api::types::PublishCacheDiskRequest>,
) -> Result<Json<crate::api::types::PublishCacheDiskResponse>, ApiError> {
    let progress = progress.map(|p| p.0).unwrap_or_default();
    let dir = state.cache_disk_dir()?;
    crate::data::disk::validate_base_name(&req.base).map_err(ApiError::BadRequest)?;

    // Held across the copy, so the machine cannot start and write its layer
    // while the copy reads it.
    let lifecycle = state.lifecycle_lock(&name);
    let guard = lifecycle.lock_owned().await;
    let record = state
        .lookup_vm(&name)
        .await?
        .ok_or_else(|| ApiError::NotFound(format!("machine '{}' not found", name)))?;
    let cache = record
        .cache_disk
        .clone()
        .ok_or_else(|| ApiError::BadRequest(format!("machine '{name}' has no cache disk")))?;
    if record.actual_state() == RecordState::Running {
        return Err(ApiError::Conflict(format!(
            "stop machine '{name}' before publishing its cache disk: a running machine is still writing it"
        )));
    }
    let target = dir.join(&req.base);
    if target.exists() {
        return Err(ApiError::Conflict(format!(
            "cache base '{}' already exists; publish each version under a new name",
            req.base
        )));
    }

    let upload_urls = req
        .upload_urls
        .as_ref()
        .map(|urls| -> Result<Vec<reqwest::Url>, ApiError> {
            if urls.is_empty() || urls.len() > MAX_UPLOAD_PARTS {
                return Err(ApiError::BadRequest(format!(
                    "uploadUrls must name 1 to {MAX_UPLOAD_PARTS} parts"
                )));
            }
            urls.iter()
                .map(|url| checked_checkpoint_source(url))
                .collect()
        })
        .transpose()?;

    // The flattened copy is about as large as the disk: room first, not after.
    crate::api::cache_base_budget::make_room(&state).await;
    let layer = crate::data::disk::CacheDisk::layer_path(&vm_data_dir(&name));
    let flatten_dir = dir.clone();
    let base = req.base.clone();
    let flattening = progress.clone();
    let flatten_started = std::time::Instant::now();
    let staged = tokio::task::spawn_blocking(move || -> Result<StagedBase, ApiError> {
        let _guard = guard;
        // A machine that never started has no layer yet: its cache is the base.
        let top = if layer.exists() {
            layer
        } else {
            cache.base.clone()
        };
        flatten_staged(&top, &flatten_dir, &base, &flattening)
    })
    .await
    .map_err(|e| ApiError::internal(format!("task error: {e}")))??;
    let flatten_elapsed = flatten_started.elapsed();

    // The hash reads the staged copy alongside the upload instead of before it,
    // so a large disk pays for one read of itself, not a full hash and then the
    // upload. Both finish before `staged` can be dropped and its file removed.
    // The base takes its name only once the upload has landed. Named first, a
    // failed upload left it behind under a version the control plane never
    // recorded, and every later publish of that version collided with it.
    //
    // The flatten leaves its writes in the page cache, and the hash and upload
    // read them from there; only installing the base needs them on disk. So
    // the sync runs alongside the transfer instead of ahead of it, which on a
    // worker took 12 s of a 67 s publish of 32 GB.
    let transfer_started = std::time::Instant::now();
    let sync_path = staged.path().to_path_buf();
    let syncing = progress.clone();
    let sync = tokio::task::spawn_blocking(move || {
        sync_with_progress(&sync_path, &syncing)
            .map_err(|e| ApiError::internal(format!("sync {}: {e}", sync_path.display())))
    });
    let hash_path = staged.path().to_path_buf();
    let hashing = progress.clone();
    let hash = tokio::task::spawn_blocking(move || file_sha256(&hash_path, &hashing));
    let uploaded = upload_urls.is_some();
    let upload = async {
        let Some(urls) = upload_urls else {
            return Ok(());
        };
        let file = std::fs::File::open(staged.path())
            .map_err(|e| ApiError::internal(format!("open {}: {e}", staged.path().display())))?;
        upload_checkpoint_file(file, urls, progress).await.map(drop)
    };
    let (hashed, upload, synced) = tokio::join!(hash, upload, sync);
    upload?;
    synced.map_err(|e| ApiError::internal(format!("task error: {e}")))??;
    let sha256 = hashed.map_err(|e| ApiError::internal(format!("task error: {e}")))??;
    let transfer_elapsed = transfer_started.elapsed();

    let install_started = std::time::Instant::now();
    let base = req.base.clone();
    let digest = sha256.clone();
    let size_bytes = tokio::task::spawn_blocking(move || staged.install(&dir, &base, &digest))
        .await
        .map_err(|e| ApiError::internal(format!("task error: {e}")))??;
    tracing::info!(
        base = %req.base,
        size_bytes,
        uploaded,
        flatten_ms = flatten_elapsed.as_millis() as u64,
        hash_and_upload_ms = transfer_elapsed.as_millis() as u64,
        install_ms = install_started.elapsed().as_millis() as u64,
        "published cache disk"
    );
    crate::api::cache_base_budget::make_room(&state).await;
    Ok(Json(crate::api::types::PublishCacheDiskResponse {
        base: req.base,
        size_bytes,
        sha256,
    }))
}

/// Remove a cache base from this server: a base a failed publish left behind,
/// or one whose cache disk was deleted. Refused while a machine here is
/// attached to it. Removing a base that is not here succeeds, so a retry is
/// safe; a base that is needed again is fetched from its source.
#[utoipa::path(
    delete,
    path = "/api/v1/cache-bases/{base}",
    tag = "Machines",
    params(
        ("base" = String, Path, description = "Cache base file name")
    ),
    responses(
        (status = 204, description = "Cache base removed, or was not here"),
        (status = 400, description = "Invalid name, or cache disks disabled", body = ApiErrorResponse),
        (status = 409, description = "A machine is attached to the base", body = ApiErrorResponse),
    )
)]
pub async fn delete_cache_base(
    State(state): State<Arc<ApiState>>,
    Path(base): Path<String>,
) -> Result<axum::http::StatusCode, ApiError> {
    let dir = state.cache_disk_dir()?;
    crate::data::disk::validate_base_name(&base).map_err(ApiError::BadRequest)?;
    // Held so a create fetching this base cannot have it removed underneath.
    let fetch_lock = cache_base_fetch_lock(&base);
    let _fetching = fetch_lock.lock().await;
    let path = dir.join(&base);
    let db = state.db().clone();
    tokio::task::spawn_blocking(move || -> Result<(), ApiError> {
        // Base names are unique per cache disk version, so the name alone
        // identifies it however the path was spelled.
        let attached = crate::api::cache_base_budget::attached_bases(&db)?;
        if let Some(name) = path.file_name().and_then(|base| attached.get(base)) {
            return Err(ApiError::Conflict(format!(
                "cache base '{}' is attached to machine '{name}'",
                path.file_name().unwrap_or_default().to_string_lossy()
            )));
        }
        crate::data::disk::remove_base(&path)
            .map_err(|e| ApiError::internal(format!("remove {}: {e}", path.display())))
    })
    .await
    .map_err(|e| ApiError::internal(format!("task error: {e}")))??;
    Ok(axum::http::StatusCode::NO_CONTENT)
}

/// Make `path` durable, touching `progress` as its data reaches the disk.
///
/// One fsync of a freshly written base is a single long call: tens of
/// seconds on a worker, minutes on a slower disk, with nothing to show for it
/// until it returns, so a request's idle timeout gave up on a publish that was
/// only waiting on its sync. On Linux the data is written back a range at a
/// time first, so a disk that is slow but moving keeps the request alive and
/// one that has stopped still times it out.
fn sync_with_progress(
    path: &std::path::Path,
    progress: &crate::api::progress::Progress,
) -> std::io::Result<()> {
    let file = std::fs::File::open(path)?;
    #[cfg(target_os = "linux")]
    {
        use std::os::unix::io::AsRawFd;
        const STEP: u64 = 256 << 20;
        let length = file.metadata()?.len();
        let mut offset = 0;
        while offset < length {
            let step = STEP.min(length - offset);
            // SAFETY: the fd is open for the lifetime of `file`; no pointers.
            let rc = unsafe {
                libc::sync_file_range(
                    file.as_raw_fd(),
                    offset as libc::off64_t,
                    step as libc::off64_t,
                    libc::SYNC_FILE_RANGE_WAIT_BEFORE
                        | libc::SYNC_FILE_RANGE_WRITE
                        | libc::SYNC_FILE_RANGE_WAIT_AFTER,
                )
            };
            if rc != 0 {
                return Err(std::io::Error::last_os_error());
            }
            progress.touch();
            offset += step;
        }
    }
    file.sync_all()?;
    progress.touch();
    Ok(())
}

/// The SHA-256 of a file, as lowercase hex, touching `progress` as it reads.
fn file_sha256(
    path: &std::path::Path,
    progress: &crate::api::progress::Progress,
) -> Result<String, ApiError> {
    use std::io::Read;
    let mut file = std::fs::File::open(path)
        .map_err(|e| ApiError::internal(format!("open {}: {e}", path.display())))?;
    // ring's SHA-256 is the same digest at several times the speed of sha2's,
    // and this one pass over the whole base sets how long a publish takes.
    let mut hasher = ring::digest::Context::new(&ring::digest::SHA256);
    let mut buffer = vec![0_u8; 8 << 20];
    loop {
        let read = file
            .read(&mut buffer)
            .map_err(|e| ApiError::internal(format!("hash {}: {e}", path.display())))?;
        if read == 0 {
            break;
        }
        hasher.update(&buffer[..read]);
        progress.touch();
    }
    Ok(hex::encode(hasher.finish()))
}

/// Largest cache base a create may fetch.
const MAX_CACHE_BASE_BYTES: u64 = 512 << 30;

/// The lock a fetch of `base` holds, shared by every create that needs it.
pub(crate) fn cache_base_fetch_lock(base: &str) -> Arc<tokio::sync::Mutex<()>> {
    static LOCKS: std::sync::OnceLock<
        parking_lot::Mutex<std::collections::HashMap<String, Arc<tokio::sync::Mutex<()>>>>,
    > = std::sync::OnceLock::new();
    LOCKS
        .get_or_init(Default::default)
        .lock()
        .entry(base.to_string())
        .or_default()
        .clone()
}

/// Fetch a requested cache base this server does not have yet from its signed
/// source URL, verified against its SHA-256 before it appears under its name.
/// A base already present is used as is: bases are immutable by name.
async fn fetch_cache_base(
    state: &Arc<ApiState>,
    spec: &crate::api::types::CacheDiskSpec,
) -> Result<(), ApiError> {
    let dir = state.cache_disk_dir()?;
    crate::data::disk::validate_base_name(&spec.base).map_err(ApiError::BadRequest)?;
    let target = dir.join(&spec.base);
    if target.exists() {
        crate::api::cache_base_budget::mark_used(&target);
        return Ok(());
    }
    let Some(raw) = spec.source_url.as_deref() else {
        return Ok(());
    };
    let expected = spec
        .sha256
        .as_deref()
        .map(str::to_ascii_lowercase)
        .filter(|hex| hex.len() == 64 && hex.bytes().all(|b| b.is_ascii_hexdigit()))
        .ok_or_else(|| {
            ApiError::BadRequest("cacheDisk.sourceUrl needs a hex sha256 to verify against".into())
        })?;
    let url = checked_checkpoint_source(raw)?;
    // One download per base, in a task of its own: a create that needs a base
    // another create is already fetching waits for it instead of fetching it
    // again, and a create whose caller gave up waiting leaves the download
    // running, so the retry finds the base instead of starting over.
    let lock = cache_base_fetch_lock(&spec.base);
    let base = spec.base.clone();
    let fetch_state = state.clone();
    let fetch = tokio::spawn(async move {
        let _fetching = lock.lock_owned().await;
        if target.exists() {
            return Ok(());
        }
        // Under the lock no other fetch of this base runs in this server, so
        // any partial download of it left behind is abandoned.
        remove_abandoned_partials(&dir, &base);
        crate::api::cache_base_budget::make_room(&fetch_state).await;
        let client = reqwest::Client::builder()
            .redirect(reqwest::redirect::Policy::none())
            .connect_timeout(Duration::from_secs(30))
            .read_timeout(Duration::from_secs(120))
            .build()
            .map_err(|e| ApiError::internal(format!("build cache base fetch client: {e}")))?;
        let stamp = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map(|d| d.as_nanos())
            .unwrap_or_default();
        let partial =
            PartialDownload(dir.join(format!(".{base}.{}.{stamp}.partial", std::process::id())));
        let actual = crate::api::cache_base_fetch::download(
            &client,
            &url,
            &partial.0,
            MAX_CACHE_BASE_BYTES,
            Default::default(),
        )
        .await?;
        if actual != expected {
            return Err(ApiError::BadRequest(format!(
                "cache base sha256 is {actual}, expected {expected}"
            )));
        }
        match std::fs::hard_link(&partial.0, &target) {
            // Verified as it arrived, so a checkpoint of a machine on it need
            // not hash it again.
            Ok(()) => {
                crate::data::disk::record_base_digest(&target, &expected);
                drop(partial);
                crate::api::cache_base_budget::make_room(&fetch_state).await;
                Ok(())
            }
            // Another create fetched the same immutable base first.
            Err(e) if e.kind() == std::io::ErrorKind::AlreadyExists => Ok(()),
            Err(e) => Err(ApiError::internal(format!(
                "publish {}: {e}",
                target.display()
            ))),
        }
    });
    fetch
        .await
        .map_err(|e| ApiError::internal(format!("cache base fetch task: {e}")))?
}

/// A cache base download in progress, removed when the fetch ends however it
/// ends; a fetch that succeeded has linked it into place first.
struct PartialDownload(std::path::PathBuf);

impl Drop for PartialDownload {
    fn drop(&mut self) {
        let _ = std::fs::remove_file(&self.0);
    }
}

/// Remove partial downloads of `base` in `dir`: `.<base>.<pid>.<stamp>.partial`.
fn remove_abandoned_partials(dir: &std::path::Path, base: &str) {
    let Ok(entries) = std::fs::read_dir(dir) else {
        return;
    };
    let prefix = format!(".{base}.");
    for entry in entries.flatten() {
        let name = entry.file_name();
        let Some(name) = name.to_str() else {
            continue;
        };
        let is_partial_of_base = name
            .strip_prefix(&prefix)
            .and_then(|rest| rest.strip_suffix(".partial"))
            .and_then(|rest| rest.split_once('.'))
            .is_some_and(|(pid, stamp)| {
                !pid.is_empty()
                    && !stamp.is_empty()
                    && pid.bytes().all(|b| b.is_ascii_digit())
                    && stamp.bytes().all(|b| b.is_ascii_digit())
            });
        if is_partial_of_base {
            match std::fs::remove_file(entry.path()) {
                Ok(()) => tracing::info!(file = name, "removed an abandoned cache base download"),
                Err(e) => {
                    tracing::warn!(file = name, error = %e, "could not remove an abandoned cache base download")
                }
            }
        }
    }
}

/// A published base still under its hidden partial name: removed on drop
/// unless [`StagedBase::install`] gave it its real name.
struct StagedBase(std::path::PathBuf);

impl StagedBase {
    fn path(&self) -> &std::path::Path {
        &self.0
    }

    /// Link the staged file to `dir/base`, which fails rather than replace a
    /// base that appeared meanwhile, and record its digest. Returns its size.
    fn install(self, dir: &std::path::Path, base: &str, digest: &str) -> Result<u64, ApiError> {
        let target = dir.join(base);
        std::fs::hard_link(&self.0, &target).map_err(|e| {
            if e.kind() == std::io::ErrorKind::AlreadyExists {
                ApiError::Conflict(format!(
                    "cache base '{base}' already exists; publish each version under a new name"
                ))
            } else {
                ApiError::internal(format!("publish {}: {e}", target.display()))
            }
        })?;
        crate::data::disk::record_base_digest(&target, digest);
        std::fs::File::open(dir)
            .and_then(|d| d.sync_all())
            .map_err(|e| ApiError::internal(format!("sync {}: {e}", dir.display())))?;
        std::fs::metadata(&target)
            .map(|meta| meta.len())
            .map_err(|e| ApiError::internal(format!("stat {}: {e}", target.display())))
    }
}

impl Drop for StagedBase {
    fn drop(&mut self) {
        let _ = std::fs::remove_file(&self.0);
    }
}

/// Flatten `top` into a hidden partial file in `dir`, named for `base`.
#[cfg(any(target_os = "linux", target_os = "macos"))]
fn flatten_staged(
    top: &std::path::Path,
    dir: &std::path::Path,
    base: &str,
    progress: &crate::api::progress::Progress,
) -> Result<StagedBase, ApiError> {
    let stamp = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_nanos())
        .unwrap_or_default();
    let staged = StagedBase(dir.join(format!(".{base}.{}.{stamp}.partial", std::process::id())));
    crate::agent::fork::flatten_standalone(top, staged.path(), &|| progress.touch())
        .map_err(ApiError::from)?;
    Ok(staged)
}

#[cfg(not(any(target_os = "linux", target_os = "macos")))]
fn flatten_staged(
    _top: &std::path::Path,
    _dir: &std::path::Path,
    _base: &str,
    _progress: &crate::api::progress::Progress,
) -> Result<StagedBase, ApiError> {
    Err(ApiError::BadRequest(
        "cache disks are not supported on this host".into(),
    ))
}

/// Amend a machine's egress allow list. A stopped machine takes any change; a
/// running one takes changes that keep an allow list in force, effective for
/// its next connection or lookup.
#[utoipa::path(
    post,
    path = "/api/v1/machines/{name}/egress",
    tag = "Machines",
    params(
        ("name" = String, Path, description = "Machine name")
    ),
    request_body = UpdateEgressRequest,
    responses(
        (status = 200, description = "Egress updated", body = MachineInfo),
        (status = 400, description = "Invalid request", body = ApiErrorResponse),
        (status = 404, description = "Machine not found", body = ApiErrorResponse),
        (status = 409, description = "Change needs the machine stopped", body = ApiErrorResponse),
        (status = 500, description = "Update failed", body = ApiErrorResponse)
    )
)]
pub async fn update_machine_egress(
    State(state): State<Arc<ApiState>>,
    Path(name): Path<String>,
    Json(req): Json<UpdateEgressRequest>,
) -> Result<Json<MachineInfo>, ApiError> {
    // Serialize against start/stop/delete on the same machine, as resize does:
    // the stopped check below is only meaningful under the lifecycle lock.
    let lifecycle = state.lifecycle_lock(&name);
    let _guard = lifecycle.lock_owned().await;

    let record = state
        .lookup_vm(&name)
        .await?
        .ok_or_else(|| ApiError::NotFound(format!("machine '{}' not found", name)))?;

    let actual_state = record.actual_state();
    let running = match actual_state {
        RecordState::Stopped | RecordState::Created => false,
        RecordState::Running => true,
        _ => {
            return Err(ApiError::Conflict(format!(
                "machine '{}' must be stopped or running before its egress changes. Current state: {:?}",
                name, actual_state
            )));
        }
    };
    let (record, _egress_lock) = if running {
        let lock = crate::agent::lock_live_egress(&name)?;
        let fresh = state
            .lookup_vm(&name)
            .await?
            .ok_or_else(|| ApiError::NotFound(format!("machine '{}' not found", name)))?;
        (fresh, Some(lock))
    } else {
        (record, None)
    };

    // Normalize CIDRs with the CLI's parser, so a malformed entry is a 400
    // here instead of a silently narrower or wider policy later.
    let normalize = |cidrs: &[String]| -> Result<Vec<String>, ApiError> {
        cidrs
            .iter()
            .map(|c| crate::smolfile::parse_cidr(c))
            .collect::<Result<Vec<_>, _>>()
            .map_err(ApiError::BadRequest)
    };
    let parse_udp = |specs: &[String]| -> Result<Vec<smolvm_protocol::EgressRule>, ApiError> {
        specs
            .iter()
            .map(|spec| crate::smolfile::parse_allow_udp(spec))
            .collect::<Result<Vec<_>, _>>()
            .map_err(ApiError::BadRequest)
    };
    let update = crate::config::EgressUpdate {
        allow_hosts: req.allow_hosts,
        allow_host_patterns: req.allow_host_patterns,
        allow_cidrs: normalize(&req.allow_cidrs)?,
        remove_allow_hosts: req.remove_allow_hosts,
        remove_allow_cidrs: normalize(&req.remove_allow_cidrs)?,
        outbound_localhost_only: req.outbound_localhost_only,
        allow_all: req.allow_all,
        reset_allow_list: req.reset_allow_list,
        allow_udp: parse_udp(&req.allow_udp)?,
        remove_allow_udp: parse_udp(&req.remove_allow_udp)?,
    };
    let next = record
        .updated_egress(&update)
        .map_err(|error| match error {
            crate::Error::Config { .. } => ApiError::BadRequest(error.to_string()),
            other => ApiError::from(other),
        })?
        .ok_or_else(|| ApiError::BadRequest("request contains no egress changes".into()))?;
    let rules_change = next.egress_rules != record.egress_rules;

    if running {
        record
            .check_live_egress(&next)
            .map_err(|error| ApiError::Conflict(error.to_string()))?;
        crate::agent::apply_live_egress_policy(&name, &next, rules_change)?;
    }
    let updated = {
        let next = next.clone();
        state
            .update_vm(&name, move |r| {
                r.network = next.network;
                r.allowed_cidrs = next.allowed_cidrs.clone();
                r.dns_filter_hosts = next.dns_filter_hosts.clone();
                r.egress_rules = next.egress_rules.clone();
            })
            .await
    };
    let updated = updated.and_then(|updated| {
        updated.ok_or_else(|| {
            ApiError::NotFound(format!("machine '{}' disappeared during update", name))
        })
    });
    let updated = match updated {
        Ok(updated) => updated,
        Err(error) => {
            // The record keeps the old allow list, so the running machine must too.
            if running {
                let _ = crate::agent::apply_live_egress_policy(&name, &record, rules_change);
            }
            return Err(error);
        }
    };

    Ok(Json(record_to_info(&name, &updated)))
}

/// Where the export subprocess writes its executable stub. `pack create -o X` derives the
/// real artifact as `X.smolmachine`, so this must NOT already end in that extension or the
/// CLI rejects it outright.
fn export_stub_path(dir: &std::path::Path) -> std::path::PathBuf {
    dir.join("export")
}

/// Export a stopped machine to a `.smolmachine` and push it directly to a
/// registry.
///
/// The machine must be stopped: exporting a running VM would snapshot an
/// inconsistent overlay. The `.smolmachine` is produced by subprocessing this
/// same binary's `pack create --from-vm <name>` (the tested path that boots a
/// helper VM to export the container overlay), then streamed to the registry
/// with the control-plane-minted, pre-scoped OCI bearer.
#[utoipa::path(
    post,
    path = "/api/v1/machines/{name}/export",
    tag = "Machines",
    params(
        ("name" = String, Path, description = "Machine name")
    ),
    request_body = ExportRequest,
    responses(
        (status = 200, description = "Machine exported and pushed", body = ExportResponse),
        (status = 404, description = "Machine not found", body = ApiErrorResponse),
        (status = 409, description = "Machine is not stopped", body = ApiErrorResponse),
        (status = 500, description = "Export or push failed", body = ApiErrorResponse)
    )
)]
pub async fn export_machine(
    State(state): State<Arc<ApiState>>,
    Path(id): Path<String>,
    Json(req): Json<ExportRequest>,
) -> Result<Json<ExportResponse>, ApiError> {
    // Hold the per-machine lifecycle lock across BOTH the stopped-check and the
    // pack export below so a concurrent start cannot boot the VM in between and
    // leave `pack create --from-vm` reading disks that are being written — the
    // inconsistent-snapshot race the stopped-check alone can't close (start
    // acquires this same lock). Mirrors start/stop/delete/resize.
    let lifecycle = state.lifecycle_lock(&id);
    let _guard = lifecycle.lock().await;

    // Resolve the machine record; the path id is the machine name in this API.
    let record = state
        .lookup_vm(&id)
        .await?
        .ok_or_else(|| ApiError::NotFound(format!("machine '{}' not found", id)))?;
    let name = id;

    // Require STOPPED via the shared probe so a running VM (whose overlay is
    // still being written) can't be snapshotted into an inconsistent image.
    let name_probe = name.clone();
    let record_probe = record.clone();
    let resolved =
        tokio::task::spawn_blocking(move || resolve_machine_state(&name_probe, &record_probe))
            .await
            .map_err(|e| ApiError::internal(format!("task error: {}", e)))?;
    if resolved != RecordState::Stopped {
        return Err(ApiError::Conflict(
            "machine must be stopped to export".to_string(),
        ));
    }

    // Build the .smolmachine by subprocessing this binary's tested export path.
    // The serve handlers and the pack CLI share the same on-disk SmolvmDb, so
    // `pack create --from-vm <name>` sees the serve-managed machine.
    // `pack create -o X` names the executable STUB and derives the sidecar as
    // X.smolmachine, rejecting an `-o` that already carries that extension. Stage both
    // inside a temp dir so the sidecar is cleaned up with the stub rather than left behind.
    let tmp_dir =
        tempfile::tempdir().map_err(|e| ApiError::internal(format!("create temp dir: {}", e)))?;
    let tmp_path = export_stub_path(tmp_dir.path());
    let exe =
        std::env::current_exe().map_err(|e| ApiError::internal(format!("current_exe: {}", e)))?;

    let output = tokio::process::Command::new(&exe)
        .args([
            "pack",
            "create",
            "--from-vm",
            &name,
            "-o",
            &tmp_path.to_string_lossy(),
        ])
        .output()
        .await
        .map_err(|e| ApiError::internal(format!("spawn pack export: {}", e)))?;
    if !output.status.success() {
        let stderr = String::from_utf8_lossy(&output.stderr);
        return Err(ApiError::internal(format!(
            "pack export failed: {}",
            stderr
        )));
    }

    // `pack create -o X` emits an executable stub at X and the actual pack data
    // at X.smolmachine (the sidecar carrying the SMOLPACK footer). The manifest
    // and the pushed blob must come from the SIDECAR — reading the stub fails
    // with "invalid magic". Resolve it exactly like `smol pack push` does, with
    // the pre-sidecar single-file layout as the fallback.
    let sidecar = smolvm_pack::sidecar_path_for(&tmp_path);
    let artifact = if sidecar.exists() {
        sidecar.clone()
    } else {
        tmp_path.clone()
    };

    // Read back the PackManifest from the sidecar footer for the response.
    let manifest = smolvm_pack::read_manifest_from_sidecar(&artifact)
        .map_err(|e| ApiError::internal(format!("read exported manifest: {}", e)))?;
    let manifest_json = serde_json::to_string(&manifest)
        .map_err(|e| ApiError::internal(format!("serialize manifest: {}", e)))?;

    // Push directly to the registry using the pre-scoped bearer token. The
    // control mints a tenant-scoped OCI bearer, so use the raw token path
    // (.with_token), not /v2/auth.
    let base_url = if smolvm_registry::is_local_registry(&req.reference_host) {
        format!("http://{}", req.reference_host)
    } else {
        format!("https://{}", req.reference_host)
    };
    let client = smolvm_registry::RegistryClient::new(base_url).with_token(req.push_token.clone());

    let result = smolvm_registry::push(&client, &req.repo, &req.tag, &artifact)
        .await
        .map_err(|e| ApiError::internal(format!("registry push failed: {}", e)))?;

    // The tempfile guard only removes the stub path; clean the sidecar too so
    // exports don't accumulate multi-GB files in /tmp.
    let _ = std::fs::remove_file(&sidecar);

    // tmp drops here, deleting the stub.
    Ok(Json(ExportResponse {
        digest: result.manifest_digest,
        size_bytes: result.layer_size,
        platform: result.platform,
        manifest: manifest_json,
    }))
}

/// True if `host` is a loopback, link-local, or private-range address — an
/// SSRF-prone pull destination on a fleet node (its own `127.0.0.1` services, the
/// cloud metadata endpoint at `169.254.169.254`, or a neighbour on the private
/// network). Hostnames that are not IP literals return false (a DNS-rebind to a
/// private address is a residual not covered here).
fn is_ssrf_prone_registry_host(host: &str) -> bool {
    // localhost / 127.0.0.0/8 / ::1 / 0.0.0.0 — reuse the registry classifier.
    if smolvm_registry::is_local_registry(host) {
        return true;
    }
    // Extract the bare host (strip IPv6 brackets and any :port), then classify it
    // only if it parses as an IP literal.
    let bare = if let Some(rest) = host.strip_prefix('[') {
        rest.split(']').next().unwrap_or(rest)
    } else if host.matches(':').count() == 1 {
        host.split(':').next().unwrap_or(host)
    } else {
        host
    };
    match bare.parse::<std::net::IpAddr>() {
        Ok(std::net::IpAddr::V4(v4)) => {
            v4.is_private() || v4.is_loopback() || v4.is_link_local() || v4.is_unspecified()
        }
        Ok(std::net::IpAddr::V6(v6)) => {
            let first = v6.segments()[0];
            v6.is_loopback()
                || v6.is_unspecified()
                || (first & 0xffc0) == 0xfe80 // link-local fe80::/10
                || (first & 0xfe00) == 0xfc00 // unique-local fc00::/7
        }
        Err(_) => false,
    }
}

/// The `.smolmachine` a checkpoint's image layers came from: this host's copy
/// when it has one, otherwise pulled from the registry reference the checkpoint
/// recorded and checked to be the very same artifact.
async fn checkpoint_pack_sidecar(
    packed: &smolvm_pack::format::CheckpointPackedLayers,
    identity_token: Option<&str>,
    blob_peers: &[String],
) -> Result<std::path::PathBuf, ApiError> {
    if let Some(path) = crate::portable_checkpoint::cached_checkpoint_pack(packed) {
        return Ok(path);
    }
    let reference = packed.registry_ref.as_deref().ok_or_else(|| {
        ApiError::BadRequest(format!(
            "this checkpoint mounts image layers from pack sha256:{}, which this host does \
             not have, and it records no registry reference to fetch it from",
            packed.artifact_sha256
        ))
    })?;
    let pulled = pull_smolmachine(reference, identity_token, blob_peers).await?;
    let expected = format!("sha256:{}", packed.artifact_sha256);
    if pulled.digest != expected {
        return Err(ApiError::Conflict(format!(
            "{reference} now resolves to {} but this checkpoint was captured with {expected}; \
             the pack it needs is no longer published under that reference",
            pulled.digest
        )));
    }
    Ok(pulled.path)
}

async fn pull_from_registry(
    registry_ref: &str,
    identity_token: Option<&str>,
    blob_peers: &[String],
) -> Result<String, ApiError> {
    let result = pull_smolmachine(registry_ref, identity_token, blob_peers).await?;
    tracing::info!(path = %result.path.display(), cached = result.cached, "pull complete");
    Ok(result.path.to_string_lossy().into_owned())
}

/// Resolve `registry_ref` and pull its `.smolmachine` layer into this node's
/// blob cache, returning the full [`smolvm_registry::PullResult`].
///
/// Split out of [`pull_from_registry`] so the pre-warm endpoint
/// ([`crate::api::handlers::prewarm`]) reaches the registry through byte-for-byte
/// the same reference parsing, mirror lookup, credential precedence, cache, and
/// peer fallback that a real create uses. A warm path that resolved references
/// even slightly differently would cache a blob under one key and leave the
/// create looking for another — a silent no-op that still looks like a success.
pub(crate) async fn pull_smolmachine(
    registry_ref: &str,
    identity_token: Option<&str>,
    blob_peers: &[String],
) -> Result<smolvm_registry::PullResult, ApiError> {
    let parsed = crate::registry::Reference::parse(registry_ref)
        .map_err(|e| ApiError::BadRequest(format!("invalid registry reference: {}", e)))?;

    let settings = crate::settings::SmolSettings::load()
        .map_err(|e| ApiError::internal(format!("load settings: {}", e)))?;

    let effective_registry = settings
        .machines
        .get_mirror(&parsed.registry)
        .unwrap_or(&parsed.registry);
    let api_host = match effective_registry {
        "docker.io" => "registry-1.docker.io",
        h => h,
    };

    // A control-plane tenant pull (identity_token present) must never target a
    // loopback/link-local/private-range host: on a fleet node that is an SSRF
    // pivot into node-local services, not a real registry. Local dev (no token)
    // is unaffected, and legitimate tenant pulls resolve public registries.
    if identity_token.is_some() && is_ssrf_prone_registry_host(api_host) {
        return Err(ApiError::BadRequest(format!(
            "registry host '{}' is a private/loopback address and is not permitted for tenant image pulls",
            api_host
        )));
    }

    let base_url = if smolvm_registry::is_local_registry(api_host) {
        format!("http://{}", api_host)
    } else {
        format!("https://{}", api_host)
    };

    let mut client = smolvm_registry::RegistryClient::new(base_url);

    // A request-supplied identity token (the control plane's short-lived,
    // tenant-scoped pull token) takes precedence over any persisted credential.
    if let Some(token) = identity_token {
        client = client.with_identity_token(token.to_string());
    } else if let Some(entry) = settings.machines.registries.get(effective_registry) {
        if let Some(ref token) = entry.identity_token {
            client = client.with_identity_token(token.clone());
        }
    }

    let cache = smolvm_registry::BlobCache::open_default()
        .map_err(|e| ApiError::internal(format!("blob cache: {}", e)))?;

    let repo = parsed.repository();
    let tag_or_digest = registry_reference_tag_or_digest(&parsed);

    tracing::info!(
        registry_ref = %registry_ref,
        repo = %repo,
        reference = %tag_or_digest,
        "pulling .smolmachine from registry"
    );

    let result = smolvm_registry::pull(&client, &repo, tag_or_digest, None, &cache, blob_peers)
        .await
        .map_err(|e| match &e {
            // A missing image/manifest is the caller's mistake (typo'd ref, or a
            // bare name that resolved to an empty repo) — surface it as 404, not a
            // 500. A 500 here misreports a client error as a server fault and
            // pollutes the fleet error-rate SLO on every bad reference.
            smolvm_registry::RegistryError::BlobNotFound(_)
            | smolvm_registry::RegistryError::ApiError { status: 404, .. } => {
                ApiError::NotFound(format!("image not found in registry: {}", e))
            }
            _ => ApiError::internal(format!("registry pull failed: {}", e)),
        })?;

    Ok(result)
}

fn registry_reference_tag_or_digest(parsed: &crate::registry::Reference) -> &str {
    parsed
        .digest
        .as_deref()
        .or(parsed.tag.as_deref())
        .unwrap_or("latest")
}

/// The machine a create request asks for, as the spec every creation path
/// resolves ([`crate::machine_spec::resolve`]). Every request field is named,
/// so a new one does not compile until it reaches the spec or is named as
/// something else (the source, the name). `cache_disk` is the request's cache
/// disk, already fetched and resolved on this server.
pub(crate) fn create_spec_from_request(
    req: &CreateMachineRequest,
    cache_disk: Option<crate::data::disk::CacheDisk>,
) -> Result<crate::machine_spec::CreateSpec, ApiError> {
    let CreateMachineRequest {
        // The machine's name, not an option of it.
        name: _,
        cpus,
        mem,
        mounts,
        disk_volumes,
        ports,
        network,
        gpu,
        cuda,
        nested_virt,
        auto_graph,
        entrypoint,
        cmd,
        docker_socket,
        stop_signal,
        stop_timeout_secs,
        storage_gb,
        overlay_gb,
        block_io,
        disk_durability,
        // Resolved by the caller into `cache_disk`.
        cache_disk: _,
        allowed_cidrs,
        egress_rules,
        allowed_hosts,
        credentials,
        network_backend,
        guest_subnet,
        restart,
        // The source, and how to fetch it.
        image: _,
        from: _,
        registry_ref: _,
        registry_identity_token: _,
        blob_peers: _,
        secrets,
        env,
        workdir,
    } = req;

    // Remote volumes (`s3://` sources) apart from host mounts, mirroring the
    // CLI's -v handling; host mount paths are validated here.
    let mut remote_volumes = Vec::new();
    let mut host_mounts = Vec::new();
    for mount in mounts {
        if crate::remote_volume::is_remote_source(&mount.source) {
            remote_volumes.push(
                crate::remote_volume::from_parts(&mount.source, &mount.target, mount.readonly)
                    .map_err(|e| ApiError::BadRequest(e.to_string()))?,
            );
        } else {
            host_mounts
                .push(HostMount::try_from(mount).map_err(|e| ApiError::BadRequest(e.to_string()))?);
        }
    }
    // Disk volumes take the same lone guest paths as the CLI's `-v PATH`.
    let (not_guest_paths, disk_volumes) =
        crate::data::storage::split_disk_volume_specs(disk_volumes)
            .map_err(|e| ApiError::BadRequest(e.to_string()))?;
    if let Some(spec) = not_guest_paths.first() {
        return Err(ApiError::BadRequest(format!(
            "diskVolumes: {spec} is not an absolute guest path"
        )));
    }
    // Untrusted scope rejects every source kind, so any non-empty `secrets`
    // map on the API surface is refused; secrets are configured locally.
    crate::api::handlers::validate_request_secrets(secrets)?;
    crate::api::handlers::validate_request_env(env)?;
    let mut env = crate::api::types::EnvVar::to_tuples(env);
    if *auto_graph {
        crate::util::enable_cuda_auto_graph_env(&mut env);
    }
    // A request workload replaces the source's entrypoint and command together.
    let (entrypoint, cmd) = if entrypoint.is_empty() && cmd.is_empty() {
        (None, None)
    } else {
        (Some(entrypoint.clone()), Some(cmd.clone()))
    };
    let restart_policy = restart
        .as_ref()
        .map(|spec| spec.policy.as_deref().unwrap_or("never").parse())
        .transpose()
        .map_err(|e: String| ApiError::BadRequest(e))?;
    Ok(crate::machine_spec::CreateSpec {
        entrypoint,
        cmd,
        env,
        workdir: workdir.clone(),
        secret_refs: secrets.clone(),
        restart_policy,
        restart_max_retries: restart.as_ref().map(|spec| spec.max_retries.unwrap_or(0)),
        stop_signal: stop_signal.clone(),
        stop_timeout_secs: *stop_timeout_secs,
        cpus: *cpus,
        mem: *mem,
        storage_gb: *storage_gb,
        overlay_gb: *overlay_gb,
        block_io: *block_io,
        disk_durability: *disk_durability,
        cache_disk,
        mounts: host_mounts,
        remote_volumes,
        disk_volumes,
        net: *network,
        network_backend: *network_backend,
        guest_subnet: guest_subnet.clone(),
        ports: ports.iter().map(PortMapping::from).collect(),
        allowed_cidrs: allowed_cidrs.clone(),
        allowed_hosts: allowed_hosts.clone(),
        egress_rules: egress_rules.clone(),
        credentials: credentials.clone(),
        // Values arrive over the API, never from this server's environment.
        credentials_supplied_only: true,
        gpu: *gpu,
        nested_virt: *nested_virt,
        cuda: *cuda || *auto_graph,
        docker_socket: *docker_socket,
        ..Default::default()
    })
}

#[cfg(test)]
mod tests {

    use super::*;
    use crate::db::SmolvmDb;
    use std::sync::atomic::{AtomicUsize, Ordering};
    use tempfile::TempDir;

    #[test]
    fn only_partial_downloads_of_the_base_are_removed() {
        let dir = TempDir::new().unwrap();
        let names = [
            ".cdisk-1-v1.qcow2.4242.1791794701210442779.partial",
            ".cdisk-1-v1.qcow2.17.99.partial",
            ".cdisk-1-v12.qcow2.4242.1791794701210442779.partial",
            ".cdisk-1-v1.qcow2.sha256",
            "cdisk-1-v1.qcow2",
            ".cdisk-1-v1.qcow2.oops.partial",
        ];
        for name in names {
            std::fs::write(dir.path().join(name), b"x").unwrap();
        }
        remove_abandoned_partials(dir.path(), "cdisk-1-v1.qcow2");
        let mut left: Vec<String> = std::fs::read_dir(dir.path())
            .unwrap()
            .map(|e| e.unwrap().file_name().into_string().unwrap())
            .collect();
        left.sort();
        assert_eq!(
            left,
            [
                ".cdisk-1-v1.qcow2.oops.partial",
                ".cdisk-1-v1.qcow2.sha256",
                ".cdisk-1-v12.qcow2.4242.1791794701210442779.partial",
                "cdisk-1-v1.qcow2",
            ]
        );
    }

    fn branch_request(json: serde_json::Value) -> ForkRequest {
        serde_json::from_value(json).unwrap()
    }

    #[test]
    fn branches_with_pinned_ports_share_their_source_transaction() {
        let ported = branch_request(serde_json::json!({
            "name": "child",
            "ports": [{"host": 31028, "guest": 4318}]
        }));
        assert!(coalescable_branch(&ported));
        let held = branch_request(serde_json::json!({"name": "slot", "hold": true}));
        assert!(!coalescable_branch(&held));
    }

    #[test]
    fn pinned_ports_reject_port_zero_and_a_repeated_host_port() {
        assert!(validate_pinned_ports(&[(31028, 4318), (31029, 8080)]).is_ok());
        assert!(matches!(
            validate_pinned_ports(&[(0, 4318)]),
            Err(ApiError::BadRequest(_))
        ));
        assert!(matches!(
            validate_pinned_ports(&[(31028, 0)]),
            Err(ApiError::BadRequest(_))
        ));
        assert!(matches!(
            validate_pinned_ports(&[(31028, 4318), (31028, 8080)]),
            Err(ApiError::BadRequest(_))
        ));
    }

    #[tokio::test]
    async fn api_local_images_need_the_local_image_dir_and_stay_inside_it() {
        let (_db_dir, state) = setup_test_state();
        let bad = |result: Result<String, ApiError>| matches!(result, Err(ApiError::BadRequest(_)));
        assert_eq!(
            resolve_api_image(&state, "alpine:3.20".into())
                .await
                .unwrap(),
            "alpine:3.20"
        );
        assert!(bad(resolve_api_image(&state, "-".into()).await));

        let images = TempDir::new().unwrap();
        let rootfs = images.path().join("rootfs");
        std::fs::create_dir(&rootfs).unwrap();
        let outside = TempDir::new().unwrap();
        #[cfg(unix)]
        std::os::unix::fs::symlink(outside.path(), images.path().join("escape")).unwrap();

        // No --local-image-dir: every local path is refused.
        assert!(bad(
            resolve_api_image(&state, rootfs.display().to_string()).await
        ));

        state.set_local_image_dir(Some(images.path().canonicalize().unwrap()));
        let accepted = resolve_api_image(&state, rootfs.display().to_string())
            .await
            .unwrap();
        assert_eq!(
            accepted,
            format!("local-dir:{}", rootfs.canonicalize().unwrap().display())
        );
        for refused in [
            "/".to_string(),
            outside.path().display().to_string(),
            format!("{}/../", images.path().display()),
            images.path().join("escape").display().to_string(),
            images.path().join("missing.tar").display().to_string(),
            format!("local-dir:{}", rootfs.display()),
            "local-dir:/".to_string(),
            "local:../../..".to_string(),
        ] {
            assert!(
                bad(resolve_api_image(&state, refused.clone()).await),
                "{refused} must be refused"
            );
        }
    }

    #[test]
    fn start_body_is_optional_even_with_a_json_content_type() {
        use crate::api::types::StartMachineRequest;
        let json = {
            let mut headers = axum::http::HeaderMap::new();
            headers.insert(header::CONTENT_TYPE, "application/json".parse().unwrap());
            headers
        };
        let none = axum::http::HeaderMap::new();
        for (headers, body) in [
            (&json, ""),
            (&json, " \n"),
            (&none, ""),
            (&none, "not json"),
        ] {
            let request: StartMachineRequest =
                optional_json_body(headers, body.as_bytes()).unwrap();
            assert!(request.registry_auth.is_none() && request.egress_interceptor.is_none());
        }
        assert!(optional_json_body::<StartMachineRequest>(&json, b"{}").is_ok());
        assert!(matches!(
            optional_json_body::<StartMachineRequest>(&json, b"{not json"),
            Err(ApiError::BadRequest(_))
        ));
    }

    #[test]
    fn start_options_in_the_body_are_taken_like_the_query_string() {
        use crate::api::types::StartMachineRequest;
        let json = {
            let mut headers = axum::http::HeaderMap::new();
            headers.insert(header::CONTENT_TYPE, "application/json".parse().unwrap());
            headers
        };
        let body = |text: &str| -> StartMachineRequest {
            optional_json_body(&json, text.as_bytes()).unwrap()
        };

        let start = StartMachineQuery::default().with_body(&body(r#"{"branchable":true}"#));
        assert!(start.forkable);
        let start = StartMachineQuery::default().with_body(&body(r#"{"forkable":true}"#));
        assert!(start.forkable);
        let start = StartMachineQuery::default()
            .with_body(&body(r#"{"branchPoolSize":4,"cudaVramLimitMib":2048}"#));
        assert_eq!(start.fork_pool_size, Some(4));
        assert_eq!(start.cuda_vram_limit_mib, Some(2048));

        // The query string wins, and an empty body changes nothing.
        let query = StartMachineQuery {
            forkable: true,
            fork_pool_size: Some(2),
            cuda_vram_limit_mib: None,
        };
        let start = query.with_body(&body(r#"{"branchable":false,"branchPoolSize":8}"#));
        assert!(start.forkable);
        assert_eq!(start.fork_pool_size, Some(2));
        let start = StartMachineQuery::default().with_body(&body("{}"));
        assert!(!start.forkable && start.fork_pool_size.is_none());

        // Unknown fields stay tolerated for an older node.
        assert!(!body(r#"{"someNewerField":1}"#).branchable);
    }

    #[test]
    fn machine_response_reports_resolved_image_for_registry_binding() {
        let mut record = VmRecord::new("image-contract".into(), 1, 512, vec![], vec![], false);
        let bare = serde_json::to_value(record_to_info("image-contract", &record)).unwrap();
        assert!(bare.get("image").is_none());
        for image in [
            "registry.smolmachines.com/tenants/example/app:latest",
            "ghcr.io/example/app:latest",
        ] {
            record.image = Some(image.into());
            let response = serde_json::to_value(record_to_info("image-contract", &record)).unwrap();
            assert_eq!(response["image"], image);
            let manager = AgentManager::for_vm("image-contract").unwrap();
            let entry = machine_entry_from_record(&record, manager);
            let cached = serde_json::to_value(crate::api::state::machine_entry_to_info(
                "image-contract".into(),
                &entry,
            ))
            .unwrap();
            assert_eq!(cached["image"], image);
        }
    }

    #[tokio::test]
    async fn bounded_futures_stream_results_without_exceeding_the_limit() {
        const TOTAL: usize = 8;
        const WIDTH: usize = 4;

        let active = Arc::new(AtomicUsize::new(0));
        let peak = Arc::new(AtomicUsize::new(0));
        let gate = Arc::new(tokio::sync::Semaphore::new(0));
        let (started_tx, mut started_rx) = tokio::sync::watch::channel(0usize);
        let jobs = (0..TOTAL)
            .map(|index| {
                let active = active.clone();
                let peak = peak.clone();
                let gate = gate.clone();
                let started_tx = started_tx.clone();
                async move {
                    let now_active = active.fetch_add(1, Ordering::SeqCst) + 1;
                    peak.fetch_max(now_active, Ordering::SeqCst);
                    started_tx.send_modify(|started| *started += 1);
                    let permit = gate.acquire().await.expect("test gate closed");
                    permit.forget();
                    active.fetch_sub(1, Ordering::SeqCst);
                    index
                }
            })
            .collect::<Vec<_>>();
        drop(started_tx);

        let (result_tx, mut result_rx) = tokio::sync::mpsc::unbounded_channel();
        let runner = tokio::spawn(async move {
            run_bounded_futures(jobs, WIDTH, move |result| {
                result_tx.send(result).expect("result receiver open");
                true
            })
            .await
        });

        while *started_rx.borrow() < WIDTH {
            started_rx.changed().await.expect("workers still pending");
        }
        assert_eq!(*started_rx.borrow(), WIDTH);
        assert_eq!(active.load(Ordering::SeqCst), WIDTH);
        assert!(!runner.is_finished());

        gate.add_permits(1);
        let first = result_rx.recv().await.expect("first result");
        assert!(first < TOTAL);
        while *started_rx.borrow() < WIDTH + 1 {
            started_rx.changed().await.expect("workers still pending");
        }
        assert_eq!(active.load(Ordering::SeqCst), WIDTH);

        gate.add_permits(TOTAL);
        let mut received = 1;
        while received < TOTAL {
            result_rx.recv().await.expect("remaining result");
            received += 1;
        }
        assert!(runner.await.expect("runner task"));
        assert_eq!(peak.load(Ordering::SeqCst), WIDTH);
        assert_eq!(active.load(Ordering::SeqCst), 0);
    }

    #[tokio::test]
    async fn boot_slots_release_while_prior_workers_wait_for_readiness() {
        const TOTAL: usize = 8;
        const WIDTH: usize = 2;

        let boot_slots = Arc::new(tokio::sync::Semaphore::new(WIDTH));
        let boot_release = Arc::new(tokio::sync::Semaphore::new(0));
        let readiness_release = Arc::new(tokio::sync::Semaphore::new(0));
        let active = Arc::new(AtomicUsize::new(0));
        let peak = Arc::new(AtomicUsize::new(0));
        let (started_tx, mut started_rx) = tokio::sync::watch::channel(0usize);
        let jobs = (0..TOTAL)
            .map(|index| {
                let boot_slots = boot_slots.clone();
                let boot_release = boot_release.clone();
                let readiness_release = readiness_release.clone();
                let active = active.clone();
                let peak = peak.clone();
                let started_tx = started_tx.clone();
                async move {
                    let boot_permit = boot_slots.acquire_owned().await.expect("scheduler open");
                    let now_active = active.fetch_add(1, Ordering::SeqCst) + 1;
                    peak.fetch_max(now_active, Ordering::SeqCst);
                    started_tx.send_modify(|started| *started += 1);

                    let permit = boot_release.acquire().await.expect("test gate open");
                    permit.forget();
                    active.fetch_sub(1, Ordering::SeqCst);
                    drop(boot_permit);

                    let permit = readiness_release
                        .acquire()
                        .await
                        .expect("readiness gate open");
                    permit.forget();
                    index
                }
            })
            .collect::<Vec<_>>();
        drop(started_tx);

        let (result_tx, mut result_rx) = tokio::sync::mpsc::unbounded_channel();
        let runner = tokio::spawn(async move {
            run_bounded_futures(jobs, TOTAL, move |result| {
                result_tx.send(result).expect("result receiver open");
                true
            })
            .await
        });

        for expected in (WIDTH..=TOTAL).step_by(WIDTH) {
            while *started_rx.borrow() < expected {
                started_rx.changed().await.expect("boots still pending");
            }
            assert_eq!(active.load(Ordering::SeqCst), WIDTH);
            boot_release.add_permits(WIDTH);
        }
        while active.load(Ordering::SeqCst) != 0 {
            tokio::task::yield_now().await;
        }
        assert!(!runner.is_finished());
        assert_eq!(peak.load(Ordering::SeqCst), WIDTH);

        readiness_release.add_permits(TOTAL);
        for _ in 0..TOTAL {
            result_rx.recv().await.expect("remaining result");
        }
        assert!(runner.await.expect("runner task"));
    }

    #[tokio::test]
    async fn shared_boot_slots_bound_independent_batches() {
        const WIDTH: usize = 2;
        const PER_BATCH: usize = 4;

        let boot_slots = Arc::new(tokio::sync::Semaphore::new(WIDTH));
        let release = Arc::new(tokio::sync::Semaphore::new(0));
        let active = Arc::new(AtomicUsize::new(0));
        let peak = Arc::new(AtomicUsize::new(0));
        let (started_tx, mut started_rx) = tokio::sync::watch::channel(0usize);
        let build_batch = |offset| {
            (0..PER_BATCH)
                .map(|index| {
                    let boot_slots = boot_slots.clone();
                    let release = release.clone();
                    let active = active.clone();
                    let peak = peak.clone();
                    let started_tx = started_tx.clone();
                    async move {
                        let permit = boot_slots.acquire_owned().await.expect("scheduler open");
                        let now_active = active.fetch_add(1, Ordering::SeqCst) + 1;
                        peak.fetch_max(now_active, Ordering::SeqCst);
                        started_tx.send_modify(|started| *started += 1);
                        let gate = release.acquire().await.expect("test gate open");
                        gate.forget();
                        active.fetch_sub(1, Ordering::SeqCst);
                        drop(permit);
                        offset + index
                    }
                })
                .collect::<Vec<_>>()
        };
        let first = build_batch(0);
        let second = build_batch(PER_BATCH);
        drop(started_tx);

        let first =
            tokio::spawn(async move { run_bounded_futures(first, PER_BATCH, |_| true).await });
        let second =
            tokio::spawn(async move { run_bounded_futures(second, PER_BATCH, |_| true).await });

        while *started_rx.borrow() < WIDTH {
            started_rx.changed().await.expect("boots still pending");
        }
        assert_eq!(active.load(Ordering::SeqCst), WIDTH);
        assert_eq!(peak.load(Ordering::SeqCst), WIDTH);

        release.add_permits(PER_BATCH * 2);
        assert!(first.await.expect("first batch task"));
        assert!(second.await.expect("second batch task"));
        assert_eq!(peak.load(Ordering::SeqCst), WIDTH);
        assert_eq!(active.load(Ordering::SeqCst), 0);
    }

    #[test]
    fn ssrf_prone_registry_host_flags_loopback_linklocal_and_private() {
        for host in [
            "127.0.0.1:8081",
            "localhost:5000",
            "0.0.0.0",
            "169.254.169.254", // cloud metadata
            "10.0.0.5",
            "172.16.4.4",
            "192.168.1.10",
            "[::1]:5000",
            "[fe80::1]",
            "[fc00::1]:443",
        ] {
            assert!(
                is_ssrf_prone_registry_host(host),
                "{host} should be flagged"
            );
        }
        for host in [
            "registry-1.docker.io",
            "registry.smolmachines.com",
            "ghcr.io",
            "8.8.8.8",
            "203.0.113.7:5000",
        ] {
            assert!(
                !is_ssrf_prone_registry_host(host),
                "{host} should NOT be flagged"
            );
        }
    }

    #[test]
    fn export_stub_path_is_not_the_sidecar_name() {
        // Regression: the handler used to hand `pack create` a temp file that already
        // ended in `.smolmachine`, which the CLI rejects because `-o` names the stub.
        let dir = std::path::Path::new("/tmp/export-test");
        let stub = export_stub_path(dir);
        assert!(
            stub.extension()
                .is_none_or(|e| !e.eq_ignore_ascii_case("smolmachine")),
            "-o must name the stub, not the sidecar: {}",
            stub.display()
        );
        let sidecar = smolvm_pack::sidecar_path_for(&stub);
        assert_eq!(
            sidecar.extension().and_then(|e| e.to_str()),
            Some("smolmachine"),
            "the derived sidecar must be the .smolmachine artifact"
        );
        assert_ne!(stub, sidecar);
    }

    #[test]
    fn a_capture_that_outlasts_its_wait_is_a_retryable_unavailable() {
        let e = SmolvmError::agent("read control socket", "no reply to FORK within 220 s");
        match classify_fork_error(e) {
            ApiError::Unavailable(msg) => assert!(msg.contains("retry the branch"), "{msg}"),
            other => panic!("expected Unavailable, got {other:?}"),
        }
    }

    #[test]
    fn classify_fork_error_maps_precondition_failures_to_conflict() {
        // A golden started without SMOLVM_FORKABLE has no memfd RAM to CoW-fork —
        // a caller-fixable precondition (409), not a 500 a client would retry.
        let e = SmolvmError::agent(
            "fork",
            "golden FORK failed: ERR EINVAL no memfd-backed RAM (start the golden VM with SMOLVM_FORKABLE=1)",
        );
        assert!(matches!(classify_fork_error(e), ApiError::Conflict(_)));
        // The same refusal as the fork layer rewords it for people.
        let e = SmolvmError::agent(
            "fork",
            "machine 'g' was not started as branchable, so it has no copy-on-write memory to branch from.",
        );
        assert!(matches!(classify_fork_error(e), ApiError::Conflict(_)));
        // A stopped golden's dead control socket is likewise a 409.
        let e = SmolvmError::agent("fork", "golden 'g' control socket not responding");
        assert!(matches!(classify_fork_error(e), ApiError::Conflict(_)));
        // An unrelated fork failure stays a 500.
        let e = SmolvmError::agent("fork", "disk write failed");
        assert!(matches!(classify_fork_error(e), ApiError::Internal(_)));
        let e = SmolvmError::vm_creation(
            "branch needs at least 2048 MiB of effective host headroom for 8 children, but only 1024 MiB is available",
        );
        assert!(matches!(classify_fork_error(e), ApiError::Unavailable(_)));
    }

    #[test]
    fn a_source_at_its_disk_chain_limit_is_a_conflict_not_a_server_fault() {
        let reason = "storage.qcow2 already has 32 qcow2 backing layers; the safe limit is 32. \
                      Stop and pack this machine into a new root before creating another live fork";
        match classify_fork_error(SmolvmError::agent_conflict("fork-continue", reason)) {
            ApiError::Conflict(msg) => assert!(msg.contains("pack this machine"), "{msg}"),
            other => panic!("expected Conflict, got {other:?}"),
        }
        // The kind decides it, not the wording: the same text as a plain failure stays a 500.
        assert!(matches!(
            classify_fork_error(SmolvmError::agent("fork-continue", reason)),
            ApiError::Internal(_)
        ));
    }

    #[test]
    fn classify_launch_error_flags_virtio_port_conflict() {
        // The real virtio-net host-port bind failure → retryable PortConflict.
        let e = "agent operation failed: configure virtio-net: failed to start virtio network \
                 runtime: Address already in use (os error 98)"
            .to_string();
        assert!(matches!(
            classify_launch_error(e),
            ApiError::PortConflict(_)
        ));
        let e = "configure virtio-net: failed to start virtio network runtime: cannot publish                  host TCP 127.0.0.1:9222 to guest TCP 9222: Only one usage of each socket                  address (protocol/network address/port) is normally permitted. (os error 10048)"
            .to_string();
        assert!(matches!(
            classify_launch_error(e),
            ApiError::PortConflict(_)
        ));
    }

    #[test]
    fn prepared_fork_boot_error_preserves_clone_rejuvenation_identity() {
        let error = PreparedForkBootError::CloneIdentityRejuvenation(
            "clone identity rejuvenation failed: identity reset could not be confirmed".to_string(),
        );
        assert!(matches!(
            classify_prepared_fork_boot_error(error),
            ApiError::CloneIdentityRejuvenationFailed(_)
        ));
    }

    #[test]
    fn validate_workload_image_source_rejects_imageless_workload() {
        let cmd = vec!["python".to_string(), "app.py".to_string()];
        let ep = vec!["/bin/sh".to_string()];
        // Imageless (no image, no from) + a command/entrypoint → rejected.
        assert!(validate_workload_image_source(false, false, &cmd, &[]).is_err());
        assert!(validate_workload_image_source(false, false, &[], &ep).is_err());
        // With an image or a from source, the workload has somewhere to run.
        assert!(validate_workload_image_source(true, false, &cmd, &[]).is_ok());
        assert!(validate_workload_image_source(false, true, &cmd, &ep).is_ok());
        // Imageless with no workload is the ordinary exec-driven machine.
        assert!(validate_workload_image_source(false, false, &[], &[]).is_ok());
    }

    #[test]
    fn classify_launch_error_keeps_others_internal() {
        // An unrelated AddrInUse (no virtio context) must NOT be treated as a
        // published-port conflict — reallocating a port wouldn't help.
        assert!(matches!(
            classify_launch_error("bind vsock: Address already in use".to_string()),
            ApiError::Internal(_)
        ));
        // A generic boot failure stays a 500.
        assert!(matches!(
            classify_launch_error("failed to start machine: kernel panic".to_string()),
            ApiError::Internal(_)
        ));
    }

    #[test]
    fn a_staged_base_that_is_never_installed_leaves_nothing_behind() {
        let dir = tempfile::tempdir().unwrap();
        let partial = dir.path().join(".b-v1.qcow2.1.2.partial");
        std::fs::write(&partial, b"base").unwrap();
        drop(StagedBase(partial.clone()));
        assert!(!partial.exists());
        assert!(!dir.path().join("b-v1.qcow2").exists());
    }

    #[test]
    fn installing_a_staged_base_names_it_and_refuses_a_taken_name() {
        let dir = tempfile::tempdir().unwrap();
        let stage = |n: u8| {
            let partial = dir.path().join(format!(".b-v1.qcow2.{n}.1.partial"));
            std::fs::write(&partial, [n; 4]).unwrap();
            StagedBase(partial)
        };
        let first = stage(1);
        let first_partial = first.path().to_path_buf();
        assert_eq!(first.install(dir.path(), "b-v1.qcow2", "ab").unwrap(), 4);
        assert!(!first_partial.exists());
        assert_eq!(
            std::fs::read(dir.path().join("b-v1.qcow2")).unwrap(),
            [1; 4]
        );

        let second = stage(2);
        let second_partial = second.path().to_path_buf();
        assert!(matches!(
            second.install(dir.path(), "b-v1.qcow2", "cd"),
            Err(ApiError::Conflict(_))
        ));
        assert!(!second_partial.exists());
        assert_eq!(
            std::fs::read(dir.path().join("b-v1.qcow2")).unwrap(),
            [1; 4]
        );
    }

    #[test]
    fn classify_launch_error_returns_an_invalid_archive_to_the_caller() {
        // A start of a machine whose image file is not a `docker save` archive
        // must say so with a 400, not report a server fault.
        let e = "failed to start machine: agent operation failed: pull image: crane export \
                 failed: Error: reading tarball from stdin: file manifest.json not found in \
                 tar (is the image a valid `docker save` / OCI archive?)"
            .to_string();
        assert!(matches!(classify_launch_error(e), ApiError::BadRequest(_)));
    }

    #[test]
    fn machine_info_distinguishes_unknown_disk_depth_from_zero() {
        let record = VmRecord::new("depth-vm".to_string(), 1, 512, vec![], vec![], false);
        let mut info = record_to_info("depth-vm", &record);
        assert!(serde_json::to_value(&info)
            .unwrap()
            .get("diskChainDepth")
            .is_none());
        for depth in [0, 23, 33] {
            info.disk_chain_depth = Some(depth);
            assert_eq!(
                serde_json::to_value(&info).unwrap()["diskChainDepth"],
                depth
            );
        }
    }

    #[test]
    fn test_record_to_info() {
        let mut record = VmRecord::new(
            "test-vm".to_string(),
            2,
            1024,
            vec![
                ("/host/path".to_string(), "/guest/path".to_string(), false),
                ("/host/ro".to_string(), "/guest/ro".to_string(), true),
            ],
            vec![(8080, 80), (3000, 3000)],
            false,
        );
        record.gpu = Some(true);
        record.cuda = true;
        record.forkable = true;
        record.golden = Some("parent-vm".to_string());

        let info = record_to_info("test-vm", &record);

        assert_eq!(info.name, "test-vm");
        assert_eq!(info.state, "created");
        assert_eq!(info.cpus, 2);
        assert_eq!(info.mem, 1024);
        assert_eq!(info.mounts.len(), 2);
        assert_eq!(info.ports.len(), 2);
        assert!(!info.network);
        assert!(info.gpu);
        assert!(info.cuda);
        assert!(info.branchable);
        assert!(info.forkable);
        assert_eq!(info.parent_machine.as_deref(), Some("parent-vm"));
        assert_eq!(info.cuda_branch_pool_size, info.cuda_fork_pool_size);
        assert_eq!(info.branchpoint_held, info.forkpoint_held);
        assert!(info.pid.is_none());
    }

    #[test]
    fn test_record_to_info_with_running_state() {
        let mut record = VmRecord::new("running-vm".to_string(), 1, 512, vec![], vec![], false);
        record.state = RecordState::Running;
        record.pid = Some(12345);

        let info = record_to_info("running-vm", &record);

        assert_eq!(info.name, "running-vm");
        // Note: actual_state() checks if process is alive, which won't be true in test
        // So it will show as "stopped" even though record state is Running
        assert_eq!(info.cpus, 1);
        assert_eq!(info.mem, 512);
        assert_eq!(info.mounts.len(), 0);
        assert_eq!(info.ports.len(), 0);
    }

    #[test]
    fn test_record_to_info_default_values() {
        let record = VmRecord::new("minimal-vm".to_string(), 1, 512, vec![], vec![], false);

        let info = record_to_info("minimal-vm", &record);

        assert_eq!(info.name, "minimal-vm");
        assert_eq!(info.state, "created");
        assert_eq!(info.cpus, 1);
        assert_eq!(info.mem, 512);
        assert_eq!(info.mounts.len(), 0);
        assert_eq!(info.ports.len(), 0);
        assert!(!info.network);
        assert!(info.pid.is_none());
        assert!(info.created_at > 0);
        // A machine created without explicit disk sizes still reports the RESOLVED
        // provisioned sizes (the node default), not None — billing/telemetry need
        // the actual allocated GiB.
        assert_eq!(info.storage_gb, Some(DEFAULT_STORAGE_SIZE_GIB));
        assert_eq!(info.overlay_gb, Some(DEFAULT_OVERLAY_SIZE_GIB));
    }

    #[test]
    fn test_record_to_info_with_network() {
        let record = VmRecord::new("network-vm".to_string(), 1, 512, vec![], vec![], true);

        let info = record_to_info("network-vm", &record);

        assert_eq!(info.name, "network-vm");
        assert!(info.network);
    }

    #[test]
    fn test_record_to_info_echoes_backend_and_cidrs() {
        let mut record = VmRecord::new("policy-vm".to_string(), 1, 512, vec![], vec![], true);
        record.network_backend = Some(crate::network::NetworkBackend::VirtioNet);
        record.allowed_cidrs = Some(vec!["10.0.0.0/8".to_string()]);

        let info = record_to_info("policy-vm", &record);

        assert_eq!(
            info.network_backend,
            Some(crate::network::NetworkBackend::VirtioNet)
        );
        assert_eq!(
            info.allowed_cidrs.as_deref(),
            Some(["10.0.0.0/8".to_string()].as_slice())
        );

        // Unset config stays absent so the JSON omits the fields entirely.
        let bare = VmRecord::new("bare-vm".to_string(), 1, 512, vec![], vec![], false);
        let bare_info = record_to_info("bare-vm", &bare);
        assert!(bare_info.network_backend.is_none());
        assert!(bare_info.allowed_cidrs.is_none());
    }

    #[test]
    fn registry_reference_uses_digest_before_tag_or_latest() {
        let digest = "sha256:abcdef0123456789abcdef0123456789abcdef0123456789abcdef0123456789";

        let digest_ref =
            crate::registry::Reference::parse(&format!("python-dev@{digest}")).unwrap();
        assert_eq!(registry_reference_tag_or_digest(&digest_ref), digest);

        let tagged_ref = crate::registry::Reference::parse("python-dev:v1").unwrap();
        assert_eq!(registry_reference_tag_or_digest(&tagged_ref), "v1");

        let latest_ref = crate::registry::Reference::parse("python-dev").unwrap();
        assert_eq!(registry_reference_tag_or_digest(&latest_ref), "latest");
    }

    #[test]
    fn create_request_accepts_disk_volumes() {
        let req: CreateMachineRequest = serde_json::from_value(serde_json::json!({
            "name": "api-vm",
            "diskVolumes": ["/var/lib/docker", "/var/lib/containerd"]
        }))
        .unwrap();

        assert_eq!(req.disk_volumes, ["/var/lib/docker", "/var/lib/containerd"]);
    }

    #[test]
    fn create_request_accepts_env_and_workdir() {
        let req: CreateMachineRequest = serde_json::from_value(serde_json::json!({
            "name": "api-vm",
            "env": [{"name": "FOO", "value": "bar"}],
            "workdir": "/app"
        }))
        .unwrap();

        assert_eq!(req.env.len(), 1);
        assert_eq!(req.env[0].name, "FOO");
        assert_eq!(req.env[0].value, "bar");
        assert_eq!(req.workdir.as_deref(), Some("/app"));
    }

    #[test]
    fn create_request_auto_graph_is_opt_in() {
        let enabled: CreateMachineRequest = serde_json::from_value(serde_json::json!({
            "name": "api-vm",
            "autoGraph": true
        }))
        .unwrap();
        assert!(enabled.auto_graph);

        let defaulted: CreateMachineRequest = serde_json::from_value(serde_json::json!({
            "name": "api-vm"
        }))
        .unwrap();
        assert!(!defaulted.auto_graph);
    }

    #[test]
    fn auto_graph_policy_overrides_conflicting_request_env() {
        let req: CreateMachineRequest = serde_json::from_value(serde_json::json!({
            "autoGraph": true,
            "env": [
                {"name": crate::util::CUDA_AUTO_GRAPH_ENV, "value": "0"},
                {"name": crate::util::TORCHINDUCTOR_CUDAGRAPHS_ENV, "value": "0"}
            ]
        }))
        .unwrap();
        let spec = create_spec_from_request(&req, None).unwrap();
        assert!(spec.cuda, "autoGraph implies CUDA");
        assert_eq!(
            spec.env,
            vec![
                (
                    crate::util::CUDA_AUTO_GRAPH_ENV.to_string(),
                    "1".to_string()
                ),
                (
                    crate::util::TORCHINDUCTOR_CUDAGRAPHS_ENV.to_string(),
                    "1".to_string(),
                ),
            ]
        );
    }
    #[test]
    fn create_request_deserialization_keeps_resource_omission_distinct() {
        let req: CreateMachineRequest = serde_json::from_value(serde_json::json!({
            "name": "api-vm"
        }))
        .unwrap();

        assert_eq!(req.cpus, None);
        assert_eq!(req.mem, None);

        let req: CreateMachineRequest = serde_json::from_value(serde_json::json!({
            "name": "api-vm",
            "cpus": 2,
            "memoryMb": 2048
        }))
        .unwrap();

        assert_eq!(req.cpus, Some(2));
        assert_eq!(req.mem, Some(2048));
    }

    /// Helper to create a test database and API state.
    #[allow(dead_code)]
    fn setup_test_state() -> (TempDir, Arc<ApiState>) {
        let dir = TempDir::new().expect("failed to create temp dir");
        let db_path = dir.path().join("test.db");
        let db = SmolvmDb::open_at(&db_path).expect("failed to open test db");
        let state = Arc::new(ApiState::with_db(db));
        (dir, state)
    }

    #[test]
    fn delete_cleanup_failure_preserves_record_for_retry() {
        let (dir, state) = setup_test_state();
        let name = "cleanup-failure";
        create_test_vm(state.db(), name, Some(20), Some(5));
        let data_dir = dir.path().join("machine-data");
        // A file instead of a directory fails even when tests run as root.
        std::fs::write(&data_dir, b"not a directory").unwrap();

        let error = remove_machine_data_and_record(&state, name, &data_dir).unwrap_err();
        assert!(matches!(error, ApiError::Internal(_)));
        assert!(state.db().get_vm(name).unwrap().is_some());
        assert_eq!(std::fs::read(&data_dir).unwrap(), b"not a directory");

        // Repair the host path and retry through fresh API state, as after restart.
        std::fs::remove_file(&data_dir).unwrap();
        std::fs::create_dir(&data_dir).unwrap();
        std::fs::write(data_dir.join("storage.raw"), b"remaining disk").unwrap();
        drop(state);
        let db = SmolvmDb::open_at(&dir.path().join("test.db")).unwrap();
        let recovered = ApiState::with_db(db);
        remove_machine_data_and_record(&recovered, name, &data_dir).unwrap();
        assert!(!data_dir.exists());
        assert!(recovered.db().get_vm(name).unwrap().is_none());
    }

    /// Something still writing into a machine's data directory while it is
    /// removed makes the removal see a directory that is not empty; once the
    /// writer stops, the retry removes everything.
    #[test]
    fn delete_cleanup_outlasts_a_writer_that_settles() {
        let (dir, state) = setup_test_state();
        let name = "cleanup-busy";
        create_test_vm(state.db(), name, Some(20), Some(5));
        let data_dir = dir.path().join("machine-data");
        std::fs::create_dir_all(data_dir.join("nested")).unwrap();
        for index in 0..200 {
            std::fs::write(data_dir.join("nested").join(format!("f{index}")), b"x").unwrap();
        }
        let writing = Arc::new(std::sync::atomic::AtomicBool::new(true));
        let writer = {
            let (data_dir, writing) = (data_dir.clone(), writing.clone());
            std::thread::spawn(move || {
                let mut index = 0u64;
                while writing.load(std::sync::atomic::Ordering::Relaxed) {
                    let _ = std::fs::create_dir_all(data_dir.join("nested"));
                    let _ = std::fs::write(data_dir.join("nested").join(format!("w{index}")), b"x");
                    index += 1;
                }
            })
        };
        let stop = {
            let writing = writing.clone();
            std::thread::spawn(move || {
                std::thread::sleep(std::time::Duration::from_millis(600));
                writing.store(false, std::sync::atomic::Ordering::Relaxed);
            })
        };
        remove_machine_data_and_record(&state, name, &data_dir).unwrap();
        stop.join().unwrap();
        writer.join().unwrap();
        // The writer may recreate a stray entry after the final pass returned;
        // the record is gone either way.
        assert!(state.db().get_vm(name).unwrap().is_none());
    }

    #[test]
    fn delete_cleanup_accepts_already_absent_data() {
        let (dir, state) = setup_test_state();
        let name = "cleanup-already-absent";
        create_test_vm(state.db(), name, Some(20), Some(5));
        // A previous attempt may have removed storage before its DB write failed.
        let data_dir = dir.path().join("missing-parent/machine-data");
        remove_machine_data_and_record(&state, name, &data_dir).unwrap();
        assert!(state.db().get_vm(name).unwrap().is_none());
    }

    #[cfg(unix)]
    #[test]
    fn delete_cleanup_inspection_error_preserves_record() {
        let (dir, state) = setup_test_state();
        let name = "cleanup-inspection-error";
        create_test_vm(state.db(), name, Some(20), Some(5));
        // A symlink loop makes stat fail without relying on the caller's uid.
        let loop_path = dir.path().join("loop");
        std::os::unix::fs::symlink("loop", &loop_path).unwrap();
        let data_dir = loop_path.join("machine-data");
        assert!(matches!(
            remove_machine_data_and_record(&state, name, &data_dir),
            Err(ApiError::Internal(_))
        ));
        assert!(state.db().get_vm(name).unwrap().is_some());
    }

    #[tokio::test]
    async fn test_resize_validation_shrink_storage_rejected() {
        let (_dir, state) = setup_test_state();
        let db = state.db();
        create_test_vm(db, "test-vm", Some(20), Some(5));

        let req = ResizeMachineRequest {
            storage_gb: Some(10),
            expected_runtime: None,
            operation_id: None,
            overlay_gb: None,
            cpus: None,
            mem: None,
        };
        let result = resize_machine(State(state), Path("test-vm".to_string()), Json(req)).await;
        assert!(matches!(result.unwrap_err(), ApiError::BadRequest(_)));
    }

    #[tokio::test]
    async fn test_resize_validation_no_params_rejected() {
        let (_dir, state) = setup_test_state();
        let db = state.db();
        create_test_vm(db, "test-vm", Some(20), Some(5));

        let req = ResizeMachineRequest {
            storage_gb: None,
            expected_runtime: None,
            operation_id: None,
            overlay_gb: None,
            cpus: None,
            mem: None,
        };
        let result = resize_machine(State(state), Path("test-vm".to_string()), Json(req)).await;
        assert!(matches!(result.unwrap_err(), ApiError::BadRequest(_)));
    }

    #[tokio::test]
    async fn test_resize_not_found() {
        let (_dir, state) = setup_test_state();
        let req = ResizeMachineRequest {
            storage_gb: Some(30),
            expected_runtime: None,
            operation_id: None,
            overlay_gb: None,
            cpus: None,
            mem: None,
        };
        let result = resize_machine(State(state), Path("nonexistent".to_string()), Json(req)).await;
        assert!(matches!(result.unwrap_err(), ApiError::NotFound(_)));
    }

    #[tokio::test]
    async fn set_ports_on_a_stopped_machine_saves_the_whole_set() {
        let (_dir, state) = setup_test_state();
        create_test_vm(state.db(), "ports-vm", Some(20), Some(5));
        let port = |host, guest, protocol| PortSpec {
            host,
            guest,
            protocol,
        };
        use crate::data::network::PortProtocol::{Tcp, Udp};

        let req = SetPortsRequest {
            ports: vec![port(18080, 80, Tcp), port(15353, 53, Udp)],
        };
        let info = set_machine_ports(State(state.clone()), Path("ports-vm".into()), Json(req))
            .await
            .unwrap();
        assert_eq!(info.ports.len(), 2);
        let saved = state.db().get_vm("ports-vm").unwrap().unwrap();
        assert_eq!(saved.ports, vec![(18080, 80)]);
        assert_eq!(saved.udp_ports, vec![(15353, 53)]);

        // The whole set: an empty list removes them all.
        let req = SetPortsRequest { ports: vec![] };
        let info = set_machine_ports(State(state.clone()), Path("ports-vm".into()), Json(req))
            .await
            .unwrap();
        assert!(info.ports.is_empty());
        let saved = state.db().get_vm("ports-vm").unwrap().unwrap();
        assert!(saved.ports.is_empty() && saved.udp_ports.is_empty());
    }

    #[tokio::test]
    async fn set_ports_refuses_a_host_port_twice_and_an_unknown_machine() {
        let (_dir, state) = setup_test_state();
        create_test_vm(state.db(), "ports-vm", Some(20), Some(5));
        let tcp = |host, guest| PortSpec {
            host,
            guest,
            protocol: crate::data::network::PortProtocol::Tcp,
        };
        let req = SetPortsRequest {
            ports: vec![tcp(18080, 80), tcp(18080, 81)],
        };
        let result =
            set_machine_ports(State(state.clone()), Path("ports-vm".into()), Json(req)).await;
        assert!(matches!(result.unwrap_err(), ApiError::BadRequest(_)));

        let req = SetPortsRequest { ports: vec![] };
        let result = set_machine_ports(State(state), Path("nope".into()), Json(req)).await;
        assert!(matches!(result.unwrap_err(), ApiError::NotFound(_)));
    }

    #[tokio::test]
    async fn update_egress_adds_and_removes_udp_allows_on_a_stopped_machine() {
        let (_dir, state) = setup_test_state();
        create_test_vm(state.db(), "udp-vm", Some(20), Some(5));
        let request = |body: serde_json::Value| -> UpdateEgressRequest {
            serde_json::from_value(body).unwrap()
        };

        let info = update_machine_egress(
            State(state.clone()),
            Path("udp-vm".into()),
            Json(request(
                serde_json::json!({"allowUdp": ["192.0.2.0/24:3478-3480"]}),
            )),
        )
        .await
        .unwrap();
        let rule = crate::smolfile::parse_allow_udp("192.0.2.0/24:3478-3480").unwrap();
        assert_eq!(info.egress_rules, vec![rule.clone()]);
        let saved = state.db().get_vm("udp-vm").unwrap().unwrap();
        assert_eq!(saved.egress_rules, vec![rule]);
        assert!(saved.network);
        assert!(saved.allowed_cidrs.is_none());

        let result = update_machine_egress(
            State(state.clone()),
            Path("udp-vm".into()),
            Json(request(serde_json::json!({"allowUdp": ["192.0.2.0/24:0"]}))),
        )
        .await;
        assert!(matches!(result.unwrap_err(), ApiError::BadRequest(_)));

        let info = update_machine_egress(
            State(state.clone()),
            Path("udp-vm".into()),
            Json(request(
                serde_json::json!({"removeAllowUdp": ["192.0.2.0/24:3478-3480"]}),
            )),
        )
        .await
        .unwrap();
        assert!(info.egress_rules.is_empty());
        let saved = state.db().get_vm("udp-vm").unwrap().unwrap();
        assert!(saved.egress_rules.is_empty());
    }

    #[test]
    fn a_taken_host_port_is_a_retryable_port_conflict() {
        let taken = crate::Error::config(
            "published ports",
            "could not change machine 'm''s published ports while it runs: cannot publish \
             host TCP 0.0.0.0:18080 to guest TCP 80: Address already in use (os error 98)",
        );
        assert!(matches!(
            classify_set_ports_error(taken),
            ApiError::PortConflict(_)
        ));
        let refused = crate::Error::config(
            "published ports",
            "machine 'm' is running without virtio-net networking, so its ports can only \
             change while it is stopped",
        );
        assert!(matches!(
            classify_set_ports_error(refused),
            ApiError::BadRequest(_)
        ));
    }

    /// Helper to create a VM record in the database.
    fn create_test_vm(db: &SmolvmDb, name: &str, storage_gb: Option<u64>, overlay_gb: Option<u64>) {
        let mut record = VmRecord::new(name.to_string(), 1, 512, vec![], vec![], false);
        record.storage_gb = storage_gb;
        record.overlay_gb = overlay_gb;
        db.insert_vm(name, &record)
            .expect("failed to insert test vm");
    }
}
