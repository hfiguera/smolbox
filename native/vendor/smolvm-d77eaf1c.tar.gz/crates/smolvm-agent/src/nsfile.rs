//! File operations performed inside the workload container's mount namespace.
//!
//! The files API used to write at the requested path in the AGENT's mount
//! namespace — the VM rootfs. On a persistent machine that path lands in the
//! overlay's *upper* layer, while the workload's root is the *merged* overlay
//! mount. Writing into a layer beneath a live overlayfs is unsupported by the
//! kernel, so the merged view never observed the write: an upload reported
//! success and the container saw nothing, and a file the container created was
//! invisible to a download. The two sides addressed different filesystems.
//!
//! The fix is to do the work where the workload lives. `setns(CLONE_NEWMNT)`
//! into the container's mount namespace gives exactly the view the workload has
//! — the merged overlay *and* every volume, bind and tmpfs mounted inside it,
//! in the right order. Resolving `/data/x` there hits the volume mounted at
//! `/data`, not the directory buried underneath it.
//!
//! Two properties fall out of doing it this way rather than joining paths from
//! outside:
//!
//! * **Symlink containment is the kernel's job.** Path resolution runs against
//!   the container's own root, so a planted `/tmp -> /storage` symlink cannot
//!   redirect an upload out of the container. A `<overlay>/merged/<path>` join
//!   would follow it — the escape class `safe_unpack` exists to defend against.
//! * **No mount is invisible.** Anything the container gains later is handled
//!   without changes here.
//!
//! `setns(CLONE_NEWMNT)` is refused for a multithreaded caller, and the agent
//! runs a threaded async runtime, so the work happens in a fresh single-threaded
//! re-exec of this same binary (`smolvm-agent ns-file …`) — dispatched at the
//! very top of `main` before any thread starts, the same idiom
//! [`crate::forkpoint`] uses. Bytes move over pipes so neither side buffers a
//! whole file.
//!
//! WHEN THE WORKLOAD IS NOT RUNNING the old behavior is correct and is kept:
//! overlayfs reads `upper` at mount time, so populating it *before* the overlay
//! is mounted is exactly how a rootfs is pre-seeded. Only writes *beneath a
//! live* overlay are lost. That is why this routes into the container only when
//! one is actually running.

use std::io::{BufRead, Read, Write};
use std::os::unix::fs::OpenOptionsExt as _;
use std::path::Path;
use std::process::{Command, Stdio};

/// argv marker selecting the namespace helper instead of the PID-1 agent.
const HELPER_ARG: &str = "ns-file";
/// This binary, re-executed for the helper.
const AGENT_BINARY: &str = "/usr/local/bin/smolvm-agent";

/// Whether this invocation is the namespace file helper.
///
/// Checked before the async runtime starts: `setns(CLONE_NEWMNT)` requires a
/// single-threaded process, so the helper must never have spawned a thread.
pub fn helper_requested() -> bool {
    std::env::args().nth(1).as_deref() == Some(HELPER_ARG)
}

/// Entry point for `smolvm-agent ns-file <op> <pid> <path> [mode [uid gid]]`.
///
/// Protocol, chosen so the parent never buffers a whole file:
/// * `read`  — stdout gets `OK <size>\n` then exactly `<size>` raw bytes, or
///   `ERR <message>\n`.
/// * `list`  — stdout gets `OK <json>\n`, the JSON being the entry array.
/// * `write` — raw bytes arrive on stdin until EOF; stdout gets `OK\n` or
///   `ERR <message>\n`. mode/uid/gid are positional with `-` meaning
///   "not requested".
pub fn run_helper() -> i32 {
    let args: Vec<String> = std::env::args().collect();
    // argv: [bin, "ns-file", "mount-cache-all", path, major, minor] — runs in the
    // caller's namespace and enters each other one through a child.
    if args.get(2).map(String::as_str) == Some("mount-cache-all") {
        return match mount_cache_everywhere(&args) {
            Ok(()) => 0,
            Err(e) => {
                let _ = std::io::stdout().write_all(format!("ERR {e}\n").as_bytes());
                1
            }
        };
    }
    // argv: [bin, "ns-file", "attach-mount", pid, target, source, ro] — takes
    // the source mount here, in the caller's namespace, before entering the
    // container's, where the source path does not exist.
    if args.get(2).map(String::as_str) == Some("attach-mount") {
        return match helper_attach_mount(&args) {
            Ok(()) => 0,
            Err(e) => {
                let _ = std::io::stdout().write_all(format!("ERR {e}\n").as_bytes());
                1
            }
        };
    }
    // argv: [bin, "ns-file", op, pid, path, (mode), (uid), (gid)]
    if args.len() < 5 {
        eprintln!("ns-file: usage: ns-file <read|write> <pid> <path> [mode [uid gid]]");
        return 2;
    }
    let op = args[2].as_str();
    let Ok(pid) = args[3].parse::<u32>() else {
        eprintln!("ns-file: bad pid");
        return 2;
    };
    let path = args[4].clone();
    let opt = |i: usize| args.get(i).filter(|v| v.as_str() != "-");
    let mode = opt(5).and_then(|m| u32::from_str_radix(m, 8).ok());
    let uid = opt(6).and_then(|u| u.parse::<u32>().ok());
    let gid = opt(7).and_then(|g| g.parse::<u32>().ok());

    if let Err(e) = enter_mount_namespace(pid) {
        // Report through the protocol so the parent surfaces one clean error.
        let _ = std::io::stdout().write_all(format!("ERR {e}\n").as_bytes());
        return 1;
    }

    let result = match op {
        "read" => helper_read(&path),
        "list" => helper_list(&path),
        "write" => helper_write(&path, mode, uid, gid),
        "connect" => helper_connect(&path),
        "mount-cache" => helper_mount_cache(&path, &args),
        "remount-shm" => helper_remount_shm(&path, &args),
        "detach-mount" => helper_detach_mount(&path),
        _ => Err("unknown op".to_string()),
    };
    match result {
        Ok(()) => 0,
        Err(e) => {
            let _ = std::io::stdout().write_all(format!("ERR {e}\n").as_bytes());
            1
        }
    }
}

/// `open_tree(2)` and `move_mount(2)`: the same numbers on x86_64 and aarch64
/// (asm-generic). Named here because the musl `libc` the agent builds against
/// does not export them.
#[cfg(target_os = "linux")]
const SYS_OPEN_TREE: libc::c_long = 428;
#[cfg(target_os = "linux")]
const SYS_MOVE_MOUNT: libc::c_long = 429;
#[cfg(target_os = "linux")]
const OPEN_TREE_CLONE: libc::c_uint = 1;
#[cfg(target_os = "linux")]
const MOVE_MOUNT_F_EMPTY_PATH: libc::c_uint = 0x4;

/// Clone the attached share at `source` as a detached mount, enter the
/// container's mount namespace, and attach the clone at `target` there. The
/// clone carries the mount across: `source` is not a path inside the container.
#[cfg(target_os = "linux")]
fn helper_attach_mount(args: &[String]) -> Result<(), String> {
    use std::os::unix::io::FromRawFd as _;

    let (Some(pid), Some(target), Some(source), Some(ro)) =
        (args.get(3), args.get(4), args.get(5), args.get(6))
    else {
        return Err("usage: attach-mount <pid> <target> <source> <ro|rw>".to_string());
    };
    let pid: u32 = pid.parse().map_err(|_| "bad pid".to_string())?;
    let c = |s: &str| std::ffi::CString::new(s).map_err(|e| e.to_string());
    let source_c = c(source)?;
    // SAFETY: a NUL-terminated path; the result is checked before use.
    let fd = unsafe {
        libc::syscall(
            SYS_OPEN_TREE,
            libc::AT_FDCWD,
            source_c.as_ptr(),
            OPEN_TREE_CLONE | libc::O_CLOEXEC as libc::c_uint,
        )
    };
    if fd < 0 {
        return Err(format!(
            "open_tree {source}: {}",
            std::io::Error::last_os_error()
        ));
    }
    // SAFETY: open_tree returned a new descriptor this helper owns.
    let tree = unsafe { std::fs::File::from_raw_fd(fd as libc::c_int) };
    enter_mount_namespace(pid)?;
    std::fs::create_dir_all(target).map_err(|e| format!("create {target}: {e}"))?;
    let target_c = c(target)?;
    let empty = c("")?;
    // SAFETY: `tree` is a live detached mount; the paths are NUL-terminated.
    let rc = unsafe {
        libc::syscall(
            SYS_MOVE_MOUNT,
            std::os::unix::io::AsRawFd::as_raw_fd(&tree),
            empty.as_ptr(),
            libc::AT_FDCWD,
            target_c.as_ptr(),
            MOVE_MOUNT_F_EMPTY_PATH,
        )
    };
    if rc != 0 {
        return Err(format!(
            "move_mount {target}: {}",
            std::io::Error::last_os_error()
        ));
    }
    if ro == "ro" {
        // The host already refuses writes; this reports them as a read-only
        // filesystem instead of failed writes.
        // SAFETY: a NUL-terminated path for a mount this helper just made.
        let rc = unsafe {
            libc::mount(
                std::ptr::null(),
                target_c.as_ptr(),
                std::ptr::null(),
                // A bind remount replaces every per-mount flag, so
                // keep the ones the device was mounted with.
                libc::MS_REMOUNT
                    | libc::MS_BIND
                    | libc::MS_RDONLY
                    | libc::MS_NOSUID
                    | libc::MS_NODEV,
                std::ptr::null(),
            )
        };
        if rc != 0 {
            let error = std::io::Error::last_os_error();
            // SAFETY: as above.
            unsafe { libc::umount2(target_c.as_ptr(), libc::MNT_DETACH) };
            return Err(format!("make {target} read-only: {error}"));
        }
    }
    Ok(())
}

#[cfg(not(target_os = "linux"))]
fn helper_attach_mount(_args: &[String]) -> Result<(), String> {
    Err("mount namespaces are Linux-only".to_string())
}

/// Lazily unmount `target` in the namespace just joined.
#[cfg(target_os = "linux")]
fn helper_detach_mount(target: &str) -> Result<(), String> {
    let target_c = std::ffi::CString::new(target).map_err(|e| e.to_string())?;
    // SAFETY: a NUL-terminated path.
    if unsafe { libc::umount2(target_c.as_ptr(), libc::MNT_DETACH) } != 0 {
        let error = std::io::Error::last_os_error();
        // Not mounted in this container: nothing to undo.
        if !matches!(
            error.raw_os_error(),
            Some(libc::EINVAL) | Some(libc::ENOENT)
        ) {
            return Err(format!("unmount {target}: {error}"));
        }
    }
    Ok(())
}

#[cfg(not(target_os = "linux"))]
fn helper_detach_mount(_target: &str) -> Result<(), String> {
    Err("mount namespaces are Linux-only".to_string())
}

/// Whether any workload container runs in a mount namespace of its own.
#[cfg(target_os = "linux")]
pub(crate) fn has_live_containers() -> bool {
    let own = std::fs::read_link("/proc/self/ns/mnt").ok();
    let skip = [own, std::fs::read_link("/proc/1/ns/mnt").ok()];
    let containers = live_containers().into_iter().filter_map(|pid| {
        std::fs::read_link(format!("/proc/{pid}/ns/mnt"))
            .ok()
            .map(|ns| (pid, ns))
    });
    !namespaces_to_enter(containers, &skip).is_empty()
}

#[cfg(not(target_os = "linux"))]
pub(crate) fn has_live_containers() -> bool {
    false
}

/// Attach the share at `source` onto `target` in every workload container.
#[cfg(target_os = "linux")]
pub(crate) fn attach_in_every_container(
    source: &Path,
    target: &str,
    read_only: bool,
) -> Result<(), String> {
    let source = source.to_string_lossy().into_owned();
    let mode = if read_only { "ro" } else { "rw" };
    in_every_container(|pid| {
        [
            "ns-file",
            "attach-mount",
            &pid.to_string(),
            target,
            &source,
            mode,
        ]
        .map(String::from)
        .to_vec()
    })
}

/// Unmount `target` in every workload container.
#[cfg(target_os = "linux")]
pub(crate) fn detach_in_every_container(target: &str) -> Result<(), String> {
    in_every_container(|pid| {
        ["ns-file", "detach-mount", &pid.to_string(), target]
            .map(String::from)
            .to_vec()
    })
}

#[cfg(not(target_os = "linux"))]
pub(crate) fn attach_in_every_container(
    _source: &Path,
    _target: &str,
    _read_only: bool,
) -> Result<(), String> {
    Err("mount namespaces are Linux-only".to_string())
}

#[cfg(not(target_os = "linux"))]
pub(crate) fn detach_in_every_container(_target: &str) -> Result<(), String> {
    Err("mount namespaces are Linux-only".to_string())
}

/// Mount the cache slot's filesystem at `path` in the namespace just joined:
/// argv carries the block device's major and minor after the path. A namespace
/// without `path`, or with a filesystem there already, is left alone. The
/// device node is made in the namespace's own `/dev` only for the mount call,
/// so nothing from the container image is needed and nothing is left behind.
#[cfg(target_os = "linux")]
fn helper_mount_cache(path: &str, args: &[String]) -> Result<(), String> {
    let number = |i: usize| -> Result<u32, String> {
        args.get(i).and_then(|v| v.parse().ok()).ok_or_else(|| {
            "mount-cache: usage: mount-cache <pid> <path> <major> <minor>".to_string()
        })
    };
    let (major, minor) = (number(5)?, number(6)?);
    if !std::path::Path::new(path).is_dir() {
        return Ok(());
    }
    let mounted = std::fs::read_to_string("/proc/self/mountinfo")
        .unwrap_or_default()
        .lines()
        .any(|line| {
            let fields: Vec<&str> = line.split(' ').collect();
            let fstype = line
                .split(" - ")
                .nth(1)
                .and_then(|rest| rest.split(' ').next());
            fields.get(4) == Some(&path) && fstype == Some("ext4")
        });
    if mounted {
        return Ok(());
    }
    let c = |s: &str| std::ffi::CString::new(s).map_err(|e| e.to_string());
    let node = c("/dev/.smolvm-cache")?;
    let target = c(path)?;
    let fstype = c("ext4")?;
    // SAFETY: valid NUL-terminated paths for a block device node this helper
    // owns, mounted and then unlinked.
    unsafe {
        libc::unlink(node.as_ptr());
        if libc::mknod(
            node.as_ptr(),
            libc::S_IFBLK | 0o600,
            libc::makedev(major, minor),
        ) != 0
        {
            return Err(format!("mknod: {}", std::io::Error::last_os_error()));
        }
        let rc = libc::mount(
            node.as_ptr(),
            target.as_ptr(),
            fstype.as_ptr(),
            // A cache is shared state, not part of the image: never let it
            // carry setuid binaries or device nodes into the container.
            libc::MS_NOATIME | libc::MS_NOSUID | libc::MS_NODEV,
            std::ptr::null(),
        );
        let error = std::io::Error::last_os_error();
        libc::unlink(node.as_ptr());
        if rc != 0 {
            return Err(format!("mount {path}: {error}"));
        }
    }
    Ok(())
}

#[cfg(not(target_os = "linux"))]
fn helper_mount_cache(_path: &str, _args: &[String]) -> Result<(), String> {
    Err("mount namespaces are Linux-only".to_string())
}

/// Resize the tmpfs at `path` in the namespace just joined to the size after
/// the path (`50%` and the like, resolved against the RAM online now). Anything
/// other than a tmpfs there is left alone.
#[cfg(target_os = "linux")]
fn helper_remount_shm(path: &str, args: &[String]) -> Result<(), String> {
    let size = args
        .get(5)
        .ok_or_else(|| "remount-shm: usage: remount-shm <pid> <path> <size>".to_string())?;
    let c = |s: &str| std::ffi::CString::new(s).map_err(|e| e.to_string());
    let (target, data) = (c(path)?, c(&format!("size={size}"))?);
    // statfs rather than /proc/self/mountinfo: the container's /proc belongs to
    // its own PID namespace, where this helper has no `self`.
    // SAFETY: `target` is NUL-terminated and `fs` is a properly sized buffer.
    let mut fs: libc::statfs = unsafe { std::mem::zeroed() };
    if unsafe { libc::statfs(target.as_ptr(), &mut fs) } != 0 || !is_tmpfs(&fs) {
        return Ok(());
    }
    // A remount clears the per-mount flags it is not given, so the mount's
    // own are passed back (ST_* and MS_* share these bit values).
    // SAFETY: as for statfs above.
    let mut vfs: libc::statvfs = unsafe { std::mem::zeroed() };
    if unsafe { libc::statvfs(target.as_ptr(), &mut vfs) } != 0 {
        return Err(format!(
            "statvfs {path}: {}",
            std::io::Error::last_os_error()
        ));
    }
    let kept = vfs.f_flag & (libc::MS_RDONLY | libc::MS_NOSUID | libc::MS_NODEV | libc::MS_NOEXEC);
    // SAFETY: valid NUL-terminated strings that outlive the call.
    let rc = unsafe {
        libc::mount(
            std::ptr::null(),
            target.as_ptr(),
            std::ptr::null(),
            libc::MS_REMOUNT | kept,
            data.as_ptr().cast(),
        )
    };
    if rc != 0 {
        return Err(format!(
            "remount {path}: {}",
            std::io::Error::last_os_error()
        ));
    }
    Ok(())
}

/// Whether `fs` describes a tmpfs. The type of `f_type` differs between glibc
/// and musl, so both sides are widened to one type.
#[cfg(target_os = "linux")]
#[allow(clippy::unnecessary_cast)]
fn is_tmpfs(fs: &libc::statfs) -> bool {
    fs.f_type as i64 == libc::TMPFS_MAGIC as i64
}

#[cfg(not(target_os = "linux"))]
fn helper_remount_shm(_path: &str, _args: &[String]) -> Result<(), String> {
    Err("mount namespaces are Linux-only".to_string())
}

/// Regrow /dev/shm in every container after the machine gained RAM. Its size
/// is a share of memory resolved when the tmpfs was mounted, so without this a
/// live grow left it at the boot size. A machine started with `--shm-size`
/// keeps the size it asked for.
#[cfg(target_os = "linux")]
pub(crate) fn regrow_shm_everywhere() -> Result<(), String> {
    if std::env::var_os(smolvm_protocol::guest_env::SHM_SIZE).is_some() {
        return Ok(());
    }
    in_every_container(|pid| {
        vec![
            "ns-file".into(),
            "remount-shm".into(),
            pid.to_string(),
            "/dev/shm".into(),
            "50%".into(),
        ]
    })
}

#[cfg(not(target_os = "linux"))]
pub(crate) fn regrow_shm_everywhere() -> Result<(), String> {
    Ok(())
}

/// Mount the cache slot into the mount namespace of every container this
/// machine runs, one child per distinct namespace (see [`in_every_container`]),
/// so one namespace that refuses the mount does not leave the rest without it.
#[cfg(target_os = "linux")]
fn mount_cache_everywhere(args: &[String]) -> Result<(), String> {
    let (path, major, minor) = match (args.get(3), args.get(4), args.get(5)) {
        (Some(p), Some(a), Some(b)) => (p.clone(), a.clone(), b.clone()),
        _ => return Err("usage: mount-cache-all <path> <major> <minor>".to_string()),
    };
    in_every_container(|pid| {
        [
            "ns-file",
            "mount-cache",
            &pid.to_string(),
            &path,
            &major,
            &minor,
        ]
        .map(String::from)
        .to_vec()
    })
}

/// Run this binary with `helper_args(pid)` once per distinct mount namespace
/// among the machine's crun containers. Only crun's own containers are entered:
/// a container the user runs inside one (Docker in the machine, an `unshare`)
/// has a namespace of its own and is left to its owner. Every container is
/// tried, and all failures are reported together.
#[cfg(target_os = "linux")]
fn in_every_container(helper_args: impl Fn(u32) -> Vec<String>) -> Result<(), String> {
    let own = std::fs::read_link("/proc/self/ns/mnt").map_err(|e| format!("own namespace: {e}"))?;
    let skip = [Some(own), std::fs::read_link("/proc/1/ns/mnt").ok()];
    let containers = live_containers().into_iter().filter_map(|pid| {
        std::fs::read_link(format!("/proc/{pid}/ns/mnt"))
            .ok()
            .map(|ns| (pid, ns))
    });
    // The fixed path, not current_exe(): the agent pivot_roots during boot, so
    // its own /proc/self/exe no longer resolves when PID 1 calls this.
    let exe = AGENT_BINARY;
    let mut failures = Vec::new();
    for pid in namespaces_to_enter(containers, &skip) {
        match std::process::Command::new(exe)
            .args(helper_args(pid))
            .output()
        {
            Ok(output) if output.status.success() => {}
            Ok(output) => failures.push(format!(
                "container {pid}: {}",
                String::from_utf8_lossy(&output.stdout).trim()
            )),
            Err(e) => failures.push(format!("container {pid}: spawn: {e}")),
        }
    }
    if failures.is_empty() {
        Ok(())
    } else {
        Err(failures.join("; "))
    }
}

#[cfg(not(target_os = "linux"))]
fn mount_cache_everywhere(_args: &[String]) -> Result<(), String> {
    Err("mount namespaces are Linux-only".to_string())
}

/// One PID per distinct mount namespace among `candidates`, leaving out the
/// namespaces in `skip` (the caller's own and the VM's, which already have the
/// cache).
#[cfg_attr(not(target_os = "linux"), allow(dead_code))]
fn namespaces_to_enter<N: PartialEq>(
    candidates: impl IntoIterator<Item = (u32, N)>,
    skip: &[Option<N>],
) -> Vec<u32> {
    let mut seen: Vec<N> = Vec::new();
    let mut pids = Vec::new();
    for (pid, ns) in candidates {
        if skip.iter().flatten().any(|s| *s == ns) || seen.contains(&ns) {
            continue;
        }
        seen.push(ns);
        pids.push(pid);
    }
    pids
}

/// Join `pid`'s mount namespace.
///
/// The container carries no user namespace (the OCI spec requests only
/// pid/mount/ipc/uts), so uid/gid stay meaningful across the switch and only the
/// mount namespace has to be entered.
#[cfg(target_os = "linux")]
fn enter_mount_namespace(pid: u32) -> Result<(), String> {
    let ns = format!("/proc/{pid}/ns/mnt");
    let file = std::fs::File::open(&ns).map_err(|e| format!("open {ns}: {e}"))?;
    // SAFETY: `fd` is a live descriptor for a mount-namespace file; setns only
    // reads it. Single-threaded by construction (dispatched before any thread).
    let rc = unsafe {
        libc::setns(
            std::os::unix::io::AsRawFd::as_raw_fd(&file),
            libc::CLONE_NEWNS,
        )
    };
    if rc != 0 {
        return Err(format!("setns({ns}): {}", std::io::Error::last_os_error()));
    }
    // The old cwd belongs to the namespace we just left; a relative path or a
    // `..` walk from it would resolve outside the container.
    std::env::set_current_dir("/").map_err(|e| format!("chdir /: {e}"))?;
    Ok(())
}

/// Non-Linux stub. `setns`/`CLONE_NEWNS` are Linux-only, and the agent's unit
/// tests build on macOS. Unreachable in practice: the agent runs in a Linux
/// guest, and off Linux no workload container is ever resolved (`for_workload`
/// yields [`GuestNs::Root`]), so no caller ever spawns the helper off Linux.
#[cfg(not(target_os = "linux"))]
fn enter_mount_namespace(_pid: u32) -> Result<(), String> {
    Err("mount namespaces are Linux-only".to_string())
}

/// Open before checking metadata without blocking on a FIFO. Checking metadata
/// before open leaves a race where a path can be replaced by a FIFO in between.
/// O_NONBLOCK has no effect on ordinary files; the caller still rejects every
/// non-regular file before sending a successful read response.
pub(crate) fn open_file_for_read(path: &Path) -> std::io::Result<std::fs::File> {
    std::fs::OpenOptions::new()
        .read(true)
        .custom_flags(libc::O_NONBLOCK)
        .open(path)
}

fn helper_read(path: &str) -> Result<(), String> {
    let mut file = open_file_for_read(Path::new(path)).map_err(|e| format!("open {path}: {e}"))?;
    let meta = file.metadata().map_err(|e| format!("stat {path}: {e}"))?;
    // Same guard the in-VM path applies: a directory fails on read and a
    // character device may never EOF. O_NONBLOCK above also lets a FIFO reach
    // this check without waiting for a writer. Reject all of them before the
    // header commits us to a byte count.
    if !meta.is_file() {
        // See the note in the in-VM path: a directory is named specifically so
        // the caller can retry as a listing.
        return Err(if meta.is_dir() {
            format!("is a directory: {path}")
        } else {
            format!("not a regular file: {path}")
        });
    }
    let size = meta.len();
    let mut out = std::io::stdout().lock();
    out.write_all(format!("OK {size}\n").as_bytes())
        .map_err(|e| e.to_string())?;
    std::io::copy(&mut file, &mut out).map_err(|e| format!("read {path}: {e}"))?;
    out.flush().map_err(|e| e.to_string())?;
    Ok(())
}

/// List a directory inside the container's mount namespace.
///
/// One line of JSON rather than the `read` protocol's raw byte stream: a
/// listing is small and structured, and the parent wants to parse it rather
/// than copy it.
fn helper_list(path: &str) -> Result<(), String> {
    let entries = crate::list_directory_entries(path)?;
    let json = serde_json::to_string(&entries).map_err(|e| format!("serialize listing: {e}"))?;
    let mut out = std::io::stdout().lock();
    out.write_all(format!("OK {json}\n").as_bytes())
        .map_err(|e| format!("write listing: {e}"))?;
    out.flush().map_err(|e| format!("flush listing: {e}"))
}

fn helper_write(
    path: &str,
    mode: Option<u32>,
    uid: Option<u32>,
    gid: Option<u32>,
) -> Result<(), String> {
    let target = Path::new(path);
    let parent = target.parent().filter(|p| !p.as_os_str().is_empty());
    if let Some(dir) = parent {
        std::fs::create_dir_all(dir).map_err(|e| format!("create {}: {e}", dir.display()))?;
    }
    // Stage beside the target so the rename is same-filesystem and atomic: a
    // reader in the container sees either the old file or the whole new one.
    let tmp = target.with_file_name(format!(
        ".smolvm-upload.{}.{}",
        std::process::id(),
        target
            .file_name()
            .map(|n| n.to_string_lossy().into_owned())
            .unwrap_or_default()
    ));
    let mut file = std::fs::File::create(&tmp).map_err(|e| format!("create staging: {e}"))?;
    let mut stdin = std::io::stdin().lock();
    let copied = std::io::copy(&mut stdin, &mut file);
    if let Err(e) = copied {
        let _ = std::fs::remove_file(&tmp);
        return Err(format!("write {path}: {e}"));
    }
    if let Err(e) = file.sync_all() {
        let _ = std::fs::remove_file(&tmp);
        return Err(format!("fsync {path}: {e}"));
    }
    drop(file);
    if let Some(m) = mode {
        use std::os::unix::fs::PermissionsExt as _;
        if let Err(e) = std::fs::set_permissions(&tmp, std::fs::Permissions::from_mode(m)) {
            let _ = std::fs::remove_file(&tmp);
            return Err(format!("chmod {path}: {e}"));
        }
    }
    if uid.is_some() || gid.is_some() {
        if let Err(e) = std::os::unix::fs::chown(&tmp, uid, gid) {
            let _ = std::fs::remove_file(&tmp);
            return Err(format!("chown {path}: {e}"));
        }
    }
    if let Err(e) = std::fs::rename(&tmp, target) {
        let _ = std::fs::remove_file(&tmp);
        return Err(format!("rename into {path}: {e}"));
    }
    let mut out = std::io::stdout().lock();
    out.write_all(b"OK\n").map_err(|e| e.to_string())?;
    out.flush().map_err(|e| e.to_string())?;
    Ok(())
}

/// Dial `path` inside the container and hand the connected socket back.
///
/// A file operation can move bytes through a pipe, but a proxy needs the socket
/// ITSELF: the parent relays traffic for the life of the connection, so what has
/// to cross the process boundary is the descriptor, not its contents. `SCM_RIGHTS`
/// over the inherited stdin socket is the only way to pass one.
#[cfg(target_os = "linux")]
fn helper_connect(path: &str) -> Result<(), String> {
    use std::os::unix::io::AsRawFd as _;
    let app = std::os::unix::net::UnixStream::connect(path)
        .map_err(|e| format!("connect {path}: {e}"))?;
    // stdin is the parent's socketpair end (set by `ContainerNs::connect`).
    send_fd(libc::STDIN_FILENO, app.as_raw_fd())?;
    let mut out = std::io::stdout().lock();
    out.write_all(b"OK\n").map_err(|e| e.to_string())?;
    out.flush().map_err(|e| e.to_string())?;
    Ok(())
}

#[cfg(not(target_os = "linux"))]
fn helper_connect(_path: &str) -> Result<(), String> {
    Err("mount namespaces are Linux-only".to_string())
}

/// Send `fd` over `sock` as an SCM_RIGHTS control message.
///
/// One byte of payload accompanies it because a control message needs at least
/// one byte of data to be delivered.
#[cfg(target_os = "linux")]
fn send_fd(sock: libc::c_int, fd: libc::c_int) -> Result<(), String> {
    let mut byte = [0u8; 1];
    let mut iov = libc::iovec {
        iov_base: byte.as_mut_ptr().cast(),
        iov_len: 1,
    };
    let mut cmsg = [0u8; 32]; // >= CMSG_SPACE(sizeof(int))
    let mut msg: libc::msghdr = unsafe { std::mem::zeroed() };
    msg.msg_iov = &mut iov;
    msg.msg_iovlen = 1;
    msg.msg_control = cmsg.as_mut_ptr().cast();
    msg.msg_controllen = cmsg.len() as _;
    // SAFETY: `msg` points at live local storage sized per CMSG_SPACE, and the
    // header is filled exactly as sendmsg requires before the payload is copied.
    unsafe {
        let hdr = libc::CMSG_FIRSTHDR(&msg);
        (*hdr).cmsg_level = libc::SOL_SOCKET;
        (*hdr).cmsg_type = libc::SCM_RIGHTS;
        (*hdr).cmsg_len = libc::CMSG_LEN(std::mem::size_of::<libc::c_int>() as u32) as _;
        std::ptr::copy_nonoverlapping(&fd, libc::CMSG_DATA(hdr).cast::<libc::c_int>(), 1);
        msg.msg_controllen = (*hdr).cmsg_len;
        if libc::sendmsg(sock, &msg, 0) < 0 {
            return Err(format!("sendmsg: {}", std::io::Error::last_os_error()));
        }
    }
    Ok(())
}

// ===========================================================================
// Parent side
// ===========================================================================

/// Why guest I/O is happening in the VM's own namespace rather than a
/// container's.
///
/// Carried rather than discarded: the container path declining to run is
/// invisible from the outside — an upload still reports success, a socket dial
/// still returns — so without a reason a silent no-op is indistinguishable from
/// a working container. Diagnosing one such case took hours of reading bytes off
/// a live guest.
#[derive(Debug, Clone, PartialEq, Eq)]
#[cfg_attr(not(target_os = "linux"), allow(dead_code))]
pub enum RootReason {
    /// The request named the VM's own filesystem.
    VmTarget,
    /// Nothing is running: no container to enter.
    NoWorkload,
    /// Several unrelated workloads (a pod). Picking one would write into an
    /// arbitrary container's filesystem, so we decline instead of guessing.
    Ambiguous(usize),
}

impl std::fmt::Display for RootReason {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::VmTarget => write!(f, "the request targets the VM's own filesystem"),
            Self::NoWorkload => write!(f, "no running workload container"),
            Self::Ambiguous(n) => write!(f, "{n} running workload containers; cannot choose"),
        }
    }
}

/// A running workload container's mount namespace.
///
/// Holding this type IS the proof a container was found, so the operations below
/// exist only here — a caller cannot reach for them and silently get the VM's
/// namespace instead.
#[derive(Debug, Clone, Copy)]
pub struct ContainerNs {
    pid: u32,
}

/// Where a guest path or socket should be resolved.
///
/// Both arms are legitimate. The VM namespace is *correct* when no workload is
/// running: overlayfs reads `upper` at mount time, so seeding it before the
/// container starts is how a rootfs is pre-populated. What must never happen is
/// choosing it by accident.
#[derive(Debug, Clone)]
#[cfg_attr(not(target_os = "linux"), allow(dead_code))]
pub enum GuestNs {
    Root(RootReason),
    Container(ContainerNs),
}

impl GuestNs {
    /// Resolve where this machine's workload lives, logging the reason whenever
    /// the answer is the VM's own namespace.
    pub fn for_workload() -> Self {
        match workload_container() {
            Ok(pid) => Self::Container(ContainerNs { pid }),
            Err(reason) => {
                tracing::debug!(reason = %reason, "guest I/O staying in the VM namespace");
                Self::Root(reason)
            }
        }
    }

    /// The namespace of a container running on persistent overlay
    /// `workload_id`, whose mounted root is `merged`: its recorded main
    /// container when that runs there, else any container rooted on it. With
    /// none running, I/O goes through `merged` directly.
    pub fn on_overlay(workload_id: &str, merged: &Path) -> Self {
        match overlay_container(workload_id, merged) {
            Some(pid) => Self::Container(ContainerNs { pid }),
            None => Self::Root(RootReason::NoWorkload),
        }
    }
}

/// A running container whose root filesystem is the overlay mounted at
/// `merged`. A container's root is that very mount, so the two report the
/// same device and inode; nothing else does.
#[cfg(target_os = "linux")]
fn overlay_container(workload_id: &str, merged: &Path) -> Option<u32> {
    use std::os::unix::fs::MetadataExt;
    let root = std::fs::metadata(merged).ok()?;
    let rooted_here = |pid: u32| {
        std::fs::metadata(format!("/proc/{pid}/root"))
            .is_ok_and(|m| m.dev() == root.dev() && m.ino() == root.ino())
    };
    let main = std::fs::read_to_string(crate::paths::main_container_id_path(workload_id))
        .ok()
        .and_then(|cid| crate::crun_container_pid(cid.trim()))
        .filter(|pid| rooted_here(*pid));
    main.or_else(|| live_containers().into_iter().find(|pid| rooted_here(*pid)))
}

#[cfg(not(target_os = "linux"))]
fn overlay_container(_workload_id: &str, _merged: &Path) -> Option<u32> {
    None
}

/// The init PID of the container this machine's guest I/O belongs in.
///
/// Prefers the machine's recorded main container. When that is not running —
/// the normal state of an exec-driven machine, whose main container exits
/// between commands while each `exec` runs its own — it falls back to the single
/// container crun actually has running. Reading the overlay tree alone missed
/// those entirely, so the container path never engaged on such a machine and
/// every file operation silently took the VM-namespace route.
#[cfg(target_os = "linux")]
fn workload_container() -> Result<u32, RootReason> {
    let mains = live_main_containers();
    match mains.len() {
        1 => return Ok(mains[0]),
        0 => {}
        n => return Err(RootReason::Ambiguous(n)),
    }
    // No recorded main container is alive. Anything crun is running now shares
    // this machine's filesystem, so entering it resolves paths the same way.
    let running = live_containers();
    match running.len() {
        1 => Ok(running[0]),
        0 => Err(RootReason::NoWorkload),
        n => Err(RootReason::Ambiguous(n)),
    }
}

/// Off Linux there are no containers at all, which is what `NoWorkload` says.
/// Present so the agent's unit tests build on a developer machine.
#[cfg(not(target_os = "linux"))]
fn workload_container() -> Result<u32, RootReason> {
    Err(RootReason::NoWorkload)
}

/// PIDs of the running containers each overlay records as its main one.
#[cfg(target_os = "linux")]
fn live_main_containers() -> Vec<u32> {
    let Ok(entries) = std::fs::read_dir(crate::paths::OVERLAYS_DIR) else {
        return Vec::new();
    };
    entries
        .flatten()
        .filter_map(|e| std::fs::read_to_string(e.path().join("main_container_id")).ok())
        .filter_map(|cid| crate::crun_container_pid(cid.trim()))
        .collect()
}

/// PIDs of every container crun currently has running.
///
/// The crun state directory is the truth about what exists right now; the
/// overlay tree only records the container a machine was STARTED with. Entries
/// for exited containers resolve to `None` (their recorded pid no longer
/// matches), so they filter themselves out.
#[cfg(target_os = "linux")]
fn live_containers() -> Vec<u32> {
    let Ok(entries) = std::fs::read_dir(crate::paths::CRUN_ROOT_DIR) else {
        return Vec::new();
    };
    entries
        .flatten()
        .filter_map(|e| e.file_name().into_string().ok())
        .filter_map(|cid| crate::crun_container_pid(&cid))
        .collect()
}

/// A file opened inside the container, streaming over the helper's pipe.
///
/// The bytes are NOT buffered: `reader` is the live pipe, bounded to the size
/// the helper reported, so the existing chunked send streams straight through it
/// exactly as it did from a `File`.
pub struct ContainerFile {
    /// Kept so the helper is reaped when the transfer ends (or is abandoned).
    _child: std::process::Child,
    /// Size reported by the helper's `stat` inside the container.
    pub size: u64,
    /// Payload, capped at `size` so a misbehaving helper cannot overrun.
    pub reader: std::io::Take<std::io::BufReader<std::process::ChildStdout>>,
}

// Reachable only on Linux: `workload_container` yields a `ContainerNs` only
// there, so a developer build on macOS sees these as unused by construction.
#[cfg_attr(not(target_os = "linux"), allow(dead_code))]
impl ContainerNs {
    /// Open `path` inside the container for reading.
    pub fn open(&self, path: &str) -> Result<ContainerFile, String> {
        let mut child = Command::new(AGENT_BINARY)
            .args([HELPER_ARG, "read", &self.pid.to_string(), path])
            .stdout(Stdio::piped())
            .stderr(Stdio::null())
            .spawn()
            .map_err(|e| format!("spawn ns-file helper: {e}"))?;
        let stdout = child.stdout.take().expect("piped");
        let mut reader = std::io::BufReader::new(stdout);
        let mut header = String::new();
        reader
            .read_line(&mut header)
            .map_err(|e| format!("ns-file helper: {e}"))?;
        let header = header.trim_end();
        if let Some(msg) = header.strip_prefix("ERR ") {
            return Err(msg.to_string());
        }
        let size: u64 = header
            .strip_prefix("OK ")
            .and_then(|s| s.parse().ok())
            .ok_or_else(|| format!("ns-file helper: bad header {header:?}"))?;
        Ok(ContainerFile {
            _child: child,
            size,
            reader: reader.take(size),
        })
    }

    /// List a directory inside the container.
    pub fn list(&self, path: &str) -> Result<Vec<smolvm_protocol::DirectoryEntry>, String> {
        let out = Command::new(AGENT_BINARY)
            .args([HELPER_ARG, "list", &self.pid.to_string(), path])
            .stderr(Stdio::null())
            .output()
            .map_err(|e| format!("spawn ns-file helper: {e}"))?;
        let text = String::from_utf8_lossy(&out.stdout);
        let line = text.lines().next().unwrap_or("").trim_end();
        if let Some(msg) = line.strip_prefix("ERR ") {
            return Err(msg.to_string());
        }
        let json = line
            .strip_prefix("OK ")
            .ok_or_else(|| format!("ns-file helper: bad header {line:?}"))?;
        serde_json::from_str(json).map_err(|e| format!("parse listing: {e}"))
    }

    /// Write `data` to `path` inside the container, atomically, applying `mode`
    /// and `uid`/`gid` ownership so a non-root workload can read its own upload.
    pub fn write(
        &self,
        path: &str,
        data: &[u8],
        mode: Option<u32>,
        uid: Option<u32>,
        gid: Option<u32>,
    ) -> Result<(), String> {
        write_via_helper(
            self.pid,
            path,
            &mut std::io::Cursor::new(data),
            mode,
            uid,
            gid,
        )
    }

    /// Stream `reader` into `path` inside the container without buffering the
    /// whole payload — the streaming-upload counterpart to [`write`].
    pub fn write_reader<R: std::io::Read>(
        &self,
        path: &str,
        reader: &mut R,
        mode: Option<u32>,
        uid: Option<u32>,
        gid: Option<u32>,
    ) -> Result<(), String> {
        write_via_helper(self.pid, path, reader, mode, uid, gid)
    }

    /// Dial `path` inside the container and return the connected socket.
    ///
    /// The descriptor is received over a socketpair given to the helper as its
    /// stdin, so the caller relays traffic on a socket that was opened with the
    /// container's view of the filesystem.
    #[cfg(target_os = "linux")]
    pub fn connect(&self, path: &str) -> Result<std::os::unix::net::UnixStream, String> {
        use std::os::unix::io::{AsRawFd as _, FromRawFd as _, IntoRawFd as _};
        let (ours, theirs) =
            std::os::unix::net::UnixStream::pair().map_err(|e| format!("socketpair: {e}"))?;
        let child = Command::new(AGENT_BINARY)
            .args([HELPER_ARG, "connect", &self.pid.to_string(), path])
            // SAFETY: `theirs` is an owned socket handed to the child as fd 0.
            .stdin(unsafe { Stdio::from_raw_fd(theirs.into_raw_fd()) })
            .stdout(Stdio::piped())
            .stderr(Stdio::null())
            .spawn()
            .map_err(|e| format!("spawn ns-file helper: {e}"))?;
        let out = child
            .wait_with_output()
            .map_err(|e| format!("ns-file helper: {e}"))?;
        // Check the reply BEFORE reading a descriptor: on failure there is none,
        // and the error text says why the dial failed inside the container.
        parse_ok_reply(&String::from_utf8_lossy(&out.stdout))?;
        let fd = recv_fd(ours.as_raw_fd())?;
        // SAFETY: `fd` was just received via SCM_RIGHTS and is owned by us.
        Ok(unsafe { std::os::unix::net::UnixStream::from_raw_fd(fd) })
    }

    #[cfg(not(target_os = "linux"))]
    pub fn connect(&self, _path: &str) -> Result<std::os::unix::net::UnixStream, String> {
        Err("mount namespaces are Linux-only".to_string())
    }
}

/// Receive a descriptor sent with [`send_fd`].
#[cfg(target_os = "linux")]
fn recv_fd(sock: libc::c_int) -> Result<libc::c_int, String> {
    let mut byte = [0u8; 1];
    let mut iov = libc::iovec {
        iov_base: byte.as_mut_ptr().cast(),
        iov_len: 1,
    };
    let mut cmsg = [0u8; 32];
    let mut msg: libc::msghdr = unsafe { std::mem::zeroed() };
    msg.msg_iov = &mut iov;
    msg.msg_iovlen = 1;
    msg.msg_control = cmsg.as_mut_ptr().cast();
    msg.msg_controllen = cmsg.len() as _;
    // SAFETY: `msg` describes live local storage; the header is inspected only
    // after recvmsg reports success, and only for an SCM_RIGHTS payload.
    unsafe {
        if libc::recvmsg(sock, &mut msg, 0) < 0 {
            return Err(format!("recvmsg: {}", std::io::Error::last_os_error()));
        }
        let hdr = libc::CMSG_FIRSTHDR(&msg);
        if hdr.is_null()
            || (*hdr).cmsg_level != libc::SOL_SOCKET
            || (*hdr).cmsg_type != libc::SCM_RIGHTS
        {
            return Err("helper sent no descriptor".to_string());
        }
        let mut fd: libc::c_int = -1;
        std::ptr::copy_nonoverlapping(libc::CMSG_DATA(hdr).cast::<libc::c_int>(), &mut fd, 1);
        if fd < 0 {
            return Err("helper sent an invalid descriptor".to_string());
        }
        Ok(fd)
    }
}

fn write_via_helper<R: std::io::Read>(
    pid: u32,
    path: &str,
    data: &mut R,
    mode: Option<u32>,
    uid: Option<u32>,
    gid: Option<u32>,
) -> Result<(), String> {
    // Fixed positional args; "-" is the explicit "not requested" placeholder
    // so uid/gid can follow an absent mode unambiguously.
    let args = vec![
        HELPER_ARG.to_string(),
        "write".to_string(),
        pid.to_string(),
        path.to_string(),
        mode.map_or_else(|| "-".to_string(), |m| format!("{m:o}")),
        uid.map_or_else(|| "-".to_string(), |u| u.to_string()),
        gid.map_or_else(|| "-".to_string(), |g| g.to_string()),
    ];
    let mut child = Command::new(AGENT_BINARY)
        .args(&args)
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::null())
        .spawn()
        .map_err(|e| format!("spawn ns-file helper: {e}"))?;
    {
        let mut stdin = child.stdin.take().expect("piped");
        std::io::copy(data, &mut stdin).map_err(|e| format!("ns-file helper write: {e}"))?;
    } // drop closes stdin → helper sees EOF
    let out = child
        .wait_with_output()
        .map_err(|e| format!("ns-file helper: {e}"))?;
    parse_ok_reply(&String::from_utf8_lossy(&out.stdout))
}

/// Strict reply parsing: anything that is not exactly `OK` is a failure, so a
/// truncated or unexpected reply is never read as success.
fn parse_ok_reply(reply: &str) -> Result<(), String> {
    match reply.trim_end() {
        "OK" => Ok(()),
        other => Err(other
            .strip_prefix("ERR ")
            .unwrap_or("ns-file helper failed")
            .to_string()),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[cfg(target_os = "linux")]
    #[test]
    fn file_read_open_does_not_block_on_a_fifo_or_a_symlink_to_one() {
        use std::ffi::CString;
        use std::io::Read as _;
        use std::os::unix::ffi::OsStrExt as _;
        use std::time::Duration;

        let dir = tempfile::tempdir().unwrap();
        let pipe = dir.path().join("pipe");
        let name = CString::new(pipe.as_os_str().as_bytes()).unwrap();
        assert_eq!(unsafe { libc::mkfifo(name.as_ptr(), 0o600) }, 0);
        let link = dir.path().join("link");
        std::os::unix::fs::symlink(&pipe, &link).unwrap();

        // A blocking open of either path would hang this test without a writer.
        for path in [pipe, link] {
            let (tx, rx) = std::sync::mpsc::channel();
            std::thread::spawn(move || {
                let file = open_file_for_read(&path).unwrap();
                tx.send(file.metadata().unwrap().is_file()).unwrap();
            });
            assert!(!rx.recv_timeout(Duration::from_secs(2)).unwrap());
        }

        let regular = dir.path().join("regular");
        std::fs::write(&regular, b"hello").unwrap();
        let mut file = open_file_for_read(&regular).unwrap();
        let mut data = Vec::new();
        file.read_to_end(&mut data).unwrap();
        assert_eq!(data, b"hello");
    }

    #[test]
    fn helper_is_selected_only_by_the_exact_marker() {
        // Guards the dispatch in `main`: matching too loosely would turn a normal
        // agent boot into a helper run.
        assert_eq!(HELPER_ARG, "ns-file");
    }

    // The cache goes into each container's namespace once, and never into the
    // caller's or the VM's, which already have it.
    #[test]
    fn each_container_namespace_is_entered_once() {
        let candidates = [(10, "vm"), (20, "a"), (21, "a"), (30, "b"), (40, "self")];
        let pids = namespaces_to_enter(candidates, &[Some("self"), Some("vm")]);
        assert_eq!(pids, vec![20, 30]);
    }

    #[test]
    fn a_write_reply_is_parsed_strictly() {
        // The parent must not read a truncated or unexpected reply as success.
        for bad in ["", "ERR boom", "OKAY", "ERR "] {
            assert_ne!(bad.trim_end(), "OK", "{bad:?} must not look like success");
        }
    }
}

#[cfg(test)]
mod guest_ns_tests {
    use super::{parse_ok_reply, RootReason};

    #[test]
    fn a_fallback_to_the_vm_namespace_always_carries_a_reason() {
        // The container path declining to run is invisible from outside: an
        // upload still reports success and a dial still returns. Without a
        // reason, a silent no-op is indistinguishable from a working container —
        // which is what made one such case take hours to find.
        for r in [RootReason::NoWorkload, RootReason::Ambiguous(3)] {
            assert!(!r.to_string().is_empty(), "{r:?} must explain itself");
        }
        assert!(RootReason::Ambiguous(3).to_string().contains('3'));
    }

    #[test]
    fn only_an_exact_ok_is_success() {
        // A truncated or unexpected reply must never read as success: the write
        // path reports 200 on Ok, so a loose parse silently loses a file.
        assert!(parse_ok_reply("OK\n").is_ok());
        assert!(parse_ok_reply("OK").is_ok());
        for bad in ["", "OKAY", "ERR boom", "ERR ", "ok"] {
            assert!(parse_ok_reply(bad).is_err(), "{bad:?} must not be success");
        }
    }

    #[test]
    fn a_helper_error_reaches_the_caller_verbatim() {
        // The reason a dial or write failed INSIDE the container is the only
        // diagnostic the operator gets; swallowing it leaves an unexplained 500.
        assert_eq!(
            parse_ok_reply("ERR connect /run/app.sock: No such file or directory").unwrap_err(),
            "connect /run/app.sock: No such file or directory"
        );
    }

    #[test]
    fn an_unrecognised_reply_is_not_reported_as_an_empty_error() {
        assert_eq!(
            parse_ok_reply("garbage").unwrap_err(),
            "ns-file helper failed"
        );
    }
}
