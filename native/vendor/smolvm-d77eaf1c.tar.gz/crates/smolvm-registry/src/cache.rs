//! Local blob cache for registry pulls.
//!
//! Content-addressed storage at `~/.cache/smolvm-registry/blobs/sha256/`.
//! Blobs are stored by their digest, each with a zero-length `.used` sibling
//! that records when it was last read. LRU eviction keeps total size under a
//! configurable limit — default 5 GB, override with `SMOLVM_BLOB_CACHE_MAX_BYTES`.

use sha2::{Digest, Sha256};
use std::fs;
use std::io::{self, Read, Write};
use std::path::{Path, PathBuf};

/// Subdirectory holding manifests fetched by digest (see
/// [`BlobCache::manifest_by_digest`]); a directory, so the blob walks skip it.
const MANIFEST_DIR: &str = "manifests";

/// Subdirectory holding per-blob download locks (see
/// [`BlobCache::download_lock_file`]); a directory, so the blob walks skip it.
const LOCK_DIR: &str = "locks";

/// Subdirectory recording which reference each pull resolved to which blob
/// (see [`BlobCache::record_pull`]); a directory, so the blob walks skip it.
const REFS_DIR: &str = "refs";

/// What one pull of a reference left in the cache.
#[derive(Debug, Clone, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct PulledRef {
    /// Registry host the blob came from (`registry.smolmachines.com`).
    pub registry: String,
    /// Repository within the registry (`library/pi`).
    pub repository: String,
    /// Tag or digest the pull asked for (`latest`, `sha256:…`).
    pub reference: String,
    /// Digest of the `.smolmachine` blob it resolved to.
    pub digest: String,
    /// When the pull finished, as seconds since the Unix epoch.
    pub pulled_at: u64,
}

/// A `.smolmachine` blob in the cache, with the pulls that resolved to it.
#[derive(Debug, Clone, serde::Serialize)]
pub struct CachedArtifact {
    /// Digest of the blob.
    pub digest: String,
    /// Size of the blob in bytes.
    pub size: u64,
    /// Path of the blob, usable wherever a `.smolmachine` file is.
    pub path: PathBuf,
    /// Pulls that resolved to this blob, newest first. Empty for a blob put
    /// here some other way (a portable checkpoint, or a pull by an older
    /// smolvm that recorded nothing).
    pub refs: Vec<PulledRef>,
}

/// `sha256:<hex>` of `bytes`.
fn digest_of(bytes: &[u8]) -> String {
    format!("sha256:{:x}", Sha256::digest(bytes))
}

/// Default maximum blob-cache size when `SMOLVM_BLOB_CACHE_MAX_BYTES` is unset: 5 GB.
const DEFAULT_MAX_SIZE: u64 = 5 * 1024 * 1024 * 1024;

/// Resolve the blob-cache byte cap from `SMOLVM_BLOB_CACHE_MAX_BYTES`, falling
/// back to [`DEFAULT_MAX_SIZE`]. A fleet pulling multi-GB `.smolmachine`
/// artifacts should set this well above the largest artifact (bounded by disk)
/// so hot worlds are not re-pulled from the registry on every launch.
fn configured_max_size() -> u64 {
    parse_cache_limit(std::env::var("SMOLVM_BLOB_CACHE_MAX_BYTES").ok().as_deref())
}

/// Parse a byte-count cache limit, ignoring absent / unparseable / zero values.
/// Split out from `configured_max_size` so it is unit-testable without touching
/// the process-global environment.
fn parse_cache_limit(val: Option<&str>) -> u64 {
    val.and_then(|v| v.trim().parse::<u64>().ok())
        .filter(|&n| n > 0)
        .unwrap_or(DEFAULT_MAX_SIZE)
}

/// True if a cache-dir entry is an in-flight `.partial` download rather than a
/// finalized blob. A partial is being streamed by an active pull, so it must
/// never be counted toward the cache size or evicted — deleting one makes the
/// owning pull's `adopt` rename fail with ENOENT ("No such file or directory"),
/// which surfaces as `registry pull failed` on large artifacts (only large ones
/// push the cache over its cap and trigger eviction in the first place).
fn is_partial(path: &Path) -> bool {
    path.extension().and_then(|e| e.to_str()) == Some("partial")
}

/// True if a cache-dir entry is a `.used` recency marker rather than a blob.
///
/// Recency lives on a zero-length sibling instead of the blob's own inode
/// because a cache hit must not write to the blob at all: a hit used to set
/// the blob's atime for LRU, and on Linux every `utimensat` also moves the
/// inode's ctime. A machine create that pins a verified artifact by its exact
/// inode identity (device, inode, length, mtime, ctime) then sees "changed
/// while it was being verified" whenever another create of the same artifact
/// hits the cache mid-verification — a burst of creates from one pack failed
/// at random for that reason alone.
fn is_lru_marker(path: &Path) -> bool {
    path.extension().and_then(|e| e.to_str()) == Some(LRU_MARKER_EXT)
}

const LRU_MARKER_EXT: &str = "used";

fn lru_marker_path(blob: &Path) -> PathBuf {
    let mut name = blob.as_os_str().to_owned();
    name.push(".");
    name.push(LRU_MARKER_EXT);
    PathBuf::from(name)
}

/// Record that `blob` was just used. Writes only the marker, never the blob.
fn note_used(blob: &Path) {
    let marker = lru_marker_path(blob);
    let created = fs::OpenOptions::new()
        .create(true)
        .append(true)
        .open(&marker)
        .is_ok();
    if created {
        let _ = filetime::set_file_mtime(&marker, filetime::FileTime::now());
    }
}

/// When `blob` was last used: its marker's mtime, or for a blob cached before
/// markers existed, the atime the old scheme maintained.
fn last_used(blob: &Path, meta: &fs::Metadata) -> std::time::SystemTime {
    fs::metadata(lru_marker_path(blob))
        .and_then(|m| m.modified())
        .or_else(|_| meta.accessed())
        .unwrap_or(std::time::UNIX_EPOCH)
}

/// Content-addressed blob cache.
pub struct BlobCache {
    root: PathBuf,
    max_size: u64,
}

impl BlobCache {
    /// Open or create a cache at the default location.
    pub fn open_default() -> std::io::Result<Self> {
        let cache_dir = dirs::cache_dir()
            .ok_or_else(|| std::io::Error::new(std::io::ErrorKind::NotFound, "no cache dir"))?
            .join("smolvm-registry")
            .join("blobs");
        Self::open(cache_dir, configured_max_size())
    }

    /// Open or create a cache at a specific path with a size limit.
    pub fn open(root: PathBuf, max_size: u64) -> std::io::Result<Self> {
        fs::create_dir_all(&root)?;
        Ok(Self { root, max_size })
    }

    /// Look up a blob by digest. Returns the path if it exists.
    pub fn get(&self, digest: &str) -> Option<PathBuf> {
        let path = self.blob_path(digest);
        if path.exists() {
            note_used(&path);
            Some(path)
        } else {
            None
        }
    }

    /// Store a blob. Returns the path where it was written.
    ///
    /// If storing this blob would exceed `max_size`, evicts least-recently-accessed
    /// blobs first.
    pub fn put(&self, digest: &str, data: &[u8]) -> std::io::Result<PathBuf> {
        let path = self.blob_path(digest);
        if path.exists() {
            return Ok(path);
        }

        // Evict if needed.
        let current = self.total_size()?;
        if current + data.len() as u64 > self.max_size {
            self.evict_until(self.max_size.saturating_sub(data.len() as u64))?;
        }

        // Write atomically via temp file.
        let tmp = path.with_extension("partial");
        fs::write(&tmp, data)?;
        fs::rename(&tmp, &path)?;
        Ok(path)
    }

    /// Import a local artifact without loading it into memory. The copied bytes
    /// must match `digest` before they become visible to cache readers.
    pub fn put_file_verified(&self, digest: &str, source: &Path) -> io::Result<PathBuf> {
        if let Some(path) = self.get(digest) {
            return Ok(path);
        }
        let mut source = fs::File::open(source)?;
        // A `.partial` file is excluded from eviction until it is published.
        let mut staged = tempfile::Builder::new()
            .suffix(".partial")
            .tempfile_in(&self.root)?;
        let mut hasher = Sha256::new();
        let mut buffer = [0u8; 1024 * 1024];
        let mut size = 0u64;
        loop {
            let count = source.read(&mut buffer)?;
            if count == 0 {
                break;
            }
            staged.write_all(&buffer[..count])?;
            hasher.update(&buffer[..count]);
            size += count as u64;
        }
        if digest != format!("sha256:{:x}", hasher.finalize()) {
            return Err(io::Error::new(
                io::ErrorKind::InvalidData,
                "local pack digest changed while caching",
            ));
        }
        staged.as_file().sync_all()?;
        let path = self.blob_path(digest);
        let current = self.total_size()?;
        if current.saturating_add(size) > self.max_size {
            self.evict_until(self.max_size.saturating_sub(size))?;
        }
        match staged.persist_noclobber(&path) {
            Ok(_) => Ok(path),
            Err(error) if error.error.kind() == io::ErrorKind::AlreadyExists => Ok(path),
            Err(error) => Err(error.error),
        }
    }

    /// Total size of all cached blobs in bytes.
    pub fn total_size(&self) -> std::io::Result<u64> {
        let mut total = 0u64;
        if self.root.exists() {
            for entry in fs::read_dir(&self.root)? {
                let entry = entry?;
                let path = entry.path();
                if entry.file_type()?.is_file() && !is_partial(&path) && !is_lru_marker(&path) {
                    total += entry.metadata()?.len();
                }
            }
        }
        Ok(total)
    }

    /// Remove all cached blobs.
    pub fn prune_all(&self) -> std::io::Result<u64> {
        let mut freed = 0u64;
        if self.root.exists() {
            for entry in fs::read_dir(&self.root)? {
                let entry = entry?;
                if entry.file_type()?.is_file() {
                    freed += entry.metadata()?.len();
                    fs::remove_file(entry.path())?;
                }
            }
            let _ = fs::remove_dir_all(self.root.join(MANIFEST_DIR));
            let _ = fs::remove_dir_all(self.root.join(REFS_DIR));
        }
        Ok(freed)
    }

    /// Record that pulling `registry`/`repository`:`reference` produced the
    /// blob `digest`, replacing what an earlier pull of the same reference
    /// recorded (a tag moved on is listed under its new blob).
    pub fn record_pull(&self, pulled: &PulledRef) -> io::Result<()> {
        let dir = self.root.join(REFS_DIR);
        fs::create_dir_all(&dir)?;
        let mut key = Sha256::new();
        for part in [&pulled.registry, &pulled.repository, &pulled.reference] {
            key.update(part.as_bytes());
            key.update([0]);
        }
        let mut staged = tempfile::Builder::new()
            .suffix(".partial")
            .tempfile_in(&dir)?;
        serde_json::to_writer(&mut staged, pulled)?;
        staged
            .persist(dir.join(format!("{:x}.json", key.finalize())))
            .map_err(|error| error.error)?;
        Ok(())
    }

    /// Every blob in the cache with the references pulled to it, most recently
    /// pulled first. Records whose blob was evicted are dropped.
    pub fn list_artifacts(&self) -> io::Result<Vec<CachedArtifact>> {
        let mut by_digest: std::collections::BTreeMap<String, CachedArtifact> =
            std::collections::BTreeMap::new();
        if !self.root.exists() {
            return Ok(Vec::new());
        }
        for entry in fs::read_dir(&self.root)? {
            let entry = entry?;
            let path = entry.path();
            if !entry.file_type()?.is_file() || is_partial(&path) || is_lru_marker(&path) {
                continue;
            }
            let Some(digest) = path
                .file_name()
                .and_then(|n| n.to_str())
                .and_then(|n| n.strip_prefix("sha256_"))
                .map(|hex| format!("sha256:{hex}"))
            else {
                continue;
            };
            by_digest.insert(
                digest.clone(),
                CachedArtifact {
                    digest,
                    size: entry.metadata()?.len(),
                    path,
                    refs: Vec::new(),
                },
            );
        }
        if let Ok(refs) = fs::read_dir(self.root.join(REFS_DIR)) {
            for entry in refs.flatten() {
                let Ok(bytes) = fs::read(entry.path()) else {
                    continue;
                };
                let Ok(pulled) = serde_json::from_slice::<PulledRef>(&bytes) else {
                    continue;
                };
                if let Some(artifact) = by_digest.get_mut(&pulled.digest) {
                    artifact.refs.push(pulled);
                }
            }
        }
        let mut artifacts: Vec<CachedArtifact> = by_digest.into_values().collect();
        for artifact in &mut artifacts {
            artifact
                .refs
                .sort_by_key(|a| std::cmp::Reverse(a.pulled_at));
        }
        artifacts
            .sort_by_key(|a| std::cmp::Reverse(a.refs.first().map(|r| r.pulled_at).unwrap_or(0)));
        Ok(artifacts)
    }

    /// Evict least-recently-accessed blobs until total size is at or below `target`.
    fn evict_until(&self, target: u64) -> std::io::Result<()> {
        let mut entries: Vec<(PathBuf, u64, std::time::SystemTime)> = Vec::new();

        for entry in fs::read_dir(&self.root)? {
            let entry = entry?;
            // Never evict in-flight `.partial` downloads — a concurrent pull is
            // actively writing them; deleting one breaks its adopt with ENOENT.
            let path = entry.path();
            if !entry.file_type()?.is_file() || is_partial(&path) || is_lru_marker(&path) {
                continue;
            }
            let meta = entry.metadata()?;
            let used = last_used(&path, &meta);
            entries.push((path, meta.len(), used));
        }

        // Least recently used first.
        entries.sort_by_key(|(_, _, used)| *used);

        let mut current = entries.iter().map(|(_, size, _)| size).sum::<u64>();

        for (path, size, _) in &entries {
            if current <= target {
                break;
            }
            tracing::debug!(path = %path.display(), size, "evicting cached blob");
            fs::remove_file(path)?;
            let _ = fs::remove_file(lru_marker_path(path));
            current -= size;
        }

        Ok(())
    }

    /// Remove `.partial` files untouched for `max_age` that no pull is writing,
    /// returning the bytes freed.
    ///
    /// A pull that is cancelled or crashes leaves its partial behind, and
    /// nothing else ever removed one: eviction skips partials because an active
    /// pull may be writing them, so workers kept abandoned downloads from months
    /// earlier. A resumable `<digest>.partial` is in use exactly while its
    /// blob's download lock is held, so one whose lock this sweep can take is
    /// abandoned; a recent one is kept so a retry can still resume it. Other
    /// partials are temp files that live only within one call.
    pub fn sweep_abandoned_partials(&self, max_age: std::time::Duration) -> io::Result<u64> {
        let now = std::time::SystemTime::now();
        let mut freed = 0u64;
        for entry in fs::read_dir(&self.root)? {
            let entry = entry?;
            let path = entry.path();
            if !entry.file_type()?.is_file() || !is_partial(&path) {
                continue;
            }
            let meta = entry.metadata()?;
            let age = now.duration_since(meta.modified()?).unwrap_or_default();
            if age < max_age {
                continue;
            }
            let digest = path
                .file_stem()
                .and_then(|stem| stem.to_str())
                .map(|stem| stem.trim_end_matches(".ranged"))
                .filter(|stem| stem.starts_with("sha256_"))
                .map(|stem| stem.replacen('_', ":", 1));
            let _lock = match digest {
                Some(digest) => {
                    let lock = self.download_lock_file(&digest)?;
                    match lock.try_lock() {
                        Ok(()) => Some(lock),
                        Err(fs::TryLockError::WouldBlock) => continue,
                        Err(fs::TryLockError::Error(e)) => return Err(e),
                    }
                }
                None => None,
            };
            match fs::remove_file(&path) {
                Ok(()) => {
                    tracing::info!(path = %path.display(), bytes = meta.len(), "removed an abandoned partial download");
                    freed += meta.len();
                }
                Err(e) if e.kind() == io::ErrorKind::NotFound => {}
                Err(e) => return Err(e),
            }
        }
        Ok(freed)
    }

    /// Return the cache path for a blob with this digest.
    ///
    /// Used by the pull flow to write directly to `path.with_extension("partial")`,
    /// then call [`adopt`] to finalize.
    pub fn blob_path_for(&self, digest: &str) -> PathBuf {
        self.blob_path(digest)
    }

    /// Open (creating if needed) the file a pull locks while it fetches this
    /// blob. Every fetch of a blob streams into the same `<digest>.partial`, so
    /// two at once write into one file and the second fails with ENOENT when
    /// the first renames it into place. Holding an exclusive lock on this file
    /// across the cache check and the fetch makes the later pull wait and then
    /// find the blob cached. Lock files are never removed: a pull that opened a
    /// removed one would lock an inode no one else can see.
    pub fn download_lock_file(&self, digest: &str) -> io::Result<fs::File> {
        let dir = self.root.join(LOCK_DIR);
        fs::create_dir_all(&dir)?;
        fs::OpenOptions::new()
            .create(true)
            .truncate(false)
            .write(true)
            .open(dir.join(format!("{}.lock", digest.replace(':', "_"))))
    }

    /// Adopt an externally-written partial file into the cache.
    ///
    /// Expects the file at `blob_path_for(digest).with_extension("partial")` to
    /// be fully written and digest-verified by the caller. Handles eviction if
    /// needed, then atomically renames the partial file into place.
    pub fn adopt(&self, digest: &str, size: u64) -> std::io::Result<PathBuf> {
        let path = self.blob_path(digest);
        let partial = path.with_extension("partial");

        if path.exists() {
            // Already cached (race condition protection).
            let _ = fs::remove_file(&partial);
            return Ok(path);
        }

        let current = self.total_size()?;
        if current + size > self.max_size {
            self.evict_until(self.max_size.saturating_sub(size))?;
        }

        fs::rename(&partial, &path)?;
        Ok(path)
    }

    /// A manifest previously fetched from `registry`/`repo` by `digest`.
    ///
    /// A digest names exact content, so a manifest fetched by one never changes
    /// and need not be fetched again. It is keyed by registry and repo as well
    /// as digest because the registry fetch is what authorizes the caller for
    /// that repo: a hit only reuses what was already fetched for the same repo.
    /// The bytes are returned only while they still hash to `digest`.
    pub fn manifest_by_digest(&self, registry: &str, repo: &str, digest: &str) -> Option<Vec<u8>> {
        let path = self.manifest_path(registry, repo, digest)?;
        let bytes = fs::read(&path).ok()?;
        (digest_of(&bytes) == digest).then_some(bytes)
    }

    /// Record a manifest fetched from `registry`/`repo` by `digest`. Bytes that
    /// do not hash to `digest` (an index resolved to one of its entries) are not
    /// stored and `Ok(false)` is returned.
    pub fn put_manifest_by_digest(
        &self,
        registry: &str,
        repo: &str,
        digest: &str,
        bytes: &[u8],
    ) -> io::Result<bool> {
        let Some(path) = self.manifest_path(registry, repo, digest) else {
            return Ok(false);
        };
        if digest_of(bytes) != digest {
            return Ok(false);
        }
        let dir = self.root.join(MANIFEST_DIR);
        fs::create_dir_all(&dir)?;
        let mut staged = tempfile::Builder::new()
            .suffix(".partial")
            .tempfile_in(&dir)?;
        staged.write_all(bytes)?;
        staged.persist(&path).map_err(|error| error.error)?;
        Ok(true)
    }

    /// Where a digest-addressed manifest lives, or `None` for a malformed digest.
    fn manifest_path(&self, registry: &str, repo: &str, digest: &str) -> Option<PathBuf> {
        let hex = digest.strip_prefix("sha256:")?;
        if hex.len() != 64 || !hex.chars().all(|c| c.is_ascii_hexdigit()) {
            return None;
        }
        let mut scope = Sha256::new();
        scope.update(registry.as_bytes());
        scope.update([0]);
        scope.update(repo.as_bytes());
        Some(self.root.join(MANIFEST_DIR).join(format!(
            "{:x}-{}",
            scope.finalize(),
            hex.to_ascii_lowercase()
        )))
    }

    /// Path for a blob with the given digest.
    fn blob_path(&self, digest: &str) -> PathBuf {
        // Store as flat files: "sha256:abc..." → "sha256_abc..."
        let filename = digest.replace(':', "_");
        self.root.join(filename)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_put_and_get() {
        let tmp = tempfile::tempdir().unwrap();
        let cache = BlobCache::open(tmp.path().to_path_buf(), 1024 * 1024).unwrap();

        let digest = "sha256:abcdef0123456789abcdef0123456789abcdef0123456789abcdef0123456789";
        let data = b"hello world";

        // Miss before put.
        assert!(cache.get(digest).is_none());

        // Put and get.
        let path = cache.put(digest, data).unwrap();
        assert!(path.exists());
        assert_eq!(fs::read(&path).unwrap(), data);

        // Hit after put.
        assert!(cache.get(digest).is_some());
    }

    #[test]
    fn local_file_import_is_content_addressed_and_independent_of_source() {
        let tmp = tempfile::tempdir().unwrap();
        // An artifact larger than the cache cap must still publish; its staging
        // file must never be mistaken for an evictable blob.
        let cache = BlobCache::open(tmp.path().join("cache"), 8).unwrap();
        let source = tmp.path().join("pack.smolmachine");
        fs::write(&source, b"packed layers").unwrap();
        let digest = format!("sha256:{:x}", Sha256::digest(b"packed layers"));
        let wrong = format!("sha256:{:x}", Sha256::digest(b"other layers"));

        assert_eq!(
            cache.put_file_verified(&wrong, &source).unwrap_err().kind(),
            io::ErrorKind::InvalidData
        );
        assert!(cache.get(&wrong).is_none());

        let cached = cache.put_file_verified(&digest, &source).unwrap();
        fs::remove_file(&source).unwrap();
        assert_eq!(fs::read(&cached).unwrap(), b"packed layers");
        assert_eq!(cache.get(&digest), Some(cached));
    }

    #[test]
    fn test_put_idempotent() {
        let tmp = tempfile::tempdir().unwrap();
        let cache = BlobCache::open(tmp.path().to_path_buf(), 1024 * 1024).unwrap();

        let digest = "sha256:abcdef0123456789abcdef0123456789abcdef0123456789abcdef0123456789";
        cache.put(digest, b"data1").unwrap();
        // Second put with same digest doesn't overwrite.
        cache.put(digest, b"data2").unwrap();
        let path = cache.get(digest).unwrap();
        assert_eq!(fs::read(path).unwrap(), b"data1");
    }

    #[test]
    fn test_eviction() {
        let tmp = tempfile::tempdir().unwrap();
        // Tiny cache: 20 bytes max.
        let cache = BlobCache::open(tmp.path().to_path_buf(), 20).unwrap();

        let d1 = "sha256:1111111111111111111111111111111111111111111111111111111111111111";
        let d2 = "sha256:2222222222222222222222222222222222222222222222222222222222222222";

        cache.put(d1, &[0u8; 15]).unwrap();
        assert!(cache.get(d1).is_some());

        // This should trigger eviction of d1.
        cache.put(d2, &[0u8; 15]).unwrap();
        assert!(cache.get(d2).is_some());
        // d1 should have been evicted.
        assert!(cache.get(d1).is_none());
    }

    #[test]
    fn evict_does_not_delete_in_flight_partial() {
        // Regression (large-artifact "registry pull failed: No such file or
        // directory"): under cache pressure, a pull's eviction must not delete
        // ANOTHER concurrent pull's in-flight `.partial` download, nor its own.
        // Before the fix, `total_size`/`evict_until` counted and removed
        // `.partial` files, so the victim's `adopt` rename hit ENOENT. Only
        // large artifacts trip it because only they push the cache over its cap.
        let tmp = tempfile::tempdir().unwrap();
        let cache = BlobCache::open(tmp.path().to_path_buf(), 100).unwrap();

        let victim = "sha256:1111111111111111111111111111111111111111111111111111111111111111";
        let pulling = "sha256:2222222222222222222222222222222222222222222222222222222222222222";

        // A concurrent pull is mid-download: its large `.partial` is on disk.
        let victim_partial = cache.blob_path_for(victim).with_extension("partial");
        fs::write(&victim_partial, [0u8; 80]).unwrap();

        // This pull finishes streaming its own large blob and adopts it — which
        // triggers eviction because the cache dir now looks over-cap.
        let pulling_partial = cache.blob_path_for(pulling).with_extension("partial");
        fs::write(&pulling_partial, [0u8; 80]).unwrap();
        let adopted = cache
            .adopt(pulling, 80)
            .expect("adopt must not fail — its own .partial must survive eviction");

        assert!(adopted.exists(), "adopted blob missing after rename");
        assert!(
            victim_partial.exists(),
            "eviction deleted another concurrent pull's in-flight .partial (the ENOENT bug)"
        );
    }

    /// Workers kept abandoned partial downloads for months: nothing removed a
    /// partial a cancelled pull left behind. A sweep removes an old one no pull
    /// holds, and keeps a recent one (a retry may resume it), one whose pull is
    /// running, and every finished blob.
    #[test]
    fn a_sweep_removes_only_old_partials_no_pull_is_writing() {
        let tmp = tempfile::tempdir().unwrap();
        let cache = BlobCache::open(tmp.path().to_path_buf(), u64::MAX).unwrap();
        let day = std::time::Duration::from_secs(24 * 60 * 60);
        let age = |path: &Path, by: std::time::Duration| {
            fs::File::options()
                .write(true)
                .open(path)
                .unwrap()
                .set_modified(std::time::SystemTime::now() - by)
                .unwrap();
        };
        let partial = |digest: &str| cache.blob_path_for(digest).with_extension("partial");
        let abandoned = "sha256:1111111111111111111111111111111111111111111111111111111111111111";
        let recent = "sha256:2222222222222222222222222222222222222222222222222222222222222222";
        let pulling = "sha256:3333333333333333333333333333333333333333333333333333333333333333";
        for digest in [abandoned, recent, pulling] {
            fs::write(partial(digest), [0u8; 64]).unwrap();
        }
        age(&partial(abandoned), 2 * day);
        age(&partial(pulling), 2 * day);
        let temp = tmp.path().join(".tmpAbC123.partial");
        fs::write(&temp, [0u8; 8]).unwrap();
        age(&temp, 2 * day);
        let finished = cache.put("sha256:abc", b"blob").unwrap();
        age(&finished, 2 * day);

        let held = cache.download_lock_file(pulling).unwrap();
        held.lock().unwrap();
        let freed = cache.sweep_abandoned_partials(day).unwrap();

        assert_eq!(freed, 64 + 8);
        assert!(
            !partial(abandoned).exists(),
            "an old partial no pull holds is removed"
        );
        assert!(!temp.exists(), "an old temp partial is removed");
        assert!(
            partial(recent).exists(),
            "a recent partial stays for a resume"
        );
        assert!(
            partial(pulling).exists(),
            "a partial an active pull holds stays"
        );
        assert!(finished.exists(), "finished blobs are never swept");
        drop(held);
    }

    /// A ranged download's `<digest>.ranged.partial` is guarded by the same
    /// download lock as the blob's resumable partial: kept while its pull runs,
    /// removed once abandoned.
    #[test]
    fn a_sweep_honors_the_lock_on_a_ranged_partial() {
        let tmp = tempfile::tempdir().unwrap();
        let cache = BlobCache::open(tmp.path().to_path_buf(), u64::MAX).unwrap();
        let day = std::time::Duration::from_secs(24 * 60 * 60);
        let digest = "sha256:4444444444444444444444444444444444444444444444444444444444444444";
        let ranged = cache
            .blob_path_for(digest)
            .with_extension(crate::pull::RANGED_PARTIAL_EXTENSION);
        fs::write(&ranged, [0u8; 64]).unwrap();
        fs::File::options()
            .write(true)
            .open(&ranged)
            .unwrap()
            .set_modified(std::time::SystemTime::now() - 2 * day)
            .unwrap();

        let held = cache.download_lock_file(digest).unwrap();
        held.lock().unwrap();
        assert_eq!(cache.sweep_abandoned_partials(day).unwrap(), 0);
        assert!(ranged.exists(), "a ranged partial its pull holds stays");
        drop(held);

        assert_eq!(cache.sweep_abandoned_partials(day).unwrap(), 64);
        assert!(!ranged.exists(), "an abandoned ranged partial is removed");
    }

    /// A pull's reference is listed with its blob; a re-pull of a moved tag
    /// lists it under the new blob, leaving the old one without a name; an
    /// evicted blob's record is not listed; prune forgets every record.
    #[test]
    fn listed_artifacts_carry_the_references_pulled_to_them() {
        let tmp = tempfile::tempdir().unwrap();
        let cache = BlobCache::open(tmp.path().to_path_buf(), u64::MAX).unwrap();
        let old = cache.put(&digest_of(b"old"), b"old").unwrap();
        cache.put(&digest_of(b"new"), b"new!").unwrap();
        let pulled = |reference: &str, digest: &str, at: u64| PulledRef {
            registry: "registry.smolmachines.com".into(),
            repository: "library/pi".into(),
            reference: reference.into(),
            digest: digest.into(),
            pulled_at: at,
        };
        cache
            .record_pull(&pulled("latest", &digest_of(b"old"), 1))
            .unwrap();
        cache
            .record_pull(&pulled("v1", &digest_of(b"old"), 2))
            .unwrap();
        cache
            .record_pull(&pulled("latest", &digest_of(b"new"), 3))
            .unwrap();
        cache
            .record_pull(&pulled("gone", &digest_of(b"evicted"), 4))
            .unwrap();

        let listed = cache.list_artifacts().unwrap();
        assert_eq!(listed.len(), 2, "one entry per blob still cached");
        assert_eq!(
            listed[0].digest,
            digest_of(b"new"),
            "most recent pull first"
        );
        assert_eq!(listed[0].size, 4);
        assert_eq!(
            listed[0].refs,
            vec![pulled("latest", &digest_of(b"new"), 3)]
        );
        assert_eq!(listed[1].path, old);
        assert_eq!(
            listed[1].refs,
            vec![pulled("v1", &digest_of(b"old"), 2)],
            "the moved tag no longer names the old blob"
        );

        cache.prune_all().unwrap();
        cache.put(&digest_of(b"new"), b"new!").unwrap();
        assert!(cache.list_artifacts().unwrap()[0].refs.is_empty());
    }

    #[test]
    fn cache_limit_parses_env_or_defaults() {
        // Valid byte counts are honored.
        assert_eq!(
            parse_cache_limit(Some("10737418240")),
            10 * 1024 * 1024 * 1024
        );
        assert_eq!(parse_cache_limit(Some("  5000000000 ")), 5_000_000_000);
        // Absent / unparseable / zero fall back to the default.
        assert_eq!(parse_cache_limit(None), DEFAULT_MAX_SIZE);
        assert_eq!(parse_cache_limit(Some("garbage")), DEFAULT_MAX_SIZE);
        assert_eq!(parse_cache_limit(Some("0")), DEFAULT_MAX_SIZE);
    }

    /// A cache hit must not write to the blob's inode: the machine-create path
    /// pins a verified artifact by (dev, ino, len, mtime, ctime), and setting
    /// atime moves ctime on Linux, so a concurrent hit made verification fail.
    #[cfg(unix)]
    #[test]
    fn get_does_not_touch_the_blob_inode() {
        use std::os::unix::fs::MetadataExt;
        let tmp = tempfile::tempdir().unwrap();
        let cache = BlobCache::open(tmp.path().to_path_buf(), 1024 * 1024).unwrap();
        let digest = "sha256:1111111111111111111111111111111111111111111111111111111111111111";
        let path = cache.put(digest, b"payload").unwrap();
        // Coarse filesystems stamp whole seconds; make sure a touch would show.
        let old = filetime::FileTime::from_unix_time(1_600_000_000, 0);
        filetime::set_file_times(&path, old, old).unwrap();
        let before = fs::metadata(&path).unwrap();
        std::thread::sleep(std::time::Duration::from_millis(20));

        for _ in 0..3 {
            assert_eq!(cache.get(digest).as_deref(), Some(path.as_path()));
        }

        let after = fs::metadata(&path).unwrap();
        assert_eq!(after.ino(), before.ino());
        assert_eq!(after.len(), before.len());
        assert_eq!(
            (after.mtime(), after.mtime_nsec()),
            (before.mtime(), before.mtime_nsec())
        );
        assert_eq!(
            (after.ctime(), after.ctime_nsec()),
            (before.ctime(), before.ctime_nsec())
        );
        assert_eq!(
            (after.atime(), after.atime_nsec()),
            (before.atime(), before.atime_nsec())
        );
        assert!(
            lru_marker_path(&path).exists(),
            "recency is recorded on the marker"
        );
    }

    /// The marker keeps LRU order: a blob that was read recently survives
    /// eviction ahead of one that was only written, and markers are neither
    /// counted toward the size nor evicted on their own.
    #[test]
    fn get_refreshes_recency_through_the_marker() {
        let tmp = tempfile::tempdir().unwrap();
        let cache = BlobCache::open(tmp.path().to_path_buf(), 250).unwrap();
        let a = "sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
        let b = "sha256:bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb";
        let c = "sha256:cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc";
        let pa = cache.put(a, &[0u8; 100]).unwrap();
        let pb = cache.put(b, &[0u8; 100]).unwrap();
        // Pin distinct, ordered recency so the test does not depend on clock resolution.
        let t = |secs: i64| filetime::FileTime::from_unix_time(1_600_000_000 + secs, 0);
        filetime::set_file_times(&pa, t(1), t(1)).unwrap();
        filetime::set_file_times(&pb, t(2), t(2)).unwrap();
        cache.get(a).unwrap();
        filetime::set_file_mtime(lru_marker_path(&pa), t(3)).unwrap();
        assert_eq!(cache.total_size().unwrap(), 200, "markers do not count");

        cache.put(c, &[0u8; 100]).unwrap();

        assert!(cache.get(a).is_some(), "recently read blob survives");
        assert!(
            cache.get(b).is_none(),
            "least recently used blob is evicted"
        );
        assert!(!lru_marker_path(&pb).exists(), "its marker goes with it");
        assert!(cache.get(c).is_some());
    }

    /// `last_used` is where the upgrade path lives: a blob cached before
    /// markers existed has none, and its recency must come from the atime the
    /// old scheme maintained rather than collapsing to the epoch.
    #[test]
    fn last_used_falls_back_to_atime_when_no_marker_exists() {
        let tmp = tempfile::tempdir().unwrap();
        let cache = BlobCache::open(tmp.path().to_path_buf(), 1024 * 1024).unwrap();
        let digest = "sha256:1111111111111111111111111111111111111111111111111111111111111111";
        let blob = cache.put(digest, b"payload").unwrap();
        let atime = filetime::FileTime::from_unix_time(1_600_000_500, 0);
        filetime::set_file_atime(&blob, atime).unwrap();
        assert!(!lru_marker_path(&blob).exists());

        let from_atime = last_used(&blob, &fs::metadata(&blob).unwrap());
        assert_ne!(
            from_atime,
            std::time::UNIX_EPOCH,
            "a pre-marker blob must not read as epoch-old"
        );
        assert_eq!(
            from_atime,
            std::time::UNIX_EPOCH + std::time::Duration::from_secs(1_600_000_500)
        );

        note_used(&blob);
        let marker = filetime::FileTime::from_unix_time(1_600_009_000, 0);
        filetime::set_file_mtime(lru_marker_path(&blob), marker).unwrap();
        assert_eq!(
            last_used(&blob, &fs::metadata(&blob).unwrap()),
            std::time::UNIX_EPOCH + std::time::Duration::from_secs(1_600_009_000),
            "once a marker exists it is the authority"
        );
    }

    /// An upgraded node holds a mix: blobs read since the upgrade have markers,
    /// the rest carry only their old atime. Eviction must order the two kinds
    /// against each other, or the untouched-but-hot half of a warm cache is
    /// thrown away first and re-pulled.
    #[test]
    fn eviction_orders_pre_marker_blobs_against_marked_ones() {
        let tmp = tempfile::tempdir().unwrap();
        let cache = BlobCache::open(tmp.path().to_path_buf(), 250).unwrap();
        let unmarked = "sha256:1111111111111111111111111111111111111111111111111111111111111111";
        let marked = "sha256:2222222222222222222222222222222222222222222222222222222222222222";
        let fresh = "sha256:3333333333333333333333333333333333333333333333333333333333333333";
        let unmarked_path = cache.put(unmarked, &[0u8; 100]).unwrap();
        let marked_path = cache.put(marked, &[0u8; 100]).unwrap();
        let t = |secs: i64| filetime::FileTime::from_unix_time(1_600_000_000 + secs, 0);
        // Pre-marker blob, read recently under the old scheme.
        filetime::set_file_atime(&unmarked_path, t(900)).unwrap();
        assert!(!lru_marker_path(&unmarked_path).exists());
        // Marked blob, last read long before that.
        note_used(&marked_path);
        filetime::set_file_mtime(lru_marker_path(&marked_path), t(1)).unwrap();

        cache.put(fresh, &[0u8; 100]).unwrap();

        assert!(
            cache.get(unmarked).is_some(),
            "a pre-marker blob read recently outranks a marked blob read long ago"
        );
        assert!(
            cache.get(marked).is_none(),
            "the genuinely least recently used blob is the one evicted"
        );
        assert!(cache.get(fresh).is_some());
    }

    #[test]
    fn a_manifest_is_reused_only_for_its_registry_repo_and_digest() {
        let tmp = tempfile::tempdir().unwrap();
        let cache = BlobCache::open(tmp.path().to_path_buf(), 1024 * 1024).unwrap();
        let bytes = br#"{"schemaVersion":2}"#;
        let digest = digest_of(bytes);

        assert!(cache
            .manifest_by_digest("https://r", "a/app", &digest)
            .is_none());
        assert!(cache
            .put_manifest_by_digest("https://r", "a/app", &digest, bytes)
            .unwrap());
        assert_eq!(
            cache
                .manifest_by_digest("https://r", "a/app", &digest)
                .as_deref(),
            Some(&bytes[..])
        );
        assert!(cache
            .manifest_by_digest("https://r", "b/app", &digest)
            .is_none());
        assert!(cache
            .manifest_by_digest("https://other", "a/app", &digest)
            .is_none());
        // A manifest is not a blob: it takes no space in the blob budget.
        assert_eq!(cache.total_size().unwrap(), 0);
    }

    #[test]
    fn a_manifest_that_does_not_hash_to_its_digest_is_neither_stored_nor_served() {
        let tmp = tempfile::tempdir().unwrap();
        let cache = BlobCache::open(tmp.path().to_path_buf(), 1024 * 1024).unwrap();
        let bytes = br#"{"schemaVersion":2}"#;
        let digest = digest_of(bytes);

        // An index resolved to one entry hashes to the entry, not the index.
        assert!(!cache
            .put_manifest_by_digest("https://r", "a", &digest, b"other")
            .unwrap());
        assert!(!cache
            .put_manifest_by_digest("https://r", "a", "v1", bytes)
            .unwrap());
        assert!(!cache
            .put_manifest_by_digest("https://r", "a", "sha256:../x", bytes)
            .unwrap());

        cache
            .put_manifest_by_digest("https://r", "a", &digest, bytes)
            .unwrap();
        let path = cache.manifest_path("https://r", "a", &digest).unwrap();
        fs::write(&path, b"tampered").unwrap();
        assert!(cache
            .manifest_by_digest("https://r", "a", &digest)
            .is_none());
    }

    #[test]
    fn prune_all_drops_cached_manifests() {
        let tmp = tempfile::tempdir().unwrap();
        let cache = BlobCache::open(tmp.path().to_path_buf(), 1024 * 1024).unwrap();
        let bytes = br#"{"schemaVersion":2}"#;
        let digest = digest_of(bytes);
        cache
            .put_manifest_by_digest("https://r", "a", &digest, bytes)
            .unwrap();
        cache.prune_all().unwrap();
        assert!(cache
            .manifest_by_digest("https://r", "a", &digest)
            .is_none());
    }

    #[test]
    fn test_prune_all() {
        let tmp = tempfile::tempdir().unwrap();
        let cache = BlobCache::open(tmp.path().to_path_buf(), 1024 * 1024).unwrap();

        let d1 = "sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
        cache.put(d1, b"test data").unwrap();
        assert!(cache.total_size().unwrap() > 0);

        let freed = cache.prune_all().unwrap();
        assert!(freed > 0);
        assert_eq!(cache.total_size().unwrap(), 0);
    }
}
