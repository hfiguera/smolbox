//! TCP relay support for the virtio-net backend.
//!
//! Context
//! =======
//!
//! In the Phase 1 virtio-net design, guest TCP does not flow directly from the
//! guest to the outside network through the host kernel. Instead, the host-side
//! smoltcp runtime terminates the guest-visible TCP connection in userspace and
//! relays payloads to a normal host `TcpStream`.
//!
//! Conceptually:
//!
//! ```text
//! guest app
//!   -> guest kernel TCP
//!   -> Ethernet frame
//!   -> smoltcp TCP socket (inside smolvm)
//!   -> channel
//!   -> host TcpStream
//!   -> remote server
//! ```
//!
//! That means:
//! - the host runtime can observe every guest TCP byte stream on this NIC
//! - smoltcp owns the guest-facing TCP state machine
//! - the relay thread owns the host-facing TCP socket
//! - channels bridge payloads between them

use crate::egress::EgressPolicy;
use crate::queues::WakePipe;
use crate::virtio_net_log;
use polling::{Event, Events};
use smoltcp::iface::{Interface, SocketHandle, SocketSet};
use smoltcp::socket::tcp;
use smoltcp::wire::IpListenEndpoint;
use smolvm_protocol::mediated_egress::{Decision, FlowPrelude, MAX_INITIAL_BYTES};
use smolvm_protocol::{FlowTransport, RuleAction};
use std::collections::{HashMap, HashSet};
use std::io::{self, Read, Write};
use std::net::{IpAddr, Ipv4Addr, Ipv6Addr, Shutdown, SocketAddr, TcpStream};
use std::sync::atomic::{AtomicU8, Ordering};
use std::sync::mpsc::{self, Receiver, SyncSender, TryRecvError, TrySendError};
use std::sync::Arc;
use std::thread;
use std::time::{Duration, Instant};

const TCP_RX_BUFFER_BYTES: usize = 64 * 1024;
const TCP_TX_BUFFER_BYTES: usize = 64 * 1024;
const MAX_CONNECTIONS: usize = 512;
const CHANNEL_CAPACITY: usize = 32;
const RELAY_BUFFER_BYTES: usize = 16 * 1024;
const CLOSE_RETRY_LIMIT: u16 = 64;
/// The longest an idle relay thread waits before rechecking both directions
/// on its own. Every way a direction gains work wakes it sooner: the host
/// socket turning readable or writable, and the poll loop handing it a guest
/// payload or closing the guest side. This only bounds the cost of a missed
/// wake.
const RELAY_WAIT_BACKSTOP: Duration = Duration::from_millis(100);
/// The relay thread's key for its host socket in its own poller.
const HOST_STREAM_KEY: usize = 0;
const FIRST_PAYLOAD_HOLD: Duration = Duration::from_millis(100);
const MEDIATED_CONNECT_TIMEOUT: Duration = Duration::from_secs(2);
const MEDIATED_IDLE_TIMEOUT: Duration = Duration::from_secs(30 * 60);
const MEDIATED_MAX_LIFETIME: Duration = Duration::from_secs(24 * 60 * 60);
const PUBLISHED_PORT_START: u16 = 49_152;
const PUBLISHED_PORT_END: u16 = 65_535;

/// Track all active guest TCP connections bridged through host sockets.
///
/// One entry corresponds to one `(guest source, destination)` tuple. The table
/// lives in the smoltcp poll thread and owns all guest-facing socket handles.
pub struct TcpRelayTable {
    connections: HashMap<SocketHandle, TrackedConnection>,
    connection_keys: HashSet<(SocketAddr, SocketAddr)>,
    used_published_ports: HashSet<u16>,
    next_published_port: u16,
    max_connections: usize,
    /// Outbound allow-list applied before opening a host connection for a
    /// guest-initiated flow. Inbound published-port connections bypass it.
    egress: EgressPolicy,
    /// The guest-visible gateway addresses (IPv4/IPv6/link-local). A guest flow
    /// destined to one of these is dialing "the host" via its default gateway,
    /// so the host-side relay connects to loopback instead of the gateway's own
    /// (non-routable) userspace address. See `host_connect_addr`.
    gateway_ips: Vec<IpAddr>,
    /// One authenticated smolvm-owned loopback service allowed through the
    /// otherwise-denied gateway address.
    host_service: Option<crate::GatewayHostService>,
    /// Redirect selected streams after egress admits their real destination.
    /// `None` relays every flow directly.
    intercept: Option<crate::StreamInterception>,
    /// Guest ports already reported as refusing published connections, so a
    /// client retrying in a loop produces one warning rather than one per
    /// attempt.
    unaccepted_guest_ports: HashSet<u16>,
}

/// Open TCP flows of one machine at a point in time. Outbound flows are the
/// guest's own connections; inbound ones arrived on a published port.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct FlowSummary {
    /// Open guest-initiated flows.
    pub outbound_open: u32,
    /// Open published-port flows.
    pub inbound_open: u32,
    /// Distinct destination IPs among the outbound flows.
    pub distinct_outbound_peers: u32,
    /// Age in seconds of the longest-lived open outbound flow, 0 when none.
    pub oldest_outbound_secs: u64,
    /// Destination of the longest-lived open outbound flow.
    pub oldest_outbound_dest: Option<SocketAddr>,
}

/// Summarize `(destination, inbound, opened_at)` flow entries as of `now`.
fn summarize_flows(
    flows: impl Iterator<Item = (SocketAddr, bool, Instant)>,
    now: Instant,
) -> FlowSummary {
    let mut summary = FlowSummary::default();
    let mut peers = HashSet::new();
    let mut oldest: Option<(Instant, SocketAddr)> = None;
    for (destination, inbound, opened_at) in flows {
        if inbound {
            summary.inbound_open = summary.inbound_open.saturating_add(1);
            continue;
        }
        summary.outbound_open = summary.outbound_open.saturating_add(1);
        peers.insert(destination.ip());
        if oldest.is_none_or(|(at, _)| opened_at < at) {
            oldest = Some((opened_at, destination));
        }
    }
    summary.distinct_outbound_peers = u32::try_from(peers.len()).unwrap_or(u32::MAX);
    if let Some((at, destination)) = oldest {
        summary.oldest_outbound_secs = now.saturating_duration_since(at).as_secs();
        summary.oldest_outbound_dest = Some(destination);
    }
    summary
}

/// Destination port whose guest flows go through the credential interceptor.
pub const INTERCEPTED_PORT: u16 = 443;

/// Upper bound on the interceptor's own connect to the destination.
const INTERCEPT_VERDICT_TIMEOUT: Duration = Duration::from_secs(15);

/// Newly established guest connection ready for a host relay thread.
///
/// The poll loop emits these once the guest-side smoltcp socket reaches
/// `Established`. At that point we can safely create the host-side relay
/// thread and give it channel endpoints for payload exchange.
pub struct NewTcpConnection {
    /// Destination originally requested by the guest.
    pub destination: SocketAddr,
    /// How the host-side relay should be started.
    pub relay_target: RelayTarget,
    /// Guest-to-host payloads read from the smoltcp socket.
    pub from_smoltcp: Receiver<Vec<u8>>,
    /// Host-to-guest payloads written back into the smoltcp socket.
    pub to_smoltcp: SyncSender<Vec<u8>>,
    /// Shared relay exit state.
    pub exit_state: RelayExitState,
    /// Wakes the relay thread when the poll loop hands it a guest payload or
    /// closes the guest side.
    pub proxy_wake: WakePipe,
    /// The policy to show the guest's opening bytes to, for an outbound
    /// connection; `None` for a published port's inbound one.
    pub watch_opening: Option<EgressPolicy>,
}

#[derive(Debug)]
struct TrackedConnection {
    // `source` and `destination` identify the guest-side flow.
    source: SocketAddr,
    destination: SocketAddr,
    // guest -> host relay payloads
    to_proxy: Option<ToProxy>,

    // host -> guest relay payloads
    from_proxy: Receiver<Vec<u8>>,
    // endpoints are held here until the guest-side handshake completes
    pending_proxy_endpoints: Option<PendingProxyEndpoints>,
    // once true, a dedicated host relay thread exists
    relay_spawned: bool,
    // partial guest->host payload already consumed from smoltcp but not yet
    // accepted by the relay thread channel
    buffered_guest_data: Option<Vec<u8>>,
    // partial host->guest payload not yet fully accepted by smoltcp
    buffered_proxy_data: Option<(Vec<u8>, usize)>,
    // bounded retry count for closing with unsent buffered data
    close_attempts: u16,
    // set once we've sent FIN to the guest after the host half-closed, so the
    // HalfClosed handling closes the guest send-half exactly once
    guest_send_closed: bool,
    // relay thread termination mode observed by the poll loop
    exit_state: RelayExitState,
    // reserved local source port for published inbound connections
    reserved_published_port: Option<u16>,
    // when the guest-side flow entered the table, for the flow summary
    opened_at: Instant,
}

#[derive(Debug)]
struct PendingProxyEndpoints {
    from_smoltcp: Receiver<Vec<u8>>,
    to_smoltcp: SyncSender<Vec<u8>>,
    relay_target: RelayTarget,
    proxy_wake: WakePipe,
    watch_opening: Option<EgressPolicy>,
}

/// The poll loop's sending half of a guest->host channel. It wakes the relay
/// thread on every payload it hands over, and again once it is dropped, so a
/// relay waiting on its socket sees guest data and a guest close at once.
#[derive(Debug)]
struct ToProxy {
    sender: Option<SyncSender<Vec<u8>>>,
    wake: WakePipe,
}

impl ToProxy {
    fn try_send(&self, payload: Vec<u8>) -> Result<(), TrySendError<Vec<u8>>> {
        let sender = self
            .sender
            .as_ref()
            .ok_or(TrySendError::Disconnected(Vec::new()))?;
        sender.try_send(payload)?;
        self.wake.wake();
        Ok(())
    }
}

impl Drop for ToProxy {
    fn drop(&mut self) {
        // Disconnect first, so the woken relay observes the closed channel.
        drop(self.sender.take());
        self.wake.wake();
    }
}

/// A guest->host channel whose sender wakes the relay thread waiting on `WakePipe`.
fn proxy_channel() -> (ToProxy, Receiver<Vec<u8>>, WakePipe) {
    let (sender, receiver) = mpsc::sync_channel(CHANNEL_CAPACITY);
    let wake = WakePipe::new();
    (
        ToProxy {
            sender: Some(sender),
            wake: wake.share(),
        },
        receiver,
        wake,
    )
}

/// How a host-side TCP relay should obtain its remote socket.
#[derive(Debug)]
pub enum RelayTarget {
    /// Open a new outbound host `TcpStream` to the destination.
    Connect(SocketAddr),
    /// Static allow under mediation; still subject to mediated time limits.
    DirectMediated(SocketAddr),
    /// Use an already-accepted host `TcpStream` from a published port listener.
    Attached(TcpStream),
    /// Dial the credential interceptor and announce the guest's real
    /// destination in an authenticated preamble before relaying guest bytes.
    Intercept {
        endpoint: crate::InterceptEndpoint,
        destination: SocketAddr,
    },
    /// Ask a host decider before connecting to the origin or using its stream.
    Mediated {
        binding: crate::MediatedBinding,
        destination: SocketAddr,
        direct_address: SocketAddr,
        direct_allowed: bool,
        audit: EgressPolicy,
    },
}

/// Host relay termination state shared between the poll loop and the relay thread.
///
/// The relay thread cannot mutate smoltcp sockets directly because those sockets
/// are owned by the poll loop thread. Instead it reports how it finished, and
/// the poll loop interprets that into guest-side socket actions:
/// - `Graceful`   -> close guest socket cleanly
/// - `HalfClosed` -> host closed its send half; send FIN to the guest but keep
///   the guest socket open so guest->host output still drains
/// - `Abort`      -> abort/reset guest socket
#[derive(Clone, Debug)]
pub struct RelayExitState {
    inner: Arc<AtomicU8>,
}

/// How a host TCP relay thread terminated.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
#[repr(u8)]
pub enum RelayExitMode {
    /// Relay thread is still running.
    Running = 0,
    /// Remote side closed normally; send FIN toward the guest.
    Graceful = 1,
    /// Remote connect or I/O failed; abort the guest TCP socket.
    Abort = 2,
    /// Host closed its send half (host-read EOF) but the guest may still be
    /// sending. Mirror the FIN toward the guest and keep pumping guest->host
    /// until the guest closes too. Without this a hijacked-attach response is
    /// dropped: the docker CLI half-closes (`shutdown(SHUT_WR)`) after
    /// `101 UPGRADED` when it has no stdin, while the daemon is still streaming.
    HalfClosed = 3,
}

impl RelayExitState {
    fn new() -> Self {
        Self {
            inner: Arc::new(AtomicU8::new(RelayExitMode::Running as u8)),
        }
    }

    fn load(&self) -> RelayExitMode {
        match self.inner.load(Ordering::Relaxed) {
            1 => RelayExitMode::Graceful,
            2 => RelayExitMode::Abort,
            3 => RelayExitMode::HalfClosed,
            _ => RelayExitMode::Running,
        }
    }

    fn store(&self, mode: RelayExitMode) {
        self.inner.store(mode as u8, Ordering::Relaxed);
    }
}

impl TcpRelayTable {
    /// Create a new relay table.
    pub fn new(
        max_connections: Option<usize>,
        egress: EgressPolicy,
        gateway_ips: Vec<IpAddr>,
        host_service: Option<crate::GatewayHostService>,
    ) -> Self {
        Self {
            connections: HashMap::new(),
            connection_keys: HashSet::new(),
            used_published_ports: HashSet::new(),
            next_published_port: PUBLISHED_PORT_START,
            max_connections: max_connections.unwrap_or(MAX_CONNECTIONS),
            egress,
            gateway_ips,
            host_service,
            intercept: None,
            unaccepted_guest_ports: HashSet::new(),
        }
    }

    /// Route selected guest streams through a host interceptor.
    pub fn with_intercept(mut self, intercept: Option<crate::StreamInterception>) -> Self {
        self.intercept = intercept;
        self
    }

    /// Relay target for a guest-initiated flow that egress already admitted.
    fn outbound_target(&self, destination: SocketAddr) -> RelayTarget {
        // The dedicated rollout ingress is a smolvm-owned service on the
        // gateway, not an outbound origin. Keep it available even when every
        // external TCP flow is delegated to a broker.
        if self.is_host_service_destination(destination) {
            return RelayTarget::Connect(self.host_connect_addr(destination));
        }
        match self.egress.rule_action(
            FlowTransport::Tcp,
            destination.ip(),
            Some(destination.port()),
        ) {
            // A static allow admits the flow; it does not exempt it from a
            // credential or egress interceptor, or a range reopened with
            // `--allow-private` would carry a credential's placeholder to the
            // origin verbatim. Only mediated egress gives allow the meaning
            // "dial directly, without asking the decider".
            Some(RuleAction::Allow)
                if matches!(self.intercept, Some(crate::StreamInterception::Mediated(_))) =>
            {
                return RelayTarget::DirectMediated(self.host_connect_addr(destination));
            }
            Some(RuleAction::Redirect) => {
                if let Some(crate::StreamInterception::Mediated(binding)) = self.intercept {
                    return RelayTarget::Mediated {
                        binding,
                        destination,
                        direct_address: self.host_connect_addr(destination),
                        direct_allowed: self.egress.allows_flow(
                            FlowTransport::Tcp,
                            self.host_connect_addr(destination).ip(),
                            Some(destination.port()),
                        ),
                        audit: self.egress.clone(),
                    };
                }
            }
            _ => {}
        }
        match self.intercept {
            Some(crate::StreamInterception::Https(endpoint))
                if destination.port() == INTERCEPTED_PORT
                    && !self.gateway_ips.contains(&destination.ip()) =>
            {
                RelayTarget::Intercept {
                    endpoint,
                    destination,
                }
            }
            Some(crate::StreamInterception::AllTcp(endpoint)) => RelayTarget::Intercept {
                endpoint,
                destination,
            },
            Some(crate::StreamInterception::Mediated(binding)) => RelayTarget::Mediated {
                binding,
                destination,
                direct_address: self.host_connect_addr(destination),
                direct_allowed: self.egress.allows(self.host_connect_addr(destination).ip())
                    || self.is_host_service_destination(destination),
                audit: self.egress.clone(),
            },
            _ => RelayTarget::Connect(self.host_connect_addr(destination)),
        }
    }

    /// Start fresh stacks at different points in the ephemeral range. The guest
    /// may still have connections from the stack saved in its checkpoint.
    pub(crate) fn with_published_port_seed(mut self, seed: u16) -> Self {
        self.next_published_port =
            PUBLISHED_PORT_START + seed % (PUBLISHED_PORT_END - PUBLISHED_PORT_START + 1);
        self
    }

    /// Number of guest TCP flows currently occupying relay table entries.
    pub(crate) fn active_connections(&self) -> usize {
        self.connections.len()
    }

    /// Maximum number of simultaneous guest TCP flows accepted by this table.
    pub(crate) fn capacity(&self) -> usize {
        self.max_connections
    }

    /// Summarize the open flows for the machine's flow telemetry. Walks the
    /// table once; the poll loop calls it on a slow cadence, never per packet.
    pub(crate) fn flow_summary(&self, now: Instant) -> FlowSummary {
        summarize_flows(
            self.connections.values().map(|connection| {
                (
                    connection.destination,
                    connection.reserved_published_port.is_some(),
                    connection.opened_at,
                )
            }),
            now,
        )
    }

    fn destination_allowed(&self, destination: SocketAddr) -> bool {
        if self.is_host_service_destination(destination) {
            return true;
        }
        // A gateway destination is dialed as host loopback. A deny on the
        // dialed address has to hold even though the guest named the gateway.
        let dialed = self.host_connect_addr(destination);
        if dialed.ip() != destination.ip()
            && self
                .egress
                .rule_action(FlowTransport::Tcp, dialed.ip(), Some(dialed.port()))
                == Some(RuleAction::Deny)
        {
            return false;
        }
        if self.egress.rule_action(
            FlowTransport::Tcp,
            destination.ip(),
            Some(destination.port()),
        ) == Some(RuleAction::Redirect)
            && !matches!(self.intercept, Some(crate::StreamInterception::Mediated(_)))
        {
            return false;
        }
        self.egress.allows_flow(
            FlowTransport::Tcp,
            destination.ip(),
            Some(destination.port()),
        )
    }

    fn is_host_service_destination(&self, destination: SocketAddr) -> bool {
        self.host_service
            .is_some_and(|service| service.guest_port == destination.port())
            && self.gateway_ips.contains(&destination.ip())
    }

    /// The host-side address the relay should dial for a guest flow.
    ///
    /// The guest's default gateway IP is its stand-in for "the host" (the slirp /
    /// `host.docker.internal` convention): a guest reaches host-local services by
    /// connecting to its gateway. But that gateway IP is THIS userspace stack's
    /// own address, not a routable host interface — a literal relay to it
    /// blackholes (the guest completes the smoltcp handshake, then never receives
    /// reply bytes). Map a gateway-IP destination to loopback so it actually
    /// reaches the host; every other destination is dialed as-is. Egress already
    /// gated the ORIGINAL destination in `create_tcp_socket`, so under the
    /// multi-tenant `Strict` floor the gateway/CGNAT range is refused before it
    /// reaches here — this redirect only applies where reaching the host is the
    /// intended, local-default behavior.
    fn host_connect_addr(&self, destination: SocketAddr) -> SocketAddr {
        if self.gateway_ips.contains(&destination.ip()) {
            let loopback = if destination.is_ipv4() {
                IpAddr::V4(Ipv4Addr::LOCALHOST)
            } else {
                IpAddr::V6(Ipv6Addr::LOCALHOST)
            };
            let port = self
                .host_service
                .filter(|service| service.guest_port == destination.port())
                .map_or(destination.port(), |service| service.host_port);
            return SocketAddr::new(loopback, port);
        }
        destination
    }

    /// Whether a relay socket already exists for the same guest source and destination.
    pub fn has_socket_for(&self, source: &SocketAddr, destination: &SocketAddr) -> bool {
        self.connection_keys.contains(&(*source, *destination))
    }

    /// Create a smoltcp TCP socket for a guest SYN.
    ///
    /// Why this happens before full ingress processing:
    /// - when the first guest SYN arrives, smoltcp needs a matching socket to
    ///   receive it
    /// - the poll loop therefore pre-creates a listening socket keyed to the
    ///   destination the guest is trying to reach
    /// - only after the guest-facing connection reaches `Established` do we
    ///   spawn the host relay thread
    ///
    /// Data path after creation:
    ///
    /// ```text
    /// smoltcp socket --to_proxy channel--> host relay thread
    /// host relay thread --from_proxy channel--> smoltcp socket
    /// ```
    pub fn create_tcp_socket(
        &mut self,
        source: SocketAddr,
        destination: SocketAddr,
        sockets: &mut SocketSet<'_>,
    ) -> bool {
        if self.connections.len() >= self.max_connections {
            virtio_net_log!(
                "virtio-net: dropping outbound TCP connection because relay table is full active={} capacity={}",
                self.connections.len(),
                self.max_connections
            );
            return false;
        }

        // Egress policy: drop the guest SYN before any socket is created when the
        // destination isn't allowed, so the guest just sees the connection fail.
        // Inbound published-port flows take a separate path and are unaffected.
        if !self.destination_allowed(destination) {
            tracing::debug!(
                %destination,
                "virtio-net: blocking outbound connection by egress policy"
            );
            // Recorded in the machine's egress audit trail (dedicated file +
            // stderr) — parsed by the host's `read_egress_denials`.
            self.egress
                .record_denial("connect", &format_args!("to {destination}"));
            return false;
        }
        // A `block` entry fails the connection like a denial, recorded only as
        // the watchlist match.
        if self.egress.observe_destination(destination) {
            return false;
        }
        if self.is_host_service_destination(destination)
            && self
                .egress
                .record_decision("tcp", "allow", &destination, "internal_service")
                .is_err()
        {
            self.egress
                .record_denial("connect", &format_args!("to {destination}"));
            return false;
        }
        if self.egress.rule_action(
            FlowTransport::Tcp,
            destination.ip(),
            Some(destination.port()),
        ) == Some(RuleAction::Allow)
            && self
                .egress
                .record_decision("tcp", "allow", &destination, "static_rule")
                .is_err()
        {
            self.egress.record_denial("connect", &destination);
            return false;
        }

        let rx_buffer = tcp::SocketBuffer::new(vec![0u8; TCP_RX_BUFFER_BYTES]);
        let tx_buffer = tcp::SocketBuffer::new(vec![0u8; TCP_TX_BUFFER_BYTES]);
        let mut socket = tcp::Socket::new(rx_buffer, tx_buffer);
        socket.set_nagle_enabled(false);

        let listen_endpoint = IpListenEndpoint {
            addr: Some(destination.ip().into()),
            port: destination.port(),
        };
        if socket.listen(listen_endpoint).is_err() {
            return false;
        }

        let handle = sockets.add(socket);

        let (to_proxy_tx, to_proxy_rx, proxy_wake) = proxy_channel();
        let (from_proxy_tx, from_proxy_rx) = mpsc::sync_channel(CHANNEL_CAPACITY);
        let exit_state = RelayExitState::new();

        self.connection_keys.insert((source, destination));
        self.connections.insert(
            handle,
            TrackedConnection {
                source,
                destination,
                to_proxy: Some(to_proxy_tx),
                from_proxy: from_proxy_rx,

                pending_proxy_endpoints: Some(PendingProxyEndpoints {
                    from_smoltcp: to_proxy_rx,
                    to_smoltcp: from_proxy_tx,
                    relay_target: self.outbound_target(destination),
                    proxy_wake,
                    watch_opening: Some(self.egress.clone()),
                }),
                relay_spawned: false,
                buffered_guest_data: None,
                buffered_proxy_data: None,
                close_attempts: 0,
                guest_send_closed: false,
                exit_state,
                reserved_published_port: None,
                opened_at: Instant::now(),
            },
        );

        true
    }

    /// Create a guest-facing TCP connection for a published host socket.
    ///
    /// This is the host->guest mirror of `create_tcp_socket`:
    ///
    /// ```text
    /// host client connects to published port
    ///   -> host listener accepts TcpStream
    ///   -> poll loop creates smoltcp TCP socket from gateway_ip:ephemeral
    ///      to guest_ip:guest_port
    ///   -> guest kernel sees a normal inbound TCP connection on guest_port
    /// ```
    ///
    /// The guest-visible source address is the gateway IP, not the original
    /// host peer address. That keeps the first version simple and matches the
    /// fact that this runtime is acting as a userspace gateway/proxy.
    pub fn create_published_socket(
        &mut self,
        interface: &mut Interface,
        gateway_ip: Ipv4Addr,
        destination: SocketAddr,
        host_stream: TcpStream,
        sockets: &mut SocketSet<'_>,
    ) -> bool {
        if self.connections.len() >= self.max_connections {
            virtio_net_log!(
                "virtio-net: dropping published TCP connection because relay table is full active={} capacity={}",
                self.connections.len(),
                self.max_connections
            );
            return false;
        }

        let Some(local_port) = self.allocate_published_port() else {
            tracing::warn!(
                "dropping published TCP connection because no gateway source port is available"
            );
            return false;
        };

        // Inbound published connections always target the guest's IPv4 on the
        // internal link (the host listener family is independent of this).
        let std::net::IpAddr::V4(destination_ip) = destination.ip() else {
            self.used_published_ports.remove(&local_port);
            return false;
        };

        let rx_buffer = tcp::SocketBuffer::new(vec![0u8; TCP_RX_BUFFER_BYTES]);
        let tx_buffer = tcp::SocketBuffer::new(vec![0u8; TCP_TX_BUFFER_BYTES]);
        let mut socket = tcp::Socket::new(rx_buffer, tx_buffer);
        socket.set_nagle_enabled(false);
        let local_endpoint = IpListenEndpoint {
            addr: Some(gateway_ip.into()),
            port: local_port,
        };
        if socket
            .connect(
                interface.context(),
                (destination_ip, destination.port()),
                local_endpoint,
            )
            .is_err()
        {
            self.used_published_ports.remove(&local_port);
            return false;
        }

        let handle = sockets.add(socket);
        let source = SocketAddr::new(std::net::IpAddr::V4(gateway_ip), local_port);

        let (to_proxy_tx, to_proxy_rx, proxy_wake) = proxy_channel();
        let (from_proxy_tx, from_proxy_rx) = mpsc::sync_channel(CHANNEL_CAPACITY);
        let exit_state = RelayExitState::new();

        self.connection_keys.insert((source, destination));
        self.connections.insert(
            handle,
            TrackedConnection {
                source,
                destination,
                to_proxy: Some(to_proxy_tx),
                from_proxy: from_proxy_rx,

                pending_proxy_endpoints: Some(PendingProxyEndpoints {
                    from_smoltcp: to_proxy_rx,
                    to_smoltcp: from_proxy_tx,
                    relay_target: RelayTarget::Attached(host_stream),
                    proxy_wake,
                    watch_opening: None,
                }),
                relay_spawned: false,
                buffered_guest_data: None,
                buffered_proxy_data: None,
                close_attempts: 0,
                guest_send_closed: false,
                exit_state,
                reserved_published_port: Some(local_port),
                opened_at: Instant::now(),
            },
        );

        true
    }

    /// Relay TCP payloads between smoltcp sockets and host relay threads.
    ///
    /// This runs in the poll thread. It is responsible for:
    /// - draining bytes received from the guest-facing smoltcp socket and
    ///   pushing them toward the host relay thread
    /// - draining bytes received from the host relay thread and writing them
    ///   back into the smoltcp socket
    /// - interpreting relay exit state into guest-side `close()` or `abort()`
    pub fn relay_data(&mut self, sockets: &mut SocketSet<'_>) {
        let mut read_buffer = [0u8; RELAY_BUFFER_BYTES];

        for (&handle, connection) in &mut self.connections {
            if !connection.relay_spawned {
                continue;
            }

            let socket = sockets.get_mut::<tcp::Socket>(handle);

            match connection.exit_state.load() {
                RelayExitMode::Abort => {
                    socket.abort();
                    continue;
                }
                RelayExitMode::Graceful => {
                    flush_proxy_data(socket, connection);
                    if connection.buffered_proxy_data.is_none() {
                        socket.close();
                    } else {
                        connection.close_attempts += 1;
                        if connection.close_attempts >= CLOSE_RETRY_LIMIT {
                            socket.abort();
                        }
                    }
                    continue;
                }
                RelayExitMode::HalfClosed => {
                    // Host closed its send half: flush any remaining host->guest
                    // bytes, then send FIN to the guest exactly once. Crucially
                    // we do NOT `continue` — fall through to the guest->host
                    // drain below so the guest's in-flight response still
                    // reaches the host. The thread flips to Graceful once the
                    // guest closes too, and the connection is torn down then.
                    flush_proxy_data(socket, connection);
                    if connection.buffered_proxy_data.is_none() && !connection.guest_send_closed {
                        socket.close();
                        connection.guest_send_closed = true;
                    }
                }
                RelayExitMode::Running => {}
            }

            flush_guest_data(connection);
            while connection.buffered_guest_data.is_none() && socket.can_recv() {
                match socket.recv_slice(&mut read_buffer) {
                    Ok(bytes_read) if bytes_read > 0 => {
                        let payload = read_buffer[..bytes_read].to_vec();
                        if !send_guest_payload(connection, payload) {
                            break;
                        }
                    }
                    _ => break,
                }
            }

            if connection.buffered_guest_data.is_none() && !socket.may_recv() {
                connection.to_proxy = None;
            }

            flush_proxy_data(socket, connection);
        }
    }

    /// Collect connections that reached ESTABLISHED and need a host relay thread.
    ///
    /// The separation between `create_tcp_socket` and this method is important:
    /// the guest TCP handshake is accepted first on the smoltcp side, and only
    /// once that succeeds do we commit to opening the host-side `TcpStream`.
    pub fn take_new_connections(&mut self, sockets: &mut SocketSet<'_>) -> Vec<NewTcpConnection> {
        let mut new_connections = Vec::new();

        for (&handle, connection) in &mut self.connections {
            if connection.relay_spawned {
                continue;
            }

            let socket = sockets.get::<tcp::Socket>(handle);
            let state = socket.state();
            if state == tcp::State::Established || state == tcp::State::CloseWait {
                connection.relay_spawned = true;

                if let Some(endpoints) = connection.pending_proxy_endpoints.take() {
                    new_connections.push(NewTcpConnection {
                        destination: connection.destination,
                        relay_target: endpoints.relay_target,
                        from_smoltcp: endpoints.from_smoltcp,
                        to_smoltcp: endpoints.to_smoltcp,
                        exit_state: connection.exit_state.clone(),
                        proxy_wake: endpoints.proxy_wake,
                        watch_opening: endpoints.watch_opening,
                    });
                }
            }
        }

        new_connections
    }

    /// Remove closed sockets and drop their relay endpoints.
    ///
    /// This is the final ownership cleanup step for a guest TCP flow.
    ///
    /// An aborted socket reaches `Closed` synchronously, but its RST is only
    /// emitted on the next interface dispatch — and smoltcp clears the
    /// endpoint tuple right after sending it. Reaping on `Closed` alone
    /// therefore destroys the queued RST and the guest never learns the
    /// connection died (it hangs until its own timeout, which is how a failed
    /// host-side connect used to black-hole every unreachable destination).
    /// Wait for `remote_endpoint()` to clear so the RST is on the wire first.
    pub fn cleanup_closed(&mut self, sockets: &mut SocketSet<'_>) {
        let keys = &mut self.connection_keys;
        let published_ports = &mut self.used_published_ports;
        let unaccepted = &mut self.unaccepted_guest_ports;
        self.connections.retain(|&handle, connection| {
            let socket = sockets.get::<tcp::Socket>(handle);
            if socket.state() == tcp::State::Closed && socket.remote_endpoint().is_none() {
                keys.remove(&(connection.source, connection.destination));
                if let Some(port) = connection.reserved_published_port {
                    published_ports.remove(&port);
                    // A published connection that closed before the guest
                    // handshake completed was refused (or reset) by the guest:
                    // nothing accepts connections on guest_ip:guest_port.
                    if !connection.relay_spawned
                        && first_refusal_of_guest_port(unaccepted, connection.destination.port())
                    {
                        tracing::warn!(
                            "nothing inside the machine accepted a published-port connection on {}; \
                             a server listening only on 127.0.0.1 inside the machine is not \
                             reachable through a published port, so listen on 0.0.0.0",
                            connection.destination
                        );
                    }
                }
                sockets.remove(handle);
                false
            } else {
                true
            }
        });
    }

    fn allocate_published_port(&mut self) -> Option<u16> {
        let start = self.next_published_port;

        loop {
            let candidate = self.next_published_port;
            self.next_published_port = if candidate == PUBLISHED_PORT_END {
                PUBLISHED_PORT_START
            } else {
                candidate + 1
            };

            if self.used_published_ports.insert(candidate) {
                return Some(candidate);
            }

            if self.next_published_port == start {
                return None;
            }
        }
    }
}

/// Record that a published connection to `guest_port` was refused by the
/// guest. Returns `true` only the first time for each port, so the caller
/// warns once per port rather than once per connection attempt.
fn first_refusal_of_guest_port(reported: &mut HashSet<u16>, guest_port: u16) -> bool {
    reported.insert(guest_port)
}

/// Spawn one host TCP relay thread for an established guest connection.
///
/// Thread responsibilities:
/// - connect a host `TcpStream` to the guest-requested destination
/// - copy bytes guest->host from `from_smoltcp`
/// - copy bytes host->guest into `to_smoltcp`
/// - wake the poll loop when host->guest data arrives or guest->host backpressure eases
/// - report termination mode through `exit_state`
pub fn spawn_tcp_relay(connection: NewTcpConnection, relay_wake: Arc<WakePipe>) -> io::Result<()> {
    let destination = connection.destination;
    let thread_name = format!("smolvm-tcp-{}", destination.port());
    virtio_net_log!(
        "virtio-net: host TCP relay thread spawn attempt destination={} thread={}",
        destination,
        thread_name
    );
    let spawn_failure_exit_state = connection.exit_state.clone();
    let spawn_failure_wake = relay_wake.clone();
    let spawn_result = thread::Builder::new()
        .name(thread_name)
        .spawn(move || run_tcp_relay(connection, relay_wake));
    match handle_relay_spawn_result(
        spawn_result,
        destination,
        &spawn_failure_exit_state,
        &spawn_failure_wake,
    ) {
        Ok(_handle) => Ok(()),
        Err(err) => Err(err),
    }
}

fn handle_relay_spawn_result<T>(
    result: io::Result<T>,
    destination: SocketAddr,
    exit_state: &RelayExitState,
    relay_wake: &WakePipe,
) -> io::Result<T> {
    result.map_err(|err| {
        virtio_net_log!(
            "virtio-net: failed to spawn host TCP relay thread destination={} error={}",
            destination,
            err
        );
        // `take_new_connections` has already marked this entry as having a
        // relay. Without an explicit terminal state, a failed OS thread
        // creation leaves the entry in Running forever and eventually
        // exhausts the bounded relay table.
        exit_state.store(RelayExitMode::Abort);
        relay_wake.wake();
        err
    })
}

fn run_tcp_relay(connection: NewTcpConnection, relay_wake: Arc<WakePipe>) {
    let destination = connection.destination;
    let exit_state = connection.exit_state.clone();
    // The relay thread is intentionally isolated from smoltcp internals. Its
    // contract is just channels in, channels out, and an exit code back.
    virtio_net_log!(
        "virtio-net: host TCP relay thread started destination={}",
        destination
    );
    match tcp_relay_loop(connection, relay_wake, &exit_state) {
        Ok(mode) => {
            virtio_net_log!(
                "virtio-net: host TCP relay thread exited destination={} mode={:?}",
                destination,
                mode
            );
            exit_state.store(mode)
        }
        Err(err) => {
            virtio_net_log!(
                "virtio-net: host TCP relay failed destination={} error={}",
                destination,
                err
            );
            exit_state.store(RelayExitMode::Abort);
        }
    }
}

fn tcp_relay_loop(
    connection: NewTcpConnection,
    relay_wake: Arc<WakePipe>,
    exit_state: &RelayExitState,
) -> io::Result<RelayExitMode> {
    let NewTcpConnection {
        destination,
        relay_target,
        from_smoltcp,
        to_smoltcp,
        proxy_wake,
        watch_opening,
        ..
    } = connection;
    // Host-side flow:
    //
    // 1. Connect a normal host TcpStream to the destination.
    // 2. Non-blockingly drain guest payloads from the channel into the socket.
    // 3. Non-blockingly read remote payloads from the socket into the channel.
    // 4. If neither side made progress, wait until one can: the host socket
    //    turns readable or writable, or the poll loop wakes `proxy_wake`.
    let mediated = matches!(
        &relay_target,
        RelayTarget::Mediated { .. } | RelayTarget::DirectMediated(_)
    );
    let mut pending_guest_data: Option<(Vec<u8>, usize)> = None;
    let stream = match relay_target {
        RelayTarget::Connect(destination) => {
            virtio_net_log!(
                "virtio-net: connecting host TCP relay socket destination={}",
                destination
            );
            let stream = TcpStream::connect(destination)?;
            virtio_net_log!(
                "virtio-net: host TCP relay socket connected destination={}",
                destination
            );
            stream
        }
        RelayTarget::DirectMediated(destination) => {
            TcpStream::connect_timeout(&destination, INTERCEPT_VERDICT_TIMEOUT)?
        }
        RelayTarget::Attached(stream) => {
            virtio_net_log!(
                "virtio-net: using accepted host TCP socket for published port guest_destination={} peer_addr={:?} local_addr={:?}",
                destination,
                stream.peer_addr().ok(),
                stream.local_addr().ok()
            );
            stream
        }
        RelayTarget::Intercept {
            endpoint,
            destination,
        } => {
            virtio_net_log!(
                "virtio-net: redirecting guest flow to credential interceptor destination={} interceptor={}",
                destination,
                endpoint.addr
            );
            // The preamble is written blocking, before any guest byte: it is a
            // few dozen bytes to a loopback listener and must precede the TLS
            // ClientHello the guest sends next.
            let mut stream = TcpStream::connect(endpoint.addr)?;
            endpoint.write_preamble(&mut stream, destination)?;
            // The interceptor dials the destination before answering; a
            // failure aborts the flow as a failed direct connect would.
            stream.set_read_timeout(Some(INTERCEPT_VERDICT_TIMEOUT))?;
            smolvm_protocol::intercept::read_verdict(&mut stream)?;
            stream.set_read_timeout(None)?;
            stream
        }
        RelayTarget::Mediated {
            binding,
            destination,
            direct_address,
            direct_allowed,
            audit,
        } => {
            // The guest handshake is complete, but the origin has not been
            // dialed. Wait briefly for application bytes so a host decider can
            // inspect them before choosing a route. Server-speaks-first flows
            // continue after this bounded hold with an empty initial payload.
            let first = collect_initial_bytes(&from_smoltcp, FIRST_PAYLOAD_HOLD);
            if first.is_some() {
                relay_wake.wake();
            }
            let first_len = first
                .as_ref()
                .map_or(0, |bytes| bytes.len().min(MAX_INITIAL_BYTES));
            let broker_result = (|| -> io::Result<(TcpStream, Decision)> {
                let mut broker =
                    TcpStream::connect_timeout(&binding.endpoint.addr, MEDIATED_CONNECT_TIMEOUT)?;
                broker.set_write_timeout(Some(INTERCEPT_VERDICT_TIMEOUT))?;
                FlowPrelude {
                    machine_id: binding.machine_id,
                    parent_id: binding.parent_id,
                    destination,
                    initial_bytes: first
                        .as_ref()
                        .map_or_else(Vec::new, |bytes| bytes[..first_len].to_vec()),
                }
                .write_to(&mut broker, &binding.endpoint.token)?;
                broker.set_read_timeout(Some(INTERCEPT_VERDICT_TIMEOUT))?;
                let decision = Decision::read_from(&mut broker)?;
                broker.set_read_timeout(None)?;
                broker.set_write_timeout(None)?;
                Ok((broker, decision))
            })();
            let (broker, decision) = match broker_result {
                Ok(result) => result,
                Err(error) => {
                    let _ =
                        audit.record_decision("tcp", "deny", &destination, "broker_unavailable");
                    return Err(error);
                }
            };
            if decision == Decision::AllowDirect && !direct_allowed {
                audit.record_decision("tcp", "deny", &destination, "direct_target_policy")?;
                return Err(io::Error::new(
                    io::ErrorKind::PermissionDenied,
                    "egress policy denied direct target",
                ));
            }
            let action = match decision {
                Decision::AllowDirect => "allow",
                Decision::Deny => "deny",
                Decision::Redirect => "redirect",
            };
            audit.record_decision("tcp", action, &destination, "broker_decision")?;
            match decision {
                Decision::Deny => {
                    return Err(io::Error::new(
                        io::ErrorKind::PermissionDenied,
                        "egress decider denied flow",
                    ));
                }
                Decision::Redirect => {
                    if let Some(first) = first {
                        if first_len < first.len() {
                            pending_guest_data = Some((first, first_len));
                        }
                    }
                    broker
                }
                Decision::AllowDirect => {
                    if let Some(first) = first {
                        pending_guest_data = Some((first, 0));
                    }
                    drop(broker);
                    TcpStream::connect_timeout(&direct_address, INTERCEPT_VERDICT_TIMEOUT)?
                }
            }
        }
    };
    stream.set_nonblocking(true)?;

    let registered = RegisteredStream::new(stream, proxy_wake.poller().clone())?;
    relay_stream(
        &registered.stream,
        &registered.poller,
        from_smoltcp,
        to_smoltcp,
        &relay_wake,
        exit_state,
        RelayFlow {
            mediated,
            pending_guest_data,
            opening: watch_opening.map(|egress| OpeningWatch::new(egress, destination)),
        },
    )
}

/// Whether `bytes` already hold what a decider needs to route a flow: one whole
/// TLS record (the ClientHello, SNI included), the whole header block of an
/// HTTP request, or, for any other protocol, its first segment.
///
/// A ClientHello carrying a post-quantum key share is about 1.8 KB and often
/// spans two segments, with the SNI in the second; a decider shown only the
/// first segment could not route it by name.
fn initial_bytes_complete(bytes: &[u8]) -> bool {
    if bytes.first() == Some(&0x16) {
        // A TLS record: content type, two version bytes, a two-byte length.
        return bytes.len() >= 5
            && bytes.len() >= 5 + usize::from(u16::from_be_bytes([bytes[3], bytes[4]]));
    }
    const METHODS: [&[u8]; 9] = [
        b"GET ",
        b"POST ",
        b"PUT ",
        b"HEAD ",
        b"DELETE ",
        b"OPTIONS ",
        b"PATCH ",
        b"CONNECT ",
        b"TRACE ",
    ];
    if METHODS.iter().any(|method| bytes.starts_with(method)) {
        return bytes.windows(4).any(|window| window == b"\r\n\r\n");
    }
    // Any other protocol may send a line and then wait for the server, so
    // holding it for more than its first segment would only add latency.
    true
}

/// A flow's opening bytes for the decider: the guest's segments until they are
/// [complete](initial_bytes_complete), reach `MAX_INITIAL_BYTES`, or `hold` has
/// passed since the first wait. `None` when the guest sent nothing in time (a
/// server-speaks-first protocol) or closed its side.
fn collect_initial_bytes(from: &Receiver<Vec<u8>>, hold: Duration) -> Option<Vec<u8>> {
    let deadline = Instant::now() + hold;
    let mut collected: Option<Vec<u8>> = None;
    loop {
        let remaining = deadline.saturating_duration_since(Instant::now());
        if remaining.is_zero() {
            break;
        }
        let Ok(segment) = from.recv_timeout(remaining) else {
            break;
        };
        let bytes = collected.get_or_insert_with(Vec::new);
        bytes.extend_from_slice(&segment);
        if bytes.len() >= MAX_INITIAL_BYTES || initial_bytes_complete(bytes) {
            break;
        }
    }
    collected
}

/// A relay's host socket registered in the relay's poller. Owning both ties
/// the registration to the socket's lifetime: `Drop` removes it before the
/// socket closes, on every exit path, unwinding included.
struct RegisteredStream {
    stream: TcpStream,
    poller: Arc<polling::Poller>,
}

impl RegisteredStream {
    fn new(stream: TcpStream, poller: Arc<polling::Poller>) -> io::Result<Self> {
        stream.set_nodelay(true)?;
        // SAFETY: the stream is owned by the value returned here, whose Drop
        // removes it from the poller before the stream itself is dropped.
        unsafe { poller.add(&stream, Event::none(HOST_STREAM_KEY))? };
        Ok(Self { stream, poller })
    }
}

impl Drop for RegisteredStream {
    fn drop(&mut self) {
        let _ = self.poller.delete(&self.stream);
    }
}

/// How a flow entered the relay.
struct RelayFlow {
    /// Bounded by the mediated connection lifetime.
    mediated: bool,
    /// Guest bytes already read (with the offset written so far) that must
    /// reach the host before anything else.
    pending_guest_data: Option<(Vec<u8>, usize)>,
    /// Shown the guest's opening bytes until it has seen enough of them.
    opening: Option<OpeningWatch>,
}

/// Copies of the first bytes a guest sends on an outbound connection, held
/// until they say what the connection is (a miner's stratum login, a TLS
/// server name) and then shown to the egress policy once. Holding copies
/// never delays the guest's bytes on their way to the host.
struct OpeningWatch {
    egress: EgressPolicy,
    destination: SocketAddr,
    seen: Vec<u8>,
}

impl OpeningWatch {
    fn new(egress: EgressPolicy, destination: SocketAddr) -> Self {
        Self {
            egress,
            destination,
            seen: Vec::new(),
        }
    }

    /// Take the next guest segment. `None` while more are needed; once the
    /// opening is known, whether a `block` watchlist entry refuses the flow.
    fn feed(&mut self, segment: &[u8]) -> Option<bool> {
        let room = crate::opening::MAX_OPENING_BYTES.saturating_sub(self.seen.len());
        self.seen
            .extend_from_slice(&segment[..segment.len().min(room)]);
        let opening = crate::opening::classify(&self.seen)?;
        Some(self.egress.observe_opening(self.destination, &opening))
    }
}

/// Copies bytes both ways between the host socket and the guest channels
/// until the flow ends, waiting on `poller` whenever neither direction can
/// make progress.
fn relay_stream(
    stream: &TcpStream,
    poller: &polling::Poller,
    from_smoltcp: Receiver<Vec<u8>>,
    to_smoltcp: SyncSender<Vec<u8>>,
    relay_wake: &WakePipe,
    exit_state: &RelayExitState,
    flow: RelayFlow,
) -> io::Result<RelayExitMode> {
    let RelayFlow {
        mediated,
        mut pending_guest_data,
        mut opening,
    } = flow;
    // Shows a guest segment to the opening watch until it has a verdict, and
    // ends the flow when that verdict is a watchlist `block`.
    let mut watch = |segment: &[u8]| -> io::Result<()> {
        let Some(verdict) = opening.as_mut().and_then(|watch| watch.feed(segment)) else {
            return Ok(());
        };
        opening = None;
        if verdict {
            return Err(io::Error::new(
                io::ErrorKind::PermissionDenied,
                "egress watchlist blocked the server name",
            ));
        }
        Ok(())
    };
    // The whole first payload is the guest's opening, including any prefix a
    // decider already forwarded.
    if let Some((payload, _)) = &pending_guest_data {
        watch(payload)?;
    }
    let mut stream = stream;
    let mut events = Events::new();
    let mut guest_write_closed = false;
    let mut guest_channel_closed = false;
    let mut host_read_closed = false;
    let mut read_buffer = [0u8; RELAY_BUFFER_BYTES];
    let started = Instant::now();
    let mut last_activity = started;

    loop {
        if mediated
            && (started.elapsed() >= MEDIATED_MAX_LIFETIME
                || last_activity.elapsed() >= MEDIATED_IDLE_TIMEOUT)
        {
            return Err(io::Error::new(
                io::ErrorKind::TimedOut,
                "mediated TCP flow lifetime expired",
            ));
        }
        let mut did_work = false;

        if pending_guest_data.is_none() && !guest_channel_closed {
            match from_smoltcp.try_recv() {
                Ok(payload) => {
                    watch(&payload)?;
                    pending_guest_data = Some((payload, 0));
                    // Consuming from the bounded guest->host channel may free
                    // capacity for a payload buffered in the smoltcp poll
                    // thread. Wake it so backpressure clears promptly even for
                    // one-way guest->host streams.
                    relay_wake.wake();
                    did_work = true;
                }
                Err(TryRecvError::Empty) => {}
                Err(TryRecvError::Disconnected) => {
                    guest_channel_closed = true;
                }
            }
        }

        if let Some((payload, offset)) = &mut pending_guest_data {
            while *offset < payload.len() {
                match stream.write(&payload[*offset..]) {
                    Ok(0) => {
                        return Err(io::Error::new(
                            io::ErrorKind::WriteZero,
                            "host TCP relay wrote zero bytes",
                        ));
                    }
                    Ok(bytes_written) => {
                        *offset += bytes_written;
                        did_work = true;
                    }
                    Err(err) if err.kind() == io::ErrorKind::WouldBlock => break,
                    Err(err) if err.kind() == io::ErrorKind::Interrupted => continue,
                    Err(err) => return Err(err),
                }
            }

            if *offset >= payload.len() {
                pending_guest_data = None;
            }
        }

        if guest_channel_closed && pending_guest_data.is_none() && !guest_write_closed {
            // The guest side closed its write half. Mirror that toward the
            // remote peer only after all buffered guest bytes were written.
            let _ = stream.shutdown(Shutdown::Write);
            guest_write_closed = true;
        }

        // Both directions are done — the host stopped sending (host_read_closed)
        // and the guest stopped sending and was fully flushed. Finish with a
        // clean close; the poll loop tears the guest socket down.
        if host_read_closed && guest_channel_closed && pending_guest_data.is_none() {
            return Ok(RelayExitMode::Graceful);
        }

        // host -> guest, only while the host's send half is still open. On host
        // read-EOF we do NOT tear the relay down: signal HalfClosed so the poll
        // loop mirrors the FIN to the guest, then keep draining guest->host. A
        // hijacked docker attach half-closes here (`shutdown(SHUT_WR)` with no
        // stdin) while the daemon is still streaming its response back.
        if !host_read_closed {
            match stream.read(&mut read_buffer) {
                Ok(0) => {
                    host_read_closed = true;
                    exit_state.store(RelayExitMode::HalfClosed);
                    relay_wake.wake();
                    did_work = true;
                }
                Ok(bytes_read) => {
                    if to_smoltcp.send(read_buffer[..bytes_read].to_vec()).is_err() {
                        return Ok(RelayExitMode::Graceful);
                    }
                    relay_wake.wake();
                    did_work = true;
                }
                Err(err) if err.kind() == io::ErrorKind::WouldBlock => {}
                Err(err) => return Err(err),
            }
        }

        if !did_work {
            // Read interest while the host may still send; write interest
            // while a guest payload waits on a full host send buffer.
            let interest = Event::new(
                HOST_STREAM_KEY,
                !host_read_closed,
                pending_guest_data.is_some(),
            );
            poller.modify(stream, interest)?;
            events.clear();
            poller.wait(&mut events, Some(RELAY_WAIT_BACKSTOP))?;
            if host_read_closed && pending_guest_data.is_none() {
                // Nothing reads or writes the host socket from here on, so
                // nothing would notice it failing. epoll reports EPOLLERR and
                // EPOLLHUP whatever the interest, so once the host resets, every
                // wait returns at once and this loop spins until the guest
                // closes. kqueue reports nothing, so the error is read as well.
                if let Some(err) = stream.take_error()? {
                    return Err(err);
                }
                if events.iter().any(|event| event.key == HOST_STREAM_KEY) {
                    return Err(io::Error::new(
                        io::ErrorKind::ConnectionReset,
                        "host TCP socket hung up",
                    ));
                }
            }
        } else {
            last_activity = Instant::now();
        }
    }
}

fn flush_guest_data(connection: &mut TrackedConnection) {
    let Some(payload) = connection.buffered_guest_data.take() else {
        return;
    };
    send_guest_payload(connection, payload);
}

fn send_guest_payload(connection: &mut TrackedConnection, payload: Vec<u8>) -> bool {
    let Some(to_proxy) = &connection.to_proxy else {
        return false;
    };
    match to_proxy.try_send(payload) {
        Ok(()) => true,
        Err(TrySendError::Full(payload)) => {
            connection.buffered_guest_data = Some(payload);
            false
        }
        Err(TrySendError::Disconnected(_)) => {
            connection.to_proxy = None;
            false
        }
    }
}

fn flush_proxy_data(socket: &mut tcp::Socket<'_>, connection: &mut TrackedConnection) {
    // smoltcp send windows may accept only part of an inbound host payload.
    // `buffered_proxy_data` remembers the unwritten remainder so the next poll
    // iteration can continue where it left off instead of dropping bytes.
    if let Some((data, offset)) = &mut connection.buffered_proxy_data {
        if socket.can_send() {
            match socket.send_slice(&data[*offset..]) {
                Ok(written) => {
                    *offset += written;
                    if *offset >= data.len() {
                        connection.buffered_proxy_data = None;
                    }
                }
                Err(_) => return,
            }
        } else {
            return;
        }
    }

    while connection.buffered_proxy_data.is_none() {
        match connection.from_proxy.try_recv() {
            Ok(payload) => {
                if socket.can_send() {
                    match socket.send_slice(&payload) {
                        Ok(written) if written < payload.len() => {
                            connection.buffered_proxy_data = Some((payload, written));
                        }
                        Err(_) => {
                            connection.buffered_proxy_data = Some((payload, 0));
                        }
                        _ => {}
                    }
                } else {
                    connection.buffered_proxy_data = Some((payload, 0));
                }
            }
            Err(TryRecvError::Empty | TryRecvError::Disconnected) => break,
        }
    }
}

#[cfg(test)]
mod initial_bytes_tests {
    use super::*;

    fn tls_record(body_len: usize) -> Vec<u8> {
        let mut record = vec![0x16, 0x03, 0x01];
        record.extend_from_slice(&(body_len as u16).to_be_bytes());
        record.extend(std::iter::repeat_n(0xAB, body_len));
        record
    }

    // A ClientHello split across two segments is collected whole, so a decider
    // routing by SNI sees it even when the SNI is in the second segment.
    #[test]
    fn a_tls_record_split_across_segments_is_collected_whole() {
        let record = tls_record(1795);
        assert!(!initial_bytes_complete(&record[..3]));
        assert!(!initial_bytes_complete(&record[..1200]));
        assert!(initial_bytes_complete(&record));

        let (sender, receiver) = mpsc::sync_channel(4);
        sender.send(record[..1200].to_vec()).unwrap();
        let rest = record[1200..].to_vec();
        thread::spawn(move || {
            thread::sleep(Duration::from_millis(20));
            sender.send(rest).unwrap();
        });
        assert_eq!(
            collect_initial_bytes(&receiver, Duration::from_secs(2)),
            Some(record)
        );
    }

    #[test]
    fn http_request_headers_are_collected_to_their_end() {
        assert!(!initial_bytes_complete(b"GET / HTTP/1.1\r\nHost: a"));
        assert!(initial_bytes_complete(b"GET / HTTP/1.1\r\nHost: a\r\n\r\n"));
    }

    // Another protocol is handed over after its first segment, not held for the
    // whole deadline: it may be waiting for the server to answer.
    #[test]
    fn other_protocols_are_not_held_past_their_first_segment() {
        let (sender, receiver) = mpsc::sync_channel(4);
        sender.send(b"SSH-2.0-OpenSSH_9.6\r\n".to_vec()).unwrap();
        let started = Instant::now();
        assert_eq!(
            collect_initial_bytes(&receiver, Duration::from_secs(5)),
            Some(b"SSH-2.0-OpenSSH_9.6\r\n".to_vec())
        );
        assert!(started.elapsed() < Duration::from_secs(1));
    }

    #[test]
    fn collection_stops_at_the_cap_and_at_the_deadline() {
        let (sender, receiver) = mpsc::sync_channel(4);
        sender.send(tls_record(MAX_INITIAL_BYTES)).unwrap();
        let collected = collect_initial_bytes(&receiver, Duration::from_secs(2)).unwrap();
        assert!(collected.len() >= MAX_INITIAL_BYTES);

        let (_sender, receiver) = mpsc::sync_channel::<Vec<u8>>(4);
        let started = Instant::now();
        assert_eq!(
            collect_initial_bytes(&receiver, Duration::from_millis(50)),
            None
        );
        assert!(started.elapsed() >= Duration::from_millis(50));
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn flow_summary_splits_directions_and_finds_the_oldest_outbound_flow() {
        let now = Instant::now();
        let ago = |secs| now - Duration::from_secs(secs);
        let pool: SocketAddr = "198.51.100.7:3333".parse().unwrap();
        let web: SocketAddr = "203.0.113.9:443".parse().unwrap();
        let web_other_port: SocketAddr = "203.0.113.9:80".parse().unwrap();
        let guest: SocketAddr = "100.96.0.2:8080".parse().unwrap();
        let summary = summarize_flows(
            [
                (web, false, ago(30)),
                (pool, false, ago(7200)),
                (web_other_port, false, ago(5)),
                // An inbound flow older than every outbound one is not "oldest".
                (guest, true, ago(9000)),
                (guest, true, ago(1)),
            ]
            .into_iter(),
            now,
        );
        assert_eq!(
            summary,
            FlowSummary {
                outbound_open: 3,
                inbound_open: 2,
                distinct_outbound_peers: 2,
                oldest_outbound_secs: 7200,
                oldest_outbound_dest: Some(pool),
            }
        );
    }

    #[test]
    fn flow_summary_of_only_inbound_flows_has_no_oldest_outbound() {
        let now = Instant::now();
        let guest: SocketAddr = "100.96.0.2:8080".parse().unwrap();
        let summary = summarize_flows([(guest, true, now)].into_iter(), now);
        assert_eq!(summary.inbound_open, 1);
        assert_eq!(summary.outbound_open, 0);
        assert_eq!(summary.oldest_outbound_secs, 0);
        assert_eq!(summary.oldest_outbound_dest, None);
        assert_eq!(
            summarize_flows(std::iter::empty(), now),
            FlowSummary::default()
        );
    }

    #[test]
    fn guest_relay_sockets_disable_nagle_for_outbound_and_published_connections() {
        use smoltcp::iface::Config;
        use smoltcp::phy::{Loopback, Medium};
        use smoltcp::time::Instant;
        use smoltcp::wire::{EthernetAddress, HardwareAddress};

        let gateway = Ipv4Addr::new(100, 96, 0, 1);
        let mut device = Loopback::new(Medium::Ethernet);
        let mut interface = Interface::new(
            Config::new(HardwareAddress::Ethernet(EthernetAddress([
                0x02, 0, 0, 0, 0, 1,
            ]))),
            &mut device,
            Instant::ZERO,
        );
        let mut sockets = SocketSet::new(vec![]);
        let mut table = TcpRelayTable::new(None, EgressPolicy::unrestricted(), vec![], None);
        let source = SocketAddr::from((Ipv4Addr::new(100, 96, 0, 2), 40_000));
        let destination = SocketAddr::from((Ipv4Addr::new(192, 0, 2, 10), 443));
        assert!(table.create_tcp_socket(source, destination, &mut sockets));
        let outbound_handle = *table.connections.keys().next().unwrap();
        assert!(!sockets.get::<tcp::Socket>(outbound_handle).nagle_enabled());

        let listener = std::net::TcpListener::bind((Ipv4Addr::LOCALHOST, 0)).unwrap();
        let client = TcpStream::connect(listener.local_addr().unwrap()).unwrap();
        let (_accepted, _) = listener.accept().unwrap();
        let guest = SocketAddr::from((Ipv4Addr::new(100, 96, 0, 2), 8080));
        assert!(table.create_published_socket(
            &mut interface,
            gateway,
            guest,
            client,
            &mut sockets,
        ));
        assert_eq!(table.connections.len(), 2);
        for handle in table.connections.keys() {
            assert!(!sockets.get::<tcp::Socket>(*handle).nagle_enabled());
        }
    }

    #[test]
    fn registered_relay_stream_disables_nagle_for_outbound_and_accepted_sockets() {
        let listener = std::net::TcpListener::bind((Ipv4Addr::LOCALHOST, 0)).unwrap();
        let outbound = TcpStream::connect(listener.local_addr().unwrap()).unwrap();
        let (accepted, _) = listener.accept().unwrap();

        for stream in [outbound, accepted] {
            stream.set_nodelay(false).unwrap();
            stream.set_nonblocking(true).unwrap();
            let poller = Arc::new(polling::Poller::new().unwrap());
            let registered = RegisteredStream::new(stream, poller).unwrap();
            assert!(registered.stream.nodelay().unwrap());
        }
    }

    #[test]
    fn relay_accepts_burst_beyond_old_256_limit_and_honors_configured_cap() {
        use super::*;
        let mut sockets = SocketSet::new(vec![]);
        let mut table = TcpRelayTable::new(Some(320), EgressPolicy::unrestricted(), vec![], None);
        let destination = SocketAddr::new(IpAddr::V4(Ipv4Addr::new(192, 0, 2, 10)), 443);
        for port in 40_000..40_320 {
            let source = SocketAddr::new(IpAddr::V4(Ipv4Addr::new(100, 96, 0, 2)), port);
            assert!(
                table.create_tcp_socket(source, destination, &mut sockets),
                "flow {port}"
            );
        }
        assert_eq!(table.active_connections(), 320);
        let overflow = SocketAddr::new(IpAddr::V4(Ipv4Addr::new(100, 96, 0, 2)), 40_320);
        assert!(!table.create_tcp_socket(overflow, destination, &mut sockets));
        assert_eq!(table.active_connections(), 320);
        assert!(
            TcpRelayTable::new(None, EgressPolicy::unrestricted(), vec![], None).capacity() >= 320
        );
    }
    #[test]
    fn seeded_published_ports_wrap_without_reusing_live_ports() {
        let mut table = TcpRelayTable::new(None, EgressPolicy::unrestricted(), vec![], None)
            .with_published_port_seed(u16::MAX);
        assert_eq!(table.allocate_published_port(), Some(PUBLISHED_PORT_END));
        assert_eq!(table.allocate_published_port(), Some(PUBLISHED_PORT_START));
        for expected in PUBLISHED_PORT_START + 1..PUBLISHED_PORT_END {
            assert_eq!(table.allocate_published_port(), Some(expected));
        }
        assert_eq!(table.allocate_published_port(), None);
        table.used_published_ports.remove(&PUBLISHED_PORT_END);
        assert_eq!(table.allocate_published_port(), Some(PUBLISHED_PORT_END));
        assert_eq!(table.allocate_published_port(), None);
    }

    #[test]
    fn different_port_seeds_do_not_restart_at_the_same_port() {
        let mut first = TcpRelayTable::new(None, EgressPolicy::unrestricted(), vec![], None)
            .with_published_port_seed(123);
        let mut second = TcpRelayTable::new(None, EgressPolicy::unrestricted(), vec![], None)
            .with_published_port_seed(456);
        assert_ne!(
            first.allocate_published_port(),
            second.allocate_published_port()
        );
    }

    fn test_connection(to_proxy: SyncSender<Vec<u8>>) -> TrackedConnection {
        let (_from_proxy_tx, from_proxy) = mpsc::sync_channel(CHANNEL_CAPACITY);
        TrackedConnection {
            source: SocketAddr::new(Ipv4Addr::LOCALHOST.into(), 12_345),
            destination: SocketAddr::new(Ipv4Addr::LOCALHOST.into(), 80),
            to_proxy: Some(ToProxy {
                sender: Some(to_proxy),
                wake: WakePipe::new(),
            }),
            from_proxy,
            pending_proxy_endpoints: None,
            relay_spawned: true,
            buffered_guest_data: None,
            buffered_proxy_data: None,
            close_attempts: 0,
            guest_send_closed: false,
            exit_state: RelayExitState::new(),
            reserved_published_port: None,
            opened_at: Instant::now(),
        }
    }

    #[test]
    fn failed_relay_thread_spawn_aborts_the_guest_connection() {
        let exit_state = RelayExitState::new();
        let wake = WakePipe::new();
        let destination = SocketAddr::new(Ipv4Addr::LOCALHOST.into(), 6443);
        let spawn_error = io::Error::other("injected thread spawn failure");

        let result =
            handle_relay_spawn_result::<()>(Err(spawn_error), destination, &exit_state, &wake);

        assert!(result.is_err());
        assert_eq!(exit_state.load(), RelayExitMode::Abort);
    }

    /// A host echo server for one connection, on loopback.
    fn echo_server() -> SocketAddr {
        let listener = std::net::TcpListener::bind((Ipv4Addr::LOCALHOST, 0)).unwrap();
        let address = listener.local_addr().unwrap();
        thread::spawn(move || {
            let (mut stream, _) = listener.accept().unwrap();
            let mut buffer = [0u8; 64];
            while let Ok(read @ 1..) = stream.read(&mut buffer) {
                if stream.write_all(&buffer[..read]).is_err() {
                    break;
                }
            }
        });
        address
    }

    /// A relay thread connected to `destination`, with the poll loop's ends of its channels.
    fn spawn_test_relay(destination: SocketAddr) -> (ToProxy, Receiver<Vec<u8>>, RelayExitState) {
        spawn_watched_relay(destination, None)
    }

    /// `spawn_test_relay`, showing the guest's opening bytes to `watch_opening`.
    fn spawn_watched_relay(
        destination: SocketAddr,
        watch_opening: Option<EgressPolicy>,
    ) -> (ToProxy, Receiver<Vec<u8>>, RelayExitState) {
        let (to_proxy, from_smoltcp, proxy_wake) = proxy_channel();
        let (to_smoltcp, from_proxy) = mpsc::sync_channel(CHANNEL_CAPACITY);
        let exit_state = RelayExitState::new();
        spawn_tcp_relay(
            NewTcpConnection {
                destination,
                relay_target: RelayTarget::Connect(destination),
                from_smoltcp,
                to_smoltcp,
                exit_state: exit_state.clone(),
                proxy_wake,
                watch_opening,
            },
            Arc::new(WakePipe::new()),
        )
        .unwrap();
        (to_proxy, from_proxy, exit_state)
    }

    /// A policy that admits everything and records signals to `dir`, watching
    /// `watchlist` when it is written.
    fn watching_policy(dir: &std::path::Path) -> EgressPolicy {
        EgressPolicy::unrestricted().with_watchlist(
            dir.join(crate::watchlist::EGRESS_WATCHLIST_FILE),
            dir.join(crate::EGRESS_SIGNALS_LOG),
        )
    }

    #[test]
    fn a_miner_logging_in_to_its_pool_is_recorded_and_still_relayed() {
        let dir = tempfile::tempdir().unwrap();
        let pool = echo_server();
        let (to_proxy, from_proxy, _exit_state) =
            spawn_watched_relay(pool, Some(watching_policy(dir.path())));
        // ccminer's login is split across two segments, as TCP may deliver it.
        let login: &[u8] =
            b"{\"id\": 1, \"method\": \"mining.subscribe\", \"params\": [\"ccminer/2.3.1\"]}\n";
        to_proxy.try_send(login[..20].to_vec()).unwrap();
        to_proxy.try_send(login[20..].to_vec()).unwrap();
        let mut echoed = Vec::new();
        while echoed.len() < login.len() {
            echoed.extend(from_proxy.recv_timeout(Duration::from_secs(2)).unwrap());
        }
        assert_eq!(echoed, login, "the miner's bytes reach the pool unchanged");
        let log = std::fs::read_to_string(dir.path().join(crate::EGRESS_SIGNALS_LOG)).unwrap();
        assert!(
            log.contains(&format!("egress watch {} {pool}", crate::STRATUM_SIGNAL)),
            "{log}"
        );
    }

    #[test]
    fn ordinary_traffic_records_no_signal() {
        let dir = tempfile::tempdir().unwrap();
        let server = echo_server();
        let (to_proxy, from_proxy, _exit_state) =
            spawn_watched_relay(server, Some(watching_policy(dir.path())));
        to_proxy
            .try_send(b"GET / HTTP/1.1\r\nHost: example.com\r\n\r\n".to_vec())
            .unwrap();
        from_proxy.recv_timeout(Duration::from_secs(2)).unwrap();
        assert!(!dir.path().join(crate::EGRESS_SIGNALS_LOG).exists());
    }

    #[test]
    fn a_blocked_server_name_ends_the_flow_before_its_hello_leaves() {
        use sha2::Digest;
        let dir = tempfile::tempdir().unwrap();
        let digest = sha2::Sha256::digest(b"pool.example");
        std::fs::write(
            dir.path().join(crate::watchlist::EGRESS_WATCHLIST_FILE),
            format!("p1 dns-sha256:{digest:x} block\n"),
        )
        .unwrap();
        let (accepted_tx, accepted_rx) = mpsc::channel();
        let listener = std::net::TcpListener::bind((Ipv4Addr::LOCALHOST, 0)).unwrap();
        let server = listener.local_addr().unwrap();
        thread::spawn(move || {
            let (mut stream, _) = listener.accept().unwrap();
            let mut received = Vec::new();
            let _ = stream.read_to_end(&mut received);
            let _ = accepted_tx.send(received);
        });
        let (to_proxy, _from_proxy, exit_state) =
            spawn_watched_relay(server, Some(watching_policy(dir.path())));
        to_proxy
            .try_send(crate::opening::client_hello("Pool.Example"))
            .unwrap();
        wait_for_exit_mode(&exit_state, RelayExitMode::Abort, Duration::from_secs(2));
        assert_eq!(
            accepted_rx.recv_timeout(Duration::from_secs(2)).unwrap(),
            Vec::<u8>::new(),
            "the ClientHello never reached the server"
        );
        let log = std::fs::read_to_string(dir.path().join(crate::EGRESS_SIGNALS_LOG)).unwrap();
        assert!(log.contains("egress watch p1 pool.example"), "{log}");
    }

    #[test]
    fn an_idle_relay_forwards_both_ways_without_waiting_out_a_poll_interval() {
        let (to_proxy, from_proxy, _exit_state) = spawn_test_relay(echo_server());
        let mut round_trips = Vec::new();
        for byte in 0..21u8 {
            // Let the relay go idle first: the case a fixed poll interval made slow.
            // The old 10 ms poll put the median near 15-18 ms; a woken relay is
            // well under 1 ms, so 8 ms leaves room for a loaded CI runner.
            thread::sleep(Duration::from_millis(15));
            let started = std::time::Instant::now();
            to_proxy.try_send(vec![byte]).unwrap();
            assert_eq!(
                from_proxy.recv_timeout(Duration::from_secs(2)).unwrap(),
                vec![byte]
            );
            round_trips.push(started.elapsed());
        }
        round_trips.sort();
        let median = round_trips[round_trips.len() / 2];
        assert!(
            median < Duration::from_millis(8),
            "median guest->host->guest round trip through an idle relay was {median:?}"
        );
    }

    #[test]
    fn dropping_the_guest_side_wakes_an_idle_relay_to_finish() {
        let (to_proxy, _from_proxy, exit_state) = spawn_test_relay(echo_server());
        to_proxy.try_send(vec![1]).unwrap();
        thread::sleep(Duration::from_millis(30));
        let started = std::time::Instant::now();
        drop(to_proxy);
        while exit_state.load() == RelayExitMode::Running {
            assert!(
                started.elapsed() < RELAY_WAIT_BACKSTOP / 2,
                "relay still running {:?} after the guest side closed",
                started.elapsed()
            );
            thread::sleep(Duration::from_millis(1));
        }
    }

    /// A host server for one connection that half-closes, then hands the
    /// accepted socket to `then`.
    fn half_closing_server(then: impl FnOnce(TcpStream) + Send + 'static) -> SocketAddr {
        let listener = std::net::TcpListener::bind((Ipv4Addr::LOCALHOST, 0)).unwrap();
        let address = listener.local_addr().unwrap();
        thread::spawn(move || {
            let (stream, _) = listener.accept().unwrap();
            stream.shutdown(Shutdown::Write).unwrap();
            then(stream);
        });
        address
    }

    fn wait_for_exit_mode(exit_state: &RelayExitState, mode: RelayExitMode, within: Duration) {
        let started = Instant::now();
        while exit_state.load() != mode {
            assert!(
                started.elapsed() < within,
                "relay is {:?} after {:?}, expected {mode:?}",
                exit_state.load(),
                started.elapsed()
            );
            thread::sleep(Duration::from_millis(1));
        }
    }

    #[test]
    fn a_host_reset_after_its_half_close_ends_a_relay_whose_guest_is_silent() {
        let (reset_tx, reset_rx) = mpsc::channel::<()>();
        let destination = half_closing_server(move |stream| {
            reset_rx.recv().unwrap();
            socket2::SockRef::from(&stream)
                .set_linger(Some(Duration::ZERO))
                .unwrap();
        });
        // The guest side stays open and sends nothing.
        let (_to_proxy, _from_proxy, exit_state) = spawn_test_relay(destination);
        wait_for_exit_mode(
            &exit_state,
            RelayExitMode::HalfClosed,
            Duration::from_secs(2),
        );
        reset_tx.send(()).unwrap();
        // On epoll the relay used to spin here until the guest closed.
        wait_for_exit_mode(&exit_state, RelayExitMode::Abort, RELAY_WAIT_BACKSTOP * 5);
    }

    #[test]
    fn a_host_half_close_keeps_relaying_guest_bytes() {
        let (received_tx, received_rx) = mpsc::channel();
        let destination = half_closing_server(move |mut stream| {
            let mut buffer = [0u8; 4];
            stream.read_exact(&mut buffer).unwrap();
            received_tx.send(buffer).unwrap();
            // Keep the socket open until the relay is checked.
            thread::sleep(Duration::from_secs(1));
        });
        let (to_proxy, _from_proxy, exit_state) = spawn_test_relay(destination);
        wait_for_exit_mode(
            &exit_state,
            RelayExitMode::HalfClosed,
            Duration::from_secs(2),
        );
        // Idle for a few backstop waits before the guest sends.
        thread::sleep(RELAY_WAIT_BACKSTOP * 3);
        to_proxy.try_send(b"ping".to_vec()).unwrap();
        assert_eq!(
            received_rx.recv_timeout(Duration::from_secs(2)).unwrap(),
            *b"ping"
        );
        assert_eq!(exit_state.load(), RelayExitMode::HalfClosed);
    }

    #[test]
    fn guest_payload_is_buffered_when_relay_channel_is_full() {
        let (to_proxy, from_smoltcp) = mpsc::sync_channel(1);
        to_proxy.send(vec![1]).unwrap();
        let mut connection = test_connection(to_proxy);

        assert!(!send_guest_payload(&mut connection, vec![2]));
        assert_eq!(connection.buffered_guest_data.as_deref(), Some(&[2][..]));

        assert_eq!(from_smoltcp.recv().unwrap(), vec![1]);
        flush_guest_data(&mut connection);

        assert!(connection.buffered_guest_data.is_none());
        assert_eq!(from_smoltcp.recv().unwrap(), vec![2]);
    }

    #[test]
    fn gateway_ip_destination_dials_the_host_over_loopback() {
        let gw4: IpAddr = "100.96.0.1".parse().unwrap();
        let gw6: IpAddr = "fd00::1".parse().unwrap();
        let table = TcpRelayTable::new(None, EgressPolicy::unrestricted(), vec![gw4, gw6], None);

        // A guest reaching "the host" via its gateway IP must dial loopback, not
        // the gateway's own (non-routable) userspace address — the bug that made
        // the handshake succeed but blackholed the reply. Port is preserved.
        assert_eq!(
            table.host_connect_addr(SocketAddr::new(gw4, 19997)),
            SocketAddr::new(Ipv4Addr::LOCALHOST.into(), 19997),
        );
        assert_eq!(
            table.host_connect_addr(SocketAddr::new(gw6, 6379)),
            SocketAddr::new(Ipv6Addr::LOCALHOST.into(), 6379),
        );

        // A non-gateway destination (external host / the host's LAN IP) is dialed
        // unchanged.
        let lan: IpAddr = "192.168.1.5".parse().unwrap();
        assert_eq!(
            table.host_connect_addr(SocketAddr::new(lan, 3306)),
            SocketAddr::new(lan, 3306),
        );
    }

    #[test]
    fn deny_rule_holds_against_the_address_the_relay_dials() {
        use smolvm_protocol::{EgressRule, RuleAction};
        // The guest names the gateway, the relay dials host loopback. A deny
        // on loopback has to see the dialed address, not just the gateway.
        let gateway: IpAddr = "100.96.0.1".parse().unwrap();
        let policy = EgressPolicy::unrestricted()
            .with_rules(&[EgressRule {
                transport: None,
                cidr: Some("127.0.0.0/8".into()),
                ports: None,
                action: RuleAction::Deny,
            }])
            .unwrap();
        let table = TcpRelayTable::new(None, policy, vec![gateway], None);
        assert!(!table.destination_allowed(SocketAddr::new(gateway, 5432)));
        // Without the deny the same flow is not refused by the rule path.
        let open = TcpRelayTable::new(None, EgressPolicy::unrestricted(), vec![gateway], None);
        assert!(open.destination_allowed(SocketAddr::new(gateway, 5432)));
    }

    #[test]
    fn dedicated_gateway_service_does_not_weaken_other_egress() {
        let gateway: IpAddr = "100.96.0.1".parse().unwrap();
        let external: IpAddr = "8.8.8.8".parse().unwrap();
        let table = TcpRelayTable::new(
            None,
            EgressPolicy::from_allowed_cidrs(Some(&[])),
            vec![gateway],
            Some(crate::GatewayHostService {
                guest_port: 10_081,
                host_port: 40_081,
            }),
        );

        assert!(table.destination_allowed(SocketAddr::new(gateway, 10_081)));
        assert!(!table.destination_allowed(SocketAddr::new(gateway, 22)));
        assert!(!table.destination_allowed(SocketAddr::new(external, 10_081)));
        assert_eq!(
            table.host_connect_addr(SocketAddr::new(gateway, 10_081)),
            SocketAddr::new(IpAddr::V4(Ipv4Addr::LOCALHOST), 40_081)
        );
        let mediated = table.with_intercept(Some(crate::StreamInterception::Mediated(
            crate::MediatedBinding {
                endpoint: crate::InterceptEndpoint {
                    addr: "127.0.0.1:43123".parse().unwrap(),
                    token: [9; 32],
                },
                machine_id: [7; 16],
                parent_id: [0; 16],
            },
        )));
        assert!(matches!(
            mediated.outbound_target(SocketAddr::new(gateway, 10_081)),
            RelayTarget::Connect(address) if address == "127.0.0.1:40081".parse().unwrap()
        ));
    }

    #[test]
    fn guest_fin_drops_to_proxy_channel() {
        let (to_proxy, from_smoltcp) = mpsc::sync_channel(1);
        let connection = test_connection(to_proxy);
        let rx_buffer = tcp::SocketBuffer::new(vec![0; 1024]);
        let tx_buffer = tcp::SocketBuffer::new(vec![0; 1024]);
        let socket = tcp::Socket::new(rx_buffer, tx_buffer);
        // A closed or FIN-received socket has may_recv() == false
        assert!(!socket.may_recv());

        let mut sockets = SocketSet::new(vec![]);
        let handle = sockets.add(socket);

        let mut table = TcpRelayTable::new(None, EgressPolicy::unrestricted(), vec![], None);
        table.connections.insert(handle, connection);

        table.relay_data(&mut sockets);

        // to_proxy in the connection must have been dropped (set to None)
        assert!(table.connections.get(&handle).unwrap().to_proxy.is_none());
        // The receiver on the relay thread side must see Disconnected
        assert_eq!(from_smoltcp.try_recv(), Err(TryRecvError::Disconnected));
    }

    #[test]
    fn tcp_relay_loop_handles_guest_write_shutdown_cleanly() {
        use std::net::TcpListener;

        let listener = TcpListener::bind("127.0.0.1:0").unwrap();
        let server_addr = listener.local_addr().unwrap();

        let (from_smoltcp_tx, from_smoltcp_rx) = mpsc::sync_channel(CHANNEL_CAPACITY);
        let (to_smoltcp_tx, _to_smoltcp_rx) = mpsc::sync_channel(CHANNEL_CAPACITY);
        let wake_pipe = Arc::new(WakePipe::new());
        let exit_state = RelayExitState::new();

        // Send a payload then drop from_smoltcp_tx (simulating guest FIN)
        from_smoltcp_tx.send(b"hello server".to_vec()).unwrap();
        drop(from_smoltcp_tx);

        let server_thread = thread::spawn(move || {
            let (mut stream, _) = listener.accept().unwrap();
            let mut buf = [0u8; 64];
            let n = stream.read(&mut buf).unwrap();
            assert_eq!(&buf[..n], b"hello server");
            // Server should now read EOF (0 bytes) because client shut down write half
            let eof = stream.read(&mut buf).unwrap();
            assert_eq!(eof, 0);
            drop(stream);
        });

        let relay_exit = tcp_relay_loop(
            NewTcpConnection {
                destination: server_addr,
                relay_target: RelayTarget::Connect(server_addr),
                from_smoltcp: from_smoltcp_rx,
                to_smoltcp: to_smoltcp_tx,
                exit_state: exit_state.clone(),
                proxy_wake: WakePipe::new(),
                watch_opening: None,
            },
            wake_pipe,
            &exit_state,
        )
        .unwrap();

        assert_eq!(relay_exit, RelayExitMode::Graceful);
        server_thread.join().unwrap();
    }

    #[test]
    fn intercept_target_announces_the_destination_before_guest_bytes() {
        use std::net::TcpListener;

        let listener = TcpListener::bind("127.0.0.1:0").unwrap();
        let endpoint = crate::InterceptEndpoint {
            addr: listener.local_addr().unwrap(),
            token: [0x5a; smolvm_protocol::intercept::TOKEN_LEN],
        };
        let destination = SocketAddr::new(IpAddr::V4(Ipv4Addr::new(192, 0, 2, 10)), 443);

        let (from_smoltcp_tx, from_smoltcp_rx) = mpsc::sync_channel(CHANNEL_CAPACITY);
        let (to_smoltcp_tx, to_smoltcp_rx) = mpsc::sync_channel(CHANNEL_CAPACITY);
        let wake_pipe = Arc::new(WakePipe::new());
        let exit_state = RelayExitState::new();
        from_smoltcp_tx.send(b"\x16\x03\x01hello".to_vec()).unwrap();
        drop(from_smoltcp_tx);

        let interceptor = thread::spawn(move || {
            let (mut stream, _) = listener.accept().unwrap();
            let announced = endpoint.read_preamble(&mut stream).unwrap();
            stream
                .write_all(&[smolvm_protocol::intercept::VERDICT_CONNECTED])
                .unwrap();
            let mut buf = [0u8; 64];
            let n = stream.read(&mut buf).unwrap();
            stream.write_all(b"ack").unwrap();
            (announced, buf[..n].to_vec())
        });

        let relay_exit = tcp_relay_loop(
            NewTcpConnection {
                destination,
                relay_target: RelayTarget::Intercept {
                    endpoint,
                    destination,
                },
                from_smoltcp: from_smoltcp_rx,
                to_smoltcp: to_smoltcp_tx,
                exit_state: exit_state.clone(),
                proxy_wake: WakePipe::new(),
                watch_opening: None,
            },
            wake_pipe,
            &exit_state,
        )
        .unwrap();
        assert_eq!(relay_exit, RelayExitMode::Graceful);
        let (announced, first_bytes) = interceptor.join().unwrap();
        assert_eq!(announced, destination);
        assert_eq!(first_bytes, b"\x16\x03\x01hello");
        assert_eq!(to_smoltcp_rx.recv().unwrap(), b"ack");
    }

    #[test]
    fn only_https_flows_are_redirected_to_the_interceptor() {
        let endpoint = crate::InterceptEndpoint {
            addr: "127.0.0.1:1".parse().unwrap(),
            token: [0; smolvm_protocol::intercept::TOKEN_LEN],
        };
        let gateway = IpAddr::V4(Ipv4Addr::new(100, 96, 0, 1));
        let table = TcpRelayTable::new(None, EgressPolicy::unrestricted(), vec![gateway], None)
            .with_intercept(Some(crate::StreamInterception::Https(endpoint)));
        let https = SocketAddr::new(IpAddr::V4(Ipv4Addr::new(192, 0, 2, 10)), 443);
        let http = SocketAddr::new(IpAddr::V4(Ipv4Addr::new(192, 0, 2, 10)), 80);
        let gateway_https = SocketAddr::new(gateway, 443);
        assert!(matches!(
            table.outbound_target(https),
            RelayTarget::Intercept { destination, .. } if destination == https
        ));
        assert!(matches!(table.outbound_target(http), RelayTarget::Connect(addr) if addr == http));
        assert!(matches!(
            table.outbound_target(gateway_https),
            RelayTarget::Connect(addr) if addr.ip().is_loopback()
        ));
        let plain = TcpRelayTable::new(None, EgressPolicy::unrestricted(), vec![], None);
        assert!(
            matches!(plain.outbound_target(https), RelayTarget::Connect(addr) if addr == https)
        );
    }

    /// `--block-private --allow-private 100.81.17.207/32` with a `--credential`
    /// bound to that host: the reopened range is admitted by a static allow
    /// rule, and the flow must still reach the interceptor, or the guest's
    /// placeholder goes to the origin verbatim (issue #2024).
    #[test]
    fn a_range_reopened_with_allow_private_is_still_intercepted() {
        let endpoint = crate::InterceptEndpoint {
            addr: "127.0.0.1:1".parse().unwrap(),
            token: [0; smolvm_protocol::intercept::TOKEN_LEN],
        };
        let gateway = IpAddr::V4(Ipv4Addr::new(100, 96, 0, 1));
        let egress = EgressPolicy::unrestricted()
            .with_private_floor(&["100.81.17.207/32".to_string()])
            .unwrap();
        let reopened_https = SocketAddr::new(IpAddr::V4(Ipv4Addr::new(100, 81, 17, 207)), 443);
        let reopened_http = SocketAddr::new(IpAddr::V4(Ipv4Addr::new(100, 81, 17, 207)), 80);
        let public_https = SocketAddr::new(IpAddr::V4(Ipv4Addr::new(93, 184, 215, 14)), 443);

        let credential = TcpRelayTable::new(None, egress.clone(), vec![gateway], None)
            .with_intercept(Some(crate::StreamInterception::Https(endpoint)));
        assert!(credential.destination_allowed(reopened_https));
        for https in [reopened_https, public_https] {
            assert!(matches!(
                credential.outbound_target(https),
                RelayTarget::Intercept { destination, .. } if destination == https
            ));
        }
        assert!(matches!(
            credential.outbound_target(reopened_http),
            RelayTarget::Connect(addr) if addr == reopened_http
        ));

        let all_tcp = TcpRelayTable::new(None, egress, vec![gateway], None)
            .with_intercept(Some(crate::StreamInterception::AllTcp(endpoint)));
        for destination in [reopened_https, reopened_http] {
            assert!(matches!(
                all_tcp.outbound_target(destination),
                RelayTarget::Intercept { destination: actual, .. } if actual == destination
            ));
        }
    }

    #[test]
    fn external_interceptor_receives_all_tcp_destinations() {
        let endpoint = crate::InterceptEndpoint {
            addr: "127.0.0.1:1234".parse().unwrap(),
            token: [1; smolvm_protocol::intercept::TOKEN_LEN],
        };
        let gateway = "100.96.0.1".parse().unwrap();
        let table = TcpRelayTable::new(None, EgressPolicy::unrestricted(), vec![gateway], None)
            .with_intercept(Some(crate::StreamInterception::AllTcp(endpoint)));
        for address in [
            "192.0.2.1:80",
            "192.0.2.1:443",
            "192.0.2.1:22",
            "[2001:db8::1]:8443",
            "100.96.0.1:8080",
        ] {
            let requested = address.parse().unwrap();
            assert!(matches!(table.outbound_target(requested),
                RelayTarget::Intercept { endpoint: actual, destination }
                    if actual == endpoint && destination == requested));
        }
    }

    #[test]
    fn mediated_decision_precedes_origin_dial_and_preserves_first_bytes() {
        use std::net::TcpListener;

        for decision in [Decision::Deny, Decision::AllowDirect, Decision::Redirect] {
            let origin = TcpListener::bind("127.0.0.1:0").unwrap();
            let origin_addr = origin.local_addr().unwrap();
            origin.set_nonblocking(true).unwrap();
            let broker = TcpListener::bind("127.0.0.1:0").unwrap();
            let binding = crate::MediatedBinding {
                endpoint: crate::InterceptEndpoint {
                    addr: broker.local_addr().unwrap(),
                    token: [0x5a; 32],
                },
                machine_id: [7; 16],
                parent_id: [3; 16],
            };
            let destination: SocketAddr = "1.1.1.1:443".parse().unwrap();
            let broker_thread = thread::spawn(move || {
                let (mut stream, _) = broker.accept().unwrap();
                stream
                    .set_read_timeout(Some(Duration::from_secs(2)))
                    .unwrap();
                let prelude = FlowPrelude::read_from(&mut stream, &binding.endpoint.token).unwrap();
                assert_eq!(prelude.machine_id, binding.machine_id);
                assert_eq!(prelude.parent_id, binding.parent_id);
                assert_eq!(prelude.destination, destination);
                assert_eq!(prelude.initial_bytes, b"hello");
                // Nothing may have reached the origin while the broker is
                // deciding, including a direct-allow candidate.
                assert!(
                    matches!(origin.accept(), Err(error) if error.kind() == io::ErrorKind::WouldBlock)
                );
                decision.write_to(&mut stream).unwrap();
                if decision == Decision::Redirect {
                    stream.write_all(b"redirected").unwrap();
                }
                if decision == Decision::AllowDirect {
                    origin.set_nonblocking(false).unwrap();
                    let (mut upstream, _) = origin.accept().unwrap();
                    let mut data = [0; 5];
                    upstream.read_exact(&mut data).unwrap();
                    assert_eq!(&data, b"hello");
                    upstream.write_all(b"direct").unwrap();
                }
                if decision == Decision::Deny {
                    assert!(
                        matches!(origin.accept(), Err(error) if error.kind() == io::ErrorKind::WouldBlock)
                    );
                }
            });
            let (guest_tx, guest_rx) = mpsc::sync_channel(CHANNEL_CAPACITY);
            let (reply_tx, reply_rx) = mpsc::sync_channel(CHANNEL_CAPACITY);
            guest_tx.send(b"hello".to_vec()).unwrap();
            drop(guest_tx);
            let state = RelayExitState::new();
            let result = tcp_relay_loop(
                NewTcpConnection {
                    destination,
                    relay_target: RelayTarget::Mediated {
                        binding,
                        destination,
                        direct_address: origin_addr,
                        direct_allowed: true,
                        audit: EgressPolicy::unrestricted(),
                    },
                    from_smoltcp: guest_rx,
                    to_smoltcp: reply_tx,
                    exit_state: state.clone(),
                    proxy_wake: WakePipe::new(),
                    watch_opening: None,
                },
                Arc::new(WakePipe::new()),
                &state,
            );
            broker_thread.join().unwrap();
            if decision == Decision::Deny {
                assert_eq!(result.unwrap_err().kind(), io::ErrorKind::PermissionDenied);
            } else {
                assert!(result.is_ok());
                assert_eq!(
                    reply_rx.recv().unwrap(),
                    if decision == Decision::Redirect {
                        b"redirected".to_vec()
                    } else {
                        b"direct".to_vec()
                    }
                );
            }
        }
    }

    #[test]
    fn mediated_hold_handles_server_first_and_payload_cap() {
        use std::net::TcpListener;

        for payload in [None, Some(vec![b'x'; MAX_INITIAL_BYTES + 808])] {
            let listener = TcpListener::bind("127.0.0.1:0").unwrap();
            let binding = crate::MediatedBinding {
                endpoint: crate::InterceptEndpoint {
                    addr: listener.local_addr().unwrap(),
                    token: [4; 32],
                },
                machine_id: [5; 16],
                parent_id: [0; 16],
            };
            let destination: SocketAddr = "1.1.1.1:25".parse().unwrap();
            let expected = payload.clone();
            let server = thread::spawn(move || {
                let (mut stream, _) = listener.accept().unwrap();
                stream
                    .set_read_timeout(Some(Duration::from_secs(3)))
                    .unwrap();
                let prelude = FlowPrelude::read_from(&mut stream, &binding.endpoint.token).unwrap();
                if expected.is_some() {
                    assert_eq!(prelude.initial_bytes, vec![b'x'; MAX_INITIAL_BYTES]);
                } else {
                    assert!(prelude.initial_bytes.is_empty());
                }
                Decision::Redirect.write_to(&mut stream).unwrap();
                if expected.is_some() {
                    let mut rest = vec![0; 808];
                    stream.read_exact(&mut rest).unwrap();
                    assert_eq!(rest, vec![b'x'; 808]);
                }
                stream.write_all(b"greeting").unwrap();
            });
            let (guest_tx, guest_rx) = mpsc::sync_channel(CHANNEL_CAPACITY);
            let (reply_tx, reply_rx) = mpsc::sync_channel(CHANNEL_CAPACITY);
            if let Some(payload) = payload {
                guest_tx.send(payload).unwrap();
            }
            let state = RelayExitState::new();
            let relay = thread::spawn(move || {
                tcp_relay_loop(
                    NewTcpConnection {
                        destination,
                        relay_target: RelayTarget::Mediated {
                            binding,
                            destination,
                            direct_address: destination,
                            direct_allowed: false,
                            audit: EgressPolicy::unrestricted(),
                        },
                        from_smoltcp: guest_rx,
                        to_smoltcp: reply_tx,
                        exit_state: state.clone(),
                        proxy_wake: WakePipe::new(),
                        watch_opening: None,
                    },
                    Arc::new(WakePipe::new()),
                    &state,
                )
            });
            assert_eq!(
                reply_rx.recv_timeout(Duration::from_secs(3)).unwrap(),
                b"greeting"
            );
            drop(guest_tx);
            assert!(relay.join().unwrap().is_ok());
            server.join().unwrap();
        }
    }

    #[test]
    fn interceptor_failure_never_connects_directly() {
        use std::net::TcpListener;

        let upstream = TcpListener::bind("127.0.0.1:0").unwrap();
        upstream.set_nonblocking(true).unwrap();
        let destination = upstream.local_addr().unwrap();
        for reject in [true, false] {
            let listener = TcpListener::bind("127.0.0.1:0").unwrap();
            let endpoint = crate::InterceptEndpoint {
                addr: listener.local_addr().unwrap(),
                token: [1; smolvm_protocol::intercept::TOKEN_LEN],
            };
            let interceptor = thread::spawn(move || {
                let (mut stream, _) = listener.accept().unwrap();
                assert_eq!(endpoint.read_preamble(&mut stream).unwrap(), destination);
                if reject {
                    stream.write_all(&[111]).unwrap();
                }
            });
            let (sender, receiver) = mpsc::sync_channel(CHANNEL_CAPACITY);
            sender.send(b"guest payload".to_vec()).unwrap();
            let (reply, _receiver) = mpsc::sync_channel(CHANNEL_CAPACITY);
            assert!(tcp_relay_loop(
                NewTcpConnection {
                    destination,
                    relay_target: RelayTarget::Intercept {
                        endpoint,
                        destination
                    },
                    from_smoltcp: receiver,
                    to_smoltcp: reply,
                    exit_state: RelayExitState::new(),
                    proxy_wake: WakePipe::new(),
                    watch_opening: None,
                },
                Arc::new(WakePipe::new()),
                &RelayExitState::new(),
            )
            .is_err());
            interceptor.join().unwrap();
            assert_eq!(
                upstream.accept().unwrap_err().kind(),
                io::ErrorKind::WouldBlock
            );
        }
    }

    #[test]
    fn aborted_connection_sends_rst_to_the_guest_before_cleanup() {
        use smoltcp::iface::{Config, Interface};
        use smoltcp::phy::{Loopback, Medium};
        use smoltcp::time::Instant;
        use smoltcp::wire::{EthernetAddress, HardwareAddress, IpAddress, IpCidr, Ipv4Address};

        let mut device = Loopback::new(Medium::Ethernet);
        let mut interface = Interface::new(
            Config::new(HardwareAddress::Ethernet(EthernetAddress([
                0x02, 0, 0, 0, 0, 1,
            ]))),
            &mut device,
            Instant::ZERO,
        );
        interface.update_ip_addrs(|addresses| {
            addresses
                .push(IpCidr::new(IpAddress::v4(100, 96, 0, 1), 30))
                .unwrap();
        });
        interface
            .routes_mut()
            .add_default_ipv4_route(Ipv4Address::new(100, 96, 0, 1))
            .unwrap();
        // Same as the production interface: accept flows to arbitrary
        // destinations so the relay's listen sockets can intercept them.
        interface.set_any_ip(true);

        let mut sockets = SocketSet::new(vec![]);
        let mut table = TcpRelayTable::new(None, EgressPolicy::unrestricted(), vec![], None);

        // The "guest" dials an external destination; the relay pre-creates the
        // intercepting listen socket exactly like the poll loop does on SYN.
        let destination = SocketAddr::new(IpAddr::V4(Ipv4Addr::new(192, 0, 2, 10)), 443);
        let source = SocketAddr::new(IpAddr::V4(Ipv4Addr::new(100, 96, 0, 1)), 40_000);
        assert!(table.create_tcp_socket(source, destination, &mut sockets));

        // Guest stand-in: a client socket running a real handshake against the
        // intercepting socket over the loopback device.
        let client_handle = sockets.add(tcp::Socket::new(
            tcp::SocketBuffer::new(vec![0u8; 4096]),
            tcp::SocketBuffer::new(vec![0u8; 4096]),
        ));
        sockets
            .get_mut::<tcp::Socket>(client_handle)
            .connect(
                interface.context(),
                (IpAddress::v4(192, 0, 2, 10), 443),
                40_000,
            )
            .unwrap();

        let mut now_ms: i64 = 0;
        let poll = |interface: &mut Interface,
                    device: &mut Loopback,
                    sockets: &mut SocketSet<'_>,
                    now_ms: &mut i64| {
            *now_ms += 10;
            interface.poll(Instant::from_millis(*now_ms), device, sockets);
        };

        for _ in 0..10 {
            poll(&mut interface, &mut device, &mut sockets, &mut now_ms);
            if sockets.get::<tcp::Socket>(client_handle).state() == tcp::State::Established {
                break;
            }
        }
        assert_eq!(
            sockets.get::<tcp::Socket>(client_handle).state(),
            tcp::State::Established,
            "handshake must complete before the abort is simulated"
        );

        // The host-side connect failed: the relay thread reports Abort. (The
        // intercepting socket trails the client by the final ACK, so poll until
        // the table observes it as Established.)
        let mut new_connections = Vec::new();
        for _ in 0..10 {
            poll(&mut interface, &mut device, &mut sockets, &mut now_ms);
            new_connections = table.take_new_connections(&mut sockets);
            if !new_connections.is_empty() {
                break;
            }
        }
        assert_eq!(new_connections.len(), 1);
        new_connections[0].exit_state.store(RelayExitMode::Abort);

        // Poll-loop order under test: relay_data (abort) then cleanup_closed
        // BEFORE the next egress flush. The aborted socket must survive cleanup
        // with its RST still queued, or the guest never learns and hangs until
        // its own timeout.
        table.relay_data(&mut sockets);
        table.cleanup_closed(&mut sockets);
        assert!(
            table.has_socket_for(&source, &destination),
            "aborted socket was reaped before its RST was dispatched"
        );

        // The next flushes deliver the RST; the guest-side socket must observe
        // the reset instead of staying Established.
        for _ in 0..10 {
            poll(&mut interface, &mut device, &mut sockets, &mut now_ms);
            if sockets.get::<tcp::Socket>(client_handle).state() == tcp::State::Closed {
                break;
            }
        }
        assert_eq!(
            sockets.get::<tcp::Socket>(client_handle).state(),
            tcp::State::Closed,
            "guest never received the RST for the aborted connection"
        );

        // With the RST on the wire the connection is finally reaped.
        table.cleanup_closed(&mut sockets);
        assert!(!table.has_socket_for(&source, &destination));
    }

    #[test]
    fn refused_guest_port_is_reported_once_per_port() {
        let mut reported = HashSet::new();
        assert!(first_refusal_of_guest_port(&mut reported, 8888));
        assert!(!first_refusal_of_guest_port(&mut reported, 8888));
        assert!(!first_refusal_of_guest_port(&mut reported, 8888));
        assert!(first_refusal_of_guest_port(&mut reported, 9000));
    }

    #[test]
    fn published_connection_refused_by_the_guest_is_noted_for_its_port() {
        use smoltcp::iface::{Config, Interface};
        use smoltcp::phy::{Loopback, Medium};
        use smoltcp::time::Instant;
        use smoltcp::wire::{EthernetAddress, HardwareAddress, IpAddress, IpCidr};

        let mut device = Loopback::new(Medium::Ethernet);
        let mut interface = Interface::new(
            Config::new(HardwareAddress::Ethernet(EthernetAddress([
                0x02, 0, 0, 0, 0, 1,
            ]))),
            &mut device,
            Instant::ZERO,
        );
        let gateway = Ipv4Addr::new(100, 96, 0, 1);
        interface.update_ip_addrs(|addresses| {
            addresses
                .push(IpCidr::new(IpAddress::from(gateway), 30))
                .unwrap();
        });

        // Host side of the published connection: any connected stream will do.
        let listener = std::net::TcpListener::bind((Ipv4Addr::LOCALHOST, 0)).unwrap();
        let host_client = TcpStream::connect(listener.local_addr().unwrap()).unwrap();
        let (_host_server, _) = listener.accept().unwrap();

        // Nothing listens on the "guest" port, so the SYN is answered with RST,
        // exactly as a guest kernel answers when the server is bound to
        // 127.0.0.1 only.
        let mut sockets = SocketSet::new(vec![]);
        let mut table = TcpRelayTable::new(None, EgressPolicy::unrestricted(), vec![], None);
        let guest = SocketAddr::new(IpAddr::V4(gateway), 8888);
        assert!(table.create_published_socket(
            &mut interface,
            gateway,
            guest,
            host_client,
            &mut sockets
        ));

        for now_ms in 1..=20 {
            interface.poll(Instant::from_millis(now_ms * 10), &mut device, &mut sockets);
            assert!(table.take_new_connections(&mut sockets).is_empty());
            table.cleanup_closed(&mut sockets);
            if table.active_connections() == 0 {
                break;
            }
        }
        assert_eq!(
            table.active_connections(),
            0,
            "refused connection was not reaped"
        );
        assert!(table.unaccepted_guest_ports.contains(&8888));
        assert!(table.used_published_ports.is_empty());
    }
}
