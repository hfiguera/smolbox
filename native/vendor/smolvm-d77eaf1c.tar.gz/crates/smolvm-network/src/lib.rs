//! Host-side virtio-net runtime.
//!
//! Context
//! =======
//!
//! This module is the host-side half of the new networking path:
//!
//! ```text
//! guest app
//!   -> guest kernel TCP/IP stack
//!   -> virtio-net device
//!   -> libkrun unix-stream bridge
//!   -> smolvm FrameStreamBridge
//!   -> shared frame queues
//!   -> smoltcp gateway/runtime
//!   -> host sockets / DNS forwarding / TCP relay
//!   -> external network
//! ```
//!
//! Main runtime components:
//!
//! ```text
//! VirtioNetworkRuntime
//! ├─ FrameStreamBridge
//! │  ├─ reader thread
//! │  └─ writer thread
//! ├─ TcpPortListeners
//! │  └─ one non-blocking accept loop per `-p HOST:GUEST`
//! ├─ Arc<NetworkFrameQueues>
//! │  ├─ guest_to_host
//! │  ├─ host_to_guest
//! │  ├─ guest_wake
//! │  ├─ host_wake
//! │  └─ relay_wake
//! └─ smolvm-net-poll thread
//!    ├─ VirtioNetworkDevice
//!    ├─ smoltcp Interface
//!    ├─ SocketSet
//!    └─ TcpRelayTable
//! ```
//!
//! Component roles:
//! - `FrameStreamBridge`: translates libkrun's Unix-stream frame protocol into
//!   queue operations
//! - `TcpPortListeners`: accepts host TCP connections for published ports
//!   and hands them to the poll loop
//! - `NetworkFrameQueues`: handoff boundary between threads
//! - `VirtioNetworkDevice`: adapts those queues to smoltcp's `phy::Device`
//! - poll thread: acts as the guest-visible gateway and protocol dispatcher
//! - `TcpRelayTable`: maps guest TCP flows onto host-side relay threads
//!
//! This runtime is responsible for:
//! - exchanging raw Ethernet frames with libkrun
//! - presenting a gateway endpoint to the guest
//! - handling DNS through a gateway UDP socket and host UDP forwarding
//! - relaying guest TCP connections to host `TcpStream`s
//! - accepting published host TCP ports and forwarding them into guest TCP
//!   connections

pub mod device;
pub mod dns;
pub mod dns_relay;
pub mod egress;
pub mod fabric;
// The libkrun frame bridge speaks over an AF_UNIX stream socket, available on
// both Unix and Windows (10 1809+), so the whole stack is cross-platform.
pub mod frame_stream;
pub mod icmp_relay;
pub mod opening;
// CNI netns ↔ virtio-net L2 bridge for the Kubernetes runtime (Linux only:
// needs /dev/net/tun + setns).
#[cfg(target_os = "linux")]
pub mod netns_tap;
pub mod queues;
pub mod stack;
pub mod tcp_listeners;
pub mod tcp_relay;
pub mod udp_publish;
pub mod udp_relay;
pub mod watchlist;

pub use egress::EgressPolicy;

use socket2::Socket;
use std::fmt;
use std::io;
use std::net::{IpAddr, Ipv4Addr, Ipv6Addr, SocketAddr, TcpStream, UdpSocket};
use std::sync::OnceLock;
use std::thread::JoinHandle;
use std::time::{Duration, SystemTime};

use frame_stream::{start_frame_stream_bridge, FrameStreamBridge};
use queues::NetworkFrameQueues;
use queues::DEFAULT_FRAME_QUEUE_CAPACITY;
use stack::{start_network_stack, VirtioPollConfig};
use tcp_listeners::create_tcp_channel;
pub use tcp_listeners::BoundPublishedPorts;
use tcp_listeners::TcpPortListeners;
pub use tcp_relay::FlowSummary;

/// Default upstream DNS resolver used by the gateway runtime.
pub const DEFAULT_DNS_ADDR: IpAddr = IpAddr::V4(Ipv4Addr::new(1, 1, 1, 1));

/// Transport a published port forwards.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Default)]
pub enum PortProtocol {
    /// A host TCP listener; each accepted connection becomes a guest connection.
    #[default]
    Tcp,
    /// A host UDP socket; each client address becomes a guest-facing session.
    Udp,
}

/// Host->guest published port mapping serviced by the virtio gateway.
///
/// This stays crate-local so the launchers can translate CLI/data-layer port
/// mappings into the gateway runtime without pulling the gateway logic back
/// into the main `smolvm` crate.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct PortMapping {
    /// Port bound on the host loopback interface.
    pub host: u16,
    /// Port exposed inside the guest.
    pub guest: u16,
    /// Transport forwarded between them.
    pub protocol: PortProtocol,
}

impl PortMapping {
    /// Create a new published TCP port mapping.
    pub const fn new(host: u16, guest: u16) -> Self {
        Self::with_protocol(host, guest, PortProtocol::Tcp)
    }

    /// Create a new published port mapping for `protocol`.
    pub const fn with_protocol(host: u16, guest: u16, protocol: PortProtocol) -> Self {
        Self {
            host,
            guest,
            protocol,
        }
    }
}

/// Static guest network configuration for the virtio-net MVP.
///
/// This struct describes the two endpoints of the single virtual Ethernet link:
/// - the guest NIC (`guest_*`)
/// - the host-side gateway implemented by smolvm (`gateway_*`)
///
/// The link is dual-stack: a /30 IPv4 point-to-point pair and a /64 ULA IPv6
/// pair (`fd53:4d00::/64` — `53:4d` = "SM", matching the MAC OUI scheme).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct GuestNetworkConfig {
    /// Guest IPv4 address.
    pub guest_ip: Ipv4Addr,
    /// Gateway IPv4 address.
    pub gateway_ip: Ipv4Addr,
    /// Prefix length.
    pub prefix_len: u8,
    /// Guest IPv6 (ULA) address.
    pub guest_ip6: Ipv6Addr,
    /// Gateway IPv6 (ULA) address.
    pub gateway_ip6: Ipv6Addr,
    /// IPv6 prefix length.
    pub prefix_len6: u8,
    /// Guest MAC address.
    pub guest_mac: [u8; 6],
    /// Gateway MAC address.
    pub gateway_mac: [u8; 6],
    /// DNS server address presented to the guest.
    ///
    /// For virtio-net this is the gateway's own address (`gateway_ip`): the
    /// guest sends DNS to the gateway, which forwards upstream to
    /// [`Self::upstream_dns`].
    pub dns_server: Ipv4Addr,
    /// Upstream resolver the gateway forwards guest DNS queries to.
    ///
    /// Defaults to [`DEFAULT_DNS_ADDR`]; the launcher overrides it when the
    /// caller passes `--dns <ip>` so a VM on a network that blocks the default
    /// resolver can still resolve names.
    pub upstream_dns: Ipv4Addr,
    /// Optional dedicated host service reachable only through the gateway IP.
    pub host_service: Option<GatewayHostService>,
    /// Host interceptor and the outbound streams routed through it. Each stream
    /// carries an authenticated preamble naming its original destination.
    pub intercept: Option<StreamInterception>,
}

/// Exact guest gateway port mapped to one smolvm-owned host loopback port.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct GatewayHostService {
    /// Port the guest addresses on its gateway IP.
    pub guest_port: u16,
    /// Loopback port the host listener actually owns.
    pub host_port: u16,
}

impl GuestNetworkConfig {
    /// Default Phase 1 guest network configuration.
    pub const fn default() -> Self {
        Self {
            guest_ip: Ipv4Addr::new(100, 96, 0, 2),
            gateway_ip: Ipv4Addr::new(100, 96, 0, 1),
            prefix_len: 30,
            guest_ip6: Ipv6Addr::new(0xfd53, 0x4d00, 0, 0, 0, 0, 0, 2),
            gateway_ip6: Ipv6Addr::new(0xfd53, 0x4d00, 0, 0, 0, 0, 0, 1),
            prefix_len6: 64,
            guest_mac: [0x02, 0x53, 0x4d, 0x00, 0x00, 0x02],
            gateway_mac: [0x02, 0x53, 0x4d, 0x00, 0x00, 0x01],
            dns_server: Ipv4Addr::new(100, 96, 0, 1),
            upstream_dns: match DEFAULT_DNS_ADDR {
                IpAddr::V4(ip) => ip,
                IpAddr::V6(_) => Ipv4Addr::new(1, 1, 1, 1),
            },
            host_service: None,
            intercept: None,
        }
    }
}

/// The IPv4 subnet a machine's link is drawn from, when it is not the default
/// `100.96.0.0/30`.
///
/// The default sits in the RFC 6598 shared address space (`100.64.0.0/10`),
/// which Tailscale and carrier NAT also claim; a guest running either routes its
/// own gateway away and loses the resolver on it. The gateway takes the first
/// host address and the guest the second, and the guest's resolver stays on the
/// gateway, so everything that addressed `100.96.0.1` moves with the subnet.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct GuestSubnet {
    network: Ipv4Addr,
    prefix_len: u8,
}

impl GuestSubnet {
    /// Gateway (host side) address: the subnet's first host address.
    pub fn gateway(&self) -> Ipv4Addr {
        Ipv4Addr::from(u32::from(self.network) + 1)
    }

    /// Guest address: the subnet's second host address.
    pub fn guest(&self) -> Ipv4Addr {
        Ipv4Addr::from(u32::from(self.network) + 2)
    }

    /// Prefix length the guest configures on its interface.
    pub fn prefix_len(&self) -> u8 {
        self.prefix_len
    }
}

impl std::str::FromStr for GuestSubnet {
    type Err = String;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let (addr, prefix) = s
            .trim()
            .split_once('/')
            .ok_or_else(|| format!("guest subnet '{s}' must be an IPv4 CIDR like 10.200.0.0/30"))?;
        let addr: Ipv4Addr = addr
            .parse()
            .map_err(|_| format!("guest subnet '{s}': '{addr}' is not an IPv4 address"))?;
        let prefix_len: u8 = prefix
            .parse()
            .map_err(|_| format!("guest subnet '{s}': '{prefix}' is not a prefix length"))?;
        // /30 is the smallest subnet with room for a gateway and a guest;
        // shorter than /8 would swallow whole address classes.
        if !(8..=30).contains(&prefix_len) {
            return Err(format!(
                "guest subnet '{s}': prefix must be between /8 and /30"
            ));
        }
        let mask = u32::MAX << (32 - prefix_len);
        let network = Ipv4Addr::from(u32::from(addr) & mask);
        if network != addr {
            return Err(format!(
                "guest subnet '{s}' has host bits set; did you mean {network}/{prefix_len}?"
            ));
        }
        let first = network.octets()[0];
        if network.is_loopback()
            || network.is_link_local()
            || network.is_multicast()
            || first == 0
            || first >= 240
        {
            return Err(format!(
                "guest subnet '{s}' is in a reserved range (0/8, loopback, link-local, multicast or 240/4)"
            ));
        }
        Ok(Self {
            network,
            prefix_len,
        })
    }
}

impl fmt::Display for GuestSubnet {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}/{}", self.network, self.prefix_len)
    }
}

impl GuestNetworkConfig {
    /// Move the guest link onto `subnet`: guest, gateway and the guest's
    /// resolver (which is the gateway) all follow it.
    pub fn with_guest_subnet(mut self, subnet: GuestSubnet) -> Self {
        self.guest_ip = subnet.guest();
        self.gateway_ip = subnet.gateway();
        self.prefix_len = subnet.prefix_len();
        self.dns_server = subnet.gateway();
        self
    }
}

pub use smolvm_protocol::InterceptEndpoint;

/// Which admitted guest streams must pass through the host interceptor.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum StreamInterception {
    /// Intercept HTTPS on port 443, preserving direct access to gateway services.
    Https(InterceptEndpoint),
    /// Route every outbound TCP flow; DNS remains host-managed and other
    /// outbound datagrams are denied.
    AllTcp(InterceptEndpoint),
    /// Decide every admitted TCP flow through the versioned host-only protocol.
    Mediated(MediatedBinding),
}

/// Launch-scoped identity for the mediated egress decider. Never given to the guest.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct MediatedBinding {
    pub endpoint: InterceptEndpoint,
    pub machine_id: [u8; 16],
    pub parent_id: [u8; 16],
}

impl StreamInterception {
    pub(crate) fn all_tcp(&self) -> bool {
        matches!(self, Self::AllTcp(_) | Self::Mediated(_))
    }
}

/// Filename of the per-VM egress denial audit log, created beside the vsock
/// socket by the launcher and read back by the host's `read_egress_denials`.
pub const EGRESS_DENIALS_LOG: &str = "egress-denials.log";
/// Structured decisions for a VM running the mediated egress protocol.
pub const EGRESS_DECISIONS_LOG: &str = "egress-decisions.jsonl";

/// Filename of the per-VM egress control socket, served by the network runtime
/// of a machine started with an allow list. The host sends it a replacement
/// allow list (see [`egress::render_live_policy`]) and reads back `ok` or
/// `error: <reason>`. A guest cannot reach a host socket through a shared
/// folder, so only the host can change a running machine's allow list.
pub const EGRESS_SOCKET: &str = "egress.sock";

pub const PORTS_SOCKET: &str = "ports.sock";

pub fn render_port_mappings(mappings: &[PortMapping]) -> String {
    mappings
        .iter()
        .map(|mapping| format!("{}:{}\n", mapping.host, mapping.guest))
        .collect()
}

pub fn parse_port_mappings(text: &str) -> Result<Vec<PortMapping>, String> {
    text.lines()
        .map(str::trim)
        .filter(|line| !line.is_empty())
        .map(|line| {
            line.split_once(':')
                .and_then(|(host, guest)| {
                    Some(PortMapping::new(host.parse().ok()?, guest.parse().ok()?))
                })
                .filter(|mapping| mapping.host != 0 && mapping.guest != 0)
                .ok_or_else(|| format!("invalid port mapping '{line}'"))
        })
        .collect()
}

/// Filename of the per-VM egress signal log: watchlist matches and stratum
/// handshakes, recorded beside the denial log by the launcher and read back by
/// the host's `read_egress_signals`. Created on the first signal only.
pub const EGRESS_SIGNALS_LOG: &str = "egress-signals.log";

/// Label of the signal a guest's stratum handshake records: a miner logging in
/// to its pool. Built in, so it is recorded whether or not an operator watchlist
/// is attached, and reported beside watchlist matches.
pub const STRATUM_SIGNAL: &str = "stratum";

/// Whether the host can actually reach the IPv6 internet.
///
/// Advertising the guest a global-scope IPv6 address (the ULA link pair) makes
/// every dual-stack client sort AAAA answers first (RFC 6724) — but the
/// gateway can only relay v6 flows the host itself can dial. On a host with no
/// working v6 every such connection dies, so callers use this probe to withhold
/// the guest's IPv6 configuration entirely and keep such guests v4-first.
///
/// This must reflect END-TO-END reachability, not a configured route: a
/// connected `UdpSocket` performs only a local route lookup (no packets), so it
/// returns `true` whenever any v6 default route exists — including a stale or
/// ULA-only one with no path to the internet (common on Windows and some Linux
/// setups). That false positive is exactly what made dual-stack guests prefer
/// AAAA and then hang. So the route lookup is used only as a cheap, zero-latency
/// NECESSARY condition; when it passes, a real TCP handshake — the same
/// operation the relay performs per flow — confirms the path actually works.
///
/// The result is cached for the process: within one smolvm run the host's v6
/// capability is effectively stable, and a stale cache is harmless because the
/// guest is also configured v4-first (see the agent's gai.conf handling), so a
/// wrongly-advertised v6 never causes a hard hang.
pub fn host_has_ipv6_route() -> bool {
    static CACHED: OnceLock<bool> = OnceLock::new();
    *CACHED.get_or_init(probe_ipv6_reachable)
}

fn probe_ipv6_reachable() -> bool {
    // Cheap necessary condition: no v6 default route at all → no v6, no latency.
    let has_route = UdpSocket::bind("[::]:0")
        .and_then(|s| s.connect("[2606:4700:4700::1111]:53"))
        .is_ok();
    if !has_route {
        return false;
    }
    // A route exists but may be non-functional. Confirm with a real TCP
    // handshake to well-known v6 anycast endpoints, raced with a short timeout.
    // A false negative (v6 works but these targets are filtered) is safe — the
    // guest stays v4-only; a false positive would reintroduce the hang.
    const TARGETS: [&str; 2] = [
        "[2606:4700:4700::1111]:443", // Cloudflare
        "[2001:4860:4860::8888]:443", // Google
    ];
    const TIMEOUT: Duration = Duration::from_millis(1000);
    let (tx, rx) = std::sync::mpsc::channel();
    for target in TARGETS {
        if let Ok(addr) = target.parse::<SocketAddr>() {
            let tx = tx.clone();
            std::thread::spawn(move || {
                let _ = tx.send(TcpStream::connect_timeout(&addr, TIMEOUT).is_ok());
            });
        }
    }
    drop(tx);
    // First success wins; otherwise drain until every probe reported (senders
    // dropped), capped by the connect timeout since the probes run in parallel.
    while let Ok(ok) = rx.recv() {
        if ok {
            return true;
        }
    }
    false
}

pub(crate) fn format_network_log_line(timestamp: SystemTime, message: &str) -> String {
    format!(
        "[{}]: {}",
        humantime::format_rfc3339_seconds(timestamp),
        message
    )
}

pub(crate) fn emit_network_log_line(message: fmt::Arguments<'_>) {
    eprintln!(
        "{}",
        format_network_log_line(SystemTime::now(), &message.to_string())
    );
}

macro_rules! virtio_net_log {
    ($($arg:tt)*) => {
        $crate::emit_network_log_line(format_args!($($arg)*))
    };
}

pub(crate) use virtio_net_log;

/// Running host-side virtio-net runtime for one guest NIC.
///
/// Ownership model:
/// - one runtime instance corresponds to one guest virtio NIC
/// - it owns the queue set shared by the worker threads
/// - it owns the libkrun Unix-stream bridge threads
/// - it owns the published-port listener threads
/// - it owns the smoltcp poll thread
///
/// Dropping the runtime is the shutdown signal. `Drop` marks the shared queues
/// as shutting down, wakes blocked workers, and joins the poll thread.
pub struct VirtioNetworkRuntime {
    queues: std::sync::Arc<NetworkFrameQueues>,
    _frame_bridge: FrameStreamBridge,
    published_ports: PublishedPorts,
    _published_udp: Option<udp_publish::UdpPortPublisher>,
    poll_handle: Option<JoinHandle<()>>,
}

#[derive(Clone)]
pub struct PublishedPorts {
    tcp: std::sync::Arc<std::sync::Mutex<TcpPortListeners>>,
    /// UDP mappings, bound once at start: changing them needs a restart.
    udp: std::sync::Arc<Vec<PortMapping>>,
}

impl PublishedPorts {
    fn lock(&self) -> std::sync::MutexGuard<'_, TcpPortListeners> {
        self.tcp
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner())
    }

    /// The published TCP mappings, the ones a running machine can change.
    /// UDP mappings are bound once at start and are not listed here.
    pub fn mappings(&self) -> Vec<PortMapping> {
        self.lock().mappings()
    }

    /// The UDP mappings bound at start, which stay until the machine stops.
    pub fn udp_mappings(&self) -> Vec<PortMapping> {
        self.udp.to_vec()
    }

    /// Make `next` the published TCP set. A UDP mapping is refused: a UDP port
    /// is bound for the runtime's life, so changing one needs a restart.
    pub fn replace(&self, next: &[PortMapping]) -> io::Result<()> {
        if next
            .iter()
            .any(|mapping| mapping.protocol == PortProtocol::Udp)
        {
            return Err(io::Error::new(
                io::ErrorKind::Unsupported,
                "published UDP ports cannot change on a running machine; stop it first",
            ));
        }
        self.lock().replace(next)
    }
}

/// Start the host-side virtio-net runtime for one guest NIC.
///
/// Inputs:
/// - `host_fd`: the host-side Unix stream fd that libkrun will use for this
///   guest NIC. The launcher eventually gets this from the libkrun
///   `krun_add_net_unixstream()` setup path.
/// - `guest_network`: the static guest/gateway addressing and MAC plan for this
///   NIC.
/// - `published_ports`: host->guest TCP port mappings, bound by the caller with
///   [`BoundPublishedPorts::bind`], that the virtio runtime services instead of TSI.
///
/// High-level flow:
///
/// ```text
/// start_virtio_network()
///   -> create shared frame queues + wake pipes
///   -> start frame reader/writer threads on the Unix stream
///   -> start host TcpListeners for published ports
///   -> start the smoltcp poll thread
///   -> return a handle that owns the whole runtime
/// ```
///
/// Expanded startup picture:
///
/// ```text
/// host_fd from libkrun
///   -> FrameStreamBridge(host_fd)
///      -> reader thread
///      -> writer thread
///   -> TcpPortListeners
///      -> accept host TcpStreams
///      -> send them to the poll loop over a bounded channel
///   -> NetworkFrameQueues
///   -> start_network_stack(...)
///      -> poll thread owns smoltcp Interface + sockets
///   -> VirtioNetworkRuntime returned to launcher
/// ```
///
/// Outcome:
/// - guest->host Ethernet frames start flowing into the queues
/// - host->guest Ethernet frames emitted by smoltcp are written back to libkrun
/// - published host TCP connections can be forwarded toward guest listeners
/// - the poll loop starts acting as the guest-visible gateway
///
/// Cross-platform: the libkrun frame bridge speaks over an AF_UNIX stream
/// socket, available on Unix and Windows (10 1809+). The caller supplies the
/// already-connected host-side socket (Unix: one end of a `socketpair`;
/// Windows: the socket `accept`ed from libkrun on the per-VM path).
pub fn start_virtio_network(
    host_stream: Socket,
    guest_network: GuestNetworkConfig,
    mut published_ports: BoundPublishedPorts,
    egress: EgressPolicy,
    fabric_lease: Option<fabric::FabricLease>,
) -> io::Result<VirtioNetworkRuntime> {
    if guest_network.intercept.is_some_and(|mode| mode.all_tcp()) && fabric_lease.is_some() {
        return Err(io::Error::new(
            io::ErrorKind::InvalidInput,
            "external interception cannot use a named network",
        ));
    }
    virtio_net_log!(
        "virtio-net: starting runtime guest_ip={} gateway_ip={} dns_server={}",
        guest_network.guest_ip,
        guest_network.gateway_ip,
        guest_network.dns_server
    );
    let queues = NetworkFrameQueues::shared(DEFAULT_FRAME_QUEUE_CAPACITY);
    let fabric = match fabric_lease {
        Some(lease) => Some(fabric::start_fabric(
            lease,
            queues.clone(),
            guest_network.gateway_mac,
            guest_network.guest_mac,
        )?),
        None => None,
    };
    let frame_bridge = start_frame_stream_bridge(host_stream, queues.clone())?;
    // tcp_sender sends the accepted TCP connections to the channel
    // tcp_receiver receives the accepted TCP connections via the channel, and let it be consumed in poll thread.
    let (tcp_sender, tcp_receiver) = create_tcp_channel();
    // UDP mappings are fixed for the runtime's life; only TCP ones are live.
    let udp_mappings: Vec<PortMapping> = published_ports
        .udp
        .iter()
        .map(|(mapping, _, _)| *mapping)
        .collect();
    let (udp_publisher, udp_publish) =
        match udp_publish::start_udp_publisher(&mut published_ports, queues.relay_wake.clone())? {
            Some((publisher, channels)) => (Some(publisher), Some(channels)),
            None => (None, None),
        };
    // Always started, even with no TCP port yet, so ports can be published
    // on the running machine later.
    let tcp_listeners =
        TcpPortListeners::start(published_ports, tcp_sender, queues.relay_wake.clone())?;
    let poll_handle = start_network_stack(
        queues.clone(),
        VirtioPollConfig {
            gateway_mac: guest_network.gateway_mac,
            guest_mac: guest_network.guest_mac,
            gateway_ipv4: guest_network.gateway_ip,
            guest_ipv4: guest_network.guest_ip,
            gateway_ipv6: guest_network.gateway_ip6,
            guest_ipv6: guest_network.guest_ip6,
            prefix_len6: guest_network.prefix_len6,
            upstream_dns: guest_network.upstream_dns,
            host_service: guest_network.host_service,
            intercept: guest_network.intercept,
            mtu: 1500,
        },
        Some(tcp_receiver),
        udp_publish,
        egress,
        fabric,
    )?;

    Ok(VirtioNetworkRuntime {
        queues,
        _frame_bridge: frame_bridge,
        published_ports: PublishedPorts {
            tcp: std::sync::Arc::new(std::sync::Mutex::new(tcp_listeners)),
            udp: std::sync::Arc::new(udp_mappings),
        },
        _published_udp: udp_publisher,
        poll_handle: Some(poll_handle),
    })
}

impl VirtioNetworkRuntime {
    /// Cumulative guest-outbound (egress) bytes on this NIC since boot, at the
    /// ethernet-frame level. The launcher polls this to surface per-machine
    /// egress to the node API for billing. TSI VMs have no virtio runtime, so
    /// egress is unavailable for them (a documented metering gap).
    pub fn egress_bytes(&self) -> u64 {
        self.queues.egress_bytes()
    }

    /// A cheap, cloneable read handle to this NIC's egress counter, so the
    /// launcher can spawn a thread that periodically flushes the value to the
    /// VM's runtime dir for the node API to read (the runtime is not `Clone`).
    pub fn egress_counter(&self) -> std::sync::Arc<std::sync::atomic::AtomicU64> {
        self.queues.egress_counter()
    }

    /// A cheap, cloneable read handle to this NIC's open-flow summary, which
    /// the poll loop refreshes every few seconds, so the launcher can flush it
    /// to the VM's runtime dir for the node API to read.
    pub fn flow_summary_slot(&self) -> queues::FlowSummarySlot {
        self.queues.flow_summary_slot()
    }

    pub fn published_ports(&self) -> PublishedPorts {
        self.published_ports.clone()
    }

    /// Take ownership of the runtime and block until the libkrun stream closes
    /// (the frame reader marks the queues shutting down on EOF), then drop it for
    /// a graceful shutdown. Used on Windows, where the runtime is built on the
    /// `accept` thread: that thread parks here so the runtime — and its worker
    /// threads — live for the whole VM lifetime instead of being dropped at the
    /// end of the `accept` callback.
    pub fn block_until_shutdown(self) {
        while !self.queues.is_shutting_down() {
            std::thread::sleep(std::time::Duration::from_millis(200));
        }
        // `self` drops here, joining the worker threads.
    }
}

impl Drop for VirtioNetworkRuntime {
    /// Shut down the worker threads in a bounded, cooperative way.
    ///
    /// The queue shutdown flag wakes the frame bridge and smoltcp poll loop so
    /// they can exit on their own. We only explicitly join the poll thread
    /// here because the frame bridge joins its own threads in its own `Drop`.
    fn drop(&mut self) {
        self.queues.begin_shutdown();
        self.published_ports.lock().close();
        if let Some(handle) = self.poll_handle.take() {
            let _ = handle.join();
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::time::UNIX_EPOCH;

    #[test]
    fn port_mappings_round_trip_through_the_control_format() {
        let mappings = vec![PortMapping::new(3000, 3000), PortMapping::new(8080, 80)];
        let rendered = render_port_mappings(&mappings);
        assert_eq!(rendered, "3000:3000\n8080:80\n");
        assert_eq!(parse_port_mappings(&rendered).unwrap(), mappings);
        assert!(parse_port_mappings("").unwrap().is_empty());
        for bad in ["3000", "a:1", "0:80", "80:0", "70000:80"] {
            assert!(parse_port_mappings(bad).is_err(), "{bad}");
        }
    }

    #[test]
    fn formats_timestamped_network_log_prefix() {
        let line = format_network_log_line(UNIX_EPOCH, "virtio-net: smoke test");
        assert_eq!(line, "[1970-01-01T00:00:00Z]: virtio-net: smoke test");
    }

    #[test]
    fn host_has_ipv6_route_is_consistent_and_cached() {
        let first = host_has_ipv6_route();
        let second = host_has_ipv6_route();
        assert_eq!(first, second);
    }

    #[test]
    fn guest_subnet_derives_gateway_guest_and_resolver() {
        let subnet: GuestSubnet = "10.200.0.0/30".parse().unwrap();
        assert_eq!(subnet.gateway(), Ipv4Addr::new(10, 200, 0, 1));
        assert_eq!(subnet.guest(), Ipv4Addr::new(10, 200, 0, 2));
        assert_eq!(subnet.to_string(), "10.200.0.0/30");

        let config =
            GuestNetworkConfig::default().with_guest_subnet("172.31.8.0/24".parse().unwrap());
        assert_eq!(config.gateway_ip, Ipv4Addr::new(172, 31, 8, 1));
        assert_eq!(config.guest_ip, Ipv4Addr::new(172, 31, 8, 2));
        assert_eq!(config.dns_server, config.gateway_ip);
        assert_eq!(config.prefix_len, 24);
    }

    #[test]
    fn guest_subnet_rejects_bad_input() {
        for bad in [
            "10.200.0.0",     // no prefix
            "10.200.0.1/30",  // host bits set
            "10.200.0.0/31",  // no room for gateway + guest
            "10.0.0.0/7",     // too wide
            "127.0.0.0/8",    // loopback
            "169.254.0.0/30", // link-local (cloud metadata)
            "224.0.0.0/30",   // multicast
            "0.0.0.0/30",
            "fd00::/64",
        ] {
            assert!(
                bad.parse::<GuestSubnet>().is_err(),
                "{bad} should be rejected"
            );
        }
    }
}
