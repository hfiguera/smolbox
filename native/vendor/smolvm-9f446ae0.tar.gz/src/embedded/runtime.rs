//! Process-local runtime registry for embedded machines.

use std::collections::HashMap;
use std::sync::{Arc, Mutex, MutexGuard, OnceLock, RwLock};
use std::time::Duration;

use crate::agent::{AgentClient, ExecEvent, RunConfig};
use crate::config::RecordState;
use crate::db::SmolvmDb;
use crate::embedded::control::{self, MachineSpec};
use crate::embedded::exec::{ExecCancel, ExecOptions};
use crate::embedded::handle::VmHandle;
use crate::{Error, Result};
use smolvm_protocol::ImageInfo;

type SharedHandle = Arc<Mutex<VmHandle>>;

/// Absolute resource targets for a running machine, never increments.
/// CPU, RAM and disk growth currently require separate requests; both disks
/// may grow in one request. Shrinking is rejected by the runtime.
#[derive(Clone, Debug, Default)]
pub struct ResizeSpec {
    /// Total online virtual CPUs requested.
    pub cpus: Option<u8>,
    /// Total guest RAM requested, in MiB.
    pub memory_mib: Option<u32>,
    /// Total managed storage disk capacity requested, in GiB.
    pub storage_gib: Option<u64>,
    /// Total writable root overlay capacity requested, in GiB.
    pub overlay_gib: Option<u64>,
}

impl ResizeSpec {
    fn validate(&self) -> Result<()> {
        let kinds = usize::from(self.cpus.is_some())
            + usize::from(self.memory_mib.is_some())
            + usize::from(self.storage_gib.is_some() || self.overlay_gib.is_some());
        if kinds != 1 {
            return Err(Error::config(
                "live resize",
                "specify exactly one resource kind: CPUs, RAM, or disks",
            ));
        }
        if self.cpus == Some(0)
            || self.memory_mib == Some(0)
            || self.storage_gib == Some(0)
            || self.overlay_gib == Some(0)
        {
            return Err(Error::config(
                "live resize",
                "resource targets must be positive",
            ));
        }
        Ok(())
    }
}

/// Stateful runtime shared by all embedded machine objects in this process.
pub struct EmbeddedRuntime {
    db: SmolvmDb,
    registry: RwLock<HashMap<String, SharedHandle>>,
    name_locks: RwLock<HashMap<String, Arc<Mutex<()>>>>,
}

impl EmbeddedRuntime {
    /// Create a runtime backed by the default smolvm database.
    pub fn new() -> Result<Self> {
        Ok(Self::with_db(SmolvmDb::open()?))
    }

    /// Create a runtime backed by an explicit database handle.
    pub fn with_db(db: SmolvmDb) -> Self {
        Self {
            db,
            registry: RwLock::new(HashMap::new()),
            name_locks: RwLock::new(HashMap::new()),
        }
    }

    /// Create a persisted machine record.
    pub fn create_machine(&self, spec: MachineSpec) -> Result<()> {
        self.with_name_lock(&spec.name, || control::create_vm(&self.db, &spec))
    }

    /// Grow a running machine without restarting it, returning verified state.
    ///
    /// Uses the same durable intent, admission checks and cross-process source
    /// lock as the CLI/API. After an interrupted call, retry the same absolute
    /// targets; a different pending target is refused rather than overwritten.
    /// This does not start a stopped machine implicitly.
    pub fn resize_machine(&self, name: &str, spec: ResizeSpec) -> Result<crate::config::VmRecord> {
        spec.validate()?;
        self.with_name_lock(name, || {
            if let Some(cpus) = spec.cpus {
                crate::agent::live_resize::grow_cpus(&self.db, name, cpus)
            } else if let Some(memory) = spec.memory_mib {
                crate::agent::live_resize::grow_memory(&self.db, name, memory)
            } else {
                crate::agent::live_resize::grow_disks(
                    &self.db,
                    name,
                    spec.storage_gib,
                    spec.overlay_gib,
                )
            }
        })
    }

    /// Create a persisted image machine with its launch-time environment,
    /// working directory and user.
    pub fn create_machine_with_workload(
        &self,
        spec: MachineSpec,
        env: Vec<(String, String)>,
        workdir: Option<String>,
        user: Option<String>,
    ) -> Result<()> {
        self.with_name_lock(&spec.name, || {
            control::create_vm_with_workload(&self.db, &spec, env, workdir, user)
        })
    }

    /// Replace a stopped machine's outbound network policy, for example to
    /// give a machine restored from a shared checkpoint its own allow list
    /// before it first boots. See [`crate::config::VmRecord::apply_egress_policy`].
    pub fn set_egress_policy(
        &self,
        name: &str,
        policy: &crate::data::network::EgressPolicy,
    ) -> Result<()> {
        self.with_name_lock(name, || control::set_egress_policy(&self.db, name, policy))
    }

    /// Capture a running checkpointable machine into a portable artifact.
    ///
    /// The source resumes as soon as its consistent RAM/disk boundary is
    /// staged; compression continues without holding the source pause.
    pub fn checkpoint_machine(
        &self,
        name: &str,
        output: &std::path::Path,
        options: &crate::portable_checkpoint::CaptureOptions,
    ) -> Result<crate::portable_checkpoint::CaptureResult> {
        self.with_name_lock(name, || {
            crate::portable_checkpoint::capture_to_path(name, output, options)
        })
    }

    /// Save execution durably and stop at that exact boundary.
    pub fn pause_machine(&self, name: &str) -> Result<()> {
        self.pause_machine_inner(name, None)
    }

    /// Retry a durable pause without ever pausing a later resumed execution.
    pub fn pause_machine_with_operation(&self, name: &str, operation: &str) -> Result<()> {
        if operation.is_empty()
            || operation.len() > 128
            || !operation
                .bytes()
                .all(|b| b.is_ascii_alphanumeric() || b == b'-' || b == b'_')
        {
            return Err(Error::agent_conflict(
                "pause machine",
                "invalid pause operation identifier",
            ));
        }
        self.pause_machine_inner(name, Some(operation))
    }

    fn pause_machine_inner(&self, name: &str, operation: Option<&str>) -> Result<()> {
        self.with_name_lock(name, || {
            let _operation_lock = crate::agent::fork::lock_saved_execution(name)?;
            let mut record = control::get_record(&self.db, name)?;
            if let Some(operation) = operation {
                self.db.claim_pause_operation(
                    name,
                    operation,
                    record.paused_checkpoint.is_none(),
                )?;
                // The previous capture process may have died while holding the
                // source frozen. No other capture can own it once this lock is held.
                if record.state == RecordState::Pausing && record.is_process_alive() {
                    let _source = crate::agent::fork::lock_fork_source(name)?;
                    let socket = crate::agent::fork::control_socket_path(name);
                    let status = crate::agent::fork::control_socket_cmd(&socket, "STATUS")?;
                    if status.trim() == "OK paused" {
                        let reply = crate::agent::fork::control_socket_cmd(&socket, "RESUME")?;
                        if !reply.starts_with("OK") {
                            return Err(Error::agent("recover interrupted pause", reply));
                        }
                    } else if status.trim() != "OK running" {
                        return Err(Error::agent("recover interrupted pause", status));
                    }
                    record = self
                        .db
                        .update_vm_durable(name, |r| {
                            r.paused_checkpoint = None;
                            r.state = RecordState::Running;
                        })?
                        .ok_or_else(|| Error::vm_not_found(name))?;
                }
                if record.state == RecordState::Paused && record.is_process_alive() {
                    let _source = crate::agent::fork::lock_fork_source(name)?;
                    let path = record.paused_checkpoint.as_ref().ok_or_else(|| {
                        Error::agent("pause machine", "saved execution is missing")
                    })?;
                    crate::portable_checkpoint::verified_sidecar_footer(path)?;
                    let status = crate::agent::fork::control_socket_cmd(
                        &crate::agent::fork::control_socket_path(name),
                        "STATUS",
                    )?;
                    if status.trim() != "OK paused" {
                        return Err(Error::agent_conflict(
                            "pause machine",
                            "source is still running; refusing to stop newer execution",
                        ));
                    }
                    crate::agent::AgentManager::for_vm_with_sizes(
                        name,
                        record.storage_gb,
                        record.overlay_gb,
                    )?
                    .stop_paused()?;
                    self.remove_cached_handle(name)?;
                }
            }
            if record.state == RecordState::Paused && !record.is_process_alive() {
                let path = record.paused_checkpoint.as_ref().ok_or_else(|| {
                    Error::agent("pause machine", "paused machine has no checkpoint")
                })?;
                crate::portable_checkpoint::verified_sidecar_footer(path)?;
                return Ok(());
            }
            if record.paused_checkpoint.is_some() {
                return Err(Error::agent_conflict(
                    "pause machine",
                    "a previous pause needs recovery; use resume",
                ));
            }
            let output = crate::agent::vm_data_dir(name).join(format!(
                "pause-{}.smolcheckpoint",
                crate::db::SmolvmDb::create_reservation_token()
            ));
            let result = crate::portable_checkpoint::capture_and_stop_to_path(
                name,
                &output,
                &Default::default(),
                |stage| {
                    self.db
                        .update_vm_durable(name, |record| {
                            record.paused_checkpoint = Some(output.clone());
                            record.state = match stage {
                                crate::portable_checkpoint::PauseCaptureStage::Capturing => {
                                    RecordState::Pausing
                                }
                                crate::portable_checkpoint::PauseCaptureStage::Durable => {
                                    RecordState::Paused
                                }
                            };
                        })?
                        .ok_or_else(|| Error::vm_not_found(name))?;
                    Ok(())
                },
            );
            if let Err(error) = result {
                // Capture's guard has resumed the original on failure. Never
                // erase the durable recovery point if the process is gone.
                let running = record.is_process_alive()
                    && crate::agent::fork::control_socket_cmd(
                        &crate::agent::fork::control_socket_path(name),
                        "STATUS",
                    )
                    .is_ok_and(|status| status.trim() == "OK running");
                if running {
                    self.db.update_vm_durable(name, |record| {
                        if record.paused_checkpoint.as_ref() == Some(&output) {
                            record.paused_checkpoint = None;
                            record.state = RecordState::Running;
                        }
                    })?;
                    if output.exists() {
                        if let Err(cleanup) = std::fs::remove_file(&output) {
                            tracing::warn!(%cleanup, "could not remove failed pause artifact");
                        }
                    }
                }
                return Err(error);
            }
            self.remove_cached_handle(name)?;
            self.db.update_vm(name, |record| {
                record.state = RecordState::Paused;
                record.pid = None;
                record.pid_start_time = None;
            })?;
            Ok(())
        })
    }

    /// Restore the saved execution under the original machine name.
    pub fn resume_machine(&self, name: &str) -> Result<()> {
        self.resume_machine_inner(name, false, None)
    }

    /// Resume execution without tying its lifetime to this runtime handle.
    pub fn resume_machine_detached(&self, name: &str) -> Result<()> {
        self.resume_machine_inner(name, true, None)
    }

    /// Resume only the pause identified by this retry key.
    pub fn resume_machine_detached_with_operation(
        &self,
        name: &str,
        operation: &str,
    ) -> Result<()> {
        self.resume_machine_inner(name, true, Some(operation))
    }

    fn resume_machine_inner(
        &self,
        name: &str,
        detached: bool,
        operation: Option<&str>,
    ) -> Result<()> {
        self.with_name_lock(name, || {
            let _operation_lock = crate::agent::fork::lock_saved_execution(name)?;
            let _source = crate::agent::fork::lock_fork_source(name)?;
            let record = control::get_record(&self.db, name)?;
            if let Some(operation) = operation {
                if !self.db.pause_operation_is_active(name, operation)? {
                    if self.db.pause_operation_was_consumed(name, operation)? && record.paused_checkpoint.is_none() && record.is_process_alive() {
                        return Ok(());
                    }
                    return Err(Error::agent_conflict("resume machine", "this is not the machine's active pause operation"));
                }
            }
            if record.paused_checkpoint.is_none() {
                if record.state == RecordState::Running && record.is_process_alive() {
                    self.db.finish_saved_execution(name, |_| {})?;
                    return Ok(());
                }
                return Err(Error::agent_conflict("resume machine", "machine is not paused; use start for a fresh boot"));
            }
            if record.is_process_alive() {
                let control_socket = crate::agent::fork::control_socket_path(name);
                let status = crate::agent::fork::control_socket_cmd(&control_socket, "STATUS")?;
                if record.state == RecordState::Pausing {
                    // The capture owner exited before committing durability.
                    // Recover the original rather than replaying an uncertain artifact.
                    if status.trim() == "OK paused" {
                        let reply = crate::agent::fork::control_socket_cmd(&control_socket, "RESUME")?;
                        if !reply.starts_with("OK") { return Err(Error::agent("resume interrupted pause", reply)); }
                    } else if status.trim() != "OK running" {
                        return Err(Error::agent("resume interrupted pause", status));
                    }
                    self.db.finish_saved_execution(name, |record| {
                        record.paused_checkpoint = None;
                        record.state = RecordState::Running;
                    })?;
                    return Ok(());
                }
                if status.trim() != "OK paused" {
                    return Err(Error::agent_conflict("resume machine", "source is still running; refusing to replace its execution"));
                }
                crate::agent::AgentManager::for_vm_with_sizes(name, record.storage_gb, record.overlay_gb)?.stop_paused()?;
            }
            self.remove_cached_handle(name)?;
            crate::portable_checkpoint::prepare_paused_restore(&record)?;
            let started = control::resume_vm(&self.db, name, detached)?;
            if detached {
                started.handle.detach();
            } else {
                self.insert_handle(name, started.handle)?;
            }
            // A successfully resumed VM owns its installed RAM/disk backing;
            // the transport artifact is no longer its recovery authority.
            if let Some(path) = record.paused_checkpoint {
                if let Err(error) = std::fs::remove_file(&path) {
                    tracing::warn!(%error, path = %path.display(), "could not remove consumed pause artifact");
                }
            }
            Ok(())
        })
    }

    /// Create a stopped machine from a portable live checkpoint artifact.
    ///
    /// Its first start resumes the captured execution state. The restored
    /// machine is also a fork/checkpoint source, which makes it suitable as a
    /// durable rollback root.
    pub fn restore_checkpoint_machine(&self, name: &str, artifact: &std::path::Path) -> Result<()> {
        self.with_name_lock(name, || {
            crate::portable_checkpoint::restore_from_path(&self.db, name, artifact)
        })
    }

    /// Restore and start a checkpoint for a detached CLI operation.
    ///
    /// The VMM outlives the caller, unlike the process-owned SDK handle.
    pub fn restore_checkpoint_machine_detached(
        &self,
        name: &str,
        artifact: &std::path::Path,
    ) -> Result<()> {
        self.with_name_lock(name, || {
            crate::portable_checkpoint::restore_from_path(&self.db, name, artifact)?;
            let start = (|| -> Result<VmHandle> {
                let started = control::start_vm(&self.db, name)?;
                let mut handle = started.handle;
                if started.freshly_started {
                    self.launch_image_workload(name, &mut handle)?;
                }
                Ok(handle)
            })();
            match start {
                Ok(handle) => {
                    handle.detach();
                    Ok(())
                }
                Err(error) => {
                    let _ = control::delete_vm(&self.db, name);
                    Err(error)
                }
            }
        })
    }

    /// Reclaim shim-managed sandbox VMs whose process is gone (node reboot or a
    /// shim crash left the record + disks behind). See
    /// [`control::reconcile_runtime_machines`]. Returns the count reclaimed.
    pub fn reconcile_runtime_machines(&self) -> Result<usize> {
        control::reconcile_runtime_machines(&self.db)
    }

    /// Start or reconnect to a persisted machine and cache its handle.
    pub fn start_machine(&self, name: &str) -> Result<()> {
        self.start_machine_with_interceptor(name, None)
    }

    /// Start with a trusted local egress interceptor binding for this boot.
    /// Callers must supply the binding again after a process restart.
    pub fn start_machine_with_interceptor(
        &self,
        name: &str,
        interceptor: Option<smolvm_protocol::InterceptEndpoint>,
    ) -> Result<()> {
        self.with_name_lock(name, || {
            if control::get_record(&self.db, name)?
                .paused_checkpoint
                .is_some()
            {
                return Err(Error::agent_conflict(
                    "start machine",
                    "machine is paused; use resume",
                ));
            }
            if let Some(handle) = self.cached_handle(name)? {
                let alive = lock_handle(&handle)?.is_process_alive();
                if alive {
                    return Ok(());
                }
                self.remove_cached_handle(name)?;
            }

            let started = control::start_vm_with_interceptor(&self.db, name, interceptor)?;
            let mut handle = started.handle;
            if started.freshly_started {
                if let Err(error) = self.launch_image_workload(name, &mut handle) {
                    let _ = handle.stop();
                    let _ = control::mark_stopped(&self.db, name);
                    return Err(error);
                }
            }
            self.insert_handle(name, handle)?;
            Ok(())
        })
    }

    /// Attach to an existing machine, starting it only when it is not already
    /// available. A frozen fork base is intentionally not agent-reachable: its
    /// vCPUs are paused while its retained checkpoint backs future clones.
    /// Treating that state as a stopped VM launches a second VMM over the same
    /// disks and replaces its control socket, destroying the fork source.
    pub fn connect_or_start_machine(&self, name: &str) -> Result<()> {
        self.connect_or_start_machine_with_interceptor(name, None)
    }

    /// Attach to a live machine or start it with a fresh interceptor binding.
    pub fn connect_or_start_machine_with_interceptor(
        &self,
        name: &str,
        interceptor: Option<smolvm_protocol::InterceptEndpoint>,
    ) -> Result<()> {
        self.with_name_lock(name, || {
            if control::get_record(&self.db, name)?
                .paused_checkpoint
                .is_some()
            {
                return Err(Error::agent_conflict(
                    "start machine",
                    "machine has saved execution; use resume",
                ));
            }
            if let Some(handle) = self.cached_handle(name)? {
                if lock_handle(&handle)?.is_process_alive() {
                    return Ok(());
                }
                self.remove_cached_handle(name)?;
            }

            let record = control::get_record(&self.db, name)?;
            // The DB remains `Running` while a retained live-RAM checkpoint is
            // paused; the shared state probe resolves its control-socket state
            // to `Frozen`. Looking only at the stored enum misses the normal
            // retained-snapshot case and starts a second VMM over the golden.
            if crate::agent::state_probe::resolve_state(name, &record)
                == crate::config::RecordState::Frozen
            {
                return Ok(());
            }

            if let Ok(handle) = control::connect_vm(&self.db, name) {
                self.insert_handle(name, handle)?;
                return Ok(());
            }

            let started = control::start_vm_with_interceptor(&self.db, name, interceptor)?;
            let mut handle = started.handle;
            if started.freshly_started {
                if let Err(error) = self.launch_image_workload(name, &mut handle) {
                    let _ = handle.stop();
                    let _ = control::mark_stopped(&self.db, name);
                    return Err(error);
                }
            }
            self.insert_handle(name, handle)?;
            Ok(())
        })
    }

    /// Start a persisted machine attached to a Kubernetes pod network namespace.
    /// The launcher bridges the guest virtio-net NIC to a tap inside `netns` so
    /// the pod carries its CNI-assigned IP (see [`control::start_vm_with_netns`]).
    /// Used by the containerd shim for pod sandboxes; requires the machine to use
    /// the virtio-net backend.
    pub fn start_machine_with_netns(&self, name: &str, netns: std::path::PathBuf) -> Result<()> {
        self.with_name_lock(name, || {
            if let Some(handle) = self.cached_handle(name)? {
                if lock_handle(&handle)?.is_process_alive() {
                    return Ok(());
                }
                self.remove_cached_handle(name)?;
            }
            let handle = control::start_vm_with_netns(&self.db, name, netns)?;
            self.insert_handle(name, handle)?;
            Ok(())
        })
    }

    /// Start (or reconnect to) a persisted machine as a FORKABLE fork base and
    /// cache its handle. Like [`start_machine`](Self::start_machine) but boots
    /// with memfd-backed guest RAM + a control socket so it can later be forked
    /// with [`fork_machine`](Self::fork_machine) — the basis for local RL rollout
    /// branching.
    pub fn start_forkable_machine(&self, name: &str) -> Result<()> {
        self.with_name_lock(name, || {
            if let Some(handle) = self.cached_handle(name)? {
                if lock_handle(&handle)?.is_process_alive() {
                    return Ok(());
                }
                self.remove_cached_handle(name)?;
            }

            let started = control::start_forkable_vm(&self.db, name)?;
            let mut handle = started.handle;
            if started.freshly_started {
                if let Err(error) = self.launch_image_workload(name, &mut handle) {
                    let _ = handle.stop();
                    let _ = control::mark_stopped(&self.db, name);
                    return Err(error);
                }
            }
            self.insert_handle(name, handle)?;
            Ok(())
        })
    }

    /// Fork a running, forkable `golden` into a new `clone` (copy-on-write guest
    /// RAM + disks, same host) and cache the clone's handle so it can be exec'd
    /// by name. `ports` are `(host, guest)` inbound forwards for the clone; empty
    /// remaps the golden's forwards to fresh host ports. Supported hosts resume
    /// the source after publishing a consistent fork generation.
    pub fn fork_machine(&self, golden: &str, clone: &str, ports: &[(u16, u16)]) -> Result<()> {
        self.with_name_locks(&[golden, clone], || {
            let handle = control::fork_vm(&self.db, golden, clone, ports)?;
            self.insert_handle(clone, handle)?;
            Ok(())
        })
    }

    /// Fork a machine and make the restored clone a new checkpoint source.
    /// This pays one eager guest-memory copy during clone boot; later forks of
    /// `clone` use the normal copy-on-write path.
    pub fn fork_checkpointable_machine(
        &self,
        source: &str,
        clone: &str,
        ports: &[(u16, u16)],
    ) -> Result<()> {
        self.with_name_locks(&[source, clone], || {
            let handle =
                control::fork_vm_with_options(&self.db, source, clone, ports, true, false, None)?;
            self.insert_handle(clone, handle)?;
            Ok(())
        })
    }

    /// Fork several clones from one retained snapshot and boot them with
    /// bounded parallelism. All names are locked together so overlapping SDK
    /// calls cannot race the golden freeze or claim the same clone name.
    pub fn fork_machines(
        &self,
        golden: &str,
        clones: &[String],
        ports: &[(u16, u16)],
        parallel: usize,
    ) -> Result<()> {
        let mut lock_names = Vec::with_capacity(clones.len() + 1);
        lock_names.push(golden);
        lock_names.extend(clones.iter().map(String::as_str));
        self.with_name_locks(&lock_names, || {
            let requests: Vec<_> = clones
                .iter()
                .map(|name| (name.clone(), ports.to_vec()))
                .collect();
            let mut started = control::fork_vm_batch(&self.db, golden, &requests, parallel)?;
            let mut registry = match self.registry.write() {
                Ok(registry) => registry,
                Err(error) => {
                    for (name, handle) in &mut started {
                        let _ = handle.stop();
                        let _ = control::delete_vm(&self.db, name);
                    }
                    return Err(Error::agent("runtime registry", error.to_string()));
                }
            };
            for (name, handle) in started {
                registry.insert(name, Arc::new(Mutex::new(handle)));
            }
            Ok(())
        })
    }

    /// Fork several machines for a detached CLI operation. The group is
    /// prepared transactionally from one generation and every successful clone
    /// outlives this process.
    pub fn fork_machines_detached(
        &self,
        golden: &str,
        clones: &[String],
        ports: &[(u16, u16)],
        parallel: usize,
    ) -> Result<()> {
        let mut lock_names = Vec::with_capacity(clones.len() + 1);
        lock_names.push(golden);
        lock_names.extend(clones.iter().map(String::as_str));
        self.with_name_locks(&lock_names, || {
            let requests: Vec<_> = clones
                .iter()
                .map(|name| (name.clone(), ports.to_vec()))
                .collect();
            for (_, handle) in control::fork_vm_batch(&self.db, golden, &requests, parallel)? {
                handle.detach();
            }
            Ok(())
        })
    }

    /// Fork a machine for a detached CLI operation. Unlike the SDK path, the
    /// clone intentionally outlives this process; all preparation, retained
    /// snapshot reuse, and fail-closed identity rejuvenation remain shared.
    pub fn fork_machine_detached(
        &self,
        golden: &str,
        clone: &str,
        ports: &[(u16, u16)],
        share_weights: bool,
    ) -> Result<()> {
        self.with_name_locks(&[golden, clone], || {
            let handle = control::fork_vm_with_options(
                &self.db,
                golden,
                clone,
                ports,
                false,
                share_weights,
                Some(false),
            )?;
            handle.detach();
            Ok(())
        })
    }

    /// Fork a checkpointable child for a detached CLI operation. The child
    /// outlives this process and can become the source of another fork.
    pub fn fork_checkpointable_machine_detached(
        &self,
        source: &str,
        clone: &str,
        ports: &[(u16, u16)],
    ) -> Result<()> {
        self.with_name_locks(&[source, clone], || {
            let handle = control::fork_vm_with_options(
                &self.db,
                source,
                clone,
                ports,
                true,
                false,
                Some(false),
            )?;
            handle.detach();
            Ok(())
        })
    }

    /// Connect to an already-running machine and cache its handle.
    pub fn connect_machine(&self, name: &str) -> Result<()> {
        self.with_name_lock(name, || {
            if let Some(handle) = self.cached_handle(name)? {
                if lock_handle(&handle)?.is_process_alive() {
                    return Ok(());
                }
                self.remove_cached_handle(name)?;
            }

            let handle = control::connect_vm(&self.db, name)?;
            self.insert_handle(name, handle)?;
            Ok(())
        })
    }

    /// Stop a machine and persist stopped state.
    pub fn stop_machine(&self, name: &str) -> Result<()> {
        self.with_name_lock(name, || {
            let _source_lock = crate::agent::fork::lock_fork_source(name)?;
            let record = control::get_record(&self.db, name)?;
            if record.paused_checkpoint.is_some() {
                return Err(Error::agent_conflict(
                    "stop machine",
                    "machine has saved execution; use resume or delete",
                ));
            }
            let dependents = self.db.dependent_clones(name)?;
            if !dependents.is_empty() {
                return Err(Error::agent(
                    "stop machine",
                    format!(
                        "machine '{name}' has dependent fork(s) ({}); delete descendants first",
                        dependents.join(", ")
                    ),
                ));
            }
            if let Some(handle) = self.remove_cached_handle(name)? {
                let mut handle = lock_handle(&handle)?;
                if !record.staged_mounts.is_empty() {
                    handle.sync_staged_mounts(&record)?;
                }
                handle.stop()?;
                control::mark_stopped(&self.db, name)?;
                return Ok(());
            }

            control::stop_vm(&self.db, name)
        })
    }

    /// Stop best-effort, remove from the registry and DB, and delete storage.
    pub fn delete_machine(&self, name: &str) -> Result<()> {
        self.with_name_lock(name, || {
            let _source_lock = crate::agent::fork::lock_fork_source(name)?;
            let Some(record) = self.db.get_vm(name)? else {
                self.remove_name_lock(name)?;
                return Ok(());
            };

            // A parent's RAM and disks back every direct child. Check before
            // stopping it: discovering the dependency after teardown would
            // leave live descendants dangling.
            let dependents = self.db.dependent_clones(name)?;
            if !dependents.is_empty() {
                return Err(Error::agent(
                    "delete machine",
                    format!(
                        "machine '{name}' has dependent fork(s) ({}); delete descendants first",
                        dependents.join(", ")
                    ),
                ));
            }

            let state = crate::agent::state_probe::resolve_state(name, &record);
            if matches!(
                state,
                crate::config::RecordState::Frozen | crate::config::RecordState::Unreachable
            ) {
                // Paused vCPUs cannot acknowledge the normal guest shutdown.
                // Reap the verified VMM directly instead of waiting for a
                // response that cannot arrive.
                self.remove_cached_handle(name)?;
                crate::agent::state_probe::recover_unreachable_machine_in_db(&record, &self.db)?;
            } else if matches!(
                state,
                crate::config::RecordState::Stopped
                    | crate::config::RecordState::Created
                    | crate::config::RecordState::Paused
            ) {
                // A graceful stop already synchronized staged mounts. Do not
                // reconnect to the now-absent agent and fail a subsequent delete.
                self.remove_cached_handle(name)?;
            } else if let Some(handle) = self.remove_cached_handle(name)? {
                let mut handle = lock_handle(&handle)?;
                if !record.staged_mounts.is_empty() {
                    handle.sync_staged_mounts(&record)?;
                }
                handle.stop()?;
            } else {
                control::stop_vm(&self.db, name)?;
            }

            // Idempotent: deleting an already-deleted machine is a no-op success
            // (the desired end state — gone — already holds). Lets SDK callers
            // call delete() more than once without an error.
            match control::delete_vm_locked(&self.db, name) {
                Ok(()) | Err(crate::Error::VmNotFound { .. }) => {}
                Err(e) => return Err(e),
            }
            self.remove_name_lock(name)?;
            Ok(())
        })
    }

    /// Copy guest-local staged mounts back to their host sources without
    /// stopping the machine.
    pub fn sync_machine(&self, name: &str) -> Result<()> {
        self.with_name_lock(name, || {
            let _source_lock = crate::agent::fork::lock_fork_source(name)?;
            let record = control::get_record(&self.db, name)?;
            if record.staged_mounts.is_empty() {
                return Ok(());
            }
            let handle = self.started_handle(name)?;
            let result = lock_handle(&handle)?.sync_staged_mounts(&record);
            result
        })
    }

    /// Execute a command directly in the VM.
    pub fn exec(
        &self,
        name: &str,
        command: Vec<String>,
        env: Vec<(String, String)>,
        workdir: Option<String>,
        timeout: Option<Duration>,
    ) -> Result<(i32, Vec<u8>, Vec<u8>)> {
        let options = ExecOptions {
            env,
            workdir,
            timeout,
            user: None,
        };
        self.exec_with_options(name, command, options)
    }

    /// Execute a command and return `(exit_code, stdout, stderr)`.
    ///
    /// The command runs over its own agent connection, so it never holds the
    /// machine for its duration: other commands, file transfers and state
    /// queries on the same machine proceed while it runs.
    pub fn exec_with_options(
        &self,
        name: &str,
        command: Vec<String>,
        options: ExecOptions,
    ) -> Result<(i32, Vec<u8>, Vec<u8>)> {
        let (image, overlay_owner) = self.image_and_overlay_owner(name)?;
        let config = self.command_run_config(name, image, overlay_owner, &command, &options)?;
        let mut client = self.command_client(name)?;
        match config {
            Some(config) => client.run_non_interactive(config),
            None => client.vm_exec(command, options.env, options.workdir, options.timeout, None),
        }
    }

    /// The [`RunConfig`] for a command on an image machine, or `None` for a
    /// bare VM (which rejects a per-command user it cannot honor).
    ///
    /// An image machine runs commands inside its persistent container overlay,
    /// exactly as the CLI and the cloud transport do. Without this a command
    /// lands in the bare VM's own rootfs, so the caller silently gets a
    /// different filesystem than the image they asked for.
    fn command_run_config(
        &self,
        name: &str,
        image: Option<String>,
        overlay_owner: String,
        command: &[String],
        options: &ExecOptions,
    ) -> Result<Option<RunConfig>> {
        let Some(image) = image else {
            if options.user.is_some() {
                return Err(Error::config(
                    "exec user",
                    "running a command as a specific user needs an image machine; \
                     a bare VM runs every command as root",
                ));
            }
            return Ok(None);
        };
        Ok(Some(
            RunConfig::new(image, command.to_vec())
                .with_env(options.env.clone())
                .with_workdir(options.workdir.clone())
                .with_timeout(options.timeout)
                .with_user(options.user.clone())
                .with_mounts(self.mount_bindings_for(name)?)
                .with_s3_volumes(self.s3_volumes_for(name)?)
                .with_persistent_overlay(Some(overlay_owner)),
        ))
    }

    /// A dedicated agent connection for one command.
    ///
    /// The machine's handle lock is held only to confirm it is started and to
    /// read where its agent listens — never for the command itself. Commands
    /// used to run over the handle's single cached connection with the lock
    /// held throughout, so one long command (a dev server, a streamed build)
    /// stalled every other call on the machine until it exited. The guest
    /// agent serves each connection on its own thread.
    fn command_client(&self, name: &str) -> Result<AgentClient> {
        let handle = self.started_handle(name)?;
        let socket = lock_handle(&handle)?.agent_socket();
        AgentClient::connect_with_retry(&socket)
    }

    /// Pull an OCI image and run a command inside it.
    pub fn run(
        &self,
        name: &str,
        image: &str,
        command: Vec<String>,
        env: Vec<(String, String)>,
        workdir: Option<String>,
        timeout: Option<Duration>,
    ) -> Result<(i32, Vec<u8>, Vec<u8>)> {
        let (_, overlay_owner) = self.image_and_overlay_owner(name)?;
        let mount_bindings = self.mount_bindings_for(name)?;
        let s3_volumes = self.s3_volumes_for(name)?;
        let handle = self.started_handle(name)?;
        let mut handle = lock_handle(&handle)?;
        if mount_bindings.is_empty() && s3_volumes.is_empty() {
            return handle.run(image, command, env, workdir, timeout);
        }
        handle.pull_image(image)?;
        handle.run_config(
            RunConfig::new(image, command)
                .with_env(env)
                .with_workdir(workdir)
                .with_timeout(timeout)
                .with_mounts(mount_bindings)
                .with_s3_volumes(s3_volumes)
                .with_persistent_overlay(Some(overlay_owner)),
        )
    }

    /// Pull an OCI image into the machine's storage.
    pub fn pull_image(&self, name: &str, image: &str) -> Result<ImageInfo> {
        let handle = self.started_handle(name)?;
        let mut handle = lock_handle(&handle)?;
        handle.pull_image(image)
    }

    /// Every machine in this host's shared DB, in name order. The DB is shared
    /// with the CLI and every other embedder, so machines other processes own
    /// are listed too — that is the point for a process reclaiming its own
    /// after a restart, which tells them apart by `labels`. Resolve a live
    /// state with [`state`](Self::state); the record's own is what was last
    /// persisted.
    pub fn list_machines(&self) -> Result<Vec<crate::config::VmRecord>> {
        Ok(self
            .db
            .list_vms()?
            .into_iter()
            .map(|(_, record)| record)
            .collect())
    }

    /// List cached OCI images in the machine's storage.
    pub fn list_images(&self, name: &str) -> Result<Vec<ImageInfo>> {
        let handle = self.started_handle(name)?;
        let mut handle = lock_handle(&handle)?;
        handle.list_images()
    }

    /// Write a file into the machine.
    pub fn write_file(
        &self,
        name: &str,
        path: &str,
        data: Vec<u8>,
        mode: Option<u32>,
    ) -> Result<()> {
        let (image, overlay_owner) = self.image_and_overlay_owner(name)?;
        let mount_bindings = self.mount_bindings_for(name)?;
        let handle = self.started_handle(name)?;
        let mut handle = lock_handle(&handle)?;
        Self::activate_image_overlay(&mut handle, image, overlay_owner, mount_bindings)?;
        handle.write_file(path, &data, mode)
    }

    /// Read a file from the machine.
    pub fn read_file(&self, name: &str, path: &str) -> Result<Vec<u8>> {
        let (image, overlay_owner) = self.image_and_overlay_owner(name)?;
        let mount_bindings = self.mount_bindings_for(name)?;
        let handle = self.started_handle(name)?;
        let mut handle = lock_handle(&handle)?;
        Self::activate_image_overlay(&mut handle, image, overlay_owner, mount_bindings)?;
        handle.read_file(path)
    }

    /// Make an image machine's persistent container rootfs the active target
    /// for the file RPCs that follow. Preparing the overlay alone only mounts
    /// it; a no-op container run also switches the agent's active file root.
    fn activate_image_overlay(
        handle: &mut VmHandle,
        image: Option<String>,
        overlay_owner: String,
        mount_bindings: Vec<(String, String, bool)>,
    ) -> Result<()> {
        let Some(image) = image else {
            return Ok(());
        };
        let (code, _, stderr) = handle.run_config(
            RunConfig::new(image, vec!["/bin/true".to_string()])
                .with_mounts(mount_bindings)
                .with_persistent_overlay(Some(overlay_owner)),
        )?;
        if code == 0 {
            Ok(())
        } else {
            Err(Error::agent(
                "activate image overlay",
                format!(
                    "container probe exited {code}: {}",
                    String::from_utf8_lossy(&stderr).trim()
                ),
            ))
        }
    }

    /// Return the host port currently forwarding to `guest_port`.
    ///
    /// Forks with unpinned ports receive fresh host ports, so SDK callers must
    /// read the clone's persisted mapping instead of assuming the golden's.
    pub fn host_port(&self, name: &str, guest_port: u16) -> Result<Option<u16>> {
        Ok(control::get_record(&self.db, name)?
            .ports
            .into_iter()
            .find_map(|(host, guest)| (guest == guest_port).then_some(host)))
    }

    /// Return all published guest ports for readiness checks.
    pub fn guest_ports(&self, name: &str) -> Result<Vec<u16>> {
        Ok(control::get_record(&self.db, name)?
            .ports
            .into_iter()
            .map(|(_, guest)| guest)
            .collect())
    }

    fn launch_image_workload(&self, name: &str, handle: &mut VmHandle) -> Result<()> {
        let record = control::get_record(&self.db, name)?;
        handle.launch_image_workload(name, &record)
    }

    /// The machine's remote volumes, resolved against its own recorded env.
    ///
    /// An exec is often what establishes the workload container — the machine's
    /// command exited, or the image's own default was short-lived — and that
    /// container is where the mount lives. Carrying the volumes on every exec
    /// means the bucket is present in whichever container ends up serving the
    /// session, instead of only when a long-running workload happens to survive.
    fn s3_volumes_for(&self, name: &str) -> Result<Vec<smolvm_protocol::S3Volume>> {
        let record = control::get_record(&self.db, name)?;
        Ok(crate::remote_volume::to_s3_volumes(
            &record.remote_volumes,
            &record.env,
        ))
    }

    fn mount_bindings_for(&self, name: &str) -> Result<Vec<(String, String, bool)>> {
        let record = control::get_record(&self.db, name)?;
        Ok(crate::workload::record_mounts_to_bindings(&record))
    }

    /// The machine's image, if it is an image (container-workload) machine.
    /// Streamed execs on such a machine must run inside its persistent container
    /// overlay so their writes survive — matching non-streaming exec.
    fn image_and_overlay_owner(&self, name: &str) -> Result<(Option<String>, String)> {
        let record = control::get_record(&self.db, name)?;
        let overlay_owner = crate::workload::persistent_overlay_owner_with_lineage(
            name,
            record.golden.as_deref(),
            record.fork_overlay_owner.as_deref(),
        );
        Ok((record.image, overlay_owner))
    }

    /// Execute a command and collect streaming output events.
    pub fn exec_streaming(
        &self,
        name: &str,
        command: Vec<String>,
        env: Vec<(String, String)>,
        workdir: Option<String>,
        timeout: Option<Duration>,
    ) -> Result<Vec<ExecEvent>> {
        let mut events = Vec::new();
        self.exec_streaming_with(name, command, env, workdir, timeout, |e| events.push(e))?;
        Ok(events)
    }

    /// Execute a command, delivering streaming output events LIVE via the
    /// callback as they arrive (no buffering). The live counterpart of
    /// `exec_streaming`; SDKs bridge the callback to a native iterator.
    pub fn exec_streaming_with<F: FnMut(ExecEvent)>(
        &self,
        name: &str,
        command: Vec<String>,
        env: Vec<(String, String)>,
        workdir: Option<String>,
        timeout: Option<Duration>,
        on_event: F,
    ) -> Result<()> {
        let options = ExecOptions {
            env,
            workdir,
            timeout,
            user: None,
        };
        self.exec_streaming_with_options(name, command, options, &ExecCancel::new(), on_event)
    }

    /// Execute a command, delivering output events live via the callback, over
    /// its own agent connection (see [`Self::exec_with_options`]).
    ///
    /// `cancel` stops the command from another thread: the connection closes,
    /// the agent kills the command, and this returns `Ok(())` without further
    /// events. An image machine streams inside its persistent container overlay
    /// so streamed installs and writes persist like non-streaming ones.
    pub fn exec_streaming_with_options<F: FnMut(ExecEvent)>(
        &self,
        name: &str,
        command: Vec<String>,
        options: ExecOptions,
        cancel: &ExecCancel,
        on_event: F,
    ) -> Result<()> {
        let (image, overlay_owner) = self.image_and_overlay_owner(name)?;
        let config = self.command_run_config(name, image, overlay_owner, &command, &options)?;
        if cancel.is_cancelled() {
            return Ok(());
        }
        let mut client = self.command_client(name)?;
        let connection = client
            .clone_stream()
            .map_err(|e| Error::agent("exec connection", e.to_string()))?;
        if !cancel.attach(connection) {
            return Ok(());
        }
        // Once cancelled, the caller has no use for the tail of the stream —
        // in particular not the "connection closed" error the teardown itself
        // produces — so stop delivering events.
        let mut on_event = on_event;
        let on_event = |event: ExecEvent| {
            if !cancel.is_cancelled() {
                on_event(event);
            }
        };
        let result = match config {
            Some(config) => client.run_streaming_with(config, on_event),
            None => client.vm_exec_streaming_with(
                command,
                options.env,
                options.workdir,
                options.timeout,
                on_event,
            ),
        };
        cancel.detach();
        match result {
            // The caller asked for this: the closed connection surfaces as a
            // read error, which is not a failure of the command.
            Err(_) if cancel.is_cancelled() => Ok(()),
            other => other,
        }
    }

    /// Get the child PID if the machine is running.
    pub fn pid(&self, name: &str) -> Option<i32> {
        if let Ok(Some(handle)) = self.cached_handle(name) {
            if let Ok(handle) = handle.lock() {
                if let Some(pid) = handle.child_pid() {
                    return Some(pid);
                }
            }
        }

        self.db
            .get_vm(name)
            .ok()
            .flatten()
            .and_then(|record| record.pid)
    }

    /// Return whether the machine process is currently running.
    pub fn is_running(&self, name: &str) -> bool {
        if self
            .db
            .get_vm(name)
            .ok()
            .flatten()
            .is_some_and(|r| r.paused_checkpoint.is_some())
        {
            return false;
        }
        if let Ok(Some(handle)) = self.cached_handle(name) {
            if let Ok(handle) = handle.lock() {
                return handle.is_process_alive();
            }
        }

        self.db
            .get_vm(name)
            .ok()
            .flatten()
            .is_some_and(|record| record.actual_state() == RecordState::Running)
    }

    /// Get the current machine state as a string.
    pub fn state(&self, name: &str) -> String {
        if let Ok(Some(record)) = self.db.get_vm(name) {
            if record.paused_checkpoint.is_some() {
                return record.state.to_string();
            }
        }
        if let Ok(Some(handle)) = self.cached_handle(name) {
            if let Ok(handle) = handle.lock() {
                return handle.state();
            }
        }

        match self.db.get_vm(name).ok().flatten() {
            Some(record) if record.actual_state() == RecordState::Running => "running".into(),
            Some(record) if record.actual_state() == RecordState::Failed => "failed".into(),
            _ => "stopped".into(),
        }
    }

    fn started_handle(&self, name: &str) -> Result<SharedHandle> {
        if control::get_record(&self.db, name)?
            .paused_checkpoint
            .is_some()
        {
            return Err(Error::agent_conflict(
                "access machine",
                "machine is pausing or paused; use resume",
            ));
        }
        self.cached_handle(name)?
            .ok_or_else(|| Error::InvalidState {
                expected: "started".into(),
                actual: "not started".into(),
            })
    }

    fn cached_handle(&self, name: &str) -> Result<Option<SharedHandle>> {
        let registry = self
            .registry
            .read()
            .map_err(|e| Error::agent("runtime registry", e.to_string()))?;
        Ok(registry.get(name).cloned())
    }

    fn insert_handle(&self, name: &str, handle: VmHandle) -> Result<()> {
        let mut registry = self
            .registry
            .write()
            .map_err(|e| Error::agent("runtime registry", e.to_string()))?;
        registry.insert(name.to_string(), Arc::new(Mutex::new(handle)));
        Ok(())
    }

    fn remove_cached_handle(&self, name: &str) -> Result<Option<SharedHandle>> {
        let mut registry = self
            .registry
            .write()
            .map_err(|e| Error::agent("runtime registry", e.to_string()))?;
        Ok(registry.remove(name))
    }

    fn with_name_lock<T, F>(&self, name: &str, op: F) -> Result<T>
    where
        F: FnOnce() -> Result<T>,
    {
        self.with_name_locks(&[name], op)
    }

    fn with_name_locks<T, F>(&self, names: &[&str], op: F) -> Result<T>
    where
        F: FnOnce() -> Result<T>,
    {
        let mut names = names.to_vec();
        names.sort_unstable();
        names.dedup();
        let locks = names
            .into_iter()
            .map(|name| self.lock_for_name(name))
            .collect::<Result<Vec<_>>>()?;
        let _guards = locks.iter().map(lock_name).collect::<Result<Vec<_>>>()?;
        op()
    }

    fn lock_for_name(&self, name: &str) -> Result<Arc<Mutex<()>>> {
        if let Some(lock) = self
            .name_locks
            .read()
            .map_err(|e| Error::agent("runtime name locks", e.to_string()))?
            .get(name)
            .cloned()
        {
            return Ok(lock);
        }

        let mut locks = self
            .name_locks
            .write()
            .map_err(|e| Error::agent("runtime name locks", e.to_string()))?;
        Ok(locks
            .entry(name.to_string())
            .or_insert_with(|| Arc::new(Mutex::new(())))
            .clone())
    }

    fn remove_name_lock(&self, name: &str) -> Result<()> {
        let mut locks = self
            .name_locks
            .write()
            .map_err(|e| Error::agent("runtime name locks", e.to_string()))?;
        locks.remove(name);
        Ok(())
    }
}

fn lock_name(lock: &Arc<Mutex<()>>) -> Result<MutexGuard<'_, ()>> {
    lock.lock()
        .map_err(|e| Error::agent("runtime name lock", e.to_string()))
}

fn lock_handle(handle: &SharedHandle) -> Result<MutexGuard<'_, VmHandle>> {
    handle
        .lock()
        .map_err(|e| Error::agent("runtime handle", e.to_string()))
}

/// Return the process-local embedded runtime singleton.
pub fn runtime() -> Result<Arc<EmbeddedRuntime>> {
    static RUNTIME: OnceLock<Arc<EmbeddedRuntime>> = OnceLock::new();

    if let Some(runtime) = RUNTIME.get() {
        return Ok(runtime.clone());
    }

    let runtime = Arc::new(EmbeddedRuntime::new()?);
    match RUNTIME.set(runtime.clone()) {
        Ok(()) => Ok(runtime),
        Err(_) => Ok(RUNTIME
            .get()
            .expect("runtime initialized by competing thread")
            .clone()),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn embedded_resize_validates_targets_before_machine_access() {
        let runtime = EmbeddedRuntime::with_db(test_db());
        for spec in [
            ResizeSpec::default(),
            ResizeSpec {
                cpus: Some(0),
                ..Default::default()
            },
            ResizeSpec {
                memory_mib: Some(0),
                ..Default::default()
            },
            ResizeSpec {
                storage_gib: Some(0),
                ..Default::default()
            },
            ResizeSpec {
                overlay_gib: Some(0),
                ..Default::default()
            },
            ResizeSpec {
                cpus: Some(4),
                memory_mib: Some(2048),
                ..Default::default()
            },
            ResizeSpec {
                cpus: Some(4),
                storage_gib: Some(8),
                ..Default::default()
            },
        ] {
            assert!(matches!(
                runtime.resize_machine("absent", spec),
                Err(Error::Config { .. })
            ));
        }
        assert!(ResizeSpec {
            storage_gib: Some(8),
            overlay_gib: Some(4),
            ..Default::default()
        }
        .validate()
        .is_ok());
        assert!(runtime.db.pending_resize_names().unwrap().is_empty());
        assert!(runtime.name_locks.read().unwrap().is_empty());
    }

    fn test_db() -> SmolvmDb {
        static NEXT_DB: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);
        let unique = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_nanos();
        let sequence = NEXT_DB.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
        let path = std::env::temp_dir().join(format!(
            "smolvm-embedded-runtime-{}-{unique}-{sequence}.db",
            std::process::id(),
        ));
        SmolvmDb::open_at(&path).unwrap()
    }

    fn test_spec(name: &str, persistent: bool) -> MachineSpec {
        MachineSpec {
            name: name.to_string(),
            mounts: Vec::new(),
            ports: Vec::new(),
            resources: crate::agent::VmResources::default(),
            image: None,
            persistent,
            // Spread the rest so a new spec field does not break the fixtures.
            ..MachineSpec::default()
        }
    }

    #[test]
    fn saved_execution_cannot_be_started_or_accessed_as_a_fresh_machine() {
        let db = test_db();
        let runtime = EmbeddedRuntime::with_db(db.clone());
        runtime.create_machine(test_spec("saved", true)).unwrap();
        db.update_vm_durable("saved", |r| {
            r.state = RecordState::Paused;
            r.paused_checkpoint = Some("missing.smolcheckpoint".into());
        })
        .unwrap();
        assert_eq!(runtime.state("saved"), "paused");
        assert!(!runtime.is_running("saved"));
        assert!(runtime.start_machine("saved").is_err());
        assert!(runtime.connect_or_start_machine("saved").is_err());
        assert!(runtime.started_handle("saved").is_err());
        assert!(runtime.pause_machine("saved").is_err());
        assert!(db
            .get_vm("saved")
            .unwrap()
            .unwrap()
            .paused_checkpoint
            .is_some());
    }

    #[test]
    fn remove_name_lock_removes_entry() {
        let runtime = EmbeddedRuntime::with_db(test_db());
        runtime.lock_for_name("runtime-remove-lock").unwrap();

        runtime.remove_name_lock("runtime-remove-lock").unwrap();

        assert!(runtime
            .name_locks
            .read()
            .expect("name locks should not be poisoned")
            .is_empty());
    }

    #[test]
    fn remove_name_lock_ignores_missing_entry() {
        let runtime = EmbeddedRuntime::with_db(test_db());
        runtime.remove_name_lock("runtime-missing-lock").unwrap();

        assert!(runtime
            .name_locks
            .read()
            .expect("name locks should not be poisoned")
            .is_empty());
    }

    #[test]
    fn runtime_rejects_duplicate_create() {
        let runtime = EmbeddedRuntime::with_db(test_db());
        runtime
            .create_machine(test_spec("runtime-duplicate", false))
            .unwrap();

        let err = runtime
            .create_machine(test_spec("runtime-duplicate", false))
            .unwrap_err();
        assert!(matches!(
            err,
            Error::Agent {
                kind: crate::error::AgentErrorKind::Conflict,
                ..
            }
        ));
    }

    #[test]
    fn runtime_state_defaults_to_stopped_for_created_record() {
        let runtime = EmbeddedRuntime::with_db(test_db());
        runtime
            .create_machine(test_spec("runtime-state", true))
            .unwrap();

        assert_eq!(runtime.state("runtime-state"), "stopped");
        assert!(!runtime.is_running("runtime-state"));
        assert_eq!(runtime.pid("runtime-state"), None);
    }

    #[test]
    fn list_machines_returns_every_record_by_name_with_its_labels() {
        let runtime = EmbeddedRuntime::with_db(test_db());
        let mut mine = test_spec("list-b", true);
        mine.labels.insert("owner".into(), "hostd".into());
        mine.detached = true;
        runtime.create_machine(mine).unwrap();
        runtime.create_machine(test_spec("list-a", false)).unwrap();

        let listed = runtime.list_machines().unwrap();
        assert_eq!(
            listed.iter().map(|r| r.name.as_str()).collect::<Vec<_>>(),
            ["list-a", "list-b"]
        );
        let (a, b) = (&listed[0], &listed[1]);
        assert!(a.ephemeral && a.labels.is_empty() && !a.detached);
        assert!(!b.ephemeral && b.detached);
        assert_eq!(b.labels.get("owner").map(String::as_str), Some("hostd"));
        assert_eq!(runtime.state("list-b"), "stopped");
    }

    #[test]
    fn reconnect_never_restarts_a_frozen_fork_base() {
        let db = test_db();
        let mut record = test_spec("frozen-checkpoint", true).to_record();
        record.state = crate::config::RecordState::Frozen;
        db.insert_vm_if_not_exists("frozen-checkpoint", &record)
            .unwrap();
        let runtime = EmbeddedRuntime::with_db(db.clone());

        runtime
            .connect_or_start_machine("frozen-checkpoint")
            .unwrap();

        assert_eq!(
            db.get_vm("frozen-checkpoint").unwrap().unwrap().state,
            crate::config::RecordState::Frozen
        );
        assert!(runtime.registry.read().unwrap().is_empty());
    }

    #[test]
    fn image_overlay_owner_uses_machine_name_for_regular_machines() {
        let runtime = EmbeddedRuntime::with_db(test_db());
        let mut spec = test_spec("runtime-image", true);
        spec.image = Some("example/image:latest".to_string());
        runtime.create_machine(spec).unwrap();

        assert_eq!(
            runtime.image_and_overlay_owner("runtime-image").unwrap(),
            (
                Some("example/image:latest".to_string()),
                "runtime-image".to_string()
            )
        );
    }

    #[test]
    fn image_overlay_owner_uses_golden_name_for_clones() {
        let runtime = EmbeddedRuntime::with_db(test_db());
        let mut record = test_spec("runtime-clone", true).to_record();
        record.image = Some("example/image:latest".to_string());
        record.golden = Some("runtime-golden".to_string());
        runtime.db.insert_vm("runtime-clone", &record).unwrap();

        assert_eq!(
            runtime.image_and_overlay_owner("runtime-clone").unwrap(),
            (
                Some("example/image:latest".to_string()),
                "runtime-golden".to_string()
            )
        );
    }

    #[test]
    fn image_overlay_owner_fails_closed_for_missing_records() {
        let runtime = EmbeddedRuntime::with_db(test_db());
        assert!(matches!(
            runtime.image_and_overlay_owner("missing"),
            Err(crate::Error::VmNotFound { .. })
        ));
    }

    #[test]
    fn host_port_reads_the_persisted_mapping() {
        let runtime = EmbeddedRuntime::with_db(test_db());
        let mut spec = test_spec("runtime-ports", true);
        spec.ports = vec![crate::data::network::PortMapping::new(49152, 3000)];
        runtime.create_machine(spec).unwrap();

        assert_eq!(
            runtime.host_port("runtime-ports", 3000).unwrap(),
            Some(49152)
        );
        assert_eq!(runtime.host_port("runtime-ports", 9222).unwrap(), None);
    }

    #[test]
    fn delete_machine_removes_name_lock_entry() {
        let runtime = EmbeddedRuntime::with_db(test_db());
        runtime
            .create_machine(test_spec("runtime-delete-lock", true))
            .unwrap();

        assert!(runtime
            .name_locks
            .read()
            .expect("name locks should not be poisoned")
            .contains_key("runtime-delete-lock"));

        runtime.delete_machine("runtime-delete-lock").unwrap();

        assert!(!runtime
            .name_locks
            .read()
            .expect("name locks should not be poisoned")
            .contains_key("runtime-delete-lock"));
    }

    #[test]
    fn delete_already_stopped_staged_machine_does_not_reconnect() {
        let db = test_db();
        let runtime = EmbeddedRuntime::with_db(db.clone());
        let mut record = test_spec("delete-stopped-staged", true).to_record();
        record.state = crate::config::RecordState::Stopped;
        record.staged_mounts = vec![(0, "/host/work".into(), "/work".into())];
        db.insert_vm("delete-stopped-staged", &record).unwrap();

        runtime.delete_machine("delete-stopped-staged").unwrap();
        assert!(db.get_vm("delete-stopped-staged").unwrap().is_none());
    }

    #[test]
    fn delete_machine_refuses_a_live_fork_parent_before_teardown() {
        let db = test_db();
        let runtime = EmbeddedRuntime::with_db(db.clone());
        runtime
            .create_machine(test_spec("delete-parent", true))
            .unwrap();
        let mut child = test_spec("delete-child", true).to_record();
        child.golden = Some("delete-parent".to_string());
        db.insert_vm("delete-child", &child).unwrap();

        let error = runtime.delete_machine("delete-parent").unwrap_err();
        assert!(error.to_string().contains("dependent fork"));
        assert!(db.get_vm("delete-parent").unwrap().is_some());
        assert!(db.get_vm("delete-child").unwrap().is_some());
    }

    #[test]
    fn stop_machine_refuses_a_live_fork_parent_before_teardown() {
        let db = test_db();
        let runtime = EmbeddedRuntime::with_db(db.clone());
        runtime
            .create_machine(test_spec("stop-parent", true))
            .unwrap();
        let mut child = test_spec("stop-child", true).to_record();
        child.golden = Some("stop-parent".to_string());
        db.insert_vm("stop-child", &child).unwrap();

        let error = runtime.stop_machine("stop-parent").unwrap_err();
        assert!(error.to_string().contains("dependent fork"));
        assert!(db.get_vm("stop-parent").unwrap().is_some());
        assert!(db.get_vm("stop-child").unwrap().is_some());
    }

    #[test]
    fn delete_machine_reaps_a_frozen_checkpoint_without_guest_shutdown() {
        let db = test_db();
        let runtime = EmbeddedRuntime::with_db(db.clone());
        let mut record = test_spec("delete-frozen", true).to_record();
        record.state = crate::config::RecordState::Frozen;
        db.insert_vm("delete-frozen", &record).unwrap();

        runtime.delete_machine("delete-frozen").unwrap();
        assert!(db.get_vm("delete-frozen").unwrap().is_none());
    }
}
