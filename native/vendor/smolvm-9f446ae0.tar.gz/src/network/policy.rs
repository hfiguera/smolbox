//! Network policy helpers.

use crate::data::network;
use crate::vm::config::NetworkPolicy;
use std::net::IpAddr;

/// Get the DNS server for a network policy.
pub fn get_dns_server(policy: &NetworkPolicy) -> Option<IpAddr> {
    match policy {
        NetworkPolicy::None => None,
        NetworkPolicy::Egress { dns, .. } => Some(dns.unwrap_or_else(network::default_dns_addr)),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_get_dns_server() {
        assert!(get_dns_server(&NetworkPolicy::None).is_none());

        let dns = get_dns_server(&NetworkPolicy::Egress {
            dns: None,
            allowed_cidrs: None,
        })
        .unwrap();
        assert_eq!(dns, crate::data::network::default_dns_addr());

        let custom: IpAddr = "8.8.8.8".parse().unwrap();
        let dns = get_dns_server(&NetworkPolicy::Egress {
            dns: Some(custom),
            allowed_cidrs: None,
        })
        .unwrap();
        assert_eq!(dns.to_string(), "8.8.8.8");
    }
}
